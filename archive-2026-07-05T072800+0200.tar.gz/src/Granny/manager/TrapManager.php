<?php

namespace Granny\manager;

use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\scheduler\PluginTask;
use Granny\Main;

class TrapManager {

    private $plugin;
    private $trappedPlayers = [];
    private $escapeProgress = [];
    private $trapPositions = [];
    private $freezeTaskId = null;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function isTrapped($playerName) {
        return isset($this->trappedPlayers[$playerName]) && $this->trappedPlayers[$playerName];
    }

    public function setTrapped($playerName, $trapped) {
        $this->trappedPlayers[$playerName] = $trapped;
        if ($trapped) {
            $this->escapeProgress[$playerName] = 0;
        } else {
            unset($this->escapeProgress[$playerName]);
            unset($this->trapPositions[$playerName]);
        }

        if ($trapped && $this->freezeTaskId === null) {
            $this->startFreezeTask();
        }

        if (!$trapped) {
            $hasTrapped = false;
            foreach ($this->trappedPlayers as $v) {
                if ($v) { $hasTrapped = true; break; }
            }
            if (!$hasTrapped) {
                $this->stopFreezeTask();
            }
        }
    }

    public function getEscapeProgress($playerName) {
        return isset($this->escapeProgress[$playerName]) ? $this->escapeProgress[$playerName] : 0;
    }

    public function addEscapeProgress($playerName, $amount = 10) {
        if (!$this->isTrapped($playerName)) {
            return 0;
        }
        $this->escapeProgress[$playerName] = min(100, $this->getEscapeProgress($playerName) + $amount);
        return $this->escapeProgress[$playerName];
    }

    public function trapPlayer(Player $player) {
        $name = $player->getName();
        $this->setTrapped($name, true);
        $this->trapPositions[$name] = new Vector3($player->x, $player->y, $player->z);
        $player->sendPopup("§c§lTRAPPED! §r§cTAP THE GROUND REPEATEDLY!");
        $player->setXpLevel(0);
        $player->setXpProgress(0.0);
    }

    public function handleEscapeTap(Player $player) {
        $name = $player->getName();
        if (!$this->isTrapped($name)) {
            return;
        }

        $progress = $this->addEscapeProgress($name);
        $xpProgress = $progress / 100;
        $player->setXpProgress($xpProgress);
        $player->setXpLevel(0);

        if ($progress >= 100) {
            $this->setTrapped($name, false);
            $player->sendPopup("§a§lEscaped!§r");
            $player->setXpLevel(0);
            $player->setXpProgress(0.0);
        }
    }

    public function tickFreeze() {
        foreach ($this->trappedPlayers as $name => $trapped) {
            if (!$trapped) continue;
            $player = $this->plugin->getServer()->getPlayerExact($name);
            if ($player === null || !$player->isOnline()) {
                $this->setTrapped($name, false);
                continue;
            }
            if (isset($this->trapPositions[$name])) {
                $pos = $this->trapPositions[$name];
                $player->teleport($pos);
            }
        }
    }

    public function resetAll() {
        foreach ($this->trappedPlayers as $name => $v) {
            if ($v) {
                $player = $this->plugin->getServer()->getPlayerExact($name);
                if ($player !== null) {
                    $player->setXpLevel(0);
                    $player->setXpProgress(0.0);
                }
            }
        }
        $this->trappedPlayers = [];
        $this->escapeProgress = [];
        $this->trapPositions = [];
        $this->stopFreezeTask();
    }

    private function startFreezeTask() {
        $task = new TrapFreezeTask($this->plugin, $this);
        $handler = $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($task, 2);
        $this->freezeTaskId = $handler->getTaskId();
    }

    private function stopFreezeTask() {
        if ($this->freezeTaskId !== null) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->freezeTaskId);
            $this->freezeTaskId = null;
        }
    }
}

class TrapFreezeTask extends PluginTask {

    private $trapManager;

    public function __construct(Main $plugin, TrapManager $trapManager) {
        parent::__construct($plugin);
        $this->trapManager = $trapManager;
    }

    public function onRun($currentTick) {
        $this->trapManager->tickFreeze();
    }
}
