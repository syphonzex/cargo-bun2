<?php

namespace Granny\manager;

use pocketmine\math\Vector3;
use pocketmine\level\Level;
use pocketmine\network\protocol\LevelEventPacket;
use pocketmine\Player;
use pocketmine\scheduler\PluginTask;
use Granny\Main;
use Granny\pathfinding\Node;
use Granny\pathfinding\NodeGraph;
use Granny\pathfinding\Pathfinder;

class NodeManager {

    private $plugin;
    private $graph;
    private $pathfinder;
    private $debugTaskId = null;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->graph = new NodeGraph();
        $this->pathfinder = new Pathfinder($this->graph);
        $this->loadNodes();
    }

    public function getGraph() {
        return $this->graph;
    }

    public function getPathfinder() {
        return $this->pathfinder;
    }

    public function addNode($name, Vector3 $pos, $patrol = false) {
        if ($this->graph->getNode($name) !== null) {
            return false;
        }
        $this->graph->addNode(new Node($name, $pos, $patrol));
        $this->saveNodes();
        return true;
    }

    public function removeNode($name) {
        $result = $this->graph->removeNode($name);
        if ($result) {
            $this->saveNodes();
        }
        return $result;
    }

    public function linkNodes($name1, $name2) {
        $result = $this->graph->linkNodes($name1, $name2);
        if ($result) {
            $this->saveNodes();
        }
        return $result;
    }

    public function unlinkNodes($name1, $name2) {
        $result = $this->graph->unlinkNodes($name1, $name2);
        if ($result) {
            $this->saveNodes();
        }
        return $result;
    }

    public function findPath(Vector3 $from, Vector3 $to) {
        return $this->pathfinder->findPath($from, $to);
    }

    public function getClosestNode(Vector3 $pos) {
        return $this->graph->getClosestNode($pos);
    }

    public function getPatrolNodes() {
        return $this->graph->getPatrolNodes();
    }

    public function startDebugTask() {
        if ($this->debugTaskId !== null) {
            return;
        }
        $task = new DebugParticleTask($this->plugin, $this);
        $handler = $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($task, 20);
        $this->debugTaskId = $handler->getTaskId();
    }

    public function stopDebugTask() {
        if ($this->debugTaskId !== null) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->debugTaskId);
            $this->debugTaskId = null;
        }
    }

    public function hasDebugPlayers() {
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if ($this->plugin->isDebug($player->getName())) {
                return true;
            }
        }
        return false;
    }

    public function sendDebugParticles() {
        $debugPlayers = [];
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if ($this->plugin->isDebug($player->getName())) {
                $debugPlayers[] = $player;
            }
        }

        if (empty($debugPlayers)) {
            $this->stopDebugTask();
            return;
        }

        foreach ($this->graph->getNodes() as $node) {
            $pos = $node->getPosition();

            $pk = new LevelEventPacket();
            $pk->evid = LevelEventPacket::EVENT_ADD_PARTICLE_MASK | 4;
            $pk->x = $pos->x;
            $pk->y = $pos->y + 1;
            $pk->z = $pos->z;
            $pk->data = 0;

            foreach ($debugPlayers as $player) {
                $player->dataPacket($pk);
            }

            foreach ($node->getLinks() as $linkName) {
                $linked = $this->graph->getNode($linkName);
                if ($linked === null) continue;

                $lpos = $linked->getPosition();
                $diffX = $lpos->x - $pos->x;
                $diffY = $lpos->y - $pos->y;
                $diffZ = $lpos->z - $pos->z;
                $steps = (int)max(1, $pos->distance($lpos) * 2);

                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $fpk = new LevelEventPacket();
                    $fpk->evid = LevelEventPacket::EVENT_ADD_PARTICLE_MASK | 9;
                    $fpk->x = $pos->x + $diffX * $t;
                    $fpk->y = $pos->y + 1 + $diffY * $t;
                    $fpk->z = $pos->z + $diffZ * $t;
                    $fpk->data = 0;

                    foreach ($debugPlayers as $player) {
                        $player->dataPacket($fpk);
                    }
                }
            }
        }
    }

    public function showDebugParticles(Player $player) {
        $this->sendDebugParticles();
    }

    private function loadNodes() {
        $config = $this->plugin->getConfig();
        $nodes = $config->get("nodes", []);
        if (is_array($nodes) && !empty($nodes)) {
            $this->graph->loadFromArray($nodes);
        }
    }

    private function saveNodes() {
        $this->plugin->getConfig()->set("nodes", $this->graph->toArray());
        $this->plugin->getConfig()->save();
    }
}

class DebugParticleTask extends PluginTask {

    private $nodeManager;

    public function __construct(Main $plugin, NodeManager $nodeManager) {
        parent::__construct($plugin);
        $this->nodeManager = $nodeManager;
    }

    public function onRun($currentTick) {
        $this->nodeManager->sendDebugParticles();
    }
}
