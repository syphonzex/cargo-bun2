<?php

namespace Granny\manager;

use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\item\Item;
use pocketmine\utils\Config;
use Granny\Main;

class LockManager {

    private $plugin;
    private $data;
    private $buildMode = [];
    private $buildBlocks = [];
    private $buildContext = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->data = new Config(
            $plugin->getDataFolder() . "locks.yml",
            Config::YAML,
            []
        );
    }

    public function createLock($name, Player $player) {
        $all = $this->data->getAll();
        if (isset($all[$name])) {
            return false;
        }

        $item = $player->getInventory()->getItemInHand();
        if ($item->getId() === 0) {
            return null;
        }

        $all[$name] = [
            "key_id" => $item->getId(),
            "key_meta" => $item->getDamage(),
            "key_name" => $item->hasCustomName() ? $item->getCustomName() : "",
            "blocks" => [],
            "world" => $player->getLevel()->getName(),
            "alert_granny" => true,
            "actions" => []
        ];
        $this->data->setAll($all);
        $this->data->save();

        $this->buildMode[$player->getName()] = true;
        $this->buildBlocks[$player->getName()] = [];
        $this->buildContext[$player->getName()] = ["lock" => $name, "type" => "lock"];

        return true;
    }

    public function isInBuildMode($playerName) {
        return isset($this->buildMode[$playerName]);
    }

    public function getBuildLockName($playerName) {
        if (!isset($this->buildContext[$playerName])) return null;
        return $this->buildContext[$playerName]["lock"];
    }

    public function getBuildContext($playerName) {
        return isset($this->buildContext[$playerName]) ? $this->buildContext[$playerName] : null;
    }

    public function startBuildMode($playerName, $lockName, $type) {
        $this->buildMode[$playerName] = true;
        $this->buildBlocks[$playerName] = [];
        $this->buildContext[$playerName] = ["lock" => $lockName, "type" => $type];
    }

    public function trackBlock($playerName, Vector3 $pos, $worldName, $origId = 0, $origMeta = 0) {
        if (!$this->isInBuildMode($playerName)) return;
        $key = ((int)$pos->x) . ":" . ((int)$pos->y) . ":" . ((int)$pos->z);
        $this->buildBlocks[$playerName][$key] = [
            "x" => (int)$pos->x,
            "y" => (int)$pos->y,
            "z" => (int)$pos->z,
            "world" => $worldName,
            "orig_id" => $origId,
            "orig_meta" => $origMeta
        ];
    }

    public function confirmBuild($playerName) {
        if (!$this->isInBuildMode($playerName)) return false;

        $ctx = $this->buildContext[$playerName];
        $lockName = $ctx["lock"];
        $type = $ctx["type"];
        $blocks = $this->buildBlocks[$playerName];

        if (empty($blocks)) return false;

        $all = $this->data->getAll();
        if (!isset($all[$lockName])) return false;

        if ($type === "lock") {
            $blockList = [];
            foreach ($blocks as $b) {
                $level = $this->plugin->getServer()->getLevelByName($b["world"]);
                if ($level === null) continue;
                $block = $level->getBlock(new Vector3($b["x"], $b["y"], $b["z"]));
                $blockList[] = [
                    "x" => $b["x"], "y" => $b["y"], "z" => $b["z"],
                    "world" => $b["world"],
                    "id" => $block->getId(), "meta" => $block->getDamage()
                ];
            }
            $all[$lockName]["blocks"] = $blockList;
        } elseif ($type === "remove_blocks") {
            $blockList = [];
            foreach ($blocks as $b) {
                $level = $this->plugin->getServer()->getLevelByName($b["world"]);
                if ($level === null) continue;
                $block = $level->getBlock(new Vector3($b["x"], $b["y"], $b["z"]));
                $blockList[] = [
                    "x" => $b["x"], "y" => $b["y"], "z" => $b["z"],
                    "world" => $b["world"],
                    "id" => $block->getId(), "meta" => $block->getDamage()
                ];
            }
            $all[$lockName]["actions"][] = ["type" => "remove_blocks", "blocks" => $blockList];
        } elseif ($type === "place_blocks") {
            $blockList = [];
            foreach ($blocks as $b) {
                $level = $this->plugin->getServer()->getLevelByName($b["world"]);
                if ($level === null) continue;
                $block = $level->getBlock(new Vector3($b["x"], $b["y"], $b["z"]));
                $blockList[] = [
                    "x" => $b["x"], "y" => $b["y"], "z" => $b["z"],
                    "world" => $b["world"],
                    "id" => $block->getId(), "meta" => $block->getDamage(),
                    "orig_id" => $b["orig_id"], "orig_meta" => $b["orig_meta"]
                ];
            }
            $all[$lockName]["actions"][] = ["type" => "place_blocks", "blocks" => $blockList];
        }

        $this->data->setAll($all);
        $this->data->save();

        unset($this->buildMode[$playerName]);
        unset($this->buildBlocks[$playerName]);
        unset($this->buildContext[$playerName]);
        return true;
    }

    public function cancelBuild($playerName) {
        if (!$this->isInBuildMode($playerName)) return false;

        $ctx = $this->buildContext[$playerName];
        $blocks = $this->buildBlocks[$playerName];

        if ($ctx["type"] === "lock") {
            foreach ($blocks as $b) {
                $level = $this->plugin->getServer()->getLevelByName($b["world"]);
                if ($level !== null) {
                    $level->setBlock(new Vector3($b["x"], $b["y"], $b["z"]), Block::get(0), true, true);
                }
            }
        }

        $lockName = $ctx["lock"];
        $all = $this->data->getAll();
        if ($ctx["type"] === "lock" && isset($all[$lockName]) && empty($all[$lockName]["blocks"])) {
            unset($all[$lockName]);
            $this->data->setAll($all);
            $this->data->save();
        }

        unset($this->buildMode[$playerName]);
        unset($this->buildBlocks[$playerName]);
        unset($this->buildContext[$playerName]);
        return true;
    }

    public function addAction($lockName, $actionType, $actionData) {
        $all = $this->data->getAll();
        if (!isset($all[$lockName])) return false;
        if (!isset($all[$lockName]["actions"])) $all[$lockName]["actions"] = [];
        $all[$lockName]["actions"][] = array_merge(["type" => $actionType], $actionData);
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

    public function setAlertGranny($lockName, $value) {
        $all = $this->data->getAll();
        if (!isset($all[$lockName])) return false;
        $all[$lockName]["alert_granny"] = (bool)$value;
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

public function tryUnlock(Player $player, Vector3 $blockPos) {
    $item = $player->getInventory()->getItemInHand();
    $all = $this->data->getAll();
    $bx = (int)$blockPos->x;
    $by = (int)$blockPos->y;
    $bz = (int)$blockPos->z;

    $session = $this->plugin->getArenaManager()->getPlayerSession($player->getName());

    foreach ($all as $name => $lock) {
        if ($session !== null && $session->isLockUnlocked($name)) {
            continue;
        }

        $isLockBlock = false;
        foreach ($lock["blocks"] as $b) {
            if ($b["x"] === $bx && $b["y"] === $by && $b["z"] === $bz) {
                $isLockBlock = true;
                break;
            }
        }
        if (!$isLockBlock) continue;

        $matchesKey = ($item->getId() === $lock["key_id"] && $item->getDamage() === $lock["key_meta"]);
        if ($lock["key_name"] !== "") {
            $matchesKey = $matchesKey && $item->hasCustomName() && $item->getCustomName() === $lock["key_name"];
        }

        if (!$matchesKey) {
            $keyLabel = $lock["key_name"] !== "" ? $lock["key_name"] : $name;
            $player->sendTip("§cI need §r§f" . $keyLabel . "§r§c...");
            return true;
        }

        $playerWorld = $player->getLevel()->getFolderName();
        $this->removeLockBlocks($name, $playerWorld);
        $this->executeActions($player, isset($lock["actions"]) ? $lock["actions"] : [], $playerWorld);
        $player->sendPopup("§a§lUnlocked! §r§7" . $name);

        if ($session !== null) {
            $session->setLockUnlocked($name);
        }

        $alertGranny = isset($lock["alert_granny"]) ? $lock["alert_granny"] : true;
        if ($alertGranny) {
            \Granny\utils\SoundTrigger::triggerSound($this->plugin, $blockPos, $playerWorld);
            $this->playSound($blockPos, $player->getLevel());
        }

        return true;
    }
    return false;
}

    private function executeActions(Player $player, $actions, $overrideWorld = null) {
        foreach ($actions as $action) {
            switch ($action["type"]) {
                case "remove_blocks":
                    foreach ($action["blocks"] as $b) {
                        $wn = $overrideWorld !== null ? $overrideWorld : $b["world"];
                        $level = $this->plugin->getServer()->getLevelByName($wn);
                        if ($level !== null) {
                            $level->setBlock(new Vector3($b["x"], $b["y"], $b["z"]), Block::get(0), true, true);
                        }
                    }
                    break;
                case "place_blocks":
                    foreach ($action["blocks"] as $b) {
                        $wn = $overrideWorld !== null ? $overrideWorld : $b["world"];
                        $level = $this->plugin->getServer()->getLevelByName($wn);
                        if ($level !== null) {
                            $level->setBlock(new Vector3($b["x"], $b["y"], $b["z"]), Block::get($b["id"], $b["meta"]), true, true);
                        }
                    }
                    break;
                case "give_item":
                    if (isset($action["item_id"])) {
                        $item = Item::get($action["item_id"], isset($action["item_meta"]) ? $action["item_meta"] : 0, isset($action["item_count"]) ? $action["item_count"] : 1);
                        if (isset($action["item_name"]) && $action["item_name"] !== "") {
                            $item->setCustomName($action["item_name"]);
                        }
                        $player->getInventory()->addItem($item);
                    }
                    break;
                case "run_command":
                    if (isset($action["command"])) {
                        $cmd = str_replace("{player}", $player->getName(), $action["command"]);
                        $this->plugin->getServer()->dispatchCommand(new \pocketmine\command\ConsoleCommandSender(), $cmd);
                    }
                    break;
                case "send_message":
                    if (isset($action["message"])) {
                        $player->sendMessage($action["message"]);
                    }
                    break;
            }
        }
    }

    private function playSound(Vector3 $pos, $level) {
        $pk = new \pocketmine\network\protocol\LevelEventPacket();
        $pk->evid = \pocketmine\network\protocol\LevelEventPacket::EVENT_SOUND_DOOR;
        $pk->x = $pos->x;
        $pk->y = $pos->y;
        $pk->z = $pos->z;
        $pk->data = 0;
        $level->addChunkPacket(((int)$pos->x) >> 4, ((int)$pos->z) >> 4, $pk);
    }

    public function removeLockBlocks($lockName, $overrideWorld = null) {
        $all = $this->data->getAll();
        if (!isset($all[$lockName])) return;
        foreach ($all[$lockName]["blocks"] as $b) {
            $wn = $overrideWorld !== null ? $overrideWorld : $b["world"];
            $level = $this->plugin->getServer()->getLevelByName($wn);
            if ($level !== null) {
                $level->setBlock(new Vector3($b["x"], $b["y"], $b["z"]), Block::get(0), true, true);
            }
        }
    }

    public function restoreAllLocks($overrideWorld = null) {
        $all = $this->data->getAll();
        foreach ($all as $name => $lock) {
            foreach ($lock["blocks"] as $b) {
                $wn = $overrideWorld !== null ? $overrideWorld : $b["world"];
                $level = $this->plugin->getServer()->getLevelByName($wn);
                if ($level !== null) {
                    $level->setBlock(new Vector3($b["x"], $b["y"], $b["z"]), Block::get($b["id"], $b["meta"]), true, true);
                }
            }
            if (isset($lock["actions"])) {
                foreach ($lock["actions"] as $action) {
                    if ($action["type"] === "place_blocks") {
                        foreach ($action["blocks"] as $b) {
                            $wn = $overrideWorld !== null ? $overrideWorld : $b["world"];
                            $level = $this->plugin->getServer()->getLevelByName($wn);
                            if ($level !== null) {
                                $oid = isset($b["orig_id"]) ? $b["orig_id"] : 0;
                                $ometa = isset($b["orig_meta"]) ? $b["orig_meta"] : 0;
                                $level->setBlock(new Vector3($b["x"], $b["y"], $b["z"]), Block::get($oid, $ometa), true, true);
                            }
                        }
                    }
                    if ($action["type"] === "remove_blocks") {
                        foreach ($action["blocks"] as $b) {
                            $wn = $overrideWorld !== null ? $overrideWorld : $b["world"];
                            $level = $this->plugin->getServer()->getLevelByName($wn);
                            if ($level !== null) {
                                $level->setBlock(new Vector3($b["x"], $b["y"], $b["z"]), Block::get($b["id"], $b["meta"]), true, true);
                            }
                        }
                    }
                }
            }
        }
    }

    public function removeLock($name) {
        $all = $this->data->getAll();
        if (!isset($all[$name])) return false;
        unset($all[$name]);
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

    public function getLocks() {
        return $this->data->getAll();
    }

    public function getLock($name) {
        $all = $this->data->getAll();
        return isset($all[$name]) ? $all[$name] : null;
    }
}
