<?php

namespace Granny\manager;

use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\entity\Effect;
use pocketmine\scheduler\PluginTask;
use Granny\Main;

class DayManager {

    private $plugin;
    private $playerDays = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function getDay($playerName) {
        return isset($this->playerDays[$playerName]) ? $this->playerDays[$playerName] : 1;
    }

    public function setDay($playerName, $day) {
        $this->playerDays[$playerName] = $day;
    }

    public function resetDay($playerName) {
        $this->playerDays[$playerName] = 1;
    }

    public function resetAll() {
        $this->playerDays = [];
    }

    public function playerCaught(Player $player) {
        $name = $player->getName();
        $day = $this->getDay($name);

        if ($day >= 5) {
            $this->gameOver($player);
            return;
        }

        $newDay = $day + 1;
        $this->setDay($name, $newDay);

        $player->sendPopup("§c§lDay §r§c" . $newDay . "\n§7You were caught...");

        $this->teleportToStart($player);

        foreach ($this->plugin->getGrannyEntities() as $granny) {
            $granny->resetToSpawn();
        }

        $this->broadcastInGame("§c§l[DAY " . $newDay . "] §r§f" . $name . " §7was caught! Starting Day " . $newDay . "...");
    }

    private function gameOver(Player $player) {
        $name = $player->getName();
        $this->resetDay($name);

        $player->sendPopup("§4§lGAME OVER§r\n§cGranny got you on Day 5...");

        $session = $this->plugin->getArenaManager()->getPlayerSession($player->getName());
        if ($session !== null && $session->getPhase() === \Granny\game\GameSession::PHASE_INGAME) {
            $session->playerCaptured($player);
        } else {
            $this->teleportToStart($player);
        }

        $this->broadcastInGame("§4§l[GAME OVER] §r§f" . $name . " §7was caught on Day 5!");
    }

    private function broadcastInGame($msg) {
        foreach ($this->plugin->getArenaManager()->getSessions() as $session) {
            $session->broadcastSession($msg);
        }
    }

    private function teleportToStart($player) {
        $x = (float)$this->plugin->getConfigValue("start_room.x", 0);
        $y = (float)$this->plugin->getConfigValue("start_room.y", 64);
        $z = (float)$this->plugin->getConfigValue("start_room.z", 0);
        $player->teleport(new Vector3($x, $y, $z));
    }

    public function trapPlayer(Player $player) {
        $player->sendPopup("§c§lTRAPPED! §r§cTAP THE GROUND REPEATEDLY!");
    }

    public function freePlayer(Player $player) {
        $player->sendPopup("§a§lEscaped!§r");
    }
}
