<?php

namespace Granny\manager;

use pocketmine\math\Vector3;
use pocketmine\scheduler\PluginTask;
use Granny\Main;

class WorldManager {

	private $plugin;
	private $worldCounter = 0;

	public function __construct(Main $plugin) {
		$this->plugin = $plugin;
		$this->cleanupLeftovers();
	}

	public function getTemplate() {
		return $this->plugin->getConfigValue("template_world", null);
	}

	public function setTemplate($worldName) {
		$config = $this->plugin->getConfig();
		$all = $config->getAll();
		$all["template_world"] = $worldName;
		$config->setAll($all);
		$config->save();
	}

	public function prepareWorldCopy() {
		$template = $this->getTemplate();
		if ($template === null) return null;

		$server = $this->plugin->getServer();
		$worldsPath = $server->getDataPath() . "worlds/";
		$srcPath = $worldsPath . $template;

		if (!is_dir($srcPath)) {
			$this->plugin->getLogger()->warning("Template world not found: " . $srcPath);
			return null;
		}

		if ($server->isLevelLoaded($template)) {
			$level = $server->getLevelByName($template);
			if ($level !== null) {
				$level->save(true);
			}
		}

		$this->worldCounter++;
		$copyName = $template . "_" . $this->worldCounter;
		$destPath = $worldsPath . $copyName;

		if (is_dir($destPath)) {
			$this->deleteDirectory($destPath);
		}

		$this->copyDirectory($srcPath, $destPath);

		$server->loadLevel($copyName);
		$level = $server->getLevelByName($copyName);

		if ($level === null) {
			$this->plugin->getLogger()->warning("Failed to load copy: " . $copyName);
			$this->deleteDirectory($destPath);
			return null;
		}

		return $copyName;
	}

	public function destroyWorldCopy($worldName) {
		if ($worldName === null) return;

		$template = $this->getTemplate();
		if ($worldName === $template) return;

		$server = $this->plugin->getServer();
		$level = $server->getLevelByName($worldName);

		if ($level !== null) {
			$defaultLevel = $server->getDefaultLevel();
			foreach ($level->getPlayers() as $player) {
				if ($defaultLevel !== null) {
					$player->teleport($defaultLevel->getSafeSpawn());
				}
			}

			$plugin = $this->plugin;
			$task = new WorldUnloadTask($plugin, $worldName);
			$server->getScheduler()->scheduleDelayedTask($task, 40);
		} else {
			$worldsPath = $server->getDataPath() . "worlds/";
			$path = $worldsPath . $worldName;
			if (is_dir($path)) {
				$this->deleteDirectory($path);
			}
		}
	}

	public function forceDeleteWorld($worldName) {
		$server = $this->plugin->getServer();

		if ($server->isLevelLoaded($worldName)) {
			$level = $server->getLevelByName($worldName);
			if ($level !== null) {
				$defaultLevel = $server->getDefaultLevel();
				foreach ($level->getPlayers() as $player) {
					if ($defaultLevel !== null) {
						$player->teleport($defaultLevel->getSafeSpawn());
					}
				}
				$server->unloadLevel($level, true);
			}
		}

		$worldsPath = $server->getDataPath() . "worlds/";
		$path = $worldsPath . $worldName;
		if (is_dir($path)) {
			$this->deleteDirectory($path);
		}
	}

	private function cleanupLeftovers() {
		$template = $this->getTemplate();
		if ($template === null) return;

		$server = $this->plugin->getServer();
		$worldsPath = $server->getDataPath() . "worlds/";
		if (!is_dir($worldsPath)) return;

		$dirs = scandir($worldsPath);
		foreach ($dirs as $dir) {
			if ($dir === "." || $dir === "..") continue;
			if (strpos($dir, $template . "_") === 0 && is_dir($worldsPath . $dir)) {
				if ($server->isLevelLoaded($dir)) {
					$level = $server->getLevelByName($dir);
					if ($level !== null) {
						$defaultLevel = $server->getDefaultLevel();
						foreach ($level->getPlayers() as $player) {
							if ($defaultLevel !== null) {
								$player->teleport($defaultLevel->getSafeSpawn());
							}
						}
						$server->unloadLevel($level, true);
					}
				}
				$this->deleteDirectory($worldsPath . $dir);
				$this->plugin->getLogger()->info("Cleaned up leftover: " . $dir);
			}
		}
	}

	private function copyDirectory($src, $dest) {
		@mkdir($dest, 0777, true);
		$dir = opendir($src);
		while (($file = readdir($dir)) !== false) {
			if ($file === "." || $file === "..") continue;
			$srcFile = $src . "/" . $file;
			$destFile = $dest . "/" . $file;
			if (is_dir($srcFile)) {
				$this->copyDirectory($srcFile, $destFile);
			} else {
				copy($srcFile, $destFile);
			}
		}
		closedir($dir);
	}

	public function deleteDirectory($path) {
		if (!is_dir($path)) return;
		$items = scandir($path);
		foreach ($items as $item) {
			if ($item === "." || $item === "..") continue;
			$full = $path . "/" . $item;
			if (is_dir($full)) {
				$this->deleteDirectory($full);
			} else {
				@unlink($full);
			}
		}
		@rmdir($path);
	}

}

class WorldUnloadTask extends PluginTask {

	private $worldName;

	public function __construct(Main $plugin, $worldName) {
		parent::__construct($plugin);
		$this->worldName = $worldName;
	}

	public function onRun($currentTick) {
		$plugin = $this->getOwner();
		if (!($plugin instanceof Main)) return;

		$server = $plugin->getServer();
		$level = $server->getLevelByName($this->worldName);

		if ($level !== null) {
			$defaultLevel = $server->getDefaultLevel();
			foreach ($level->getPlayers() as $player) {
				if ($defaultLevel !== null) {
					$player->teleport($defaultLevel->getSafeSpawn());
				}
			}
			$server->unloadLevel($level, true);
		}

		$worldsPath = $server->getDataPath() . "worlds/";
		$path = $worldsPath . $this->worldName;
		if (is_dir($path)) {
			$plugin->getWorldManager()->deleteDirectory($path);
		}
	}

}