<?php

namespace Granny\manager;

use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\item\Item;
use pocketmine\utils\Config;
use Granny\Main;

class EscapeManager {

    private $plugin;
    private $data;
    private $buildMode = [];
    private $buildBlocks = [];
    private $buildContext = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->data = new Config(
            $plugin->getDataFolder() . "escapes.yml",
            Config::YAML,
            []
        );
    }

    public function createEscape($name) {
        $all = $this->data->getAll();
        if (isset($all[$name])) return false;
        $all[$name] = [
            "parts" => [],
            "main_key" => null
        ];
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

    public function removeEscape($name) {
        $all = $this->data->getAll();
        if (!isset($all[$name])) return false;
        unset($all[$name]);
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

    public function setMainKey($escapeName, Item $item) {
        $all = $this->data->getAll();
        if (!isset($all[$escapeName])) return false;
        $all[$escapeName]["main_key"] = [
            "id" => $item->getId(),
            "meta" => $item->getDamage(),
            "name" => $item->hasCustomName() ? $item->getCustomName() : ""
        ];
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

    public function addPart($escapeName, $partName, Item $keyItem) {
        $all = $this->data->getAll();
        if (!isset($all[$escapeName])) return false;
        if (isset($all[$escapeName]["parts"][$partName])) return "exists";

        $all[$escapeName]["parts"][$partName] = [
            "key_id" => $keyItem->getId(),
            "key_meta" => $keyItem->getDamage(),
            "key_name" => $keyItem->hasCustomName() ? $keyItem->getCustomName() : "",
            "lock_blocks" => [],
            "actions" => [],
            "alert_granny" => true
        ];
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

    public function removePart($escapeName, $partName) {
        $all = $this->data->getAll();
        if (!isset($all[$escapeName]["parts"][$partName])) return false;
        unset($all[$escapeName]["parts"][$partName]);
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

    public function setPartAlertGranny($escapeName, $partName, $value) {
        $all = $this->data->getAll();
        if (!isset($all[$escapeName]["parts"][$partName])) return false;
        $all[$escapeName]["parts"][$partName]["alert_granny"] = (bool)$value;
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

    public function isInBuildMode($playerName) {
        return isset($this->buildMode[$playerName]);
    }

    public function getBuildContext($playerName) {
        return isset($this->buildContext[$playerName]) ? $this->buildContext[$playerName] : null;
    }

    public function startBuildMode($playerName, $escapeName, $partName, $type) {
        $this->buildMode[$playerName] = true;
        $this->buildBlocks[$playerName] = [];
        $this->buildContext[$playerName] = [
            "escape" => $escapeName,
            "part" => $partName,
            "type" => $type
        ];
    }

    public function trackBlock($playerName, Vector3 $pos, $worldName, $origId = 0, $origMeta = 0) {
        if (!$this->isInBuildMode($playerName)) return;
        $key = ((int)$pos->x) . ":" . ((int)$pos->y) . ":" . ((int)$pos->z);
        $this->buildBlocks[$playerName][$key] = [
            "x" => (int)$pos->x,
            "y" => (int)$pos->y,
            "z" => (int)$pos->z,
            "world" => $worldName,
            "orig_id" => $origId,
            "orig_meta" => $origMeta
        ];
    }

    public function confirmBuild($playerName) {
        if (!$this->isInBuildMode($playerName)) return false;
        $ctx = $this->buildContext[$playerName];
        $blocks = array_values($this->buildBlocks[$playerName]);
        if (empty($blocks)) return false;

        $all = $this->data->getAll();
        $esc = $ctx["escape"];
        $part = $ctx["part"];
        $type = $ctx["type"];

        if (!isset($all[$esc]["parts"][$part])) return false;

        if ($type === "lock") {
            $finalBlocks = [];
            foreach ($blocks as $b) {
                $level = $this->plugin->getServer()->getLevelByName($b["world"]);
                if ($level !== null) {
                    $block = $level->getBlock(new Vector3($b["x"], $b["y"], $b["z"]));
                    $b["id"] = $block->getId();
                    $b["meta"] = $block->getDamage();
                }
                $finalBlocks[] = $b;
            }
            $all[$esc]["parts"][$part]["lock_blocks"] = $finalBlocks;
        } elseif ($type === "remove_blocks") {
            $finalBlocks = [];
            foreach ($blocks as $b) {
                $level = $this->plugin->getServer()->getLevelByName($b["world"]);
                if ($level !== null) {
                    $block = $level->getBlock(new Vector3($b["x"], $b["y"], $b["z"]));
                    $b["id"] = $block->getId();
                    $b["meta"] = $block->getDamage();
                }
                $finalBlocks[] = $b;
            }
            $all[$esc]["parts"][$part]["actions"][] = ["type" => "remove_blocks", "blocks" => $finalBlocks];
        } elseif ($type === "place_blocks") {
            $finalBlocks = [];
            foreach ($blocks as $b) {
                $level = $this->plugin->getServer()->getLevelByName($b["world"]);
                if ($level !== null) {
                    $block = $level->getBlock(new Vector3($b["x"], $b["y"], $b["z"]));
                    $b["id"] = $block->getId();
                    $b["meta"] = $block->getDamage();
                }
                $finalBlocks[] = $b;
            }
            $all[$esc]["parts"][$part]["actions"][] = ["type" => "place_blocks", "blocks" => $finalBlocks];
        }

        $this->data->setAll($all);
        $this->data->save();

        unset($this->buildMode[$playerName]);
        unset($this->buildBlocks[$playerName]);
        unset($this->buildContext[$playerName]);
        return true;
    }

    public function cancelBuild($playerName) {
        if (!$this->isInBuildMode($playerName)) return false;
        $ctx = $this->buildContext[$playerName];
        $blocks = $this->buildBlocks[$playerName];

        if ($ctx["type"] === "lock") {
            foreach ($blocks as $b) {
                $level = $this->plugin->getServer()->getLevelByName($b["world"]);
                if ($level !== null) {
                    $level->setBlock(new Vector3($b["x"], $b["y"], $b["z"]), Block::get(0), true, true);
                }
            }
        }

        unset($this->buildMode[$playerName]);
        unset($this->buildBlocks[$playerName]);
        unset($this->buildContext[$playerName]);
        return true;
    }

    public function addAction($escapeName, $partName, $actionType, $actionData) {
        $all = $this->data->getAll();
        if (!isset($all[$escapeName]["parts"][$partName])) return false;
        $all[$escapeName]["parts"][$partName]["actions"][] = array_merge(["type" => $actionType], $actionData);
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

public function tryUnlockPart(Player $player, Vector3 $blockPos) {
    $item = $player->getInventory()->getItemInHand();
    $all = $this->data->getAll();
    $bx = (int)$blockPos->x;
    $by = (int)$blockPos->y;
    $bz = (int)$blockPos->z;

    $session = $this->plugin->getArenaManager()->getPlayerSession($player->getName());

    foreach ($all as $escName => $escape) {
        if ($this->allPartsUnlocked($escName, $session)) {
            $mainKey = isset($escape["main_key"]) ? $escape["main_key"] : null;
            if ($mainKey !== null) {
                $matches = ($item->getId() === $mainKey["id"] && $item->getDamage() === $mainKey["meta"]);
                if ($mainKey["name"] !== "") {
                    $matches = $matches && $item->hasCustomName() && $item->getCustomName() === $mainKey["name"];
                }
                if ($matches) {
                    $this->triggerEscape($player, $escName);
                    return true;
                } else {
                    $keyLabel = $mainKey["name"] !== "" ? $mainKey["name"] : "the escape key";
                    $player->sendTip("§cI need §r§f" . $keyLabel . "§r§c to escape...");
                    return true;
                }
            } else {
                $this->triggerEscape($player, $escName);
                return true;
            }
        }

        foreach ($escape["parts"] as $partName => $part) {
            if ($this->isPartUnlocked($escName, $partName, $session)) continue;

            $isLockBlock = false;
            foreach ($part["lock_blocks"] as $b) {
                if ($b["x"] === $bx && $b["y"] === $by && $b["z"] === $bz) {
                    $isLockBlock = true;
                    break;
                }
            }
            if (!$isLockBlock) continue;

            $matchesKey = ($item->getId() === $part["key_id"] && $item->getDamage() === $part["key_meta"]);
            if ($part["key_name"] !== "") {
                $matchesKey = $matchesKey && $item->hasCustomName() && $item->getCustomName() === $part["key_name"];
            }

            if (!$matchesKey) {
                $keyLabel = $part["key_name"] !== "" ? $part["key_name"] : $partName;
                $player->sendTip("§cI need §r§f" . $keyLabel . "§r§c...");
                return true;
            }

            $this->unlockPart($player, $escName, $partName, $session);
            return true;
        }
    }
    return false;
}

private function triggerEscape(Player $player, $escName) {
    $session = $this->plugin->getArenaManager()->getPlayerSession($player->getName());

   // $this->broadcastInSession("§a§l[ESCAPE] §r§f" . $player->getName() . " §aescaped through §f" . $escName . "§a!", $session);

    if ($session !== null && $session->getPhase() === \Granny\game\GameSession::PHASE_INGAME) {
        $session->playerEscaped($player);
    }
}

private function unlockPart(Player $player, $escName, $partName, $session = null) {
    $all = $this->data->getAll();
    $part = $all[$escName]["parts"][$partName];
    $playerWorld = $player->getLevel()->getFolderName();

    if ($session !== null) {
        $session->setPartUnlocked($escName, $partName);
    }

    foreach ($part["lock_blocks"] as $b) {
        $level = $this->plugin->getServer()->getLevelByName($playerWorld);
        if ($level !== null) {
            $level->setBlock(new Vector3($b["x"], $b["y"], $b["z"]), Block::get(0), true, true);
        }
    }

    $this->executeActions($player, $part["actions"], $playerWorld);

    $alertGranny = isset($part["alert_granny"]) ? $part["alert_granny"] : true;
    if ($alertGranny) {
        $alertPos = new Vector3($player->x, $player->y, $player->z);
        \Granny\utils\SoundTrigger::triggerSound($this->plugin, $alertPos, $playerWorld);
        $this->playSound($alertPos, $player->getLevel());
    }

    $totalParts = count($all[$escName]["parts"]);
    $unlockedParts = $session !== null ? $session->getUnlockedCount($escName) : 0;
    $player->sendPopup("§a§lUNLOCKED! §r§7" . $partName . " §f(" . $unlockedParts . "/" . $totalParts . ")");

    $this->broadcastInSession("§6§l[ESCAPE] §r§f" . $partName . " §7unlocked! §f(" . $unlockedParts . "/" . $totalParts . ")", $session);

    if ($this->allPartsUnlocked($escName, $session)) {
        $mainKey = isset($all[$escName]["main_key"]) ? $all[$escName]["main_key"] : null;
        if ($mainKey !== null) {
            $keyLabel = $mainKey["name"] !== "" ? $mainKey["name"] : "the escape key";
            $this->broadcastInSession("§e§l[ESCAPE] §r§7All parts unlocked! Use §f" . $keyLabel . " §7to escape through §f" . $escName . "§7!", $session);
        } else {
            $this->triggerEscape($player, $escName);
        }
    }
}

    private function playSound(Vector3 $pos, $level) {
        $pk = new \pocketmine\network\protocol\LevelEventPacket();
        $pk->evid = \pocketmine\network\protocol\LevelEventPacket::EVENT_SOUND_DOOR;
        $pk->x = $pos->x;
        $pk->y = $pos->y;
        $pk->z = $pos->z;
        $pk->data = 0;
        $level->addChunkPacket(((int)$pos->x) >> 4, ((int)$pos->z) >> 4, $pk);
    }

    private function executeActions(Player $player, $actions, $overrideWorld = null) {
        foreach ($actions as $action) {
            switch ($action["type"]) {
                case "remove_blocks":
                    foreach ($action["blocks"] as $b) {
                        $wn = $overrideWorld !== null ? $overrideWorld : $b["world"];
                        $level = $this->plugin->getServer()->getLevelByName($wn);
                        if ($level !== null) {
                            $level->setBlock(new Vector3($b["x"], $b["y"], $b["z"]), Block::get(0), true, true);
                        }
                    }
                    break;
                case "place_blocks":
                    foreach ($action["blocks"] as $b) {
                        $wn = $overrideWorld !== null ? $overrideWorld : $b["world"];
                        $level = $this->plugin->getServer()->getLevelByName($wn);
                        if ($level !== null) {
                            $level->setBlock(new Vector3($b["x"], $b["y"], $b["z"]), Block::get($b["id"], $b["meta"]), true, true);
                        }
                    }
                    break;
                case "give_item":
                    if (isset($action["item_id"])) {
                        $item = Item::get($action["item_id"], isset($action["item_meta"]) ? $action["item_meta"] : 0, isset($action["item_count"]) ? $action["item_count"] : 1);
                        if (isset($action["item_name"]) && $action["item_name"] !== "") {
                            $item->setCustomName($action["item_name"]);
                        }
                        $player->getInventory()->addItem($item);
                    }
                    break;
                case "run_command":
                    if (isset($action["command"])) {
                        $cmd = str_replace("{player}", $player->getName(), $action["command"]);
                        $this->plugin->getServer()->dispatchCommand(new \pocketmine\command\ConsoleCommandSender(), $cmd);
                    }
                    break;
                case "send_message":
                    if (isset($action["message"])) {
                        $player->sendMessage($action["message"]);
                    }
                    break;
            }
        }
    }

private function broadcastInSession($msg, $session = null) {
    if ($session !== null) {
        $session->broadcastSession($msg);
    }
}

public function allPartsUnlocked($escName, $session = null) {
    $all = $this->data->getAll();
    if (!isset($all[$escName])) return false;
    $totalParts = count($all[$escName]["parts"]);
    if ($totalParts === 0) return true;

    if ($session !== null) {
        return $session->getUnlockedCount($escName) >= $totalParts;
    }

    return false;
}

public function isPartUnlocked($escName, $partName, $session = null) {
    if ($session !== null) {
        return $session->isPartUnlocked($escName, $partName);
    }
    return false;
}

public function isEscapeOpen($escName, $session = null) {
    return $this->allPartsUnlocked($escName, $session);
}

public function restoreAll($overrideWorld = null) {
    $all = $this->data->getAll();
    foreach ($all as $escName => $escape) {
        foreach ($escape["parts"] as $partName => $part) {
            foreach ($part["lock_blocks"] as $b) {
                $wn = $overrideWorld !== null ? $overrideWorld : $b["world"];
                $level = $this->plugin->getServer()->getLevelByName($wn);
                if ($level !== null) {
                    $level->setBlock(new Vector3($b["x"], $b["y"], $b["z"]), Block::get($b["id"], $b["meta"]), true, true);
                }
            }
            foreach ($part["actions"] as $action) {
                if ($action["type"] === "place_blocks") {
                    foreach ($action["blocks"] as $b) {
                        $wn = $overrideWorld !== null ? $overrideWorld : $b["world"];
                        $level = $this->plugin->getServer()->getLevelByName($wn);
                        if ($level !== null) {
                            $oid = isset($b["orig_id"]) ? $b["orig_id"] : 0;
                            $ometa = isset($b["orig_meta"]) ? $b["orig_meta"] : 0;
                            $level->setBlock(new Vector3($b["x"], $b["y"], $b["z"]), Block::get($oid, $ometa), true, true);
                        }
                    }
                }
                if ($action["type"] === "remove_blocks") {
                    foreach ($action["blocks"] as $b) {
                        $wn = $overrideWorld !== null ? $overrideWorld : $b["world"];
                        $level = $this->plugin->getServer()->getLevelByName($wn);
                        if ($level !== null) {
                            $level->setBlock(new Vector3($b["x"], $b["y"], $b["z"]), Block::get($b["id"], $b["meta"]), true, true);
                        }
                    }
                }
            }
        }
    }
}

    public function getEscapes() {
        return $this->data->getAll();
    }

    public function getEscape($name) {
        $all = $this->data->getAll();
        return isset($all[$name]) ? $all[$name] : null;
    }
}
