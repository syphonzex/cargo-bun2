<?php

namespace Granny\manager;

use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\tile\Chest;
use pocketmine\utils\Config;
use Granny\Main;

class ChestManager {

    private $plugin;
    private $data;
    private $registerMode = [];
    private $registerPreset = [];
    private $activePreset = null;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->data = new Config(
            $plugin->getDataFolder() . "chests.yml",
            Config::YAML,
            ["presets" => []]
        );
    }

    public function createPreset($name) {
        $all = $this->data->getAll();
        if (isset($all["presets"][$name])) {
            return false;
        }
        $all["presets"][$name] = ["chests" => []];
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

    public function removePreset($name) {
        $all = $this->data->getAll();
        if (!isset($all["presets"][$name])) {
            return false;
        }
        unset($all["presets"][$name]);
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

    public function setRegisterMode($playerName, $presetName) {
        if ($presetName === false || $presetName === null) {
            unset($this->registerMode[$playerName]);
            unset($this->registerPreset[$playerName]);
        } else {
            $this->registerMode[$playerName] = true;
            $this->registerPreset[$playerName] = $presetName;
        }
    }

    public function isInRegisterMode($playerName) {
        return isset($this->registerMode[$playerName]);
    }

    public function getRegisterPreset($playerName) {
        return isset($this->registerPreset[$playerName]) ? $this->registerPreset[$playerName] : null;
    }

    public function registerChest($presetName, Vector3 $pos, $worldName) {
        $all = $this->data->getAll();
        if (!isset($all["presets"][$presetName])) {
            return false;
        }

        $key = ((int)$pos->x) . ":" . ((int)$pos->y) . ":" . ((int)$pos->z) . ":" . $worldName;
        foreach ($all["presets"][$presetName]["chests"] as $c) {
            $ck = $c["x"] . ":" . $c["y"] . ":" . $c["z"] . ":" . $c["world"];
            if ($ck === $key) {
                return "exists";
            }
        }

        $all["presets"][$presetName]["chests"][] = [
            "x" => (int)$pos->x,
            "y" => (int)$pos->y,
            "z" => (int)$pos->z,
            "world" => $worldName,
            "items" => []
        ];
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

    public function addItemToChest($presetName, $chestIndex, Item $item) {
        $all = $this->data->getAll();
        if (!isset($all["presets"][$presetName])) return false;
        if (!isset($all["presets"][$presetName]["chests"][$chestIndex])) return false;

        $all["presets"][$presetName]["chests"][$chestIndex]["items"][] = [
            "id" => $item->getId(),
            "meta" => $item->getDamage(),
            "count" => $item->getCount(),
            "name" => $item->hasCustomName() ? $item->getCustomName() : ""
        ];
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

    public function removeItemFromChest($presetName, $chestIndex, $itemIndex) {
        $all = $this->data->getAll();
        if (!isset($all["presets"][$presetName])) return false;
        if (!isset($all["presets"][$presetName]["chests"][$chestIndex])) return false;
        if (!isset($all["presets"][$presetName]["chests"][$chestIndex]["items"][$itemIndex])) return false;
        array_splice($all["presets"][$presetName]["chests"][$chestIndex]["items"], $itemIndex, 1);
        $this->data->setAll($all);
        $this->data->save();
        return true;
    }

    public function findChestIndex($presetName, Vector3 $pos, $worldName) {
        $all = $this->data->getAll();
        if (!isset($all["presets"][$presetName])) return -1;
        $key = ((int)$pos->x) . ":" . ((int)$pos->y) . ":" . ((int)$pos->z) . ":" . $worldName;
        foreach ($all["presets"][$presetName]["chests"] as $i => $c) {
            $ck = $c["x"] . ":" . $c["y"] . ":" . $c["z"] . ":" . $c["world"];
            if ($ck === $key) return $i;
        }
        return -1;
    }

    public function getPresets() {
        $all = $this->data->getAll();
        return isset($all["presets"]) ? $all["presets"] : [];
    }

    public function getPreset($name) {
        $all = $this->data->getAll();
        return isset($all["presets"][$name]) ? $all["presets"][$name] : null;
    }

    public function getPresetNames() {
        return array_keys($this->getPresets());
    }

    public function fillChestsWithRandomPreset($overrideWorld = null) {
        $presets = $this->getPresets();
        if (empty($presets)) return null;

        $names = array_keys($presets);
        $picked = $names[array_rand($names)];
        $this->activePreset = $picked;
        $preset = $presets[$picked];

        if (!isset($preset["chests"]) || empty($preset["chests"])) return $picked;

        foreach ($preset["chests"] as $chestData) {
            if (empty($chestData["items"])) continue;
            $worldName = $overrideWorld !== null ? $overrideWorld : $chestData["world"];
            $level = $this->plugin->getServer()->getLevelByName($worldName);
            if ($level === null) continue;

            $tile = $level->getTile(new Vector3($chestData["x"], $chestData["y"], $chestData["z"]));
            if (!($tile instanceof Chest)) continue;

            $inv = $tile->getInventory();
            $inv->clearAll();

            $slots = range(0, $inv->getSize() - 1);
            shuffle($slots);

            $idx = 0;
            foreach ($chestData["items"] as $itemData) {
                if ($idx >= count($slots)) break;
                $item = Item::get($itemData["id"], $itemData["meta"], $itemData["count"]);
                if ($itemData["name"] !== "") {
                    $item->setCustomName($itemData["name"]);
                }
                $inv->setItem($slots[$idx], $item);
                $idx++;
            }
        }

        return $picked;
    }

    public function clearAllChests($overrideWorld = null) {
        $presets = $this->getPresets();
        foreach ($presets as $preset) {
            if (!isset($preset["chests"])) continue;
            foreach ($preset["chests"] as $c) {
                $worldName = $overrideWorld !== null ? $overrideWorld : $c["world"];
                $level = $this->plugin->getServer()->getLevelByName($worldName);
                if ($level === null) continue;
                $tile = $level->getTile(new Vector3($c["x"], $c["y"], $c["z"]));
                if ($tile instanceof Chest) {
                    $tile->getInventory()->clearAll();
                }
            }
        }
        $this->activePreset = null;
    }

    public function getActivePreset() {
        return $this->activePreset;
    }
}
