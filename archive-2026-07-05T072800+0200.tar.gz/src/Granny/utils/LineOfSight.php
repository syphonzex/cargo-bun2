<?php

namespace Granny\utils;

use pocketmine\math\Vector3;
use pocketmine\level\Level;
use pocketmine\block\Block;

class LineOfSight {

    public static function hasLineOfSight(Level $level, Vector3 $from, Vector3 $to) {
        $diff = $to->subtract($from);
        $dist = $from->distance($to);
        if($dist < 0.01) {
            return true;
        }

        $steps = (int)ceil($dist * 2);
        if($steps < 1) {
            $steps = 1;
        }

        $dx = $diff->x / $steps;
        $dy = $diff->y / $steps;
        $dz = $diff->z / $steps;

        $cx = $from->x;
        $cy = $from->y;
        $cz = $from->z;

        for($i = 0; $i <= $steps; $i++) {
            $block = $level->getBlock(new Vector3((int)floor($cx), (int)floor($cy), (int)floor($cz)));
            if($block->isSolid()) {
                return false;
            }
            $cx += $dx;
            $cy += $dy;
            $cz += $dz;
        }
        return true;
    }

    public static function hasHeightClearance(Level $level, Vector3 $pos, $height = 2) {
        $bx = (int)floor($pos->x);
        $by = (int)floor($pos->y);
        $bz = (int)floor($pos->z);
        for($h = 0; $h < $height; $h++) {
            $block = $level->getBlock(new Vector3($bx, $by + $h, $bz));
            if($block->isSolid()) {
                return false;
            }
        }
        return true;
    }
}
