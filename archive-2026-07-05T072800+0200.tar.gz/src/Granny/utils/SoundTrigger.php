<?php

namespace Granny\utils;

use pocketmine\math\Vector3;
use Granny\Main;

class SoundTrigger {

public static function triggerSound(Main $plugin, Vector3 $pos, $worldName = null) {
    $range = 15;
    if ($plugin->getConfig()->exists("hearing_range")) {
        $range = $plugin->getConfig()->get("hearing_range", 15);
    }
    $rangeSq = $range * $range;
    foreach ($plugin->getGrannyEntities() as $granny) {
        if ($granny->getLevel() === null) {
            continue;
        }
        if ($worldName !== null && $granny->getLevel()->getFolderName() !== $worldName) {
            continue;
        }
        $distSq = $granny->distanceSquared($pos);
        if ($distSq <= $rangeSq) {
            $granny->hearNoise($pos, $worldName);
        }
    }
}
}
