<?php

namespace Granny\game;

use pocketmine\math\Vector3;
use pocketmine\block\Block;
use Granny\Main;

class MapReset {

    private $plugin;
    private $blockBackup = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function saveBlock(Vector3 $pos, $levelName) {
        $key = $levelName . ":" . ((int)$pos->x) . ":" . ((int)$pos->y) . ":" . ((int)$pos->z);
        if(isset($this->blockBackup[$key])) {
            return;
        }
        $level = $this->plugin->getServer()->getLevelByName($levelName);
        if($level === null) {
            return;
        }
        $block = $level->getBlock($pos);
        $this->blockBackup[$key] = [
            "level" => $levelName,
            "x" => (int)$pos->x,
            "y" => (int)$pos->y,
            "z" => (int)$pos->z,
            "id" => $block->getId(),
            "meta" => $block->getDamage()
        ];
    }

    public function restoreMap() {
        foreach($this->blockBackup as $data) {
            $level = $this->plugin->getServer()->getLevelByName($data["level"]);
            if($level === null) {
                continue;
            }
            $level->setBlock(
                new Vector3($data["x"], $data["y"], $data["z"]),
                Block::get($data["id"], $data["meta"]),
                true,
                true
            );
        }
        $this->blockBackup = [];
    }

    public function clear() {
        $this->blockBackup = [];
    }
}
