<?php

namespace Granny\game;

use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\scheduler\PluginTask;
use Granny\Main;

class LobbyManager {

    private $plugin;
    private $queue = [];
    private $countdownTaskId = null;
    private $countdown = 0;
    private $inventoryBackup = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function addPlayer(Player $player) {
        $name = $player->getName();
        if(in_array($name, $this->queue)) {
            $player->sendMessage("§cYou are already in the queue.");
            return false;
        }

        $am = $this->plugin->getArenaManager();
        if ($am !== null && $am->getPlayerSession($name) !== null) {
            $player->sendMessage("§cYou are already in a game.");
            return false;
        }

        $max = (int)$this->plugin->getConfigValue("game.max_players", 6);
        if(count($this->queue) >= $max) {
            $player->sendMessage("§cThe game is full.");
            return false;
        }

        $this->queue[] = $name;
        

        $this->backupAndClearPlayer($player);
        $this->teleportToLobby($player);

        $this->broadcastQueue("§e" . $name . " §ajoined! §7(" . count($this->queue) . "/" . $max . ")");

        $min = (int)$this->plugin->getConfigValue("game.min_players", 1);
        if(count($this->queue) >= $min && $this->countdownTaskId === null) {
            $this->startCountdown();
        }

        return true;
    }

    public function removePlayer(Player $player) {
        $name = $player->getName();
        $key = array_search($name, $this->queue);
        if($key === false) {
            return false;
        }

        unset($this->queue[$key]);
        $this->queue = array_values($this->queue);
        

        $this->restorePlayer($player);

        $this->broadcastQueue("§e" . $name . " §cleft the queue.");

        $min = (int)$this->plugin->getConfigValue("game.min_players", 1);
        if(count($this->queue) < $min && $this->countdownTaskId !== null) {
            $this->cancelCountdown();
            $this->broadcastQueue("§cNot enough players. Countdown cancelled.");
        }

        return true;
    }

    private function startCountdown() {
        $this->countdown = (int)$this->plugin->getConfigValue("game.lobby_countdown", 20);
        $task = new LobbyCountdownTask($this->plugin, $this);
        $handler = $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($task, 20);
        $this->countdownTaskId = $handler->getTaskId();
    }

    public function cancelCountdown() {
        if($this->countdownTaskId !== null) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->countdownTaskId);
            $this->countdownTaskId = null;
        }
    }

    public function tickCountdown() {
        if ($this->countdown <= 0) {
            $this->cancelCountdown();
            $this->broadcastQueue("§ePreparing the game...");
            $queue = $this->queue;
            $this->queue = [];
            $plugin = $this->plugin;
            $plugin->scheduleTask(function() use ($plugin, $queue) {
                $session = $plugin->getArenaManager()->startGameForQueue($queue);
                if ($session === null) {
                    foreach ($queue as $name) {
                        $p = $plugin->getServer()->getPlayerExact($name);
                        if ($p !== null) {
                            $p->sendMessage("§cFailed to prepare game world! Is template set?");
                            $plugin->getLobbyManager()->restorePlayer($p);
                        }
                    }
                }
            }, 40);
            return;
        }

        if ($this->countdown <= 5 || $this->countdown % 10 === 0) {
            $this->broadcastQueue("§eGame starts in §c" . $this->countdown . "§e seconds!");
        }

        $this->countdown--;
    }

    public function getQueue() {
        return $this->queue;
    }

    public function isInQueue($playerName) {
        return in_array($playerName, $this->queue);
    }

    public function resetQueue() {
        $this->cancelCountdown();
        $this->queue = [];
    }

    private function teleportToLobby(Player $player) {
        $x = (float)$this->plugin->getConfigValue("lobby.x", 0);
        $y = (float)$this->plugin->getConfigValue("lobby.y", 64);
        $z = (float)$this->plugin->getConfigValue("lobby.z", 0);
        $worldName = $this->plugin->getConfigValue("lobby.world", "world");
        $level = $this->plugin->getServer()->getLevelByName($worldName);
        if($level === null) {
            $this->plugin->getServer()->loadLevel($worldName);
            $level = $this->plugin->getServer()->getLevelByName($worldName);
        }
        if($level !== null) {
            $player->teleport(new Vector3($x, $y, $z));
        }
    }

    private function backupAndClearPlayer(Player $player) {
        $contents = [];
        for($i = 0; $i < $player->getInventory()->getSize(); $i++) {
            $contents[$i] = $player->getInventory()->getItem($i);
        }
        $this->inventoryBackup[strtolower($player->getName())] = $contents;
        $player->getInventory()->clearAll();
    }

    public function restorePlayer(Player $player) {
        $name = $player->getName();
        $backup = isset($this->inventoryBackup[strtolower($name)]) ? $this->inventoryBackup[strtolower($name)] : null;
        unset($this->inventoryBackup[strtolower($name)]);
        if($backup !== null) {
            $player->getInventory()->clearAll();
            foreach($backup as $slot => $item) {
                $player->getInventory()->setItem($slot, $item);
            }
        }
        $player->removeAllEffects();
    }

    private function broadcastQueue($msg) {
        foreach($this->queue as $name) {
            $p = $this->plugin->getServer()->getPlayerExact($name);
            if($p !== null) {
                $p->sendMessage($msg);
            }
        }
    }
}

class LobbyCountdownTask extends PluginTask {

    private $lobbyManager;

    public function __construct(Main $plugin, LobbyManager $lobbyManager) {
        parent::__construct($plugin);
        $this->lobbyManager = $lobbyManager;
    }

    public function onRun($currentTick) {
        $this->lobbyManager->tickCountdown();
    }
}
