<?php

namespace Granny\game;

class PlayerState {

    const STATE_NONE = 0;
    const STATE_LOBBY = 1;
    const STATE_ALIVE = 2;
    const STATE_DOWNED = 3;
    const STATE_CAPTURED = 4;
    const STATE_ESCAPED = 5;

    private $states = [];
    private $inventoryBackup = [];

    public function getState($playerName) {
        return isset($this->states[$playerName]) ? $this->states[$playerName] : self::STATE_NONE;
    }

    public function setState($playerName, $state) {
        $this->states[$playerName] = $state;
    }

    public function isInGame($playerName) {
        $s = $this->getState($playerName);
        return $s === self::STATE_ALIVE || $s === self::STATE_DOWNED || $s === self::STATE_CAPTURED;
    }

    public function isAlive($playerName) {
        return $this->getState($playerName) === self::STATE_ALIVE;
    }

    public function getAlivePlayerNames() {
        $alive = [];
        foreach($this->states as $name => $state) {
            if($state === self::STATE_ALIVE) {
                $alive[] = $name;
            }
        }
        return $alive;
    }

    public function getInGamePlayerNames() {
        $inGame = [];
        foreach($this->states as $name => $state) {
            if($state === self::STATE_ALIVE || $state === self::STATE_DOWNED) {
                $inGame[] = $name;
            }
        }
        return $inGame;
    }

    public function getPlayerCount() {
        $count = 0;
        foreach($this->states as $state) {
            if($state >= self::STATE_LOBBY && $state <= self::STATE_ESCAPED) {
                $count++;
            }
        }
        return $count;
    }

    public function removePlayer($playerName) {
        unset($this->states[$playerName]);
        unset($this->inventoryBackup[$playerName]);
    }

    public function setInventoryBackup($playerName, $contents) {
        $this->inventoryBackup[$playerName] = $contents;
    }

    public function getInventoryBackup($playerName) {
        return isset($this->inventoryBackup[$playerName]) ? $this->inventoryBackup[$playerName] : null;
    }

    public function resetAll() {
        $this->states = [];
        $this->inventoryBackup = [];
    }

    public function getAllStates() {
        return $this->states;
    }
}
