<?php

namespace Granny\game;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\item\Item;
use pocketmine\utils\Config;
use Granny\Main;

class MainLobby {

    private $plugin;
    private $playerData;
    private $inLobby = [];
    private $inOptions = [];

    const PLAY_ITEM = 388;
    const OPTIONS_ITEM = 345;
    const CHAPTERS_ITEM = 340;
    const QUIT_ITEM = 355;
    const INFO_ITEM = 339;
    const BACK_ITEM = 262;

    const EASY_ITEM = 35;
    const EASY_META = 5;
    const NORMAL_ITEM = 35;
    const NORMAL_META = 4;
    const HARD_ITEM = 35;
    const HARD_META = 14;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->playerData = new Config(
            $plugin->getDataFolder() . "playerdata.yml",
            Config::YAML,
            []
        );
    }

    public function enterLobby(Player $player) {
        $name = strtolower($player->getName());
        $this->inLobby[$name] = true;
        unset($this->inOptions[$name]);

        $this->teleportToLobby($player);
        $player->setGamemode(2);
        $player->removeAllEffects();
        $this->giveHotbar($player);

        $diff = $this->getDifficulty($player->getName());
        $player->sendMessage("§6§l[GRANNY] §r§7Welcome to Granny!");
        $player->sendMessage("§7Difficulty: §f" . ucfirst($diff));
        $this->plugin->getServer()->getCommandMap()->dispatch($player, "music play granny");
    }

    public function leaveLobby(Player $player) {
        $name = strtolower($player->getName());
        unset($this->inLobby[$name]);
        unset($this->inOptions[$name]);
        $player->getInventory()->clearAll();
    }

    public function isInLobby($playerName) {
        return isset($this->inLobby[strtolower($playerName)]);
    }

    public function isInOptions($playerName) {
        return isset($this->inOptions[strtolower($playerName)]);
    }

    public function giveHotbar(Player $player) {
        $inv = $player->getInventory();
        $inv->clearAll();

        $play = Item::get(self::PLAY_ITEM, 0, 1);
        $play->setCustomName("§r§a§lPlay");

        $options = Item::get(self::OPTIONS_ITEM, 0, 1);
        $options->setCustomName("§r§e§lOptions");

        $chapters = Item::get(self::CHAPTERS_ITEM, 0, 1);
        $chapters->setCustomName("§r§b§lSwitch Chapters");

        $info = Item::get(self::INFO_ITEM, 0, 1);
        $info->setCustomName("§r§f§lInfo");

        $quit = Item::get(self::QUIT_ITEM, 0, 1);
        $quit->setCustomName("§r§c§lQuit");

        $inv->setItem(0, $play);
        $inv->setItem(2, $options);
        $inv->setItem(4, $chapters);
        $inv->setItem(6, $info);
        $inv->setItem(8, $quit);
    }

    public function giveOptionsMenu(Player $player) {
        $name = strtolower($player->getName());
        $this->inOptions[$name] = true;
        $inv = $player->getInventory();
        $inv->clearAll();

        $currentDiff = $this->getDifficulty($player->getName());

        $easy = Item::get(self::EASY_ITEM, self::EASY_META, 1);
        $easy->setCustomName("§r" . ($currentDiff === "easy" ? "§a§l> Easy §r§7[Selected]" : "§fEasy"));

        $normal = Item::get(self::NORMAL_ITEM, self::NORMAL_META, 1);
        $normal->setCustomName("§r" . ($currentDiff === "normal" ? "§e§l> Normal §r§7[Selected]" : "§fNormal"));

        $hard = Item::get(self::HARD_ITEM, self::HARD_META, 1);
        $hard->setCustomName("§r" . ($currentDiff === "hard" ? "§c§l> Hard §r§7[Selected]" : "§fHard"));

        $back = Item::get(self::BACK_ITEM, 0, 1);
        $back->setCustomName("§r§7§lBack");

        $inv->setItem(1, $easy);
        $inv->setItem(3, $normal);
        $inv->setItem(5, $hard);
        $inv->setItem(8, $back);
    }

    public function handleInteract(Player $player, Item $item) {
        $name = strtolower($player->getName());
        if (!$this->isInLobby($name)) return false;

        $id = $item->getId();
        $meta = $item->getDamage();

        if ($this->isInOptions($name)) {
            return $this->handleOptionsClick($player, $id, $meta);
        }

        return $this->handleHotbarClick($player, $id);
    }

    private function handleHotbarClick(Player $player, $id) {
        switch ($id) {
            case self::PLAY_ITEM:
                $this->leaveLobby($player);
                $this->plugin->getLobbyManager()->addPlayer($player);
                return true;

            case self::OPTIONS_ITEM:
                $this->giveOptionsMenu($player);
                return true;

            case self::CHAPTERS_ITEM:
                $player->sendMessage("§e§l[GRANNY] §r§7This feature is yet to be added!");
                $pk = new \pocketmine\network\protocol\LevelEventPacket();
                $pk->evid = \pocketmine\network\protocol\LevelEventPacket::EVENT_SOUND_ANVIL_BREAK;
                $pk->x = $player->x;
                $pk->y = $player->y;
                $pk->z = $player->z;
                $pk->data = 0;
                $player->dataPacket($pk);
                return true;

            case self::INFO_ITEM:
                $player->sendMessage("§6§l=====================");
                $player->sendMessage("§f§lWelcome to §r§cGranny§f§l.");
                $player->sendMessage("§6§l=====================");
                $player->sendMessage("");
                $player->sendMessage("§7Granny keeps you locked in her house.");
                $player->sendMessage("§7Now you have to try to get out of her");
                $player->sendMessage("§7house but be careful and quiet.");
                $player->sendMessage("§7She hears everything.");
                $player->sendMessage("");
                $player->sendMessage("§7If you drop something on the floor,");
                $player->sendMessage("§7she hears it and comes running.");
                $player->sendMessage("§7You have §f5 days§7.");
                $player->sendMessage("");
                $player->sendMessage("§eGood luck!");
                $player->sendMessage("§6§l=====================");
                return true;

            case self::QUIT_ITEM:
                $this->leaveLobby($player);
                $this->plugin->getServer()->dispatchCommand($player, "hub");
                $this->plugin->getServer()->dispatchCommand($player, "music stop");
                return true;
        }
        return false;
    }

    private function handleOptionsClick(Player $player, $id, $meta) {
        $name = $player->getName();

        if ($id === self::EASY_ITEM && $meta === self::EASY_META) {
            $this->setDifficulty($name, "easy");
            $player->sendMessage("§a§l[GRANNY] §r§7Difficulty set to §aEasy");
            $this->giveOptionsMenu($player);
            return true;
        }

        if ($id === self::NORMAL_ITEM && $meta === self::NORMAL_META) {
            $this->setDifficulty($name, "normal");
            $player->sendMessage("§e§l[GRANNY] §r§7Difficulty set to §eNormal");
            $this->giveOptionsMenu($player);
            return true;
        }

        if ($id === self::HARD_ITEM && $meta === self::HARD_META) {
            $this->setDifficulty($name, "hard");
            $player->sendMessage("§c§l[GRANNY] §r§7Difficulty set to §cHard");
            $this->giveOptionsMenu($player);
            return true;
        }

        if ($id === self::BACK_ITEM) {
            unset($this->inOptions[strtolower($name)]);
            $this->giveHotbar($player);
            return true;
        }

        return false;
    }

    public function getDifficulty($playerName) {
        $all = $this->playerData->getAll();
        $key = strtolower($playerName);
        return isset($all[$key]["difficulty"]) ? $all[$key]["difficulty"] : "normal";
    }

    public function setDifficulty($playerName, $difficulty) {
        $all = $this->playerData->getAll();
        $key = strtolower($playerName);
        if (!isset($all[$key])) $all[$key] = [];
        $all[$key]["difficulty"] = $difficulty;
        $this->playerData->setAll($all);
        $this->playerData->save();
    }

    public function getDifficultyScaling($playerName) {
        $diff = $this->getDifficulty($playerName);
        switch ($diff) {
            case "easy":
                return ["speed" => 0.7, "detection" => 0.6];
            case "hard":
                return ["speed" => 1.3, "detection" => 1.4];
            default:
                return ["speed" => 1.0, "detection" => 1.0];
        }
    }

    private function teleportToLobby(Player $player) {
        $x = (float)$this->plugin->getConfigValue("lobby.x", 0);
        $y = (float)$this->plugin->getConfigValue("lobby.y", 64);
        $z = (float)$this->plugin->getConfigValue("lobby.z", 0);
        $worldName = $this->plugin->getConfigValue("lobby.world", "world");
        $level = $this->plugin->getServer()->getLevelByName($worldName);
        if ($level === null) {
            $this->plugin->getServer()->loadLevel($worldName);
            $level = $this->plugin->getServer()->getLevelByName($worldName);
        }
        if ($level !== null) {
            $player->teleport(new Position($x, $y, $z, $level));
        }
    }

    public function handleQuit($playerName) {
        $name = strtolower($playerName);
        unset($this->inLobby[$name]);
        unset($this->inOptions[$name]);
    }
}