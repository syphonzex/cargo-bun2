<?php

namespace Granny\game;

use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;
use pocketmine\entity\Effect;
use pocketmine\item\Item;
use pocketmine\scheduler\PluginTask;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ShortTag;
use Granny\Main;
use Granny\entity\GrannyEntity;

class GameManager {

    const PHASE_IDLE = 0;
    const PHASE_LOBBY = 1;
    const PHASE_INGAME = 2;
    const PHASE_ENDING = 3;

    private $plugin;
    private $playerState;
    private $phase = self::PHASE_IDLE;
    private $roundTimer = 0;
    private $roundTaskId = null;
    private $granny = null;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->playerState = new PlayerState();
    }

    public function getPlayerState() {
        return $this->playerState;
    }

    public function getPhase() {
        return $this->phase;
    }

    public function getGranny() {
        return $this->granny;
    }

    public function startGame(array $playerNames) {
        $wm = $this->plugin->getWorldManager();
        $worldName = $wm->prepareWorld();

        if ($worldName === null) {
            $this->broadcastLobby("§cFailed to prepare game world! Is template set?");
            $this->phase = self::PHASE_IDLE;
            return;
        }

        $this->phase = self::PHASE_INGAME;
        $this->roundTimer = (int)$this->plugin->getConfigValue("game.round_time", 300);

        $playerCount = count($playerNames);
        $scaling = $this->getScaling($playerCount);

        foreach($playerNames as $name) {
            $player = $this->plugin->getServer()->getPlayerExact($name);
            if($player === null) {
                continue;
            }
            $this->playerState->setState($name, PlayerState::STATE_ALIVE);
            $this->teleportToStart($player);
            $player->getInventory()->clearAll();
            $player->getInventory()->addItem(Item::get(50, 0, 1));
            $player->setGamemode(0);
            $player->setHealth($player->getMaxHealth());
            $player->removeAllEffects();
            $player->sendTip("§lDAY 1§r\n\n\n\n\n");
        }

        $this->plugin->getItemManager()->spawnItems();

        $this->plugin->getLockManager()->restoreAllLocks();
        $this->plugin->getEscapeManager()->restoreAll();

        $presetPicked = $this->plugin->getChestManager()->fillChestsWithRandomPreset();
        if ($presetPicked !== null) {
           // $this->broadcastGame("§7Chest items loaded. §8[Preset: " . $presetPicked . "]");
        }

        $delay = (int)$this->plugin->getConfigValue("game.granny_spawn_delay", 5) * 20;
        $spawnTask = new GrannySpawnTask($this->plugin, $scaling);
        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask($spawnTask, $delay);

        $roundTask = new RoundTickTask($this->plugin);
        $handler = $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($roundTask, 20);
        $this->roundTaskId = $handler->getTaskId();

        //$this->broadcastGame("§4§lGAME STARTED! §r§7Escape before time runs out!");

        $this->plugin->getCutsceneManager()->playSceneForAll("wake");
    }

    public function tickRound() {
        if($this->phase !== self::PHASE_INGAME) {
            return;
        }

        $this->roundTimer--;

        $alive = $this->playerState->getAlivePlayerNames();
        $aliveCount = count($alive);

        if ($aliveCount <= 0) {
            $this->endGame(false);
            return;
        }

        if($this->roundTimer <= 0) {
            $this->endGame(false);
            return;
        }
    }

    public function playerEscaped(Player $player) {
        $name = $player->getName();
        $this->playerState->setState($name, PlayerState::STATE_ESCAPED);
        //$this->broadcastGame("§a" . $name . " §fhas escaped!");
        $this->plugin->getCutsceneManager()->playScene("ending", $player);

        $alive = $this->playerState->getAlivePlayerNames();
        if(count($alive) <= 0) {
            $this->endGame(true);
        }
    }

    public function playerCaptured(Player $player) {
        $name = $player->getName();
        $dm = $this->plugin->getDayManager();
        $day = $dm->getDay($name);

        if ($day >= 5) {
            $this->playerState->setState($name, PlayerState::STATE_CAPTURED);
            $player->sendPopup("§e§lLoading cinematics..");
           // $this->broadcastGame("§4" . $name . " §7was eliminated on Day 5!");
            $this->plugin->getCutsceneManager()->playScene("gameover", $player);
            $this->teleportToStart($player);
            $player->setGamemode(3);
            $dm->resetDay($name);

            $alive = $this->playerState->getAlivePlayerNames();
            if (count($alive) <= 0) {
                $this->endGame(false);
            }
            return;
        }

        $dm->setDay($name, $day + 1);
        $newDay = $day + 1;

        $player->sendTip("§c§lDay " . $newDay . "§r\n\n\n\n\n");
       // $this->broadcastGame("§c" . $name . " §7was caught! §eDay " . $newDay);

        $this->teleportToStart($player);
        $player->setHealth($player->getMaxHealth());
        $player->removeAllEffects();

        if ($this->granny !== null && !$this->granny->closed) {
            $this->granny->resetToSpawn();
            $this->granny->setFrozen(true);
        }

        $cm = $this->plugin->getCutsceneManager();
        $points = $cm->getPoints("wake");
        if (count($points) >= 2) {
            $cm->playScene("wake", $player);

            $totalTime = 0;
            foreach ($points as $i => $pt) {
                if ($i > 0) $totalTime += $pt["seconds"];
                if (isset($pt["cut"])) $totalTime += $pt["cut"];
            }
            $unfreezeDelay = (int)round(($totalTime + 1) * 20);

            $granny = $this->granny;
            $this->plugin->scheduleTask(function() use ($granny) {
                if ($granny !== null && !$granny->closed) {
                    $granny->setFrozen(false);
                }
            }, $unfreezeDelay);
        }
    }

    public function endGame($playersWon) {
        $this->phase = self::PHASE_ENDING;

        if($this->roundTaskId !== null) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->roundTaskId);
            $this->roundTaskId = null;
        }

        if ($playersWon) {
            //$this->broadcastGame("§a§lPLAYERS WIN! §r§7Escaped from Granny!");
        } else {
           // $this->broadcastGame("§c§lGRANNY WINS! §r§7No one escaped...");
        }

        $resetTask = new GameResetTask($this->plugin);
        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask($resetTask, 100);
    }

    public function resetGame() {
        $this->plugin->cleanupEntities();
        $this->granny = null;

        foreach($this->playerState->getAllStates() as $name => $state) {
            $player = $this->plugin->getServer()->getPlayerExact($name);
            if($player !== null) {
                $player->removeAllEffects();
                $player->setGamemode(0);
                $this->plugin->getLobbyManager()->restorePlayer($player);
                $this->teleportToLobby($player);
            }
        }

        $this->playerState->resetAll();
        $this->plugin->getTrapManager()->resetAll();
        $this->plugin->getDayManager()->resetAll();
        $this->plugin->getItemManager()->clearItems();
        $this->plugin->getChestManager()->clearAllChests();
        $this->plugin->getLockManager()->restoreAllLocks();
        $this->plugin->getEscapeManager()->restoreAll();
        $this->plugin->getMapReset()->restoreMap();
        $this->plugin->getWorldManager()->destroyWorld();
        $this->phase = self::PHASE_IDLE;
    }

    public function spawnGranny($scaling) {
        $x = (float)$this->plugin->getConfigValue("granny_spawn.x", 0);
        $y = (float)$this->plugin->getConfigValue("granny_spawn.y", 64);
        $z = (float)$this->plugin->getConfigValue("granny_spawn.z", 0);
        $level = $this->plugin->getWorldManager()->getActiveLevel();
        if ($level === null) {
            $worldName = $this->plugin->getConfigValue("granny_spawn.world", "world");
            $level = $this->plugin->getServer()->getLevelByName($worldName);
            if ($level === null) {
                $this->plugin->getServer()->loadLevel($worldName);
                $level = $this->plugin->getServer()->getLevelByName($worldName);
            }
        }
        if ($level === null) {
            return;
        }

        $skinData = $this->plugin->getGrannySkin();
        $skinId = $this->plugin->getGrannySkinId();
        if ($skinData === null) {
            $skinPlayer = null;
            foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                $skinPlayer = $p;
                break;
            }
            if ($skinPlayer === null) {
                return;
            }
            $skinData = $skinPlayer->getSkinData();
            $skinId = $skinPlayer->getSkinId();
        }

        $nbt = new CompoundTag("", [
            "Pos" => new ListTag("Pos", [
                new DoubleTag("", $x),
                new DoubleTag("", $y),
                new DoubleTag("", $z)
            ]),
            "Motion" => new ListTag("Motion", [
                new DoubleTag("", 0),
                new DoubleTag("", 0),
                new DoubleTag("", 0)
            ]),
            "Rotation" => new ListTag("Rotation", [
                new FloatTag("", 0),
                new FloatTag("", 0)
            ]),
            "Skin" => new CompoundTag("Skin", [
                "Data" => new StringTag("Data", $skinData),
                "Name" => new StringTag("Name", $skinId)
            ]),
            "Health" => new ShortTag("Health", 200)
        ]);

        $chunk = $level->getChunk(((int)$x) >> 4, ((int)$z) >> 4, true);
        $granny = Entity::createEntity("GrannyEntity", $chunk, $nbt);
        if($granny !== null) {
            if($granny instanceof GrannyEntity) {
                $granny->setSpeedMultiplier(isset($scaling["speed_multiplier"]) ? (float)$scaling["speed_multiplier"] : 1.0);
                $granny->setDetectionMultiplier(isset($scaling["detection_multiplier"]) ? (float)$scaling["detection_multiplier"] : 1.0);
            }
            $granny->spawnToAll();
            $this->granny = $granny;
        }
    }

    public function handlePlayerQuit(Player $player) {
        $name = $player->getName();
        if($this->plugin->getLobbyManager()->isInQueue($name)) {
            $this->plugin->getLobbyManager()->removePlayer($player);
            return;
        }
        if($this->playerState->isInGame($name)) {
            $this->playerState->setState($name, PlayerState::STATE_CAPTURED);
            $this->broadcastGame("§c" . $name . " §7disconnected.");
            $alive = $this->playerState->getAlivePlayerNames();
            if(count($alive) <= 0 && $this->phase === self::PHASE_INGAME) {
                $this->endGame(false);
            }
        }
    }

    private function teleportToStart(Player $player) {
        $x = (float)$this->plugin->getConfigValue("start_room.x", 0);
        $y = (float)$this->plugin->getConfigValue("start_room.y", 64);
        $z = (float)$this->plugin->getConfigValue("start_room.z", 0);
        $level = $this->plugin->getWorldManager()->getActiveLevel();
        if ($level !== null) {
            $player->teleport(new \pocketmine\level\Position($x, $y, $z, $level));
        } else {
            $player->teleport(new Vector3($x, $y, $z));
        }
    }

    private function teleportToLobby(Player $player) {
        $x = (float)$this->plugin->getConfigValue("lobby.x", 0);
        $y = (float)$this->plugin->getConfigValue("lobby.y", 64);
        $z = (float)$this->plugin->getConfigValue("lobby.z", 0);
        $player->teleport(new Vector3($x, $y, $z));
    }

    private function getScaling($playerCount) {
        $key = (string)min($playerCount, 4);
        $scaling = $this->plugin->getConfigValue("scaling." . $key, null);
        if(!is_array($scaling)) {
            return ["speed_multiplier" => 1.0, "detection_multiplier" => 1.0];
        }
        return $scaling;
    }

    private function broadcastLobby($msg) {
        foreach ($this->plugin->getLobbyManager()->getQueue() as $name) {
            $p = $this->plugin->getServer()->getPlayerExact($name);
            if ($p !== null) {
                $p->sendMessage($msg);
            }
        }
    }

    private function broadcastGame($msg) {
        foreach($this->playerState->getAllStates() as $name => $state) {
            $p = $this->plugin->getServer()->getPlayerExact($name);
            if($p !== null) {
                $p->sendMessage($msg);
            }
        }
    }

    
}

class RoundTickTask extends PluginTask {

    public function __construct(Main $plugin) {
        parent::__construct($plugin);
    }

    public function onRun($currentTick) {
        $this->getOwner()->getGameManager()->tickRound();
    }
}

class GrannySpawnTask extends PluginTask {

    private $scaling;

    public function __construct(Main $plugin, $scaling) {
        parent::__construct($plugin);
        $this->scaling = $scaling;
    }

    public function onRun($currentTick) {
        $this->getOwner()->getGameManager()->spawnGranny($this->scaling);
    }
}

class GameResetTask extends PluginTask {

    public function __construct(Main $plugin) {
        parent::__construct($plugin);
    }

    public function onRun($currentTick) {
        $this->getOwner()->getGameManager()->resetGame();
    }
}
