<?php

namespace Granny\game;

use pocketmine\Player;
use Granny\Main;

class ArenaManager {

    private $plugin;
    private $sessions = [];
    private $playerSession = [];
    private $nextId = 1;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function createSession() {
        $wm = $this->plugin->getWorldManager();
        $worldName = $wm->prepareWorldCopy();
        if ($worldName === null) {
            return null;
        }

        $id = $this->nextId++;
        $session = new GameSession($this->plugin, $id, $worldName);
        $this->sessions[$id] = $session;
        return $session;
    }

    public function removeSession($id) {
        if (!isset($this->sessions[$id])) return;

        $session = $this->sessions[$id];

        foreach ($session->getPlayers() as $name) {
            unset($this->playerSession[strtolower($name)]);
        }

        $worldName = $session->getWorldName();
        $this->plugin->getWorldManager()->destroyWorldCopy($worldName);
        unset($this->sessions[$id]);
    }

    public function getSession($id) {
        return isset($this->sessions[$id]) ? $this->sessions[$id] : null;
    }

    public function getSessions() {
        return $this->sessions;
    }

    public function getPlayerSession($playerName) {
        $key = strtolower($playerName);
        if (!isset($this->playerSession[$key])) return null;
        $id = $this->playerSession[$key];
        return isset($this->sessions[$id]) ? $this->sessions[$id] : null;
    }

    public function assignPlayer($playerName, $sessionId) {
        $this->playerSession[strtolower($playerName)] = $sessionId;
    }

    public function unassignPlayer($playerName) {
        unset($this->playerSession[strtolower($playerName)]);
    }

    public function startGameForQueue(array $playerNames) {
        $session = $this->createSession();
        if ($session === null) {
            return null;
        }

        foreach ($playerNames as $name) {
            $this->assignPlayer($name, $session->getId());
        }

        $session->startGame($playerNames);
        return $session;
    }

    public function handlePlayerQuit(Player $player) {
        $session = $this->getPlayerSession($player->getName());
        if ($session !== null) {
            $session->handlePlayerQuit($player);
            $this->unassignPlayer($player->getName());
        }
    }

    public function cleanupAll() {
        foreach ($this->sessions as $id => $session) {
            $session->cleanup();
            $worldName = $session->getWorldName();
            $this->plugin->getWorldManager()->destroyWorldCopy($worldName);
        }
        $this->sessions = [];
        $this->playerSession = [];
    }

    public function getActiveCount() {
        return count($this->sessions);
    }
}
