<?php

namespace Granny\listener;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\entity\Effect;
use pocketmine\network\protocol\LevelEventPacket;
use Granny\Main;
use Granny\entity\GrannyEntity;
use Granny\utils\SoundTrigger;
use Granny\utils\LineOfSight;
use Granny\game\GameManager;
use Granny\game\PlayerState;

class GrannyListener implements Listener {

    private $plugin;
    private $moveCooldowns = [];
    private $hiddenPlayers = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

public function onBlockPlace(BlockPlaceEvent $event) {
    $player = $event->getPlayer();
    $name = $player->getName();

    $lm = $this->plugin->getLockManager();
    $em = $this->plugin->getEscapeManager();

    if ($lm->isInBuildMode($name)) {
        $block = $event->getBlock();
        $replaced = $event->getBlockReplaced();
        $lm->trackBlock($name, $block, $player->getLevel()->getName(), $replaced->getId(), $replaced->getDamage());
        $lockName = $lm->getBuildLockName($name);
        $player->sendTip("§e+1 block §7added to §f" . $lockName);
        return;
    }

    if ($em->isInBuildMode($name)) {
        $block = $event->getBlock();
        $replaced = $event->getBlockReplaced();
        $em->trackBlock($name, $block, $player->getLevel()->getName(), $replaced->getId(), $replaced->getDamage());
        $ctx = $em->getBuildContext($name);
        $player->sendTip("§e+1 block §7(" . $ctx["type"] . ") §ffor §e" . $ctx["part"]);
        return;
    }

    $session = $this->plugin->getArenaManager()->getPlayerSession($name);
    if ($session !== null && $session->getPhase() === \Granny\game\GameSession::PHASE_INGAME) {
        $event->setCancelled(true);
        return;
    }
}

    public function onPlayerMove(PlayerMoveEvent $event) {
        $player = $event->getPlayer();
        $name = $player->getName();

        if (!$this->isActivePlayer($player)) {
            return;
        }

        if ($player->isSneaking()) {
            return;
        }

        $from = $event->getFrom();
        $to = $event->getTo();
        $dx = $to->x - $from->x;
        $dy = $to->y - $from->y;
        $dz = $to->z - $from->z;
        $distSq = $dx * $dx + $dy * $dy + $dz * $dz;

        if ($distSq < 0.01) {
            return;
        }

        $now = microtime(true);
        if (isset($this->moveCooldowns[$name]) && ($now - $this->moveCooldowns[$name]) < 1.0) {
            return;
        }
        $this->moveCooldowns[$name] = $now;
    }

    public function onPlayerDropItem(PlayerDropItemEvent $event) {
        $player = $event->getPlayer();
        if (!$this->isActivePlayer($player)) {
            return;
        }

        $item = $event->getItem();
        if ($this->plugin->getItemManager()->isDistraction($item)) {
            $range = 20;
        } else {
            $range = (int)$this->plugin->getConfigValue("sound_detection.item_drop", 12);
        }

        $pos = new Vector3($player->x, $player->y, $player->z);
        SoundTrigger::triggerSound($this->plugin, $pos, $range);
        $this->playAlertSound($pos, $player->getLevel());
    }

public function onBlockBreak(BlockBreakEvent $event) {
    $player = $event->getPlayer();
    if (!$this->isActivePlayer($player)) {
        return;
    }

    $session = $this->plugin->getArenaManager()->getPlayerSession($player->getName());
    if ($session !== null && $session->getPhase() === \Granny\game\GameSession::PHASE_INGAME) {
        $event->setCancelled(true);
        return;
    }

    $this->plugin->getMapReset()->saveBlock($event->getBlock(), $player->getLevel()->getName());
}

    public function onPlayerInteract(PlayerInteractEvent $event) {
        $player = $event->getPlayer();
        $block = $event->getBlock();

        $ml = $this->plugin->getMainLobby();
        if ($ml->isInLobby($player->getName())) {
            if ($ml->handleInteract($player, $player->getInventory()->getItemInHand())) {
                $event->setCancelled(true);
                return;
            }
        }

        if ($this->plugin->getTrapManager()->isTrapped($player->getName())) {
            $this->plugin->getTrapManager()->handleEscapeTap($player);
            $event->setCancelled(true);
            return;
        }

        $cm = $this->plugin->getChestManager();
        if ($cm->isInRegisterMode($player->getName())) {
            if ($block->getId() === 54) {
                $preset = $cm->getRegisterPreset($player->getName());
                $result = $cm->registerChest($preset, $block, $player->getLevel()->getName());
                if ($result === true) {
                    $player->sendMessage("§aChest registered to preset §e" . $preset . " §aat §f" . ((int)$block->x) . " " . ((int)$block->y) . " " . ((int)$block->z));
                } elseif ($result === "exists") {
                    $player->sendMessage("§cThis chest is already in preset §e" . $preset);
                } else {
                    $player->sendMessage("§cPreset §e" . $preset . " §cnot found.");
                }
                $cm->setRegisterMode($player->getName(), false);
                $event->setCancelled(true);
                return;
            }
        }

        $lm = $this->plugin->getLockManager();
        if ($lm->tryUnlock($player, $block)) {
            $event->setCancelled(true);
            SoundTrigger::triggerSound($this->plugin, new Vector3($block->x, $block->y, $block->z));
            return;
        }

        $esm = $this->plugin->getEscapeManager();
        if ($esm->tryUnlockPart($player, $block)) {
            $event->setCancelled(true);
            SoundTrigger::triggerSound($this->plugin, new Vector3($block->x, $block->y, $block->z));
            return;
        }

        if (!$this->isActivePlayer($player)) {
            return;
        }

        if ($this->checkEscapeDoor($player, $block)) {
            $event->setCancelled(true);
            return;
        }

        if ($block->getId() === 26 || $block->getId() === 107) {
            $this->handleHidingSpot($player, $block);
            $event->setCancelled(true);
            return;
        }

    }

    private function checkEscapeDoor(Player $player, Block $block) {
        $ex = (float)$this->plugin->getConfigValue("escape_door.x", 0);
        $ey = (float)$this->plugin->getConfigValue("escape_door.y", 64);
        $ez = (float)$this->plugin->getConfigValue("escape_door.z", 0);
        $doorPos = new Vector3($ex, $ey, $ez);

        if ($block->distance($doorPos) > 2) {
            return false;
        }

        $item = $player->getInventory()->getItemInHand();
        if (!$this->plugin->getItemManager()->isDoorKey($item)) {
            $player->sendPopup("§cYou need the Door Key to escape!");
            return true;
        }

        $session = $this->plugin->getArenaManager()->getPlayerSession($player->getName());
        if ($session !== null && $session->getPhase() === \Granny\game\GameSession::PHASE_INGAME) {
            $player->getInventory()->removeItem($item);
            $session->playerEscaped($player);
            $player->sendPopup("§a§lYOU ESCAPED!§r");
        }
        return true;
    }

    private function handleHidingSpot(Player $player, Block $block) {
        $playerPos = new Vector3($player->x, $player->y + $player->eyeHeight, $player->z);

        foreach ($this->plugin->getGrannyEntities() as $granny) {
            if ($granny->distanceSquared($player) > 64) {
                continue;
            }
            $grannyEye = new Vector3($granny->x, $granny->y + $granny->eyeHeight, $granny->z);
            if (LineOfSight::hasLineOfSight($player->getLevel(), $grannyEye, $playerPos)) {
                $granny->hearNoise(new Vector3($player->x, $player->y, $player->z));
                $player->sendPopup("§c§lGranny sees you!§r");
                return;
            }
        }

        $this->hiddenPlayers[$player->getName()] = true;
        $player->setGamemode(3);

        if ($block->getId() === 26) {
            $player->sendPopup("§7You hide under the bed...");
        } else {
            $player->sendPopup("§7You hide in the wardrobe...");
        }
    }

    public function onEntityDamage(EntityDamageEvent $event) {
        $entity = $event->getEntity();
        if ($entity instanceof GrannyEntity) {
            return;
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $event) {
        $player = $event->getPlayer();
        $name = $player->getName();

        unset($this->moveCooldowns[$name]);
        unset($this->hiddenPlayers[$name]);

        $lm = $this->plugin->getLockManager();
        if ($lm->isInBuildMode($name)) {
            $lm->cancelBuild($name);
        }

        $esm = $this->plugin->getEscapeManager();
        if ($esm->isInBuildMode($name)) {
            $esm->cancelBuild($name);
        }

        $cm = $this->plugin->getChestManager();
        if ($cm->isInRegisterMode($name)) {
            $cm->setRegisterMode($name, false);
        }

        $this->plugin->getMainLobby()->handleQuit($name);

        if ($this->plugin->getCutsceneManager()->isPlaying($name)) {
            $this->plugin->getCutsceneManager()->stopScene($player);
        }

        $this->plugin->getArenaManager()->handlePlayerQuit($player);
    }

    public function isHidden($playerName) {
        return isset($this->hiddenPlayers[$playerName]) && $this->hiddenPlayers[$playerName];
    }

    public function unhidePlayer(Player $player) {
        unset($this->hiddenPlayers[$player->getName()]);
        if ($player->getGamemode() === 3) {
            $player->setGamemode(0);
        }
    }

    private function playAlertSound(Vector3 $pos, $level) {
        $pk = new LevelEventPacket();
        $pk->evid = LevelEventPacket::EVENT_SOUND_DOOR;
        $pk->x = $pos->x;
        $pk->y = $pos->y;
        $pk->z = $pos->z;
        $pk->data = 0;
        $level->addChunkPacket(((int)$pos->x) >> 4, ((int)$pos->z) >> 4, $pk);
    }

    private function isActivePlayer(Player $player) {
        $session = $this->plugin->getArenaManager()->getPlayerSession($player->getName());
        if ($session !== null && $session->getPhase() === \Granny\game\GameSession::PHASE_INGAME) {
            return $session->getPlayerState()->isAlive($player->getName());
        }
        return count($this->plugin->getGrannyEntities()) > 0;
    }
}