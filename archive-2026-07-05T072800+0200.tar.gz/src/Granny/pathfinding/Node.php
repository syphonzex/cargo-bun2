<?php

namespace Granny\pathfinding;

use pocketmine\math\Vector3;

class Node {

    private $name;
    private $position;
    private $patrol;
    private $links = [];

    public function __construct($name, Vector3 $position, $patrol = false) {
        $this->name = $name;
        $this->position = $position;
        $this->patrol = $patrol;
    }

    public function getName() {
        return $this->name;
    }

    public function getPosition() {
        return $this->position;
    }

    public function isPatrol() {
        return $this->patrol;
    }

    public function setPatrol($patrol) {
        $this->patrol = $patrol;
    }

    public function addLink($nodeName) {
        if(!in_array($nodeName, $this->links)) {
            $this->links[] = $nodeName;
        }
    }

    public function removeLink($nodeName) {
        $key = array_search($nodeName, $this->links);
        if($key !== false) {
            unset($this->links[$key]);
            $this->links = array_values($this->links);
        }
    }

    public function getLinks() {
        return $this->links;
    }

    public function hasLink($nodeName) {
        return in_array($nodeName, $this->links);
    }

    public function distanceTo(Vector3 $pos) {
        return $this->position->distance($pos);
    }

    public function toArray() {
        return [
            "x" => $this->position->x,
            "y" => $this->position->y,
            "z" => $this->position->z,
            "patrol" => $this->patrol,
            "links" => $this->links
        ];
    }

    public static function fromArray($name, array $data) {
        $node = new Node(
            $name,
            new Vector3((float)$data["x"], (float)$data["y"], (float)$data["z"]),
            isset($data["patrol"]) ? (bool)$data["patrol"] : false
        );
        if(isset($data["links"]) && is_array($data["links"])) {
            foreach($data["links"] as $link) {
                $node->addLink($link);
            }
        }
        return $node;
    }
}
