<?php

namespace OnePiece\Fruits;

use pocketmine\Player;
use pocketmine\utils\Config;

/**
 * Mastery System for Devil Fruits
 * 
 * How it works:
 * - Every ability use gives mastery EXP
 * - Higher mastery = stronger damage, lower cooldowns
 * - Abilities are LOCKED until you reach required mastery level
 * - Hitting enemies gives bonus mastery EXP
 * - Each fruit has its own mastery progress
 * 
 * Mastery Levels:
 *   0-49     = Beginner   (only ability 1, weak)
 *   50-99    = Trained    (ability 1 improved)
 *   100-199  = Skilled    (ability 2 unlocks)
 *   200-299  = Expert     (ability 2 improved, ability 3 unlocks)
 *   300-399  = Master     (all abilities improved, ability 4 unlocks)
 *   400-499  = Grandmaster (near max power)
 *   500+     = Awakened   (can unlock awakening)
 */
class MasteryManager {

    /** @var Main */
    private $plugin;

    /** @var Config */
    private $data;

    /** @var array Cached mastery data [playerName => [fruit, exp, level]] */
    private $cache = [];

    /** @var array Cooldown for mastery exp gain [playerName => lastExpTime] */
    private $expCooldown = [];

    // ========================
    // MASTERY LEVEL THRESHOLDS
    // ========================

    const LEVELS = [
        1   => 0,      // Beginner
        2   => 25,
        3   => 50,
        4   => 80,
        5   => 120,    // Trained
        6   => 160,
        7   => 200,
        8   => 250,
        9   => 310,
        10  => 380,    // Skilled
        11  => 450,
        12  => 530,
        13  => 620,
        14  => 720,
        15  => 830,    // Expert
        16  => 950,
        17  => 1080,
        18  => 1220,
        19  => 1380,
        20  => 1550,   // Master
        21  => 1750,
        22  => 1960,
        23  => 2200,
        24  => 2460,
        25  => 2750,   // Grandmaster
        26  => 3100,
        27  => 3500,
        28  => 3950,
        29  => 4450,
        30  => 5000,   // Awakened Ready
    ];

    // ========================
    // ABILITY UNLOCK REQUIREMENTS
    // ========================

    /**
     * Which mastery level unlocks which ability slot
     * ability1 = always available (but weak at low mastery)
     * ability2 = unlocks at level 5
     * ability3 = unlocks at level 10
     * ability4 = unlocks at level 15
     * ability5 = unlocks at level 20
     * awakening = unlocks at level 25
     */
    const ABILITY_UNLOCK = [
        "ability1" => 1,
        "ability2" => 5,
        "ability3" => 10,
        "ability4" => 15,
        "ability5" => 20,
        "awakening" => 25,
    ];

    // ========================
    // EXP REWARDS
    // ========================

    const EXP_ABILITY_USE    = 3;   // Using any ability
    const EXP_ABILITY_HIT    = 5;   // Hitting a player with ability
    const EXP_ABILITY_KILL   = 15;  // Killing with ability
    const EXP_NPC_HIT        = 2;   // Hitting NPC/mob
    const EXP_NPC_KILL        = 8;   // Killing NPC/mob
    const EXP_TRANSFORM      = 4;   // Using transform (logia/zoan)
    const EXP_DODGE          = 2;   // Logia dodge

    /** Minimum seconds between exp gains (prevent spam) */
    const EXP_COOLDOWN = 2;

    // ========================
    // SCALING VALUES
    // ========================

    /**
     * Damage multiplier per mastery level
     * Level 1 = 0.4x (very weak)
     * Level 15 = 1.0x (normal)
     * Level 30 = 1.6x (very strong)
     */
    const DAMAGE_SCALE_MIN = 0.4;
    const DAMAGE_SCALE_MAX = 1.6;

    /**
     * Cooldown reduction per mastery level
     * Level 1 = 0% reduction (full cooldown)
     * Level 30 = 40% reduction
     */
    const COOLDOWN_REDUCTION_MAX = 0.40;

    /**
     * Range/radius bonus per mastery level
     * Level 1 = 0.6x range
     * Level 30 = 1.3x range
     */
    const RANGE_SCALE_MIN = 0.6;
    const RANGE_SCALE_MAX = 1.3;

    /**
     * Duration bonus per mastery level (for transforms, buffs)
     * Level 1 = 0.5x duration
     * Level 30 = 1.4x duration
     */
    const DURATION_SCALE_MIN = 0.5;
    const DURATION_SCALE_MAX = 1.4;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->data = new Config(
            $plugin->getDataFolder() . "mastery.yml",
            Config::YAML,
            []
        );
        $this->loadAll();
    }

    // ========================
    // DATA MANAGEMENT
    // ========================

    private function loadAll() {
        foreach ($this->data->getAll() as $name => $info) {
            $this->cache[$name] = [
                "fruit"  => $info["fruit"] ?? null,
                "exp"    => $info["exp"] ?? 0,
                "level"  => $info["level"] ?? 1,
                "kills"  => $info["kills"] ?? 0,
                "hits"   => $info["hits"] ?? 0,
                "uses"   => $info["uses"] ?? 0,
            ];
        }
    }

    public function save() {
        foreach ($this->cache as $name => $info) {
            $this->data->set($name, $info);
        }
        $this->data->save();
    }

    public function savePlayer($name) {
        if (isset($this->cache[$name])) {
            $this->data->set($name, $this->cache[$name]);
            $this->data->save();
        }
    }

    /**
     * Initialize mastery for a player who just ate a fruit
     */
    public function initPlayer($name, $fruitId) {
        // If player already has mastery for a DIFFERENT fruit, reset
        if (isset($this->cache[$name]) && $this->cache[$name]["fruit"] !== $fruitId) {
            $this->cache[$name] = [
                "fruit"  => $fruitId,
                "exp"    => 0,
                "level"  => 1,
                "kills"  => 0,
                "hits"   => 0,
                "uses"   => 0,
            ];
        } elseif (!isset($this->cache[$name])) {
            $this->cache[$name] = [
                "fruit"  => $fruitId,
                "exp"    => 0,
                "level"  => 1,
                "kills"  => 0,
                "hits"   => 0,
                "uses"   => 0,
            ];
        }
        $this->savePlayer($name);
    }

    /**
     * Remove mastery data (fruit removed/reset)
     */
    public function resetPlayer($name) {
        unset($this->cache[$name]);
        $this->data->remove($name);
        $this->data->save();
    }

    /**
     * Get player mastery data
     * @return array|null
     */
    public function getData($name) {
        return isset($this->cache[$name]) ? $this->cache[$name] : null;
    }

    public function getLevel($name) {
        return isset($this->cache[$name]) ? $this->cache[$name]["level"] : 0;
    }

    public function getExp($name) {
        return isset($this->cache[$name]) ? $this->cache[$name]["exp"] : 0;
    }

    public function getExpToNextLevel($name) {
        $level = $this->getLevel($name);
        $nextLevel = $level + 1;
        if (!isset(self::LEVELS[$nextLevel])) return 0; // Max level
        $currentExp = $this->getExp($name);
        return max(0, self::LEVELS[$nextLevel] - $currentExp);
    }

    public function getMaxLevel() {
        return max(array_keys(self::LEVELS));
    }

    public function isMaxLevel($name) {
        return $this->getLevel($name) >= $this->getMaxLevel();
    }

    // ========================
    // EXP GAIN
    // ========================

    /**
     * Add mastery EXP with cooldown check
     * @return bool Whether exp was actually added
     */
    public function addExp($name, $amount, $reason = "use") {
        if (!isset($this->cache[$name])) return false;
        if ($this->isMaxLevel($name)) return false;

        // Cooldown check
        $now = microtime(true);
        $key = $name . "_" . $reason;
        if (isset($this->expCooldown[$key])) {
            if ($now - $this->expCooldown[$key] < self::EXP_COOLDOWN) {
                return false;
            }
        }
        $this->expCooldown[$key] = $now;

        // Add EXP
        $oldLevel = $this->cache[$name]["level"];
        $this->cache[$name]["exp"] += $amount;

        // Track stats
        switch ($reason) {
            case "use":  $this->cache[$name]["uses"]++; break;
            case "hit":  $this->cache[$name]["hits"]++; break;
            case "kill": $this->cache[$name]["kills"]++; break;
        }

        // Check level up
        $this->checkLevelUp($name, $oldLevel);

        return true;
    }

    /**
     * Add EXP for using an ability
     */
    public function onAbilityUse(Player $player) {
        $this->addExp($player->getName(), self::EXP_ABILITY_USE, "use");
    }

    /**
     * Add EXP for hitting a player with ability
     */
    public function onAbilityHitPlayer(Player $player) {
        $name = $player->getName();
        $this->addExp($name, self::EXP_ABILITY_HIT, "hit");
    }

    /**
     * Add EXP for killing with ability
     */
    public function onAbilityKill(Player $player) {
        $name = $player->getName();
        $this->addExp($name, self::EXP_ABILITY_KILL, "kill");
    }

    /**
     * Add EXP for hitting NPC/mob
     */
    public function onNpcHit(Player $player) {
        $this->addExp($player->getName(), self::EXP_NPC_HIT, "npc_hit");
    }

    /**
     * Add EXP for killing NPC/mob
     */
    public function onNpcKill(Player $player) {
        $this->addExp($player->getName(), self::EXP_NPC_KILL, "npc_kill");
    }

    /**
     * Add EXP for transforming
     */
    public function onTransform(Player $player) {
        $this->addExp($player->getName(), self::EXP_TRANSFORM, "transform");
    }

    /**
     * Add EXP for logia dodge
     */
    public function onLogiaDodge(Player $player) {
        $this->addExp($player->getName(), self::EXP_DODGE, "dodge");
    }

    /**
     * Check if player leveled up
     */
    private function checkLevelUp($name, $oldLevel) {
        $currentExp = $this->cache[$name]["exp"];
        $newLevel = $oldLevel;

        // Find highest level reached
        foreach (self::LEVELS as $lvl => $required) {
            if ($currentExp >= $required) {
                $newLevel = $lvl;
            }
        }

        if ($newLevel > $oldLevel) {
            $this->cache[$name]["level"] = $newLevel;
            $this->savePlayer($name);

            // Notify player
            $player = $this->plugin->getServer()->getPlayer($name);
            if ($player !== null) {
                $this->sendLevelUpMessage($player, $oldLevel, $newLevel);
            }
        }
    }

    /**
     * Send level up notification
     */
    private function sendLevelUpMessage(Player $player, $oldLevel, $newLevel) {
        $player->sendMessage("§6═══════════════════════");
        $player->sendMessage("§e§l  MASTERY LEVEL UP!");
        $player->sendMessage("§6═══════════════════════");
        $player->sendMessage("§7Level: §c" . $oldLevel . " §7-> §a" . $newLevel);

        // Check if any new abilities unlocked
        foreach (self::ABILITY_UNLOCK as $ability => $reqLevel) {
            if ($oldLevel < $reqLevel && $newLevel >= $reqLevel) {
                if ($ability === "awakening") {
                    $player->sendMessage("§d§l  AWAKENING UNLOCKED!");
                    $player->sendMessage("§7Use /transform awaken to activate!");
                } else {
                    $num = str_replace("ability", "", $ability);
                    $player->sendMessage("§a  New Move Unlocked: §f" . ucfirst($ability) . " (Slot " . $num . ")");
                }
            }
        }

        // Show scaling info
        $dmgScale = $this->getDamageMultiplier($player->getName());
        $cdReduce = $this->getCooldownReduction($player->getName());
        $player->sendMessage("§7Damage: §f" . round($dmgScale * 100) . "%");
        $player->sendMessage("§7Cooldown: §f-" . round($cdReduce * 100) . "%");

        // Show next unlock
        $nextUnlock = $this->getNextUnlock($newLevel);
        if ($nextUnlock !== null) {
            $player->sendMessage("§7Next Unlock: §e" . $nextUnlock["name"] . " §7at Lv." . $nextUnlock["level"]);
        }

        $player->sendMessage("§6═══════════════════════");

        // Sound
        $this->plugin->getVFX()->sound(
            $player->getLevel(),
            $player->x, $player->y, $player->z,
            1021 // anvil land
        );
    }

    /**
     * Get next ability unlock info
     */
    private function getNextUnlock($currentLevel) {
        foreach (self::ABILITY_UNLOCK as $ability => $reqLevel) {
            if ($currentLevel < $reqLevel) {
                return [
                    "name"  => ucfirst($ability),
                    "level" => $reqLevel,
                ];
            }
        }
        return null;
    }

    // ========================
    // ABILITY CHECKS
    // ========================

    /**
     * Check if player can use a specific ability slot
     */
    public function canUseAbility($name, $abilitySlot) {
        if (!isset($this->cache[$name])) return false;
        $level = $this->cache[$name]["level"];
        $required = isset(self::ABILITY_UNLOCK[$abilitySlot]) ? self::ABILITY_UNLOCK[$abilitySlot] : 1;
        return $level >= $required;
    }

    /**
     * Check if player can use awakening
     */
    public function canUseAwakening($name) {
        return $this->canUseAbility($name, "awakening");
    }

    /**
     * Get list of unlocked abilities for player
     * @return array ["ability1" => true, "ability2" => false, ...]
     */
    public function getUnlockedAbilities($name) {
        $result = [];
        $level = $this->getLevel($name);
        foreach (self::ABILITY_UNLOCK as $ability => $reqLevel) {
            $result[$ability] = ($level >= $reqLevel);
        }
        return $result;
    }

    /**
     * Get total number of unlocked ability slots
     */
    public function getUnlockedSlotCount($name) {
        $count = 0;
        foreach ($this->getUnlockedAbilities($name) as $unlocked) {
            if ($unlocked) $count++;
        }
        return $count;
    }

    // ========================
    // SCALING GETTERS
    // ========================

    /**
     * Get damage multiplier based on mastery level
     * Level 1 = 0.4x, Level 30 = 1.6x
     */
    public function getDamageMultiplier($name) {
        $level = $this->getLevel($name);
        $maxLevel = $this->getMaxLevel();
        $progress = ($level - 1) / max(1, $maxLevel - 1);
        return self::DAMAGE_SCALE_MIN + $progress * (self::DAMAGE_SCALE_MAX - self::DAMAGE_SCALE_MIN);
    }

    /**
     * Get cooldown reduction (0.0 to 0.4)
     * Applied as: finalCooldown = baseCooldown * (1 - reduction)
     */
    public function getCooldownReduction($name) {
        $level = $this->getLevel($name);
        $maxLevel = $this->getMaxLevel();
        $progress = ($level - 1) / max(1, $maxLevel - 1);
        return $progress * self::COOLDOWN_REDUCTION_MAX;
    }

    /**
     * Get actual cooldown after mastery reduction
     */
    public function getScaledCooldown($name, $baseCooldown) {
        $reduction = $this->getCooldownReduction($name);
        return max(1, (int)round($baseCooldown * (1.0 - $reduction)));
    }

    /**
     * Get range/radius multiplier
     * Level 1 = 0.6x, Level 30 = 1.3x
     */
    public function getRangeMultiplier($name) {
        $level = $this->getLevel($name);
        $maxLevel = $this->getMaxLevel();
        $progress = ($level - 1) / max(1, $maxLevel - 1);
        return self::RANGE_SCALE_MIN + $progress * (self::RANGE_SCALE_MAX - self::RANGE_SCALE_MIN);
    }

    /**
     * Get duration multiplier (for transforms, buffs)
     * Level 1 = 0.5x, Level 30 = 1.4x
     */
    public function getDurationMultiplier($name) {
        $level = $this->getLevel($name);
        $maxLevel = $this->getMaxLevel();
        $progress = ($level - 1) / max(1, $maxLevel - 1);
        return self::DURATION_SCALE_MIN + $progress * (self::DURATION_SCALE_MAX - self::DURATION_SCALE_MIN);
    }

    /**
     * Get scaled damage value
     */
    public function getScaledDamage($name, $baseDamage) {
        return $baseDamage * $this->getDamageMultiplier($name);
    }

    /**
     * Get scaled range value
     */
    public function getScaledRange($name, $baseRange) {
        return $baseRange * $this->getRangeMultiplier($name);
    }

    /**
     * Get scaled duration
     */
    public function getScaledDuration($name, $baseDuration) {
        return max(1, (int)round($baseDuration * $this->getDurationMultiplier($name)));
    }

    // ========================
    // MASTERY TIER HELPERS
    // ========================

    /**
     * Get mastery tier name
     */
    public function getTierName($name) {
        $level = $this->getLevel($name);
        if ($level >= 25) return "§d§lGrandmaster";
        if ($level >= 20) return "§6§lMaster";
        if ($level >= 15) return "§c§lExpert";
        if ($level >= 10) return "§e§lSkilled";
        if ($level >= 5)  return "§a§lTrained";
        return "§7§lBeginner";
    }

    /**
     * Get mastery tier color code
     */
    public function getTierColor($name) {
        $level = $this->getLevel($name);
        if ($level >= 25) return "§d";
        if ($level >= 20) return "§6";
        if ($level >= 15) return "§c";
        if ($level >= 10) return "§e";
        if ($level >= 5)  return "§a";
        return "§7";
    }

    /**
     * Get progress bar string
     */
    public function getProgressBar($name) {
        $level = $this->getLevel($name);
        $exp = $this->getExp($name);
        $nextLevel = $level + 1;

        if (!isset(self::LEVELS[$nextLevel])) {
            return "§a||||||||||||||||||||§7 MAX";
        }

        $currentReq = self::LEVELS[$level];
        $nextReq = self::LEVELS[$nextLevel];
        $range = $nextReq - $currentReq;
        $progress = $exp - $currentReq;
        $percent = ($range > 0) ? min(1.0, $progress / $range) : 1.0;

        $totalBars = 20;
        $filled = (int)round($percent * $totalBars);
        $empty = $totalBars - $filled;

        $color = $this->getTierColor($name);
        return $color . str_repeat("|", $filled) . "§8" . str_repeat("|", $empty);
    }
}