<?php

namespace NoteBlockPlayer;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class Main extends PluginBase implements Listener{

	private $songs = [];
	private $activePlayers = [];
	private $broadcastPlayer = null;
	private $taskId = null;

	public function onEnable(){
		@mkdir($this->getDataFolder() . "songs");
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->loadSongs();
	}

	public function onDisable(){
		$this->stopAllPlayback();
		if($this->taskId !== null){
			$this->getServer()->getScheduler()->cancelTask($this->taskId);
			$this->taskId = null;
		}
	}

	private function loadSongs(){
		$parser = new NBSParser();
		$dir = $this->getDataFolder() . "songs/";
		if(!is_dir($dir)){
			return;
		}

		foreach(scandir($dir) as $file){
			if(strtolower(pathinfo($file, PATHINFO_EXTENSION)) !== "nbs"){
				continue;
			}
			$song = $parser->parse($dir . $file);
			if($song !== null){
				$key = strtolower(pathinfo($file, PATHINFO_FILENAME));
				$this->songs[$key] = $song;
				$this->getLogger()->info("Loaded song: " . $song->getName());
			}
		}

		$this->getLogger()->info("Loaded " . count($this->songs) . " song(s)");
	}

	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
		if($command->getName() !== "music"){
			return false;
		}

		if(!isset($args[0])){
			$sender->sendMessage(TextFormat::YELLOW . "/music list");
			$sender->sendMessage(TextFormat::YELLOW . "/music play <song>");
			$sender->sendMessage(TextFormat::YELLOW . "/music stop");
			$sender->sendMessage(TextFormat::YELLOW . "/music broadcast <song>");
			return true;
		}

		$sub = strtolower($args[0]);

		switch($sub){
			case "list":
				return $this->handleList($sender);
			case "play":
				return $this->handlePlay($sender, $args);
			case "stop":
				return $this->handleStop($sender);
			case "broadcast":
				return $this->handleBroadcast($sender, $args);
			case "reload":
				return $this->handleReload($sender);
			default:
				$sender->sendMessage(TextFormat::RED . "Unknown sub-command.");
				return true;
		}
	}

	private function handleList(CommandSender $sender){
		if(count($this->songs) === 0){
			$sender->sendMessage(TextFormat::RED . "No songs loaded.");
			return true;
		}

		$sender->sendMessage(TextFormat::GREEN . "Available songs (" . count($this->songs) . "):");
		foreach($this->songs as $key => $song){
			$author = $song->getAuthor() !== "" ? $song->getAuthor() : "Unknown";
			$sender->sendMessage(TextFormat::YELLOW . "  " . $key . TextFormat::GRAY . " - " . $song->getName() . " by " . $author);
		}
		return true;
	}

	private function handlePlay(CommandSender $sender, array $args){
		if(!($sender instanceof Player)){
			$sender->sendMessage(TextFormat::RED . "Use this command in-game.");
			return true;
		}

		if(!isset($args[1])){
			$sender->sendMessage(TextFormat::RED . "Usage: /music play <song>");
			return true;
		}

		$songKey = strtolower($args[1]);
		if(!isset($this->songs[$songKey])){
			$sender->sendMessage(TextFormat::RED . "Song not found: " . $args[1]);
			return true;
		}

		$this->stopPlayerPlayback($sender);

		$sp = new SongPlayer($this->songs[$songKey]);
		$sp->addPlayer($sender);
		$this->activePlayers[$sender->getName()] = $sp;

		$this->ensureTaskRunning();

		//$sender->sendMessage(TextFormat::GREEN . "Now playing: " . $this->songs[$songKey]->getName());
		return true;
	}

	private function handleStop(CommandSender $sender){
		if(!($sender instanceof Player)){
			$sender->sendMessage(TextFormat::RED . "Use this command in-game.");
			return true;
		}

		$stopped = false;

		if(isset($this->activePlayers[$sender->getName()])){
			unset($this->activePlayers[$sender->getName()]);
			$stopped = true;
		}

		if($this->broadcastPlayer !== null && $this->broadcastPlayer->hasPlayer($sender)){
			if($sender->isOp()){
				$this->broadcastPlayer = null;
				$sender->sendMessage(TextFormat::YELLOW . "Broadcast music stopped.");
				$stopped = true;
			}else{
				$this->broadcastPlayer->removePlayer($sender);
				$stopped = true;
			}
		}

		if($stopped){
			//$sender->sendMessage(TextFormat::GREEN . "Music stopped.");
		}else{
			//$sender->sendMessage(TextFormat::RED . "No music is playing.");
		}

		$this->checkStopTask();
		return true;
	}

	private function handleBroadcast(CommandSender $sender, array $args){
		if(!$sender->hasPermission("noteblockplayer.broadcast")){
			$sender->sendMessage(TextFormat::RED . "No permission.");
			return true;
		}

		if(!isset($args[1])){
			$sender->sendMessage(TextFormat::RED . "Usage: /music broadcast <song>");
			return true;
		}

		$songKey = strtolower($args[1]);
		if(!isset($this->songs[$songKey])){
			$sender->sendMessage(TextFormat::RED . "Song not found: " . $args[1]);
			return true;
		}

		$this->broadcastPlayer = new SongPlayer($this->songs[$songKey], true);

		foreach($this->getServer()->getOnlinePlayers() as $player){
			$this->broadcastPlayer->addPlayer($player);
		}

		$this->ensureTaskRunning();

		//$this->notifyAll(TextFormat::GREEN . "Now broadcasting: " . $this->songs[$songKey]->getName());
		return true;
	}

	private function handleReload(CommandSender $sender){
		if(!$sender->isOp()){
			$sender->sendMessage(TextFormat::RED . "No permission.");
			return true;
		}

		$this->stopAllPlayback();
		$this->songs = [];
		$this->loadSongs();
		$sender->sendMessage(TextFormat::GREEN . "Songs reloaded. " . count($this->songs) . " song(s) loaded.");
		return true;
	}

	public function onPlayerQuit(PlayerQuitEvent $event){
		$name = $event->getPlayer()->getName();

		if(isset($this->activePlayers[$name])){
			unset($this->activePlayers[$name]);
		}

		if($this->broadcastPlayer !== null){
			$this->broadcastPlayer->removePlayer($event->getPlayer());
		}

		$this->checkStopTask();
	}

	public function tickPlayers(){
		foreach($this->activePlayers as $name => $sp){
			$sp->onTick();
			if($sp->isFinished() || $sp->getPlayerCount() === 0){
				unset($this->activePlayers[$name]);
			}
		}

		if($this->broadcastPlayer !== null){
			foreach($this->getServer()->getOnlinePlayers() as $player){
				if(!$this->broadcastPlayer->hasPlayer($player)){
					$this->broadcastPlayer->addPlayer($player);
				}
			}

			$this->broadcastPlayer->onTick();
			if($this->broadcastPlayer->isFinished() || $this->broadcastPlayer->getPlayerCount() === 0){
				$this->broadcastPlayer = null;
			}
		}

		$this->checkStopTask();
	}

	private function ensureTaskRunning(){
		if($this->taskId === null){
			$task = new SongTask($this);
			$handler = $this->getServer()->getScheduler()->scheduleRepeatingTask($task, 1);
			$this->taskId = $handler->getTaskId();
		}
	}

	private function checkStopTask(){
		if(count($this->activePlayers) === 0 && $this->broadcastPlayer === null){
			if($this->taskId !== null){
				$this->getServer()->getScheduler()->cancelTask($this->taskId);
				$this->taskId = null;
			}
		}
	}

	private function stopPlayerPlayback(Player $player){
		$name = $player->getName();
		if(isset($this->activePlayers[$name])){
			unset($this->activePlayers[$name]);
		}
	}

	private function stopAllPlayback(){
		$this->activePlayers = [];
		$this->broadcastPlayer = null;
		$this->checkStopTask();
	}

	private function notifyAll($message){
		foreach($this->getServer()->getOnlinePlayers() as $player){
			$player->sendMessage($message);
		}
	}

}
