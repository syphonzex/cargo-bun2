<?php

namespace NoteBlockPlayer;

use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\network\protocol\UpdateBlockPacket;
use pocketmine\network\protocol\BlockEventPacket;

class SongPlayer{

	private $song;
	private $players = [];
	private $tick = 0;
	private $tickAccumulator = 0.0;
	private $finished = false;
	private $broadcast = false;

	public function __construct(Song $song, $broadcast = false){
		$this->song = $song;
		$this->broadcast = $broadcast;
	}

	public function getSong(){
		return $this->song;
	}

	public function isBroadcast(){
		return $this->broadcast;
	}

	public function isFinished(){
		return $this->finished;
	}

	public function addPlayer(Player $player){
		$this->players[$player->getName()] = $player;
	}

	public function removePlayer(Player $player){
		unset($this->players[$player->getName()]);
	}

	public function hasPlayer(Player $player){
		return isset($this->players[$player->getName()]);
	}

	public function getPlayerCount(){
		return count($this->players);
	}

	public function getPlayers(){
		return $this->players;
	}

	public function onTick(){
		if($this->finished){
			return;
		}

		$ticksPerSecond = $this->song->getTicksPerSecond();
		$ticksPerServerTick = $ticksPerSecond / 20;
		$this->tickAccumulator += $ticksPerServerTick;

		while($this->tickAccumulator >= 1.0){
			$this->tickAccumulator -= 1.0;
			$this->playSongTick();
			$this->tick++;

			if($this->tick > $this->song->getLength()){
				$this->finished = true;
				return;
			}
		}
	}

	private function playSongTick(){
		$notes = $this->song->getNotesAtTick($this->tick);
		if(empty($notes)){
			return;
		}

		foreach($this->players as $name => $player){
			if(!$player->isOnline()){
				unset($this->players[$name]);
				continue;
			}

			$bx = $player->getFloorX();
			$by = $player->getFloorY() - 1;
			$bz = $player->getFloorZ();

			if($by < 0){
				$by = 0;
			}
			if($by > 127){
				$by = 127;
			}

			$realBlock = $player->getLevel()->getBlock(new Vector3($bx, $by, $bz));
			$realId = $realBlock->getId();
			$realData = $realBlock->getDamage();

			$pk = new UpdateBlockPacket();
			$pk->x = $bx;
			$pk->z = $bz;
			$pk->y = $by;
			$pk->blockId = 25;
			$pk->blockData = 0;
			$pk->flags = UpdateBlockPacket::FLAG_NONE;
			$player->dataPacket($pk);

			foreach($notes as $note){
				$this->sendNote($player, $note, $bx, $by, $bz);
			}

			$pk2 = new UpdateBlockPacket();
			$pk2->x = $bx;
			$pk2->z = $bz;
			$pk2->y = $by;
			$pk2->blockId = $realId;
			$pk2->blockData = $realData;
			$pk2->flags = UpdateBlockPacket::FLAG_NONE;
			$player->dataPacket($pk2);
		}
	}

	private function sendNote(Player $player, array $note, $x, $y, $z){
		$instrument = $note["instrument"];
		if($instrument > 4){
			$instrument = $instrument % 5;
		}

		$key = $note["key"];
		$pitch = $this->keyToPitch($key);

		$pk = new BlockEventPacket();
		$pk->x = $x;
		$pk->y = $y;
		$pk->z = $z;
		$pk->case1 = $instrument;
		$pk->case2 = $pitch;
		$player->dataPacket($pk);
	}

	private function keyToPitch($key){
		if($key < 33){
			return 0;
		}
		if($key > 57){
			return 24;
		}
		return $key - 33;
	}

}