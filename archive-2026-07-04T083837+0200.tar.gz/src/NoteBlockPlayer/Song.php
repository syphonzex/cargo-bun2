<?php

namespace NoteBlockPlayer;

class Song{

	private $name;
	private $author;
	private $originalAuthor;
	private $tempo;
	private $length;
	private $layerCount;
	private $notes = [];
	private $layers = [];

	public function __construct($name, $author, $originalAuthor, $tempo, $length, $layerCount, array $notes, array $layers){
		$this->name = $name;
		$this->author = $author;
		$this->originalAuthor = $originalAuthor;
		$this->tempo = $tempo;
		$this->length = $length;
		$this->layerCount = $layerCount;
		$this->notes = $notes;
		$this->layers = $layers;
	}

	public function getName(){
		return $this->name;
	}

	public function getAuthor(){
		return $this->author;
	}

	public function getOriginalAuthor(){
		return $this->originalAuthor;
	}

	public function getTempo(){
		return $this->tempo;
	}

	public function getLength(){
		return $this->length;
	}

	public function getLayerCount(){
		return $this->layerCount;
	}

	public function getNotes(){
		return $this->notes;
	}

	public function getNotesAtTick($tick){
		return isset($this->notes[$tick]) ? $this->notes[$tick] : [];
	}

	public function getLayerVolume($layer){
		return isset($this->layers[$layer]["volume"]) ? $this->layers[$layer]["volume"] : 100;
	}

	public function getTicksPerSecond(){
		return $this->tempo / 100;
	}

}
