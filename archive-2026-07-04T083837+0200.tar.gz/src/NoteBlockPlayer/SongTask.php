<?php

namespace NoteBlockPlayer;

use pocketmine\scheduler\PluginTask;

class SongTask extends PluginTask{

	public function onRun($currentTick){
		$plugin = $this->getOwner();
		if(!($plugin instanceof Main)){
			return;
		}
		$plugin->tickPlayers();
	}

}
