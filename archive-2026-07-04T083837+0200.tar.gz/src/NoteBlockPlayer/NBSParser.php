<?php

namespace NoteBlockPlayer;

class NBSParser{

	private $handle;

	public function parse($filePath){
		$this->handle = fopen($filePath, "rb");
		if($this->handle === false){
			return null;
		}

		$result = $this->parseInternal();
		fclose($this->handle);
		return $result;
	}

	private function parseInternal(){
		$firstShort = $this->readShort();
		$nbsVersion = 0;
		$vanillaInstruments = 10;

		if($firstShort === 0){
			$nbsVersion = $this->readByte();
			$vanillaInstruments = $this->readByte();
			if($nbsVersion >= 3){
				$songLength = $this->readShort();
			}
		}

		$layerCount = $this->readShort();
		$songName = $this->readString();
		$songAuthor = $this->readString();
		$originalAuthor = $this->readString();
		$this->readString();
		$tempo = $this->readShort();
		$this->readByte();
		$this->readByte();
		$this->readByte();
		$this->readInt();
		$this->readInt();
		$this->readInt();
		$this->readInt();
		$this->readInt();
		$this->readString();

		if($nbsVersion >= 4){
			$this->readByte();
			$this->readByte();
			$this->readShort();
		}

		$notes = [];
		$maxTick = -1;
		$tick = -1;

		while(true){
			$tickJumps = $this->readShort();
			if($tickJumps === 0 || $tickJumps === false){
				break;
			}
			$tick += $tickJumps;
			$layer = -1;

			while(true){
				$layerJumps = $this->readShort();
				if($layerJumps === 0 || $layerJumps === false){
					break;
				}
				$layer += $layerJumps;

				$instrument = $this->readByte();
				$key = $this->readByte();

				$velocity = 100;
				$panning = 100;
				$pitch = 0;

				if($nbsVersion >= 4){
					$velocity = $this->readByte();
					$panning = $this->readByte();
					$pitch = $this->readSignedShort();
				}

				if($instrument < $vanillaInstruments){
					if(!isset($notes[$tick])){
						$notes[$tick] = [];
					}
					$notes[$tick][] = [
						"instrument" => $instrument,
						"key" => $key,
						"velocity" => $velocity,
						"layer" => $layer
					];
				}

				if($tick > $maxTick){
					$maxTick = $tick;
				}
			}
		}

		$layers = [];
		for($i = 0; $i < $layerCount; $i++){
			$layerName = $this->readString();
			if($layerName === false){
				break;
			}

			$lock = 0;
			if($nbsVersion >= 4){
				$lock = $this->readByte();
			}

			$layerVolume = $this->readByte();
			$layerPanning = 100;

			if($nbsVersion >= 2){
				$layerPanning = $this->readByte();
			}

			$layers[$i] = [
				"name" => $layerName,
				"volume" => $layerVolume === false ? 100 : $layerVolume
			];
		}

		if($songName === ""){
			$songName = pathinfo(stream_get_meta_data($this->handle)["uri"], PATHINFO_FILENAME);
		}

		return new Song(
			$songName,
			$songAuthor,
			$originalAuthor,
			$tempo,
			$maxTick,
			$layerCount,
			$notes,
			$layers
		);
	}

	private function readByte(){
		$data = fread($this->handle, 1);
		if($data === false || strlen($data) < 1){
			return false;
		}
		return unpack("C", $data)[1];
	}

	private function readShort(){
		$data = fread($this->handle, 2);
		if($data === false || strlen($data) < 2){
			return false;
		}
		return unpack("v", $data)[1];
	}

	private function readSignedShort(){
		$data = fread($this->handle, 2);
		if($data === false || strlen($data) < 2){
			return false;
		}
		$val = unpack("v", $data)[1];
		if($val >= 32768){
			$val -= 65536;
		}
		return $val;
	}

	private function readInt(){
		$data = fread($this->handle, 4);
		if($data === false || strlen($data) < 4){
			return false;
		}
		return unpack("V", $data)[1];
	}

	private function readString(){
		$length = $this->readInt();
		if($length === false || $length === 0){
			return "";
		}
		$data = fread($this->handle, $length);
		if($data === false){
			return "";
		}
		return $data;
	}

}
