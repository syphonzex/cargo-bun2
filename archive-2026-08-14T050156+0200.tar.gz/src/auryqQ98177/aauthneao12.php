<?php

namespace auryqQ98177;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\{
    PlayerMoveEvent,
    PlayerChatEvent,
    PlayerJoinEvent,
    PlayerInteractEvent,
    PlayerToggleSprintEvent,
    PlayerDropItemEvent,
    PlayerCommandPreprocessEvent,
    PlayerQuitEvent
};
use pocketmine\command\{CommandSender, Command};
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\utils\Config;
use pocketmine\{Player, Server};

class aauthneao12 extends PluginBase implements Listener {

    public $pass;
    public $can = []; // Initialize as empty array
    private $lang;

    // All translatable messages
    private $messages = [
        "welcome_back" => [
            "en" => "§a» §fWelcome back, You are logged in!",
            "pt" => "§a» §fBem-vindo de volta, você está logado!",
            "ru" => "§a» §fС возвращением, вы вошли в систему!",
            "indo" => "§a» §fSelamat datang kembali, Anda sudah login!",
            "sp" => "§a» §fBienvenido de nuevo, ¡has iniciado sesión!",
            "ac" => "§a» §fمرحبًا بك مرة أخرى، لقد قمت بتسجيل الدخول!"
        ],
        "not_logged_in" => [
            "en" => "§a» §fWelcome back, You are not logged in!\n§7- §aPlease enter your password!",
            "pt" => "§a» §fBem-vindo de volta, você não está logado!\n§7- §aPor favor, insira sua senha!",
            "ru" => "§a» §fС возвращением, вы не вошли в систему!\n§7- §aПожалуйста введите ваш пароль!",
            "indo" => "§a» §fSelamat datang kembali, Anda belum login!\n§7- §aSilakan masukkan kata sandi Anda!",
            "sp" => "§a» §fBienvenido de nuevo, ¡no has iniciado sesión!\n§7- §a¡Por favor, introduzca su contraseña!",
            "ac" => "§a» §fمرحباً بعودتك، لم تقم بتسجيل الدخول!\n§7- §aمن فضلك أدخل رقمك السري!"
        ],
        "please_register" => [
            "en" => "§a» §fWelcome, You are not logged in!\n§7- §ePlease write a password to register!",
            "pt" => "§a» §fBem-vindo, você não está logado!\n§7- §ePor favor, escreva uma senha para se cadastrar!",
            "ru" => "§a» §fДобро пожаловать, Вы не вошли в систему!\n§7- §eПожалуйста, введите пароль для регистрации!",
            "indo" => "§a» §fSelamat datang, Anda belum masuk!\n§7- §eSilakan tulis kata sandi untuk mendaftar!",
            "sp" => "§a» §f¡Bienvenido, no has iniciado sesión!\n§7- §e¡Escribe una contraseña para registrarte!",
            "ac" => "§a» §fمرحبا بك، أنت لم تقم بتسجيل الدخول!\n§7- §eالرجاء كتابة كلمة المرور للتسجيل!"
        ],
        "write_password_chat" => [
            "en" => "§a» §fWrite your password in chat to login!",
            "pt" => "§a» §fEscreva sua senha no chat para fazer login!",
            "ru" => "§a» §fНапишите свой пароль в чате для входа!",
            "indo" => "§a» §fTulis kata sandi Anda di obrolan untuk login!",
            "sp" => "§a» §f¡Escribe tu contraseña en el chat para iniciar sesión!",
            "ac" => "§a» §fاكتب كلمة المرور الخاصة بك في الدردشة لتسجيل الدخول!"
        ],
        "logged_in" => [
            "en" => "§a» §fYou have been logged in!",
            "pt" => "§a» §fVocê está logado!",
            "ru" => "§a» §fВы вошли в систему!",
            "indo" => "§a» §fAnda telah masuk!",
            "sp" => "§a» §f¡Has iniciado sesión!",
            "ac" => "§a» §fلقد تم تسجيل الدخول!"
        ],
        "wrong_password" => [
            "en" => "§a» §fWrite your password to register!",
            "pt" => "§a» §fEscreva sua senha para se cadastrar!",
            "ru" => "§a» §fНапишите свой пароль для регистрации!",
            "indo" => "§a» §fTulis kata sandi Anda untuk mendaftar!",
            "sp" => "§a» §f¡Escribe tu contraseña para registrarte!",
            "ac" => "§a» §fاكتب كلمة المرور الخاصة بك للتسجيل!"
        ],
        "registered" => [
            "en" => "§a» §fYou have been registered!",
            "pt" => "§a» §fVocê foi registrado!",
            "ru" => "§a» §fВы зарегистрированы!",
            "indo" => "§a» §fAnda telah terdaftar!",
            "sp" => "§a» §f¡Has sido registrado!",
            "ac" => "§a» §fانت تملك حساب مصرفي!"
        ],
        "password_too_short" => [
            "en" => "§a» §fYour password is too small, §eMinimum is 6 characters!",
            "pt" => "§a» §fSua senha é muito pequena, §eO mínimo é de 6 caracteres!",
            "ru" => "§a» §fВаш пароль слишком мал. §eМинимум — 6 символов!",
            "indo" => "§a» §fKata sandi Anda terlalu kecil, §eMinimal 6 karakter!",
            "sp" => "§a» §fSu contraseña es demasiado pequeña, §e¡El mínimo es 6 caracteres!",
            "ac" => "§a» §fكلمة المرور الخاصة بك صغيرة جدًا، §eالحد الأدنى هو 6 أحرف!"
        ]
    ];

    public function onEnable() {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        @mkdir($this->getDataFolder());
        $this->pass = new Config($this->getDataFolder() . "savespass.yml", Config::YAML);
        $this->lang = $this->getServer()->getPluginManager()->getPlugin("Lang");
    }

    /**
     * Get translated message for a player
     */
    public function getMessage(Player $player, string $key): string {
        $lang = "en"; // Default language
        if ($this->lang !== null) {
            $lang = $this->lang->getPlayerLanguage($player);
        }
        if (isset($this->messages[$key][$lang])) {
            return $this->messages[$key][$lang];
        }
        return $this->messages[$key]["en"]; // Fallback to English
    }

    /**
     * Check if player is authenticated
     */
    public function isAuthenticated(Player $player): bool {
        $name = $player->getName();
        return isset($this->can[$name]) && $this->can[$name] === true;
    }

    /**
     * Check if player is registered
     */
    public function isRegistered(Player $player): bool {
        $players = $this->pass->get("players");
        return is_array($players) && isset($players[strtolower($player->getName())]);
    }

    public function onCommand(CommandSender $sender, Command $cmd, $label, array $args) {
        switch ($cmd->getName()) {
            case "changepassword":
                if (!($sender instanceof Player)) {
                    $sender->sendMessage("§cThis command can only be used in-game!");
                    return true;
                }
                if (!isset($args[0])) {
                    $sender->sendMessage("§a» §e/changepassword [Password]");
                    return true;
                }
                if (strlen($args[0]) <= 5) {
                    $sender->sendMessage("§a» §fYour password is too short! Must be at least 6 characters!");
                    return true;
                }
                $this->pass->setNested("players." . strtolower($sender->getName()) . ".password", $args[0]);
                $this->pass->save();
                $sender->sendMessage("§a» §fPassword changed to §e" . $args[0]);
                break;

            case "seepassword":
                if (!isset($args[0])) {
                    $sender->sendMessage("§a» §e/seepassword [player name]");
                    return true;
                }
                $target = strtolower($args[0]);
                $players = $this->pass->get("players");
                if (!is_array($players) || !isset($players[$target])) {
                    $sender->sendMessage("§a» §fPlayer not found or wrong nickname!");
                    return true;
                }
                $password = $this->pass->getNested("players." . $target . ".password");
                $sender->sendMessage("§a» §eName: §a" . $args[0] . " §ePassword: §a" . $password);
                break;
        }
        return true;
    }

    public function onQuit(PlayerQuitEvent $event) {
        $name = $event->getPlayer()->getName();
        unset($this->can[$name]); // Clean up memory
    }

    public function onJoin(PlayerJoinEvent $event) {
        $player = $event->getPlayer();
        $name = $player->getName();

        // Initialize as not authenticated
        $this->can[$name] = false;

        if ($this->isRegistered($player)) {
            // Player is registered - check IP for auto-login
            $savedIp = $this->pass->getNested("players." . strtolower($name) . ".ip");
            if ($savedIp === $player->getAddress()) {
                $player->sendMessage($this->getMessage($player, "welcome_back"));
                $this->can[$name] = true;
            } else {
                $player->sendMessage($this->getMessage($player, "not_logged_in"));
            }
        } else {
            // Player is not registered
            $player->sendMessage($this->getMessage($player, "please_register"));
        }
    }

    public function onChat(PlayerChatEvent $event) {
        $player = $event->getPlayer();
        $msg = $event->getMessage();
        $name = $player->getName();
        $lowerName = strtolower($name);

        // Already authenticated - check if they're typing their password
        if ($this->isAuthenticated($player)) {
            $savedPass = $this->pass->getNested("players." . $lowerName . ".password");
            if ($savedPass !== null && $msg === $savedPass) {
                $player->sendMessage($this->getMessage($player, "write_password_chat"));
                $event->setCancelled();
            }
            return;
        }

        // Not authenticated
        $event->setCancelled();

        if ($this->isRegistered($player)) {
            // Registered player - check password
            $savedPass = $this->pass->getNested("players." . $lowerName . ".password");
            if ($msg === $savedPass) {
                $player->sendMessage($this->getMessage($player, "logged_in"));
                $this->pass->setNested("players." . $lowerName . ".ip", $player->getAddress());
                $this->pass->save();
                $this->can[$name] = true;
            } else {
                $player->sendMessage($this->getMessage($player, "wrong_password"));
            }
        } else {
            // New player - register
            if (strlen($msg) > 5) {
                $this->pass->setNested("players." . $lowerName . ".password", $msg);
                $this->pass->setNested("players." . $lowerName . ".ip", $player->getAddress());
                $this->pass->save();
                $this->can[$name] = true;
                $player->sendMessage($this->getMessage($player, "registered"));
            } else {
                $player->sendMessage($this->getMessage($player, "password_too_short"));
            }
        }
    }

    /**
     * Block all actions for unauthenticated players
     */
    public function onDrop(PlayerDropItemEvent $event) {
        if (!$this->isAuthenticated($event->getPlayer())) {
            $event->setCancelled();
        }
    }

    public function onMove(PlayerMoveEvent $event) {
        if (!$this->isAuthenticated($event->getPlayer())) {
            $event->setCancelled();
        }
    }

    public function onCmd(PlayerCommandPreprocessEvent $event) {
        $player = $event->getPlayer();
        if (!$this->isAuthenticated($player)) {
            if (strpos($event->getMessage(), "/") === 0) {
                $event->setCancelled();
            }
        }
    }

    public function onInteract(PlayerInteractEvent $event) {
        if (!$this->isAuthenticated($event->getPlayer())) {
            $event->setCancelled();
        }
    }

    public function onBreakBlock(BlockBreakEvent $event) {
        if (!$this->isAuthenticated($event->getPlayer())) {
            $event->setCancelled();
        }
    }

    public function onSprint(PlayerToggleSprintEvent $event) {
        if (!$this->isAuthenticated($event->getPlayer())) {
            $event->setCancelled();
        }
    }
}