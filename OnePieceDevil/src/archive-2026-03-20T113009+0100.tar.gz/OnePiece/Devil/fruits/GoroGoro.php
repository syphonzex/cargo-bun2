<?php
namespace OnePiece\Devil\fruits;

use OnePiece\Devil\BaseFruit;
use OnePiece\Devil\Main;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;
use pocketmine\entity\Effect;
use pocketmine\utils\TextFormat;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\Task;
use pocketmine\level\Level;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\MobSpellParticle;
use pocketmine\level\particle\InstantEnchantParticle;
use pocketmine\level\particle\EnchantParticle;
use pocketmine\level\particle\ExplodeParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\sound\PopSound;
use pocketmine\level\sound\ClickSound;
use pocketmine\level\sound\FizzSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\network\protocol\MoveEntityPacket;
use pocketmine\network\protocol\RemoveEntityPacket;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;

class GoroGoro extends BaseFruit {

    private $activeStorms = [];
    private $stormTaskIds = [];

    const COL_YELLOW_R = 255;
    const COL_YELLOW_G = 255;
    const COL_YELLOW_B = 0;
    const COL_WHITE_R = 255;
    const COL_WHITE_G = 255;
    const COL_WHITE_B = 200;
    const COL_BLUE_R = 100;
    const COL_BLUE_G = 180;
    const COL_BLUE_B = 255;

    public function getId() { return "goro_goro"; }
    public function getDisplayName() { return "Lightning-Lightning Fruit"; }
    public function getDescription() { return "Lightning Fruit - Enel's divine power, 200 million volts."; }
    public function getType() { return "logia"; }
    public function getRarity() { return "mythical"; }

    public function getAbilityNames() {
        return ["ability1" => "El Thor", "ability2" => "Raigo"];
    }

    public function getAbilityCooldowns() {
        return ["ability1" => 6.0, "ability2" => 26.0];
    }

    public function useAbility(Player $player, $ability) {
        switch ($ability) {
            case "ability1": return $this->elThor($player);
            case "ability2": return $this->raigo($player);
        }
        return 0;
    }

    private function elThor(Player $player) {
        $combatPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceCombat");
        $toggle = ($combatPlugin !== null && $combatPlugin->isEnabled()) ? $combatPlugin->getCombatToggle() : null;

        $target = $this->findFrontTarget($player, 14);
        $vfx = $this->getVFX();

        if ($target === null) {
            $player->sendTip($this->plugin->getTargetBlockReason($player->getName(), $target) ?? TextFormat::RED . "Cannot target this player!");
            return 2.0;
        }

        if ($target instanceof Player) {
            if (!$this->plugin->canTargetPlayer($player->getName(), $target)) {
                $reason = $this->plugin->getTargetBlockReason($player->getName(), $target);
                if ($reason !== null) $player->sendTip($reason);
                return 2.0;
            }
        }

        $mult = min(1.5, $this->getHakiMultiplier($player));
        $damage = min(13.0, 4.0 * $mult);

        $ev = new EntityDamageByEntityEvent($player, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage);
        $target->attack($damage, $ev);

        $slow = Effect::getEffect(Effect::SLOWNESS);
        $slow->setAmplifier(3);
        $slow->setDuration(60);
        $slow->setVisible(false);
        $target->addEffect($slow);

        $fatigue = Effect::getEffect(Effect::MINING_FATIGUE);
        $fatigue->setAmplifier(2);
        $fatigue->setDuration(50);
        $fatigue->setVisible(false);
        $this->safeAddEffect($player, $target, $fatigue);

        $dir = $player->getDirectionVector();
        $this->safeSetMotion($player, $target, new Vector3($dir->x * 1.5, 0.7, $dir->z * 1.5));

        $player->sendTip(TextFormat::YELLOW . "EL THOR! 200 million volts!");
        if ($target instanceof Player) {
            $target->sendTip(TextFormat::YELLOW . "EL THOR! PARALYSED!");
        }

        $this->spawnElThorVFX($player, $target);

        $tPos = $target->getPosition();
        $debrisTask = new ElThorDebrisTask(
            $this->plugin,
            $target->getLevel(),
            $tPos->x,
            $tPos->y,
            $tPos->z
        );
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($debrisTask, 1);

        if ($vfx) {
            $pos = $target->getPosition();
            $vfx->getFruitVFX()->spawnLightningStrike($target->getLevel(), $pos->x, $pos->y, $pos->z);
        }

        return $this->getAbilityCooldowns()["ability1"];
    }

    private function raigo(Player $player) {
        $combatPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceCombat");
        $toggle = ($combatPlugin !== null && $combatPlugin->isEnabled()) ? $combatPlugin->getCombatToggle() : null;

        $name = $player->getName();
        $mult = min(1.5, $this->getHakiMultiplier($player));

        $baseRadius = 10.0;
        $bonusRadius = 4.0 * ($mult - 1.0);
        $radius = $baseRadius + $bonusRadius;

        $baseDuration = 15;
        $bonusDuration = (int)(8 * ($mult - 1.0));
        $duration = $baseDuration + $bonusDuration;

        $this->destroyStorm($player, false);

        $pos = $player->getPosition();
        $durationTicks = $duration * 20;

        $this->activeStorms[$name] = [
            "x" => $pos->x,
            "y" => $pos->y,
            "z" => $pos->z,
            "radius" => $radius,
            "level" => $player->getLevel()->getName(),
            "endTime" => microtime(true) + $duration,
            "owner" => $name,
            "damage" => min(13.0, 4.5 * $mult)
        ];

        $this->spawnStormInitial($player, $radius);

        $stormTask = new LightningStormTask(
            $this->plugin,
            $player->getLevel(),
            $pos->x, $pos->y + 1, $pos->z,
            $radius,
            $name,
            $durationTicks,
            $this->activeStorms[$name]["damage"]
        );
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($stormTask, 1);
        $this->stormTaskIds[$name] = $stormTask->getTaskId();

        $player->sendTip(TextFormat::YELLOW . TextFormat::BOLD . "RAIGO!");
        $player->sendMessage(TextFormat::YELLOW . "Divine Thunder Domain activated!");
        $player->sendMessage(TextFormat::GRAY . "Radius: " . round($radius, 1) . " blocks - Duration: " . $duration . "s");

        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
            new StormExpireTask($this, $name, $this->activeStorms[$name]["endTime"]),
            $durationTicks
        );

        $vfx = $this->getVFX();
        if ($vfx) {
            $vfx->getFruitVFX()->spawnRaigoStorm($player, $radius, 8);
        }

        return $this->getAbilityCooldowns()["ability2"];
    }

    private function spawnElThorVFX(Player $player, Entity $target) {
        $lv = $player->getLevel();
        $px = $player->x;
        $py = $player->y + 1.5;
        $pz = $player->z;
        $tx = $target->x;
        $ty = $target->y + 1;
        $tz = $target->z;

        for ($i = 0; $i < 6; $i++) {
            $a = ($i / 6) * M_PI * 2;
            $lv->addParticle(new MobSpellParticle(
                new Vector3($px + cos($a) * 0.5, $py + sin($a) * 0.5, $pz),
                self::COL_YELLOW_R, self::COL_YELLOW_G, self::COL_YELLOW_B
            ));
        }

        $steps = 10;
        for ($i = 0; $i <= $steps; $i++) {
            $prog = $i / $steps;
            $bx = $px + ($tx - $px) * $prog + (mt_rand(-5, 5) / 10);
            $by = $py + ($ty - $py) * $prog + (mt_rand(-5, 5) / 10);
            $bz = $pz + ($tz - $pz) * $prog + (mt_rand(-5, 5) / 10);
            $lv->addParticle(new DustParticle(
                new Vector3($bx, $by, $bz),
                self::COL_YELLOW_R, self::COL_YELLOW_G, self::COL_YELLOW_B
            ));
            if ($i % 2 === 0) {
                $lv->addParticle(new InstantEnchantParticle(new Vector3($bx, $by + 0.2, $bz)));
            }
        }

        for ($i = 0; $i < 12; $i++) {
            $a = ($i / 12) * M_PI * 2;
            $lv->addParticle(new MobSpellParticle(
                new Vector3($tx + cos($a) * 1.5, $ty, $tz + sin($a) * 1.5),
                self::COL_YELLOW_R, self::COL_YELLOW_G, self::COL_YELLOW_B
            ));
        }

        for ($i = 0; $i < 8; $i++) {
            $lv->addParticle(new InstantEnchantParticle(new Vector3(
                $tx + (mt_rand(-15, 15) / 10),
                $ty + (mt_rand(0, 20) / 10),
                $tz + (mt_rand(-15, 15) / 10)
            )));
        }

        $lv->addParticle(new ExplodeParticle(new Vector3($tx, $ty, $tz)));
    }

    private function spawnStormInitial(Player $player, $radius) {
        $pos = $player->getPosition();
        $lv = $player->getLevel();
        $cx = $pos->x;
        $cy = $pos->y + 1;
        $cz = $pos->z;

        for ($ring = 0; $ring < 3; $ring++) {
            $rr = $radius * (0.3 + $ring * 0.35);
            $pts = 16 + $ring * 8;
            for ($i = 0; $i < $pts; $i++) {
                $a = ($i / $pts) * M_PI * 2;
                $lv->addParticle(new DustParticle(
                    new Vector3($cx + cos($a) * $rr, $cy, $cz + sin($a) * $rr),
                    self::COL_YELLOW_R, self::COL_YELLOW_G, self::COL_YELLOW_B
                ));
            }
        }

        for ($i = 0; $i < 8; $i++) {
            $a = ($i / 8) * M_PI * 2;
            for ($h = 0; $h < 5; $h++) {
                $py = $cy + $h * 1.5;
                $lv->addParticle(new MobSpellParticle(
                    new Vector3($cx + cos($a) * 0.5, $py, $cz + sin($a) * 0.5),
                    self::COL_YELLOW_R, self::COL_YELLOW_G, self::COL_YELLOW_B
                ));
            }
        }

        for ($i = 0; $i < 16; $i++) {
            $lv->addParticle(new InstantEnchantParticle(new Vector3(
                $cx + (mt_rand(-40, 40) / 10),
                $cy + (mt_rand(0, 30) / 10),
                $cz + (mt_rand(-40, 40) / 10)
            )));
        }

        $lv->addSound(new AnvilUseSound(new Vector3($cx, $cy, $cz)));
    }

    private function destroyStorm(Player $player, $notify = true) {
        $name = $player->getName();

        if (isset($this->stormTaskIds[$name])) {
            try {
                $this->plugin->getServer()->getScheduler()->cancelTask($this->stormTaskIds[$name]);
            } catch (\Exception $e) {}
            unset($this->stormTaskIds[$name]);
        }

        if (!isset($this->activeStorms[$name])) {
            return false;
        }

        unset($this->activeStorms[$name]);

        if ($notify && $player->isOnline()) {
            $player->sendMessage(TextFormat::GRAY . "Thunder domain fades...");
        }

        return true;
    }

    public function expireStorm($playerName, $endTime = null) {
        if (isset($this->activeStorms[$playerName])) {
            if ($endTime !== null && $this->activeStorms[$playerName]["endTime"] !== $endTime) {
                return;
            }
        } else {
            return;
        }

        if (isset($this->stormTaskIds[$playerName])) {
            try {
                $this->plugin->getServer()->getScheduler()->cancelTask($this->stormTaskIds[$playerName]);
            } catch (\Exception $e) {}
            unset($this->stormTaskIds[$playerName]);
        }

        unset($this->activeStorms[$playerName]);

        $player = $this->plugin->getServer()->getPlayerExact($playerName);
        if ($player !== null && $player->isOnline()) {
            $player->sendTip(TextFormat::GRAY . "Thunder domain expired.");
            $player->sendMessage(TextFormat::GRAY . "Your Raigo domain has expired.");
        }
    }

    private function getVFX() {
        return $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceFruits");
    }

    public function onEquip(Player $player) {
        $player->sendMessage(TextFormat::YELLOW . "=== Goro-Goro no Mi ===");
        $player->sendMessage(TextFormat::WHITE . "God of Lightning - 200 Million Volts");
        $player->sendMessage("");
        $player->sendMessage(TextFormat::YELLOW . "[Tap]: " . TextFormat::WHITE . "El Thor");
        $player->sendMessage(TextFormat::GRAY . "  Lightning bolt strikes target");
        $player->sendMessage("");
        $player->sendMessage(TextFormat::YELLOW . "[Sneak+Tap]: " . TextFormat::WHITE . "Raigo");
        $player->sendMessage(TextFormat::GRAY . "  Create thunder domain with orbiting lightning");
        $player->sendMessage(TextFormat::YELLOW . "========================");
    }

    public function onUnequip(Player $player) {
        $this->destroyStorm($player, false);
        $player->sendMessage(TextFormat::GRAY . "Lightning fades...");
    }
}

class ElThorDebrisTask extends Task {

    private $plugin;
    private $level;
    private $cx;
    private $cy;
    private $cz;
    private $debris = [];
    private $ticksRan = 0;
    private $maxTicks = 60;
    private $cleaned = false;

    const FALLING_SAND_TYPE = 66;
    const DATA_BLOCK_INFO = 20;

    private static $nextEid = 800000;

    private static function newEid() {
        $eid = self::$nextEid++;
        if (self::$nextEid > 899999) {
            self::$nextEid = 800000;
        }
        return $eid;
    }

    public function __construct($plugin, Level $level, $cx, $cy, $cz) {
        $this->plugin = $plugin;
        $this->level = $level;
        $this->cx = (float)$cx;
        $this->cy = (float)$cy;
        $this->cz = (float)$cz;

        $this->spawnDebris();
    }

    private function scanGroundBlocks() {
        $found = [];
        $skip = [0, 8, 9, 10, 11, 26, 30, 31, 32, 37, 38, 39, 40, 50, 51, 55, 59, 63, 64, 65, 68, 69, 70, 71, 72, 75, 76, 77, 83, 90, 93, 94, 96, 104, 105, 106, 115, 127, 131, 132, 141, 142, 143, 144, 147, 148, 149, 150, 154, 157, 167, 171, 175, 176, 177, 178, 183, 184, 185, 186, 187, 193, 194, 195, 196, 197];

        for ($bx = -3; $bx <= 3; $bx++) {
            for ($bz = -3; $bz <= 3; $bz++) {
                for ($by = -3; $by <= 1; $by++) {
                    $block = $this->level->getBlock(new Vector3((int)($this->cx + $bx), (int)($this->cy + $by), (int)($this->cz + $bz)));
                    $id = $block->getId();
                    $dmg = $block->getDamage();

                    if (in_array($id, $skip)) continue;

                    $key = $id . ":" . $dmg;
                    if (!isset($found[$key])) {
                        $found[$key] = ["id" => $id, "damage" => $dmg];
                    }

                    if (count($found) >= 5) {
                        return array_values($found);
                    }
                }
            }
        }

        if (empty($found)) {
            $found[] = ["id" => 4, "damage" => 0];
            $found[] = ["id" => 1, "damage" => 0];
            $found[] = ["id" => 3, "damage" => 0];
        }

        return array_values($found);
    }

    private function spawnDebris() {
        $blocks = $this->scanGroundBlocks();
        $players = $this->level->getPlayers();
        $debrisCount = mt_rand(3, 5);

        for ($i = 0; $i < $debrisCount; $i++) {
            $blockData = $blocks[$i % count($blocks)];
            $eid = self::newEid();

            $angle = ($i / $debrisCount) * M_PI * 2 + (mt_rand(-30, 30) / 100);
            $dist = 0.8 + (mt_rand(0, 40) / 10);
            $power = 0.15 + (mt_rand(0, 10) / 100);

            $this->debris[$eid] = [
                "eid" => $eid,
                "blockId" => $blockData["id"],
                "blockDamage" => $blockData["damage"],
                "x" => $this->cx + (mt_rand(-5, 5) / 10),
                "y" => $this->cy,
                "z" => $this->cz + (mt_rand(-5, 5) / 10),
                "vx" => cos($angle) * $dist * $power,
                "vy" => 0.5 + (mt_rand(0, 30) / 100),
                "vz" => sin($angle) * $dist * $power,
                "life" => 30 + mt_rand(-5, 10),
                "rotSpeed" => mt_rand(15, 35),
                "tick" => 0
            ];

            $pk = new AddEntityPacket();
            $pk->eid = $eid;
            $pk->type = self::FALLING_SAND_TYPE;
            $pk->x = (float)$this->debris[$eid]["x"];
            $pk->y = (float)$this->debris[$eid]["y"];
            $pk->z = (float)$this->debris[$eid]["z"];
            $pk->speedX = 0.0;
            $pk->speedY = 0.0;
            $pk->speedZ = 0.0;
            $pk->yaw = 0.0;
            $pk->pitch = 0.0;
            $pk->metadata = [
                Entity::DATA_FLAGS => [Entity::DATA_TYPE_BYTE, 0],
                self::DATA_BLOCK_INFO => [Entity::DATA_TYPE_INT, $blockData["id"] | ($blockData["damage"] << 8)],
                Entity::DATA_NO_AI => [Entity::DATA_TYPE_BYTE, 1]
            ];

            foreach ($players as $pl) {
                $pl->dataPacket($pk);
            }
        }

        for ($i = 0; $i < 10; $i++) {
            $da = ($i / 10) * M_PI * 2;
            $dd = 0.5 + mt_rand(0, 15) / 10;
            $this->level->addParticle(new DustParticle(
                new Vector3($this->cx + cos($da) * $dd, $this->cy + 0.2, $this->cz + sin($da) * $dd),
                120, 120, 120
            ));
        }
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->ticksRan++;

        if ($this->ticksRan > $this->maxTicks || empty($this->debris)) {
            $this->forceCleanup();
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $players = $this->level->getPlayers();
        $toRemove = [];

        foreach ($this->debris as $eid => &$d) {
            $d["tick"]++;
            $d["life"]--;

            $d["vy"] -= 0.045;
            $d["vx"] *= 0.98;
            $d["vz"] *= 0.98;

            $d["x"] += $d["vx"];
            $d["y"] += $d["vy"];
            $d["z"] += $d["vz"];

            if ($d["y"] < $this->cy - 2 && $d["vy"] < 0) {
                $d["vy"] = 0;
                $d["vx"] *= 0.5;
                $d["vz"] *= 0.5;
                $d["y"] = $this->cy - 2;
            }

            if ($d["life"] > 0) {
                $pk = new MoveEntityPacket();
                $pk->eid = $eid;
                $pk->x = (float)$d["x"];
                $pk->y = (float)$d["y"];
                $pk->z = (float)$d["z"];
                $pk->yaw = $d["tick"] * $d["rotSpeed"];
                $pk->pitch = $d["tick"] * ($d["rotSpeed"] * 0.7);
                $pk->headYaw = $d["tick"] * $d["rotSpeed"];

                foreach ($players as $pl) {
                    $pl->dataPacket($pk);
                }

                if ($d["tick"] < 10 && $d["tick"] % 2 === 0) {
                    $this->level->addParticle(new DustParticle(
                        new Vector3($d["x"], $d["y"], $d["z"]),
                        255, 255, 100
                    ));
                }
            } else {
                $this->removeOneDebris($players, $eid, $d);
                $toRemove[] = $eid;
            }
        }
        unset($d);

        foreach ($toRemove as $eid) {
            unset($this->debris[$eid]);
        }
    }

    private function removeOneDebris($players, $eid, $d) {
        $movePk          = new MoveEntityPacket();
        $movePk->eid     = $eid;
        $movePk->x       = 0.0;
        $movePk->y       = 0.0;
        $movePk->z       = 0.0;
        $movePk->yaw     = 0.0;
        $movePk->pitch   = 0.0;
        $movePk->headYaw = 0.0;

        foreach ($players as $pl) {
            try {
                $pl->dataPacket($movePk);
            } catch (\Exception $e) {}
        }

        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
            new GoroDelayedRemoveTask($this->plugin, $this->level, [$eid]),
            40
        );
    }


    public function forceCleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        $players = [];
        try {
            if ($this->level !== null) {
                $players = $this->level->getPlayers();
            }
        } catch (\Exception $e) {}

        foreach ($this->debris as $eid => $d) {
            $movePk = new MoveEntityPacket();
            $movePk->eid = $eid;
            $movePk->x = 100000.0;
            $movePk->y = -100.0;
            $movePk->z = 100000.0;
            $movePk->yaw = 0.0;
            $movePk->pitch = 0.0;
            $movePk->headYaw = 0.0;

            $removePk = new RemoveEntityPacket();
            $removePk->eid = $eid;

            foreach ($players as $pl) {
                try {
                    $pl->dataPacket($movePk);
                    $pl->dataPacket($removePk);
                } catch (\Exception $e) {}
            }
        }

        $this->debris = [];
    }
}

class StormExpireTask extends Task {

    private $fruit;
    private $playerName;
    private $endTime;

    public function __construct(GoroGoro $fruit, $playerName, $endTime) {
        $this->fruit = $fruit;
        $this->playerName = $playerName;
        $this->endTime = $endTime;
    }

    public function onRun($currentTick) {
        $this->fruit->expireStorm($this->playerName, $this->endTime);
    }
}

class LightningStormTask extends Task {

    private $plugin;
    private $level;
    private $cx;
    private $cy;
    private $cz;
    private $radius;
    private $ownerName;
    private $totalTicks;
    private $ticksRan = 0;
    private $phase = 0.0;
    private $cleaned = false;
    private $damage;

    private $orbEntities = [];
    private $orbCount = 5;
    private $spawned = false;

    private $chargingOrbs = [];
    private $breakStates = [];
    private $breakCooldown = 30;

    private $allSpawnedEids = [];

    private static $nextEid = 900000;

    const HIT_DAMAGE = 3.0;
    const VIEW_RANGE = 50;
    const STRIKE_INTERVAL = 40;
    const ORBIT_HEIGHT = 3.0;
    const CHARGE_STEPS = 6;
    const ORB_TYPE = 93;

    private static function newEid() {
        $eid = self::$nextEid++;
        if (self::$nextEid > 999999) {
            self::$nextEid = 900000;
        }
        return $eid;
    }

    public function __construct($plugin, Level $level, $cx, $cy, $cz, $radius, $ownerName, $totalTicks, $damage) {
        $this->plugin = $plugin;
        $this->level = $level;
        $this->cx = (float)$cx;
        $this->cy = (float)$cy;
        $this->cz = (float)$cz;
        $this->radius = (float)$radius;
        $this->ownerName = $ownerName;
        $this->totalTicks = (int)$totalTicks;
        $this->damage = $damage;

        for ($i = 0; $i < $this->orbCount; $i++) {
            $eid = self::newEid();
            $this->allSpawnedEids[$eid] = true;

            $this->orbEntities[$i] = [
                "eid" => $eid,
                "angle" => ($i / $this->orbCount) * M_PI * 2,
                "heightOffset" => self::ORBIT_HEIGHT + (mt_rand(-10, 10) / 10),
                "orbitSpeed" => 0.1 + (mt_rand(0, 50) / 1000),
                "x" => $this->cx,
                "y" => $this->cy + self::ORBIT_HEIGHT,
                "z" => $this->cz
            ];

            $this->breakStates[$i] = 0;
            $this->chargingOrbs[$i] = null;
        }
    }

    private function exileEntity($eid) {
        $pk          = new MoveEntityPacket();
        $pk->eid     = $eid;
        $pk->x       = 0.0;
        $pk->y       = 0.0;
        $pk->z       = 0.0;
        $pk->yaw     = 0.0;
        $pk->pitch   = 0.0;
        $pk->headYaw = 0.0;

        foreach ($this->level->getPlayers() as $pl) {
            try {
                $pl->dataPacket($pk);
            } catch (\Exception $e) {}
        }
    }


    private function exileAndRemove($eid) {
        $this->exileEntity($eid);

        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
            new GoroDelayedRemoveTask($this->plugin, $this->level, [$eid]),
            40
        );
    }


    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->ticksRan++;

        if ($this->ticksRan > $this->totalTicks) {
            $this->forceCleanup();
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        if ($this->plugin->getServer()->getLevelByName($this->level->getName()) === null) {
            $this->forceCleanup();
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $players = $this->getNearbyPlayers();
        if (empty($players)) return;

        if (!$this->spawned) {
            $this->spawnAllOrbs($players);
            $this->spawned = true;
        }

        $this->phase += 0.12;

        $this->updateChargingOrbs($players);
        $this->orbitOrbs($players);
        $this->updateBreakStates($players);
        $this->drawStormVFX($players);

        if ($this->ticksRan % self::STRIKE_INTERVAL === 0) {
            $this->startCharge($players);
        }
    }

    private function getNearbyPlayers() {
        $players = [];
        foreach ($this->level->getPlayers() as $p) {
            $dx = abs($p->x - $this->cx);
            $dz = abs($p->z - $this->cz);
            if ($dx <= self::VIEW_RANGE && $dz <= self::VIEW_RANGE) {
                $players[] = $p;
            }
        }
        return $players;
    }

    private function spawnOneOrb($players, $i) {
        if ($this->cleaned) return;

        $oldEid = $this->orbEntities[$i]["eid"];
        $this->exileAndRemove($oldEid);

        $newEid = self::newEid();
        $this->allSpawnedEids[$newEid] = true;
        $this->orbEntities[$i]["eid"] = $newEid;

        $orb = $this->orbEntities[$i];

        $a = $orb["angle"];
        $orbitR = $this->radius * 0.6;
        $x = $this->cx + cos($a) * $orbitR;
        $y = $this->cy + $orb["heightOffset"];
        $z = $this->cz + sin($a) * $orbitR;

        $this->orbEntities[$i]["x"] = $x;
        $this->orbEntities[$i]["y"] = $y;
        $this->orbEntities[$i]["z"] = $z;

        $pk = new AddEntityPacket();
        $pk->eid = $newEid;
        $pk->type = self::ORB_TYPE;
        $pk->x = (float)$x;
        $pk->y = (float)$y;
        $pk->z = (float)$z;
        $pk->speedX = 0.0;
        $pk->speedY = 0.0;
        $pk->speedZ = 0.0;
        $pk->yaw = 0.0;
        $pk->pitch = 0.0;
        $pk->metadata = [
            Entity::DATA_FLAGS => [Entity::DATA_TYPE_BYTE, 0],
            Entity::DATA_NO_AI => [Entity::DATA_TYPE_BYTE, 1]
        ];

        foreach ($players as $pl) {
            $pl->dataPacket($pk);
        }
    }

    private function spawnAllOrbs($players) {
        for ($i = 0; $i < $this->orbCount; $i++) {
            if ($this->breakStates[$i] > 0) continue;

            $orb = $this->orbEntities[$i];

            $a = $orb["angle"];
            $orbitR = $this->radius * 0.6;
            $x = $this->cx + cos($a) * $orbitR;
            $y = $this->cy + $orb["heightOffset"];
            $z = $this->cz + sin($a) * $orbitR;

            $this->orbEntities[$i]["x"] = $x;
            $this->orbEntities[$i]["y"] = $y;
            $this->orbEntities[$i]["z"] = $z;

            $pk = new AddEntityPacket();
            $pk->eid = $orb["eid"];
            $pk->type = self::ORB_TYPE;
            $pk->x = (float)$x;
            $pk->y = (float)$y;
            $pk->z = (float)$z;
            $pk->speedX = 0.0;
            $pk->speedY = 0.0;
            $pk->speedZ = 0.0;
            $pk->yaw = 0.0;
            $pk->pitch = 0.0;
            $pk->metadata = [
                Entity::DATA_FLAGS => [Entity::DATA_TYPE_BYTE, 0],
                Entity::DATA_NO_AI => [Entity::DATA_TYPE_BYTE, 1]
            ];

            foreach ($players as $pl) {
                $pl->dataPacket($pk);
            }
        }
    }

    private function orbitOrbs($players) {
        if ($this->cleaned) return;

        foreach ($this->orbEntities as $i => &$orb) {
            if ($this->breakStates[$i] > 0) continue;
            if ($this->chargingOrbs[$i] !== null) continue;

            $orb["angle"] += $orb["orbitSpeed"];
            $a = $orb["angle"];
            $orbitR = $this->radius * 0.6;
            $x = $this->cx + cos($a) * $orbitR;
            $y = $this->cy + $orb["heightOffset"] + sin($this->phase + $i) * 0.4;
            $z = $this->cz + sin($a) * $orbitR;

            $orb["x"] = $x;
            $orb["y"] = $y;
            $orb["z"] = $z;

            $pk = new MoveEntityPacket();
            $pk->eid = $orb["eid"];
            $pk->x = (float)$x;
            $pk->y = (float)$y;
            $pk->z = (float)$z;
            $pk->yaw = 0;
            $pk->pitch = 0;
            $pk->headYaw = 0;

            foreach ($players as $pl) {
                $pl->dataPacket($pk);
            }

            if ($this->ticksRan % 4 === 0) {
                $this->level->addParticle(new DustParticle(
                    new Vector3($x, $y, $z),
                    255, 255, 0
                ));
            }
        }
        unset($orb);
    }

    private function startCharge($players) {
        if ($this->cleaned) return;

        $combatPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceCombat");
        $toggle = ($combatPlugin !== null && $combatPlugin->isEnabled()) ? $combatPlugin->getCombatToggle() : null;

        $targets = [];

        foreach ($this->level->getEntities() as $entity) {
            if (!$entity->isAlive()) continue;

            $isValidTarget = false;

            if ($entity instanceof Player) {
                if ($entity->getName() === $this->ownerName) continue;
                if (!$this->plugin->canTargetPlayer($this->ownerName, $entity)) continue;
                $isValidTarget = true;
            } elseif ($entity instanceof NPCEntity) {
                if ($this->ownerName === "npc_" . $entity->getId()) continue;
                $isValidTarget = true;
            } elseif ($entity instanceof FactoryEntity) {
                $isValidTarget = true;
            }

            if (!$isValidTarget) continue;

            $ePos = $entity->getPosition();
            $dx = $ePos->x - $this->cx;
            $dy = $ePos->y - $this->cy;
            $dz = $ePos->z - $this->cz;
            $dist = sqrt($dx * $dx + $dy * $dy + $dz * $dz);

            if ($dist <= $this->radius) {
                $targets[] = $entity;
            }
        }

        if (empty($targets)) return;

        $availableOrb = -1;
        for ($i = 0; $i < $this->orbCount; $i++) {
            if ($this->breakStates[$i] <= 0 && $this->chargingOrbs[$i] === null) {
                $availableOrb = $i;
                break;
            }
        }

        if ($availableOrb < 0) return;

        $target = $targets[mt_rand(0, count($targets) - 1)];
        $tPos = $target->getPosition();

        $orb = $this->orbEntities[$availableOrb];

        $this->chargingOrbs[$availableOrb] = [
            "target" => $target,
            "startX" => $orb["x"],
            "startY" => $orb["y"],
            "startZ" => $orb["z"],
            "targetX" => $tPos->x,
            "targetY" => $tPos->y + 1.0,
            "targetZ" => $tPos->z,
            "step" => 0
        ];
    }

    private function updateChargingOrbs($players) {
        if ($this->cleaned) return;

        foreach ($this->chargingOrbs as $i => &$charge) {
            if ($charge === null) continue;

            $charge["step"]++;
            $progress = min(1.0, $charge["step"] / self::CHARGE_STEPS);

            $target = $charge["target"];
            if ($target !== null && $target->isAlive() && !$target->closed) {
                $tPos = $target->getPosition();
                $charge["targetX"] = $tPos->x;
                $charge["targetY"] = $tPos->y + 1.0;
                $charge["targetZ"] = $tPos->z;
            }

            $x = $charge["startX"] + ($charge["targetX"] - $charge["startX"]) * $progress;
            $y = $charge["startY"] + ($charge["targetY"] - $charge["startY"]) * $progress;
            $z = $charge["startZ"] + ($charge["targetZ"] - $charge["startZ"]) * $progress;

            $this->orbEntities[$i]["x"] = $x;
            $this->orbEntities[$i]["y"] = $y;
            $this->orbEntities[$i]["z"] = $z;

            $orb = $this->orbEntities[$i];
            $pk = new MoveEntityPacket();
            $pk->eid = $orb["eid"];
            $pk->x = (float)$x;
            $pk->y = (float)$y;
            $pk->z = (float)$z;
            $pk->yaw = $progress * 720;
            $pk->pitch = $progress * 360;
            $pk->headYaw = $progress * 720;

            foreach ($players as $pl) {
                $pl->dataPacket($pk);
            }

            $this->level->addParticle(new DustParticle(
                new Vector3($x + (mt_rand(-3, 3) / 10), $y + (mt_rand(-3, 3) / 10), $z + (mt_rand(-3, 3) / 10)),
                255, 255, 0
            ));
            $this->level->addParticle(new InstantEnchantParticle(new Vector3($x, $y, $z)));

            if ($progress >= 1.0) {
                $this->hitTarget($players, $i, $charge["target"]);
                $this->chargingOrbs[$i] = null;
            }
        }
        unset($charge);
    }

    private function hitTarget($players, $orbIndex, $target) {
        if ($this->cleaned) return;

        $orb = $this->orbEntities[$orbIndex];
        $tx = $orb["x"];
        $ty = $orb["y"];
        $tz = $orb["z"];

        if ($target !== null && $target->isAlive() && !$target->closed) {
            $owner = $this->plugin->getServer()->getPlayerExact($this->ownerName);
            if ($owner !== null) {
                $ev = new EntityDamageByEntityEvent($owner, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, self::HIT_DAMAGE);
                $target->attack(self::HIT_DAMAGE, $ev);
            } else {
                $ev = new EntityDamageEvent($target, EntityDamageEvent::CAUSE_MAGIC, self::HIT_DAMAGE);
                $target->attack(self::HIT_DAMAGE, $ev);
            }

            $slow = Effect::getEffect(Effect::SLOWNESS);
            $slow->setAmplifier(1);
            $slow->setDuration(20);
            $slow->setVisible(false);
            $target->addEffect($slow);

            if ($target instanceof Player) {
                $target->sendTip(TextFormat::YELLOW . "SHOCKED!");
            }
        }

        for ($i = 0; $i < 14; $i++) {
            $a = ($i / 14) * M_PI * 2;
            $this->level->addParticle(new DustParticle(new Vector3(
                $tx + cos($a) * 1.8,
                $ty,
                $tz + sin($a) * 1.8
            ), 255, 255, 0));
        }

        for ($i = 0; $i < 8; $i++) {
            $a = ($i / 8) * M_PI * 2;
            $this->level->addParticle(new DustParticle(new Vector3(
                $tx + cos($a) * 2.5,
                $ty - 0.5,
                $tz + sin($a) * 2.5
            ), 200, 200, 200));
        }

        for ($p = 0; $p < 10; $p++) {
            $this->level->addParticle(new InstantEnchantParticle(new Vector3(
                $tx + (mt_rand(-12, 12) / 10),
                $ty + (mt_rand(-5, 15) / 10),
                $tz + (mt_rand(-12, 12) / 10)
            )));
        }

        for ($p = 0; $p < 6; $p++) {
            $this->level->addParticle(new CriticalParticle(new Vector3(
                $tx + (mt_rand(-8, 8) / 10),
                $ty + (mt_rand(0, 10) / 10),
                $tz + (mt_rand(-8, 8) / 10)
            )));
        }

        $this->level->addParticle(new ExplodeParticle(new Vector3($tx, $ty, $tz)));
        $this->level->addParticle(new ExplodeParticle(new Vector3($tx, $ty - 0.5, $tz)));
        $this->level->addSound(new PopSound(new Vector3($tx, $ty, $tz)));
        $this->level->addSound(new ClickSound(new Vector3($tx, $ty, $tz)));
        $this->level->addSound(new AnvilUseSound(new Vector3($tx, $ty, $tz)));

        $this->exileAndRemove($orb["eid"]);
        $newEid = self::newEid();
        $this->allSpawnedEids[$newEid] = true;
        $this->orbEntities[$orbIndex]["eid"] = $newEid;

        $this->breakStates[$orbIndex] = $this->breakCooldown;
    }

    private function updateBreakStates($players) {
        if ($this->cleaned) return;

        foreach ($this->breakStates as $i => &$state) {
            if ($state <= 0) continue;

            $state--;

            if ($state <= 0) {
                $this->orbEntities[$i]["angle"] += mt_rand(0, 628) / 100;
                $this->spawnOneOrb($players, $i);

                $orb = $this->orbEntities[$i];
                for ($p = 0; $p < 6; $p++) {
                    $ra = ($p / 6) * M_PI * 2;
                    $this->level->addParticle(new DustParticle(new Vector3(
                        $orb["x"] + cos($ra) * 0.6,
                        $orb["y"],
                        $orb["z"] + sin($ra) * 0.6
                    ), 255, 255, 0));
                }
                $this->level->addSound(new PopSound(new Vector3(
                    $orb["x"], $orb["y"], $orb["z"]
                )));
            }
        }
        unset($state);
    }

    private function drawStormVFX($players) {
        $t = $this->phase;
        $r = $this->radius;
        $cx = $this->cx;
        $cy = $this->cy;
        $cz = $this->cz;

        if ($this->ticksRan % 3 !== 0) return;

        $eqPts = 12;
        for ($i = 0; $i < $eqPts; $i++) {
            $a = ($i / $eqPts) * M_PI * 2 + $t * 0.2;
            $this->level->addParticle(new DustParticle(
                new Vector3($cx + cos($a) * $r, $cy, $cz + sin($a) * $r),
                255, 255, 0
            ));
        }

        if ($this->ticksRan % 6 === 0) {
            $fa = mt_rand(0, 628) / 100;
            $fd = mt_rand(10, (int)($r * 8)) / 10;
            $this->level->addParticle(new InstantEnchantParticle(
                new Vector3($cx + cos($fa) * $fd, $cy + (mt_rand(0, 30) / 10), $cz + sin($fa) * $fd)
            ));
        }

        if ($this->ticksRan % 15 === 0) {
            $la = mt_rand(0, 628) / 100;
            $ld = mt_rand(20, (int)($r * 8)) / 10;
            $lx = $cx + cos($la) * $ld;
            $lz = $cz + sin($la) * $ld;
            for ($h = 0; $h < 8; $h++) {
                $this->level->addParticle(new DustParticle(
                    new Vector3($lx + (mt_rand(-4, 4) / 10), $cy + 6 + $h * -0.7, $lz + (mt_rand(-4, 4) / 10)),
                    255, 255, 100
                ));
            }
            $this->level->addParticle(new InstantEnchantParticle(new Vector3($lx, $cy, $lz)));
        }
    }

    public function forceCleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        $allPlayers = [];
        try {
            if ($this->level !== null) {
                $allPlayers = $this->level->getPlayers();
            }
        } catch (\Exception $e) {}

        foreach ($this->allSpawnedEids as $eid => $v) {
            $movePk = new MoveEntityPacket();
            $movePk->eid = $eid;
            $movePk->x = 100000.0;
            $movePk->y = -100.0;
            $movePk->z = 100000.0;
            $movePk->yaw = 0.0;
            $movePk->pitch = 0.0;
            $movePk->headYaw = 0.0;

            $removePk = new RemoveEntityPacket();
            $removePk->eid = $eid;

            foreach ($allPlayers as $pl) {
                try {
                    $pl->dataPacket($movePk);
                    $pl->dataPacket($removePk);
                } catch (\Exception $e) {}
            }
        }

        $this->orbEntities = [];
        $this->chargingOrbs = [];
        $this->allSpawnedEids = [];
    }
}
class GoroDelayedRemoveTask extends Task {

    private $plugin;
    private $level;
    private $eids;

    public function __construct($plugin, Level $level, array $eids) {
        $this->plugin = $plugin;
        $this->level  = $level;
        $this->eids   = $eids;
    }

    public function onRun($currentTick) {
        $allPlayers = [];
        try {
            if ($this->level !== null) {
                foreach ($this->level->getPlayers() as $pl) {
                    $allPlayers[spl_object_hash($pl)] = $pl;
                }
            }
        } catch (\Exception $e) {}
        try {
            foreach ($this->plugin->getServer()->getOnlinePlayers() as $pl) {
                $allPlayers[spl_object_hash($pl)] = $pl;
            }
        } catch (\Exception $e) {}
        foreach ($this->eids as $eid) {
            $movePk          = new MoveEntityPacket();
            $movePk->eid     = $eid;
            $movePk->x       = 0.0;
            $movePk->y       = 0.0;
            $movePk->z       = 0.0;
            $movePk->yaw     = 0.0;
            $movePk->pitch   = 0.0;
            $movePk->headYaw = 0.0;
            $removePk      = new RemoveEntityPacket();
            $removePk->eid = $eid;
            foreach ($allPlayers as $pl) {
                try {
                    $pl->dataPacket($movePk);
                    $pl->dataPacket($removePk);
                } catch (\Exception $e) {}
            }
        }
    }
}