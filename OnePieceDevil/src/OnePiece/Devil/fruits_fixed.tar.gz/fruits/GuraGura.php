<?php
namespace OnePiece\Devil\fruits;

use OnePiece\Devil\BaseFruit;
use OnePiece\Devil\Main;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;
use pocketmine\entity\Effect;
use pocketmine\utils\TextFormat;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\Task;
use pocketmine\level\Level;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\ExplodeParticle;
use pocketmine\level\particle\SplashParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\sound\SplashSound;
use pocketmine\level\sound\PopSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\network\protocol\MoveEntityPacket;
use pocketmine\network\protocol\RemoveEntityPacket;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;

class GuraGura extends BaseFruit {

    public function getId() { return "gura_gura"; }
    public function getDisplayName() { return "Quake-Quake Fruit"; }
    public function getDescription() { return "Quake Fruit - the power to destroy the world itself."; }
    public function getType() { return "paramecia"; }
    public function getRarity() { return "mythical"; }

    public function getAbilityNames() {
        return ["ability1" => "Quake Punch", "ability2" => "Shima Yurashi"];
    }

    public function getAbilityCooldowns() {
        return ["ability1" => 5.0, "ability2" => 22.0];
    }

    public function useAbility(Player $player, $ability) {
        switch ($ability) {
            case "ability1": return $this->quakePunch($player);
            case "ability2": return $this->shimaYurashi($player);
        }
        return 0;
    }

    private function quakePunch(Player $player) {
        $combatPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceCombat");
        $toggle = ($combatPlugin !== null && $combatPlugin->isEnabled()) ? $combatPlugin->getCombatToggle() : null;

        $target = $this->findFrontTarget($player, 10);
        $vfx = $this->getVFX();

        if ($target === null) {
            if ($vfx) {
                $vfx->getFruitVFX()->spawnEarthquake($player, 3.0);
            }
            $this->spawnAirCrack($player);
            $player->sendTip(TextFormat::YELLOW . "QUAKE PUNCH! - air crack!");
            return 3.0;
        }

        if ($target instanceof Player) {
            if (!$this->plugin->canTargetPlayer($player->getName(), $target)) {
                if ($vfx) {
                    $vfx->getFruitVFX()->spawnEarthquake($player, 3.0);
                }
                $this->spawnAirCrack($player);
                $player->sendTip(TextFormat::YELLOW . "QUAKE PUNCH! - air crack!");
                return 3.0;
            }
        }

        $mult = min(1.5, $this->getHakiMultiplier($player));
        $damage = min(14.0, 6.5 * $mult);

        $ev = new EntityDamageByEntityEvent($player, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage);
        $target->attack($damage, $ev);

        $dir = $player->getDirectionVector();
        $this->safeSetMotion($player, $target, new Vector3($dir->x * 3.5, 1.0, $dir->z * 3.5));

        $nausea = Effect::getEffect(Effect::NAUSEA);
        $nausea->setAmplifier(2);
        $nausea->setDuration(60);
        $nausea->setVisible(false);
        $this->safeAddEffect($player, $target, $nausea);

        $player->sendTip(TextFormat::YELLOW . "QUAKE PUNCH!");
        if ($target instanceof Player) {
            $target->sendTip(TextFormat::RED . "QUAKE PUNCH! World is shaking!");
        }

        if ($vfx) {
            $vfx->getFruitVFX()->spawnEarthquake($player, 4.0);
        }

        $tPos = $target->getPosition();
        $debrisTask = new GuraDebrisTask(
            $this->plugin,
            $target->getLevel(),
            $tPos->x,
            $tPos->y,
            $tPos->z
        );
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($debrisTask, 1);

        return $this->getAbilityCooldowns()["ability1"];
    }

private function shimaYurashi(Player $player) {
    $combatPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceCombat");
    $toggle = ($combatPlugin !== null && $combatPlugin->isEnabled()) ? $combatPlugin->getCombatToggle() : null;

    $mult = min(1.5, $this->getHakiMultiplier($player));
    $baseRadius = 18.0;
    $bonusRadius = 8.0 * ($mult - 1.0);
    $radius = $baseRadius + $bonusRadius;
    $damage = min(14.0, 6.5 * $mult);

    $player->sendTip(TextFormat::YELLOW . TextFormat::BOLD . "SHIMA YURASHI!");
    $player->sendMessage(TextFormat::AQUA . "Tsunami waves incoming!");

    $pos = $player->getPosition();
    $lv = $player->getLevel();

    $this->spawnInitialQuake($player, $radius);

    $vfx = $this->getVFX();
    if ($vfx) {
        $vfx->getFruitVFX()->spawnEarthquake($player, $radius * 0.4);
    }

    $res = Effect::getEffect(Effect::DAMAGE_RESISTANCE);
    $res->setAmplifier(1);
    $res->setDuration(100);
    $res->setVisible(false);
    $player->addEffect($res);

    $tsunamiTask = new TsunamiWaveTask(
        $this->plugin,
        $lv,
        $pos->x,
        $pos->y,
        $pos->z,
        $radius,
        $damage,
        $player->getName(),
        $toggle
    );
    $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($tsunamiTask, 1);

    return $this->getAbilityCooldowns()["ability2"];
}

    private function spawnAirCrack(Player $player) {
        $lv = $player->getLevel();
        $dir = $player->getDirectionVector();
        $pos = $player->add($dir->x * 2, $player->getEyeHeight(), $dir->z * 2);

        for ($i = 0; $i < 8; $i++) {
            $a = ($i / 8) * M_PI * 2;
            $r = 0.8 + (mt_rand(0, 5) / 10);
            $lv->addParticle(new DustParticle(
                new Vector3($pos->x + cos($a) * $r, $pos->y + sin($a) * $r * 0.5, $pos->z + sin($a) * $r),
                255, 255, 255
            ));
        }

        for ($i = 0; $i < 6; $i++) {
            $lv->addParticle(new CriticalParticle(new Vector3(
                $pos->x + (mt_rand(-10, 10) / 10),
                $pos->y + (mt_rand(-5, 5) / 10),
                $pos->z + (mt_rand(-10, 10) / 10)
            )));
        }

        for ($i = 0; $i < 3; $i++) {
            $off = ($i - 1) * 0.5;
            $lv->addParticle(new ExplodeParticle(new Vector3(
                $pos->x + $dir->x * $off,
                $pos->y,
                $pos->z + $dir->z * $off
            )));
        }

        $lv->addSound(new AnvilUseSound($pos));
    }

    private function spawnInitialQuake(Player $player, $radius) {
        $lv = $player->getLevel();
        $pos = $player->getPosition();
        $cx = $pos->x;
        $cy = $pos->y;
        $cz = $pos->z;

        for ($ring = 0; $ring < 3; $ring++) {
            $rr = 2.0 + $ring * 1.5;
            $pts = 12 + $ring * 4;
            for ($i = 0; $i < $pts; $i++) {
                $a = ($i / $pts) * M_PI * 2;
                $lv->addParticle(new DustParticle(
                    new Vector3($cx + cos($a) * $rr, $cy + 0.2, $cz + sin($a) * $rr),
                    139, 90, 43
                ));
            }
        }

        for ($i = 0; $i < 8; $i++) {
            $a = ($i / 8) * M_PI * 2;
            $d = 1.5 + mt_rand(0, 20) / 10;
            $lv->addParticle(new ExplodeParticle(new Vector3(
                $cx + cos($a) * $d,
                $cy + 0.5,
                $cz + sin($a) * $d
            )));
        }

        for ($i = 0; $i < 12; $i++) {
            $a = mt_rand(0, 628) / 100;
            $d = mt_rand(10, 40) / 10;
            $lv->addParticle(new CriticalParticle(new Vector3(
                $cx + cos($a) * $d,
                $cy + mt_rand(0, 15) / 10,
                $cz + sin($a) * $d
            )));
        }

        $lv->addSound(new AnvilUseSound(new Vector3($cx, $cy, $cz)));
    }

    private function getVFX() {
        return $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceFruits");
    }

    public function onEquip(Player $player) {
        $player->sendMessage(TextFormat::YELLOW . "=== Gura-Gura no Mi ===");
        $player->sendMessage(TextFormat::WHITE . "The Power to Destroy the World");
        $player->sendMessage("");
        $player->sendMessage(TextFormat::YELLOW . "[Tap]: " . TextFormat::WHITE . "Quake Punch");
        $player->sendMessage(TextFormat::GRAY . "  Devastating punch with ground shatter");
        $player->sendMessage("");
        $player->sendMessage(TextFormat::YELLOW . "[Sneak+Tap]: " . TextFormat::WHITE . "Shima Yurashi");
        $player->sendMessage(TextFormat::GRAY . "  Tsunami waves crash inward");
        $player->sendMessage(TextFormat::YELLOW . "========================");
    }

    public function onUnequip(Player $player) {
        $player->sendMessage(TextFormat::GRAY . "Quake powers fade...");
    }
}

class GuraDebrisTask extends Task {

    private $plugin;
    private $level;
    private $cx;
    private $cy;
    private $cz;
    private $debris = [];
    private $ticksRan = 0;
    private $maxTicks = 50;
    private $cleaned = false;

    const FALLING_SAND_TYPE = 66;
    const DATA_BLOCK_INFO = 20;

    private static $nextEid = 600000;

    private static function newEid() {
        $eid = self::$nextEid++;
        if (self::$nextEid > 699999) {
            self::$nextEid = 600000;
        }
        return $eid;
    }

    public function __construct($plugin, Level $level, $cx, $cy, $cz) {
        $this->plugin = $plugin;
        $this->level = $level;
        $this->cx = (float)$cx;
        $this->cy = (float)$cy;
        $this->cz = (float)$cz;

        $this->spawnDebris();
    }

    private function scanGroundBlocks() {
        $found = [];
        $skip = [0, 8, 9, 10, 11, 26, 30, 31, 32, 37, 38, 39, 40, 50, 51, 55, 59, 63, 64, 65, 68, 69, 70, 71, 72, 75, 76, 77, 83, 90, 93, 94, 96, 104, 105, 106, 115, 127, 131, 132, 141, 142, 143, 144, 147, 148, 149, 150, 154, 157, 167, 171, 175, 176, 177, 178, 183, 184, 185, 186, 187, 193, 194, 195, 196, 197];

        for ($bx = -3; $bx <= 3; $bx++) {
            for ($bz = -3; $bz <= 3; $bz++) {
                for ($by = -3; $by <= 1; $by++) {
                    $block = $this->level->getBlock(new Vector3((int)($this->cx + $bx), (int)($this->cy + $by), (int)($this->cz + $bz)));
                    $id = $block->getId();
                    $dmg = $block->getDamage();

                    if (in_array($id, $skip)) continue;

                    $key = $id . ":" . $dmg;
                    if (!isset($found[$key])) {
                        $found[$key] = ["id" => $id, "damage" => $dmg];
                    }

                    if (count($found) >= 5) {
                        return array_values($found);
                    }
                }
            }
        }

        if (empty($found)) {
            $found[] = ["id" => 4, "damage" => 0];
            $found[] = ["id" => 1, "damage" => 0];
            $found[] = ["id" => 3, "damage" => 0];
        }

        return array_values($found);
    }

    private function spawnDebris() {
        $blocks = $this->scanGroundBlocks();
        $players = $this->level->getPlayers();
        $debrisCount = mt_rand(4, 6);

        for ($i = 0; $i < $debrisCount; $i++) {
            $blockData = $blocks[$i % count($blocks)];
            $eid = self::newEid();

            $angle = ($i / $debrisCount) * M_PI * 2 + (mt_rand(-30, 30) / 100);
            $dist = 1.0 + (mt_rand(0, 30) / 10);
            $power = 0.18 + (mt_rand(0, 12) / 100);

            $this->debris[$eid] = [
                "eid" => $eid,
                "blockId" => $blockData["id"],
                "blockDamage" => $blockData["damage"],
                "x" => $this->cx + (mt_rand(-5, 5) / 10),
                "y" => $this->cy,
                "z" => $this->cz + (mt_rand(-5, 5) / 10),
                "vx" => cos($angle) * $dist * $power,
                "vy" => 0.6 + (mt_rand(0, 35) / 100),
                "vz" => sin($angle) * $dist * $power,
                "life" => 28 + mt_rand(-5, 10),
                "rotSpeed" => mt_rand(18, 40),
                "tick" => 0
            ];

            $pk = new AddEntityPacket();
            $pk->eid = $eid;
            $pk->type = self::FALLING_SAND_TYPE;
            $pk->x = (float)$this->debris[$eid]["x"];
            $pk->y = (float)$this->debris[$eid]["y"];
            $pk->z = (float)$this->debris[$eid]["z"];
            $pk->speedX = 0.0;
            $pk->speedY = 0.0;
            $pk->speedZ = 0.0;
            $pk->yaw = 0.0;
            $pk->pitch = 0.0;
            $pk->metadata = [
                Entity::DATA_FLAGS => [Entity::DATA_TYPE_BYTE, 0],
                self::DATA_BLOCK_INFO => [Entity::DATA_TYPE_INT, $blockData["id"] | ($blockData["damage"] << 8)],
                Entity::DATA_NO_AI => [Entity::DATA_TYPE_BYTE, 1]
            ];

            foreach ($players as $pl) {
                $pl->dataPacket($pk);
            }
        }

        for ($i = 0; $i < 10; $i++) {
            $da = ($i / 10) * M_PI * 2;
            $dd = 0.5 + mt_rand(0, 15) / 10;
            $this->level->addParticle(new DustParticle(
                new Vector3($this->cx + cos($da) * $dd, $this->cy + 0.2, $this->cz + sin($da) * $dd),
                139, 90, 43
            ));
        }

        $this->level->addSound(new AnvilUseSound(new Vector3($this->cx, $this->cy, $this->cz)));
    }

    private function releaseBlock($eid) {
        $pk = new MoveEntityPacket();
        $pk->eid = $eid;
        $pk->x = 0.0;
        $pk->y = 0.0;
        $pk->z = 0.0;
        $pk->yaw = 0.0;
        $pk->pitch = 0.0;
        $pk->headYaw = 0.0;

        foreach ($this->level->getPlayers() as $pl) {
            try {
                $pl->dataPacket($pk);
            } catch (\Exception $e) {}
        }
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->ticksRan++;

        if ($this->ticksRan > $this->maxTicks || empty($this->debris)) {
            $this->forceCleanup();
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $players = $this->level->getPlayers();
        if (empty($players)) return;

        $toRemove = [];

        foreach ($this->debris as $eid => &$d) {
            $d["tick"]++;
            $d["life"]--;

            $d["vy"] -= 0.05;
            $d["vx"] *= 0.97;
            $d["vz"] *= 0.97;

            $d["x"] += $d["vx"];
            $d["y"] += $d["vy"];
            $d["z"] += $d["vz"];

            if ($d["y"] < $this->cy - 1.5 && $d["vy"] < 0) {
                $d["vy"] = 0;
                $d["vx"] *= 0.4;
                $d["vz"] *= 0.4;
                $d["y"] = $this->cy - 1.5;
            }

            if ($d["life"] > 0) {
                $pk = new MoveEntityPacket();
                $pk->eid = $eid;
                $pk->x = (float)$d["x"];
                $pk->y = (float)$d["y"];
                $pk->z = (float)$d["z"];
                $pk->yaw = $d["tick"] * $d["rotSpeed"];
                $pk->pitch = $d["tick"] * ($d["rotSpeed"] * 0.8);
                $pk->headYaw = $d["tick"] * $d["rotSpeed"];

                foreach ($players as $pl) {
                    $pl->dataPacket($pk);
                }

                if ($d["tick"] < 8 && $d["tick"] % 2 === 0) {
                    $this->level->addParticle(new DustParticle(
                        new Vector3($d["x"], $d["y"], $d["z"]),
                        139, 90, 43
                    ));
                }
            } else {
                $this->releaseBlock($eid);
                $toRemove[] = $eid;
            }
        }
        unset($d);

        foreach ($toRemove as $eid) {
            unset($this->debris[$eid]);
        }
    }

    public function forceCleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        $eidsToRemove = [];

        foreach ($this->debris as $eid => $d) {
            $this->releaseBlock($eid);
            $eidsToRemove[] = $eid;
        }

        $this->debris = [];

        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
            new DelayedBlockRemoveTask($this->plugin, $this->level, $eidsToRemove),
            40
        );
    }
}

class TsunamiWaveTask extends Task {

    private $plugin;
    private $level;
    private $cx;
    private $cy;
    private $cz;
    private $maxRadius;
    private $damage;
    private $ownerName;
    private $toggle;

    private $ticksRan = 0;
    private $maxTicks = 120;
    private $cleaned = false;

    private $waves = [];
    private $waveCount = 2;
    private $waveSpacing = 6.0;
    private $waveSpeed = 0.3;
    private $waveHeight = 4.0;
    private $blocksPerRing = 16;

    private $hitPlayers = [];
    private $allSpawnedEids = [];

    const FALLING_SAND_TYPE = 66;
    const DATA_BLOCK_INFO = 20;
    const VIEW_RANGE = 70;

    private static $nextEid = 500000;

    private static function newEid() {
        $eid = self::$nextEid++;
        if (self::$nextEid > 599999) {
            self::$nextEid = 500000;
        }
        return $eid;
    }

    public function __construct($plugin, Level $level, $cx, $cy, $cz, $maxRadius, $damage, $ownerName, $toggle) {
        $this->plugin = $plugin;
        $this->level = $level;
        $this->cx = (float)$cx;
        $this->cy = (float)$cy;
        $this->cz = (float)$cz;
        $this->maxRadius = (float)$maxRadius;
        $this->damage = $damage;
        $this->ownerName = $ownerName;
        $this->toggle = $toggle;

        $this->initializeWaves();
    }

    private function releaseBlock($eid) {
        $pk = new MoveEntityPacket();
        $pk->eid = $eid;
        $pk->x = 0.0;
        $pk->y = 0.0;
        $pk->z = 0.0;
        $pk->yaw = 0.0;
        $pk->pitch = 0.0;
        $pk->headYaw = 0.0;

        foreach ($this->level->getPlayers() as $pl) {
            try {
                $pl->dataPacket($pk);
            } catch (\Exception $e) {}
        }
    }

    private function initializeWaves() {
        $lv = $this->level;

        for ($w = 0; $w < $this->waveCount; $w++) {
            $waveRadius = $this->maxRadius + ($w * $this->waveSpacing);

            $this->waves[$w] = [
                "radius" => $waveRadius,
                "startRadius" => $waveRadius,
                "blocks" => [],
                "active" => true
            ];

            $this->spawnWaveWall($w);
        }

        for ($i = 0; $i < 16; $i++) {
            $a = ($i / 16) * M_PI * 2;
            $lv->addParticle(new DustParticle(
                new Vector3($this->cx + cos($a) * $this->maxRadius, $this->cy + 2, $this->cz + sin($a) * $this->maxRadius),
                30, 144, 255
            ));
        }

        $lv->addSound(new SplashSound(new Vector3($this->cx, $this->cy, $this->cz)));
        $lv->addSound(new SplashSound(new Vector3($this->cx, $this->cy + 1, $this->cz)));
    }

    private function spawnWaveWall($waveIndex) {
        $waveData = &$this->waves[$waveIndex];
        $baseRadius = $waveData["radius"];
        $players = $this->level->getPlayers();

        for ($ring = 0; $ring < 3; $ring++) {
            $ringHeight = $ring * 1.4;
            $ringOffset = $ring * 0.3;

            for ($i = 0; $i < $this->blocksPerRing; $i++) {
                $angle = ($i / $this->blocksPerRing) * M_PI * 2;

                $blockRadius = $baseRadius - $ringOffset;
                $x = $this->cx + cos($angle) * $blockRadius;
                $z = $this->cz + sin($angle) * $blockRadius;
                $y = $this->cy + $ringHeight;

                $eid = self::newEid();
                $this->allSpawnedEids[$eid] = true;

                $waveData["blocks"][$eid] = [
                    "eid" => $eid,
                    "angle" => $angle,
                    "ring" => $ring,
                    "baseHeight" => $ringHeight,
                    "baseOffset" => $ringOffset,
                    "x" => $x,
                    "y" => $y,
                    "z" => $z
                ];

                $pk = new AddEntityPacket();
                $pk->eid = $eid;
                $pk->type = self::FALLING_SAND_TYPE;
                $pk->x = (float)$x;
                $pk->y = (float)$y;
                $pk->z = (float)$z;
                $pk->speedX = 0.0;
                $pk->speedY = 0.0;
                $pk->speedZ = 0.0;
                $pk->yaw = 0.0;
                $pk->pitch = 0.0;
                $pk->metadata = [
                    Entity::DATA_FLAGS => [Entity::DATA_TYPE_BYTE, 0],
                    self::DATA_BLOCK_INFO => [Entity::DATA_TYPE_INT, 35 | (3 << 8)],
                    Entity::DATA_NO_AI => [Entity::DATA_TYPE_BYTE, 1]
                ];

                foreach ($players as $pl) {
                    $pl->dataPacket($pk);
                }
            }
        }
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->ticksRan++;

        if ($this->ticksRan > $this->maxTicks) {
            $this->forceCleanup();
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        if ($this->plugin->getServer()->getLevelByName($this->level->getName()) === null) {
            $this->forceCleanup();
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $allPlayers = $this->level->getPlayers();
        $nearbyPlayers = $this->getNearbyPlayers();
        if (empty($nearbyPlayers)) return;

        $allWavesDone = true;

        foreach ($this->waves as $wIndex => &$waveData) {
            if (!$waveData["active"]) continue;

            $waveData["radius"] -= $this->waveSpeed;

            if ($waveData["radius"] <= 2.5) {
                $this->crashWave($wIndex, $allPlayers);
                $waveData["active"] = false;
                continue;
            }

            $allWavesDone = false;

            $this->updateWaveWall($wIndex, $allPlayers);
            $this->checkWaveHits($wIndex);
        }
        unset($waveData);

        if ($this->ticksRan % 4 === 0) {
            $this->drawParticles();
        }

        if ($allWavesDone) {
            $this->spawnFinalCrash();
            $this->forceCleanup();
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
        }
    }

    private function getNearbyPlayers() {
        $players = [];
        foreach ($this->level->getPlayers() as $p) {
            $dx = abs($p->x - $this->cx);
            $dz = abs($p->z - $this->cz);
            if ($dx <= self::VIEW_RANGE && $dz <= self::VIEW_RANGE) {
                $players[] = $p;
            }
        }
        return $players;
    }

    private function updateWaveWall($waveIndex, $allPlayers) {
        $waveData = &$this->waves[$waveIndex];
        $currentRadius = $waveData["radius"];
        $startRadius = $waveData["startRadius"];

        $progress = 1.0 - ($currentRadius / $startRadius);
        $wavePhase = $this->ticksRan * 0.1;

        foreach ($waveData["blocks"] as $eid => &$blockData) {
            $angle = $blockData["angle"];
            $ring = $blockData["ring"];
            $baseHeight = $blockData["baseHeight"];
            $baseOffset = $blockData["baseOffset"];

            $curlOffset = $baseOffset + ($progress * $ring * 0.8);
            $blockRadius = $currentRadius - $curlOffset;

            $x = $this->cx + cos($angle) * $blockRadius;
            $z = $this->cz + sin($angle) * $blockRadius;

            $waveMotion = sin($wavePhase + $angle * 3) * 0.3;
            $crashDrop = $progress * $ring * 0.5;

            $y = $this->cy + $baseHeight + $waveMotion - $crashDrop;

            if ($y < $this->cy + 0.3) {
                $y = $this->cy + 0.3;
            }

            $blockData["x"] = $x;
            $blockData["y"] = $y;
            $blockData["z"] = $z;

            $pk = new MoveEntityPacket();
            $pk->eid = $eid;
            $pk->x = (float)$x;
            $pk->y = (float)$y;
            $pk->z = (float)$z;
            $pk->yaw = 0.0;
            $pk->pitch = 0.0;
            $pk->headYaw = 0.0;

            foreach ($allPlayers as $pl) {
                try {
                    $pl->dataPacket($pk);
                } catch (\Exception $e) {}
            }
        }
        unset($blockData);
    }

    private function checkWaveHits($waveIndex) {
        $waveData = &$this->waves[$waveIndex];
        $currentRadius = $waveData["radius"];
        $innerRadius = $currentRadius - 4.0;
        $outerRadius = $currentRadius + 2.0;

        $owner = $this->plugin->getServer()->getPlayerExact($this->ownerName);

        foreach ($this->level->getEntities() as $entity) {
            if (!$entity->isAlive()) continue;
            if ($entity->closed) continue;

            $isValidTarget = false;

            if ($entity instanceof Player) {
                if ($entity->getName() === $this->ownerName) continue;

                if ($this->toggle !== null) {
                    if (!$this->plugin->canTargetPlayer($this->ownerName, $entity)) {
                        continue;
                    }
                }

                $hitKey = $waveIndex . "_p_" . $entity->getName();
                if (isset($this->hitPlayers[$hitKey])) continue;

                $isValidTarget = true;
            } elseif ($entity instanceof NPCEntity) {
                $hitKey = $waveIndex . "_n_" . $entity->getId();
                if (isset($this->hitPlayers[$hitKey])) continue;

                $isValidTarget = true;
            } elseif ($entity instanceof FactoryEntity) {
                $hitKey = $waveIndex . "_f_" . $entity->getId();
                if (isset($this->hitPlayers[$hitKey])) continue;

                $isValidTarget = true;
            }

            if (!$isValidTarget) continue;

            $dx = $entity->x - $this->cx;
            $dz = $entity->z - $this->cz;
            $dist = sqrt($dx * $dx + $dz * $dz);

            if ($dist >= $innerRadius && $dist <= $outerRadius) {
                $this->hitPlayers[$hitKey] = true;

                $scaledDamage = min(16.0, $this->damage * (0.85 + ($waveIndex * 0.2)));

                if ($owner !== null) {
                    $ev = new EntityDamageByEntityEvent($owner, $entity, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $scaledDamage);
                    $entity->attack($scaledDamage, $ev);
                } else {
                    $ev = new EntityDamageEvent($entity, EntityDamageEvent::CAUSE_MAGIC, $scaledDamage);
                    $entity->attack($scaledDamage, $ev);
                }

                $len = $dist > 0 ? $dist : 1;
                $knockX = -($dx / $len) * 0.5;
                $knockZ = -($dz / $len) * 0.5;
                $this->safeSetMotion($player, $entity, new Vector3($knockX, 0.3, $knockZ));

                if ($entity instanceof Player) {
                    $slow = Effect::getEffect(Effect::SLOWNESS);
                    $slow->setAmplifier(2);
                    $slow->setDuration(60);
                    $slow->setVisible(false);
                    $this->safeAddEffect($player, $entity, $slow);

                    $nausea = Effect::getEffect(Effect::NAUSEA);
                    $nausea->setAmplifier(1);
                    $nausea->setDuration(80);
                    $nausea->setVisible(false);
                    $this->safeAddEffect($player, $entity, $nausea);

                    $entity->sendTip(TextFormat::AQUA . TextFormat::BOLD . "TSUNAMI!");
                }

                $this->level->addParticle(new SplashParticle(new Vector3($entity->x, $entity->y + 1, $entity->z)));
                $this->level->addSound(new SplashSound(new Vector3($entity->x, $entity->y, $entity->z)));
            }
        }
    }

    private function crashWave($waveIndex, $allPlayers) {
        $waveData = $this->waves[$waveIndex];

        foreach ($waveData["blocks"] as $eid => $blockData) {
            $this->releaseBlock($eid);
        }

        $this->waves[$waveIndex]["blocks"] = [];

        $this->level->addSound(new SplashSound(new Vector3($this->cx, $this->cy, $this->cz)));
        $this->level->addSound(new SplashSound(new Vector3($this->cx, $this->cy + 1, $this->cz)));

        for ($i = 0; $i < 8; $i++) {
            $a = ($i / 8) * M_PI * 2;
            $this->level->addParticle(new SplashParticle(new Vector3(
                $this->cx + cos($a) * 2,
                $this->cy + 0.5,
                $this->cz + sin($a) * 2
            )));
        }
    }

    private function drawParticles() {
        $lv = $this->level;

        foreach ($this->waves as $waveData) {
            if (!$waveData["active"]) continue;

            $waveRadius = $waveData["radius"];

            for ($i = 0; $i < 8; $i++) {
                $angle = ($i / 8) * M_PI * 2 + ($this->ticksRan * 0.08);

                $x = $this->cx + cos($angle) * $waveRadius;
                $z = $this->cz + sin($angle) * $waveRadius;

                $lv->addParticle(new DustParticle(
                    new Vector3($x, $this->cy + 3.5, $z),
                    255, 255, 255
                ));

                $lv->addParticle(new DustParticle(
                    new Vector3($x, $this->cy + 1.5, $z),
                    30, 144, 255
                ));
            }
        }

        if ($this->ticksRan % 8 === 0) {
            foreach ($this->waves as $waveData) {
                if (!$waveData["active"]) continue;

                $angle = mt_rand(0, 628) / 100;
                $waveRadius = $waveData["radius"];

                $this->level->addParticle(new SplashParticle(new Vector3(
                    $this->cx + cos($angle) * $waveRadius,
                    $this->cy + 1,
                    $this->cz + sin($angle) * $waveRadius
                )));

                $this->level->addSound(new SplashSound(new Vector3(
                    $this->cx + cos($angle) * $waveRadius,
                    $this->cy,
                    $this->cz + sin($angle) * $waveRadius
                )));
            }
        }
    }

    private function spawnFinalCrash() {
        $lv = $this->level;

        for ($i = 0; $i < 16; $i++) {
            $a = ($i / 16) * M_PI * 2;
            $d = mt_rand(5, 30) / 10;
            $lv->addParticle(new SplashParticle(new Vector3(
                $this->cx + cos($a) * $d,
                $this->cy + 0.5,
                $this->cz + sin($a) * $d
            )));
        }

        for ($i = 0; $i < 12; $i++) {
            $a = ($i / 12) * M_PI * 2;
            $d = mt_rand(3, 20) / 10;
            $lv->addParticle(new DustParticle(
                new Vector3($this->cx + cos($a) * $d, $this->cy + mt_rand(5, 25) / 10, $this->cz + sin($a) * $d),
                30, 144, 255
            ));
        }

        for ($i = 0; $i < 8; $i++) {
            $lv->addParticle(new ExplodeParticle(new Vector3(
                $this->cx + (mt_rand(-20, 20) / 10),
                $this->cy + 0.5,
                $this->cz + (mt_rand(-20, 20) / 10)
            )));
        }

        for ($i = 0; $i < 4; $i++) {
            $a = ($i / 4) * M_PI * 2;
            $lv->addSound(new SplashSound(new Vector3(
                $this->cx + cos($a) * 2,
                $this->cy,
                $this->cz + sin($a) * 2
            )));
        }
        $lv->addSound(new SplashSound(new Vector3($this->cx, $this->cy, $this->cz)));

        $owner = $this->plugin->getServer()->getPlayerExact($this->ownerName);

        foreach ($this->level->getEntities() as $entity) {
            if (!$entity->isAlive()) continue;
            if ($entity->closed) continue;

            $isValidTarget = false;

            if ($entity instanceof Player) {
                if ($entity->getName() === $this->ownerName) continue;

                if ($this->toggle !== null) {
                    if (!$this->plugin->canTargetPlayer($this->ownerName, $entity)) {
                        continue;
                    }
                }

                $isValidTarget = true;
            } elseif ($entity instanceof NPCEntity) {
                $isValidTarget = true;
            } elseif ($entity instanceof FactoryEntity) {
                $isValidTarget = true;
            } elseif ($entity instanceof FactoryEntity) {
                $isValidTarget = true;
            }

            if (!$isValidTarget) continue;

            $dx = $entity->x - $this->cx;
            $dz = $entity->z - $this->cz;
            $dist = sqrt($dx * $dx + $dz * $dz);

            if ($dist <= 5.0) {
                $finalDamage = min(18.0, $this->damage * 1.5);

                if ($owner !== null) {
                    $ev = new EntityDamageByEntityEvent($owner, $entity, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $finalDamage);
                    $entity->attack($finalDamage, $ev);
                } else {
                    $ev = new EntityDamageEvent($entity, EntityDamageEvent::CAUSE_MAGIC, $finalDamage);
                    $entity->attack($finalDamage, $ev);
                }

                $this->safeSetMotion($player, $entity, new Vector3(0, 0.4, 0));

                if ($entity instanceof Player) {
                    $slow = Effect::getEffect(Effect::SLOWNESS);
                    $slow->setAmplifier(3);
                    $slow->setDuration(60);
                    $slow->setVisible(false);
                    $this->safeAddEffect($player, $entity, $slow);

                    $entity->sendTip(TextFormat::AQUA . TextFormat::BOLD . "TSUNAMI CRASH!");
                }

                $this->level->addParticle(new SplashParticle(new Vector3($entity->x, $entity->y + 1, $entity->z)));
                $this->level->addSound(new SplashSound(new Vector3($entity->x, $entity->y, $entity->z)));
            }
        }
    }

    public function forceCleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        $eidsToRemove = [];

        foreach ($this->allSpawnedEids as $eid => $v) {
            $this->releaseBlock($eid);
            $eidsToRemove[] = $eid;
        }

        foreach ($this->waves as $waveData) {
            foreach ($waveData["blocks"] as $eid => $blockData) {
                $this->releaseBlock($eid);
                $eidsToRemove[] = $eid;
            }
        }

        $this->waves = [];
        $this->allSpawnedEids = [];

        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
            new DelayedBlockRemoveTask($this->plugin, $this->level, $eidsToRemove),
            40
        );
    }
}

class DelayedBlockRemoveTask extends Task {

    private $plugin;
    private $level;
    private $eids;

    public function __construct($plugin, Level $level, array $eids) {
        $this->plugin = $plugin;
        $this->level = $level;
        $this->eids = $eids;
    }

    public function onRun($currentTick) {
        $allPlayers = [];

        try {
            if ($this->level !== null) {
                foreach ($this->level->getPlayers() as $pl) {
                    $allPlayers[spl_object_hash($pl)] = $pl;
                }
            }
        } catch (\Exception $e) {}

        try {
            foreach ($this->plugin->getServer()->getOnlinePlayers() as $pl) {
                $allPlayers[spl_object_hash($pl)] = $pl;
            }
        } catch (\Exception $e) {}

        foreach ($this->eids as $eid) {
            $movePk = new MoveEntityPacket();
            $movePk->eid = $eid;
            $movePk->x = 0.0;
            $movePk->y = 0.0;
            $movePk->z = 0.0;
            $movePk->yaw = 0.0;
            $movePk->pitch = 0.0;
            $movePk->headYaw = 0.0;

            $removePk = new RemoveEntityPacket();
            $removePk->eid = $eid;

            foreach ($allPlayers as $pl) {
                try {
                    $pl->dataPacket($movePk);
                    $pl->dataPacket($removePk);
                } catch (\Exception $e) {}
            }
        }
    }
}