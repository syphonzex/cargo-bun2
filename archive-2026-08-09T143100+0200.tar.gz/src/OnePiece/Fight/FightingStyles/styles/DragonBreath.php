<?php

namespace OnePiece\Fight\FightingStyles\styles;

use OnePiece\Fight\FightingStyles\BaseFightingStyle;
use OnePiece\Fight\Main;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\particle\LavaDripParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\sound\AnvilFallSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\BlazeShootSound;
use pocketmine\level\sound\ExplodeSound;
use pocketmine\level\sound\FizzSound;
use pocketmine\entity\Effect;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\item\Item;
use pocketmine\scheduler\Task;

class DragonBreath extends BaseFightingStyle {

    public function getId()               { return "dragon_breath"; }
    public function getDisplayName()      { return "Dragon Claw"; }
    public function getItemId()           { return Item::BONE; }
    public function getLevelRequirement() { return 500; }
    public function getRarity()           { return "legendary"; }

    public function getAbilityNames() {
        return [
            "ability1" => "Fire Claw",
            "ability2" => "Blazing Inferno",
        ];
    }

    public function getAbilityCooldowns() {
        return [
            "ability1" => 10,
            "ability2" => 25,
        ];
    }

    public function useAbility(Player $player, $ability) {
        if ($ability === "ability1") return $this->dragonClaw($player);
        if ($ability === "ability2") return $this->blazingInferno($player);
        return 0;
    }

    private function dragonClaw(Player $player) {
        $targets = $this->getNearbyTargets($player, 5.0);

        if (empty($targets)) {
            $player->sendTip(TextFormat::RED . "No targets in range!");
            return 0;
        }

        $damage = $this->getStyleDamage($player, 9.0);
        $pos    = $player->getPosition();
        $lv     = $player->getLevel();
        $dir    = $player->getDirectionVector();

        foreach ($targets as $target) {
            $this->dealDamage($player, $target, $damage);
            $target->setOnFire(4);

            $tPos = $target->getPosition();
            for ($i = 0; $i < 12; $i++) {
                $lv->addParticle(new FlameParticle(new Vector3(
                    $tPos->x + (mt_rand(-60, 60) / 100),
                    $tPos->y + (mt_rand(50, 220) / 100),
                    $tPos->z + (mt_rand(-60, 60) / 100)
                )));
                $lv->addParticle(new LavaDripParticle(new Vector3(
                    $tPos->x + (mt_rand(-40, 40) / 100),
                    $tPos->y + (mt_rand(0, 180) / 100),
                    $tPos->z + (mt_rand(-40, 40) / 100)
                )));
                $lv->addParticle(new DustParticle(new Vector3(
                    $tPos->x + (mt_rand(-50, 50) / 100),
                    $tPos->y + (mt_rand(20, 200) / 100),
                    $tPos->z + (mt_rand(-50, 50) / 100)
                ), 255, 80, 0));
            }
            $lv->addSound(new AnvilUseSound($tPos));
        }

        for ($slash = 0; $slash < 3; $slash++) {
            $spreadAngle = ($slash - 1) * 0.35;
            $sx = $dir->x * cos($spreadAngle) - $dir->z * sin($spreadAngle);
            $sz = $dir->x * sin($spreadAngle) + $dir->z * cos($spreadAngle);

            for ($step = 1; $step <= 8; $step++) {
                $px = $pos->x + $sx * $step;
                $py = $pos->y + 1.0;
                $pz = $pos->z + $sz * $step;

                $lv->addParticle(new FlameParticle(new Vector3($px, $py, $pz)));
                $lv->addParticle(new DustParticle(new Vector3($px, $py + 0.3, $pz), 255, 60, 0));
                if ($step % 2 === 0) {
                    $lv->addParticle(new SmokeParticle(new Vector3($px, $py + 0.5, $pz)));
                    $lv->addParticle(new LavaDripParticle(new Vector3($px, $py - 0.2, $pz)));
                }
            }
        }

        $lv->addSound(new BlazeShootSound($pos));
        $lv->addSound(new FizzSound($pos));

        $player->sendTip(TextFormat::GOLD . TextFormat::BOLD . "DRAGON CLAW! Hit " . count($targets) . " target(s)!");
        return 10;
    }

    private function blazingInferno(Player $player) {
        $pos    = $player->getPosition();
        $lv     = $player->getLevel();
        $dir    = $player->getDirectionVector();
        $damage = $this->getStyleDamage($player, 14.0);

        for ($wave = 0; $wave < 3; $wave++) {
            $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
                new BlazingInfernoWaveTask($this->plugin, $player, $pos, $dir, $damage, $wave),
                $wave * 5
            );
        }

        $lv->addParticle(new HugeExplodeParticle($pos->add(0, 1, 0)));
        $lv->addSound(new ExplodeSound($pos));
        $lv->addSound(new AnvilFallSound($pos));
        $lv->addSound(new BlazeShootSound($pos));

        for ($i = 0; $i < 20; $i++) {
            $a = ($i / 20) * M_PI * 2;
            $lv->addParticle(new FlameParticle(new Vector3(
                $pos->x + cos($a) * 1.5,
                $pos->y + 1.0,
                $pos->z + sin($a) * 1.5
            )));
            $lv->addParticle(new DustParticle(new Vector3(
                $pos->x + cos($a) * 2.0,
                $pos->y + 0.5,
                $pos->z + sin($a) * 2.0
            ), 255, 60, 0));
        }

        $player->sendTip(TextFormat::GOLD . TextFormat::BOLD . "BLAZING INFERNO!");
        return 25;
    }
}

class BlazingInfernoWaveTask extends Task {

    private $plugin, $player, $pos, $dir, $damage, $waveIndex;
    private static $globalHitTargets = [];

    public function __construct($plugin, Player $player, Vector3 $pos, Vector3 $dir, $damage, $waveIndex) {
        $this->plugin     = $plugin;
        $this->player     = $player;
        $this->pos        = $pos;
        $this->dir        = $dir;
        $this->damage     = $damage;
        $this->waveIndex  = $waveIndex;
    }

    public function onRun($currentTick) {
        if (!$this->player->isOnline()) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $lv = $this->player->getLevel();
        $spreadAngle = ($this->waveIndex - 1) * 0.28;
        $waveX = $this->dir->x * cos($spreadAngle) - $this->dir->z * sin($spreadAngle);
        $waveZ = $this->dir->x * sin($spreadAngle) + $this->dir->z * cos($spreadAngle);

        $playerName = $this->player->getName();
        if (!isset(self::$globalHitTargets[$playerName])) {
            self::$globalHitTargets[$playerName] = [];
        }

        for ($step = 1; $step <= 14; $step++) {
            $sx = $this->pos->x + $waveX * $step;
            $sy = $this->pos->y + 1.0 + ($step * 0.04);
            $sz = $this->pos->z + $waveZ * $step;

            $lv->addParticle(new FlameParticle(new Vector3($sx, $sy, $sz)));
            $lv->addParticle(new LavaParticle(new Vector3($sx, $sy - 0.2, $sz)));
            $lv->addParticle(new DustParticle(new Vector3($sx, $sy + 0.2, $sz), 255, 80, 0));

            if ($step % 2 === 0) {
                $lv->addParticle(new SmokeParticle(new Vector3($sx, $sy + 0.5, $sz)));
                $lv->addParticle(new FlameParticle(new Vector3(
                    $sx + (mt_rand(-20, 20) / 100),
                    $sy + (mt_rand(0, 30) / 100),
                    $sz + (mt_rand(-20, 20) / 100)
                )));
            }

            if ($step % 4 === 0) {
                $lv->addParticle(new LavaDripParticle(new Vector3($sx, $sy + 0.3, $sz)));
                $lv->addParticle(new CriticalParticle(new Vector3($sx, $sy, $sz)));
            }

            $stepVec = new Vector3($sx, $sy, $sz);

            foreach ($lv->getPlayers() as $t) {
                if ($t->getName() === $playerName) continue;
                if (isset(self::$globalHitTargets[$playerName][$t->getName()])) continue;
                if (!$this->plugin->canTargetPlayer($playerName, $t)) continue;
                if ($t->distance($stepVec) <= 2.0) {
                    $damage = $this->damage;
                    $damage = max(0.5, $this->plugin->applyDefenseReduction($t, $damage));
                    $ev = new EntityDamageByEntityEvent($this->player, $t, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage);
                    $t->attack($damage, $ev);
                    $t->setOnFire(6);
                    self::$globalHitTargets[$playerName][$t->getName()] = true;

                    $weak = Effect::getEffect(Effect::WEAKNESS);
                    $weak->setAmplifier(1);
                    $weak->setDuration(100);
                    $weak->setVisible(false);
                    $t->addEffect($weak);
                    $t->sendTip(TextFormat::GOLD . "BLAZING INFERNO!");
                }
            }

            foreach ($lv->getEntities() as $e) {
                if ($e instanceof Player) continue;
                if ($e->closed || !$e->isAlive()) continue;
                $npc     = "OnePiece\\NPC\\NPCEntity";
                $factory = "OnePieceTrades\\Factory\\FactoryEntity";
                if (!($e instanceof $npc) && !($e instanceof $factory)) continue;
                $eid = spl_object_hash($e);
                if (isset(self::$globalHitTargets[$playerName][$eid])) continue;
                if ($e->distance($stepVec) <= 2.0) {
                    $ev = new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage);
                    $e->attack($this->damage, $ev);
                    self::$globalHitTargets[$playerName][$eid] = true;
                }
            }
        }

        $lv->addSound(new BlazeShootSound($this->pos));
        $lv->addSound(new FizzSound($this->pos));

        if ($this->waveIndex === 2) {
            unset(self::$globalHitTargets[$playerName]);
        }

        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}