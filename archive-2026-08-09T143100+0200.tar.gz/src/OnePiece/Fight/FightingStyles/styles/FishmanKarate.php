<?php

namespace OnePiece\Fight\FightingStyles\styles;

use OnePiece\Fight\Main;
use OnePiece\Fight\FightingStyles\BaseFightingStyle;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\entity\Effect;
use pocketmine\level\particle\BubbleParticle;
use pocketmine\level\particle\WaterParticle;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\ExplodeParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\particle\SplashParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\sound\FizzSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\ExplodeSound;

class FishmanKarate extends BaseFightingStyle {

    public function __construct(Main $plugin) {
        parent::__construct($plugin);
    }

    public function getId()               { return "fishman_karate"; }
    public function getDisplayName()      { return "Fishman Karate"; }
    public function getItemId()           { return Item::BONE; }
    public function getLevelRequirement() { return 250; }
    public function getRarity()           { return "rare"; }

    public function getAbilityNames() {
        return [
            "ability1" => "Uchimizu",
            "ability2" => "Senmaigawara Seiken",
        ];
    }

    public function getAbilityCooldowns() {
        return [
            "ability1" => 8,
            "ability2" => 20,
        ];
    }

    public function useAbility(Player $player, $ability) {
        if ($ability === "ability1") return $this->uchimizu($player);
        if ($ability === "ability2") return $this->senmaigawaraSeiken($player);
        return 0;
    }

    private function uchimizu(Player $player) {
        $target = $this->findFrontTarget($player, 10.0);

        if ($target === null) {
            $this->spawnWaterShotMiss($player);
            $player->sendTip("§c[Fishman Karate] No target in range!");
            return 0;
        }

        $damage = $this->getStyleDamage($player, 5.0);
        $this->dealDamage($player, $target, $damage);

        $dx = $target->x - $player->x;
        $dz = $target->z - $player->z;
        $len = sqrt($dx * $dx + $dz * $dz);
        if ($len > 0) {
           // $target->setMotion(new Vector3(($dx / $len) * 2.0, 0.4, ($dz / $len) * 2.0));
        }

        $this->spawnUchimazuEffect($player, $target);

        $player->sendTip("§b[Fishman Karate] §3Uchimizu! §f" . round($damage, 1) . " DMG");

        if ($target instanceof Player) {
            $target->sendTip("§3[WATER SHOT] §f" . round($damage, 1) . " damage!");
        }

        return 8;
    }

    private function senmaigawaraSeiken(Player $player) {
        $targets = $this->getNearbyTargets($player, 6.0);

        $this->spawnSeikenShockwave($player);

        if (empty($targets)) {
            $player->sendTip("§c[Fishman Karate] No targets in range!");
            return 0;
        }

        $damage = $this->getStyleDamage($player, 10.0);
        $hitCount = 0;

        foreach ($targets as $target) {
            $this->dealDamage($player, $target, $damage);

            $dx = $target->x - $player->x;
            $dz = $target->z - $player->z;
            $len = sqrt($dx * $dx + $dz * $dz);
            if ($len > 0) {
                $kb = min(2, 1);
                $target->setMotion(new Vector3(($dx / $len) * $kb, 0.6, ($dz / $len) * $kb));
            }

            if ($target instanceof Player) {
                $slow = Effect::getEffect(Effect::SLOWNESS);
                $slow->setAmplifier(2);
                $slow->setDuration(60);
                $slow->setVisible(false);
                $target->addEffect($slow);

                $target->sendTip("§3[SEIKEN] §f" . round($damage, 1) . " damage!");
            }

            $this->spawnSeikenImpact($target);
            $hitCount++;
        }

        $player->sendTip("§b[Fishman Karate] §3Senmaigawara Seiken! §fHit " . $hitCount . " target(s) for " . round($damage, 1) . " DMG");

        return 20;
    }

    private function spawnWaterShotMiss(Player $player) {
        $level = $player->getLevel();
        $dir = $player->getDirectionVector();
        $start = $player->add(0, 1.2, 0);

        for ($i = 1; $i <= 10; $i++) {
            $p = $start->add($dir->x * $i, $dir->y * $i, $dir->z * $i);
            $level->addParticle(new DustParticle($p, 0, 100, 200));
            $level->addParticle(new BubbleParticle($p->add(
                (mt_rand(-2, 2) / 10),
                (mt_rand(-2, 2) / 10),
                (mt_rand(-2, 2) / 10)
            )));
        }

        $level->addSound(new FizzSound($start));
    }

    private function spawnUchimazuEffect(Player $player, $target) {
        $level = $player->getLevel();
        $start = $player->add(0, 1.2, 0);
        $end = $target->add(0, 1, 0);
        $dir = $end->subtract($start);
        $dist = $start->distance($end);

        if ($dist <= 0) return;

        $steps = (int)($dist * 4);
        for ($i = 0; $i <= $steps; $i++) {
            $progress = $i / max(1, $steps);
            $p = new Vector3(
                $start->x + $dir->x * $progress,
                $start->y + $dir->y * $progress,
                $start->z + $dir->z * $progress
            );

            $level->addParticle(new DustParticle($p, 0, 80, 220));
            $level->addParticle(new DustParticle($p->add(
                (mt_rand(-2, 2) / 10),
                (mt_rand(-2, 2) / 10),
                (mt_rand(-2, 2) / 10)
            ), 100, 180, 255));

            if ($i % 2 === 0) {
                $level->addParticle(new BubbleParticle($p->add(
                    (mt_rand(-3, 3) / 10),
                    (mt_rand(-3, 3) / 10),
                    (mt_rand(-3, 3) / 10)
                )));
            }
        }

        $tp = $target->add(0, 1, 0);
        for ($angle = 0; $angle < 360; $angle += 30) {
            $rad = deg2rad($angle);
            $level->addParticle(new DustParticle(
                new Vector3(
                    $tp->x + cos($rad) * 0.8,
                    $tp->y,
                    $tp->z + sin($rad) * 0.8
                ), 0, 100, 255
            ));
            $level->addParticle(new BubbleParticle(new Vector3(
                $tp->x + cos($rad) * 0.6,
                $tp->y + (mt_rand(0, 15) / 10),
                $tp->z + sin($rad) * 0.6
            )));
        }

        for ($i = 0; $i < 8; $i++) {
            $level->addParticle(new SplashParticle($tp->add(
                (mt_rand(-5, 5) / 10),
                (mt_rand(0, 10) / 10),
                (mt_rand(-5, 5) / 10)
            )));
        }

        $level->addSound(new FizzSound($tp));
        $level->addSound(new AnvilUseSound($tp));
    }

    private function spawnSeikenShockwave(Player $player) {
        $level = $player->getLevel();
        $center = $player->add(0, 0.5, 0);
        $dir = $player->getDirectionVector();

        $fistPos = $player->add($dir->x * 1.5, 1.2, $dir->z * 1.5);
        for ($i = 0; $i < 6; $i++) {
            $level->addParticle(new CriticalParticle($fistPos->add(
                (mt_rand(-3, 3) / 10),
                (mt_rand(-3, 3) / 10),
                (mt_rand(-3, 3) / 10)
            )));
        }

        for ($ring = 1; $ring <= 3; $ring++) {
            $radius = $ring * 2;
            $particleCount = $ring * 12;
            for ($i = 0; $i < $particleCount; $i++) {
                $angle = ($i / $particleCount) * M_PI * 2;
                $x = $center->x + cos($angle) * $radius;
                $z = $center->z + sin($angle) * $radius;
                $y = $center->y + 0.2;

                $level->addParticle(new DustParticle(
                    new Vector3($x, $y, $z), 0, 60 + ($ring * 20), 200 + ($ring * 15)
                ));

                if ($i % 3 === 0) {
                    $level->addParticle(new BubbleParticle(new Vector3(
                        $x + (mt_rand(-2, 2) / 10),
                        $y + (mt_rand(0, 8) / 10),
                        $z + (mt_rand(-2, 2) / 10)
                    )));
                }
            }
        }

        for ($i = 0; $i < 16; $i++) {
            $angle = ($i / 16) * M_PI * 2;
            $level->addParticle(new SplashParticle(new Vector3(
                $center->x + cos($angle) * 1.5,
                $center->y + 0.5,
                $center->z + sin($angle) * 1.5
            )));
        }

        $level->addParticle(new HugeExplodeParticle($center));
        $level->addSound(new ExplodeSound($center));
        $level->addSound(new AnvilUseSound($center));
    }

    private function spawnSeikenImpact($target) {
        $level = $target->getLevel();
        $tp = $target->add(0, 1, 0);

        for ($angle = 0; $angle < 360; $angle += 25) {
            $rad = deg2rad($angle);
            for ($r = 0.3; $r <= 1.2; $r += 0.3) {
                $level->addParticle(new DustParticle(
                    new Vector3(
                        $tp->x + cos($rad) * $r,
                        $tp->y,
                        $tp->z + sin($rad) * $r
                    ), 0, 80, 230
                ));
            }
        }

        for ($i = 0; $i < 10; $i++) {
            $level->addParticle(new BubbleParticle($tp->add(
                (mt_rand(-6, 6) / 10),
                (mt_rand(-5, 12) / 10),
                (mt_rand(-6, 6) / 10)
            )));
        }

        for ($i = 0; $i < 6; $i++) {
            $level->addParticle(new CriticalParticle($tp->add(
                (mt_rand(-4, 4) / 10),
                (mt_rand(0, 8) / 10),
                (mt_rand(-4, 4) / 10)
            )));
        }

        for ($i = 0; $i < 6; $i++) {
            $level->addParticle(new SplashParticle($tp->add(
                (mt_rand(-5, 5) / 10),
                (mt_rand(0, 10) / 10),
                (mt_rand(-5, 5) / 10)
            )));
        }

        $level->addParticle(new ExplodeParticle($tp));
        $level->addSound(new AnvilUseSound($tp));
    }
}