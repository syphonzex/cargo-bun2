<?php

namespace OnePiece\Fight\FightingStyles;

use OnePiece\Fight\Main;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class StyleManager {

    private $plugin;
    private $styles = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function register(BaseFightingStyle $style) {
        $this->styles[strtolower($style->getId())] = $style;
    }

    public function getStyle($id) {
        return isset($this->styles[strtolower($id)]) ? $this->styles[strtolower($id)] : null;
    }

    public function getAllStyles() {
        return $this->styles;
    }

    public function loadPlayer(Player $player) {
        $this->plugin->getStyleMastery()->load($player->getName());
    }

    public function savePlayer(Player $player) {
        $this->plugin->getStyleMastery()->save($player->getName());
    }

    public function playerHasStyle(Player $player) {
        return $this->plugin->getStyleMastery()->getEquipped($player->getName()) !== null;
    }

    public function getPlayerStyleId(Player $player) {
        return $this->plugin->getStyleMastery()->getEquipped($player->getName());
    }

    public function getPlayerStyle(Player $player) {
        $id = $this->getPlayerStyleId($player);
        if ($id === null) return null;
        return $this->getStyle($id);
    }

    public function forceStyle(Player $player, $styleId) {
        $styleId = strtolower($styleId);
        $style = $this->getStyle($styleId);
        if ($style === null) return false;

        $mastery = $this->plugin->getStyleMastery();
        $name = $player->getName();
        $mastery->addStyle($name, $styleId);
        $mastery->setEquipped($name, $styleId);
        $mastery->save($name);

        $player->sendMessage(TextFormat::GOLD . "You were force-given " . $style->getRarityColor() . $style->getDisplayName() . TextFormat::GOLD . "!");
        return true;
    }

    public function giveStyle(Player $player, $styleId) {
        $styleId = strtolower($styleId);
        $style = $this->getStyle($styleId);
        if ($style === null) return false;

        $lvReq = $style->getLevelRequirement();
        if ($this->plugin->getStatsPlugin() !== null) {
            $sm = $this->plugin->getStatsPlugin()->getStatManager();
            $sp = $sm->getStatPlayer($player);
            if ($sp !== null && $sp->getLevel() < $lvReq) {
                $player->sendMessage(TextFormat::RED . "You need Level " . $lvReq . " to use " . $style->getDisplayName() . "!");
                return false;
            }
        }

        $mastery = $this->plugin->getStyleMastery();
        $name = $player->getName();
        $mastery->addStyle($name, $styleId);
        $mastery->setEquipped($name, $styleId);
        $mastery->save($name);

        $player->sendMessage(TextFormat::GOLD . "You learned " . $style->getRarityColor() . $style->getDisplayName() . TextFormat::GOLD . "!");
        $player->sendMessage(TextFormat::GRAY . "Use your style item to use Ability 1, Sneak+Use for Ability 2.");
        return true;
    }

    public function equipStyle(Player $player, $styleId) {
        $styleId = strtolower($styleId);
        $mastery = $this->plugin->getStyleMastery();
        $name = $player->getName();

        if (!$mastery->hasStyle($name, $styleId)) {
            $player->sendMessage(TextFormat::RED . "You don't own that fighting style!");
            return false;
        }

        $style = $this->getStyle($styleId);
        if ($style === null) return false;

        $mastery->setEquipped($name, $styleId);
        $mastery->save($name);

        $player->sendMessage(TextFormat::GOLD . "Equipped " . $style->getRarityColor() . $style->getDisplayName() . TextFormat::GOLD . "!");
        return true;
    }

    public function removeStyle(Player $player, $styleId = null) {
        $mastery = $this->plugin->getStyleMastery();
        $name = $player->getName();

        if ($styleId !== null) {
            $mastery->removeStyle($name, strtolower($styleId));
        } else {
            $equipped = $mastery->getEquipped($name);
            if ($equipped !== null) {
                $mastery->removeStyle($name, $equipped);
            }
        }

        $mastery->save($name);
        $player->sendMessage(TextFormat::GRAY . "Fighting style removed.");
        return true;
    }
}