<?php

namespace OnePiece\Fight\Swords;

use OnePiece\Fight\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class SwordCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("sword", "Sword commands", "/sword <equip|buy|info|list>", ["swords"]);
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (empty($args)) {
            if ($sender instanceof Player) return $this->showInfo($sender);
            return false;
        }

        switch (strtolower($args[0])) {
            case "buy":
                return $this->handleBuy($sender, $args);
            case "equip":
                if ($sender instanceof Player) return $this->handleEquip($sender, $args);
                return false;
            case "give":
                return $this->handleGive($sender, $args);
            case "force":
                return $this->handleForce($sender, $args);
            case "remove":
                return $this->handleRemove($sender, $args);
            case "info":
                if ($sender instanceof Player) return $this->showInfo($sender);
                return false;
            case "list":
                if ($sender instanceof Player) return $this->showList($sender);
                return false;
            default:
                if ($sender instanceof Player) return $this->showInfo($sender);
                return false;
        }
    }

    private function handleBuy(CommandSender $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only!");
            return true;
        }
        if (count($args) < 3) {
            $sender->sendMessage("§cUsage: /sword buy <player> <swordId>");
            return true;
        }

        $target = $this->plugin->getServer()->getPlayerExact($args[1]);
        if ($target === null) {
            $sender->sendMessage("§cPlayer not found.");
            return true;
        }

        $swordId = strtolower($args[2]);
        $sword = $this->plugin->getSwordManager()->getSword($swordId);
        if ($sword === null) {
            $sender->sendMessage("§cUnknown sword.");
            return true;
        }

        if ($target->getExpLevel() < $sword->getLevelRequirement()) {
            $target->sendMessage("§cYou need Level " . $sword->getLevelRequirement() . " to wield this sword!");
            return true;
        }

        if ($this->plugin->getSwordMastery()->hasSword($target->getName(), $swordId)) {
            $this->plugin->getSwordManager()->equipSword($target, $swordId);
            $this->plugin->setPlayerMode($target, "sword");
            $this->plugin->updateWeaponSlot($target);
            $target->sendMessage("§eYou have equipped your " . $sword->getDisplayName() . ".");
            return true;
        }

        $price = 0;
        switch($swordId) {
            case "katana": $price = 10000; break;
            case "wado_ichimonji": $price = 100000; break;
            case "shusui": $price = 500000; break;
            case "enma": $price = 5000000; break;
            case "yoru": $price = 10000000; break;
            default: $price = 0; break;
        }

        $berryPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceBerry");
        if ($berryPlugin === null) {
            $sender->sendMessage("§cBerry system not found. Transaction aborted.");
            return true;
        }

        $bm = $berryPlugin->getBerryManager();
        if (!$bm->has($target->getName(), $price)) {
            $target->sendMessage("§cYou need §e" . $bm->format($price) . " §cto buy this sword! You have: §e" . $bm->format($bm->get($target->getName())));
            return true;
        }

        $bm->remove($target->getName(), $price);
        $this->plugin->getSwordManager()->giveSword($target, $swordId);
        $this->plugin->getSwordManager()->equipSword($target, $swordId);
        
        $target->sendMessage("§a§l[SHOP] §r§aYou purchased §f" . $sword->getDisplayName() . " §afor §e" . $bm->format($price) . "§a!");
        $this->plugin->setPlayerMode($target, "sword");
        $this->plugin->updateWeaponSlot($target);

        return true;
    }

    private function showInfo(Player $sender) {
        $mast = $this->plugin->getSwordMastery();
        $sm   = $this->plugin->getSwordManager();
        $name = $sender->getName();

        $sender->sendMessage(TextFormat::GOLD . "==============================");
        $sender->sendMessage(TextFormat::GOLD . "  Sword Info");
        $sender->sendMessage(TextFormat::GOLD . "==============================");

        $owned = $mast->getOwnedSwords($name);
        if (empty($owned)) {
            $sender->sendMessage(TextFormat::GRAY . "You don't own any swords.");
        } else {
            $equipped = $mast->getEquipped($name);
            $sender->sendMessage(TextFormat::YELLOW . "Owned Swords:");
            foreach ($owned as $sId => $data) {
                $sword = $sm->getSword($sId);
                if ($sword === null) continue;
                $lv = isset($data["level"]) ? $data["level"] : 1;
                $tag = ($sId === $equipped) ? " §a[EQUIPPED]" : "";
                $sender->sendMessage($sword->getRarityColor() . "  " . $sword->getDisplayName() . " §7- Mastery Lv." . $lv . $tag);
            }

            if ($equipped !== null) {
                $sword = $sm->getSword($equipped);
                if ($sword !== null) {
                    $level = $mast->getLevel($name);
                    $exp   = $mast->getExp($name);
                    $next  = $mast->getExpToNext($name);
                    $bar   = $mast->getProgressBar($name);

                    $sender->sendMessage("");
                    $sender->sendMessage(TextFormat::GOLD . "Equipped: " . $sword->getRarityColor() . $sword->getDisplayName());
                    $sender->sendMessage(TextFormat::YELLOW . "Mastery: " . TextFormat::WHITE . "Lv." . $level . " " . $bar);
                    $sender->sendMessage(TextFormat::YELLOW . "EXP: " . TextFormat::WHITE . $exp . "/" . $next);
                    $sender->sendMessage(TextFormat::YELLOW . "Melee DMG: " . TextFormat::WHITE . $sword->getMeleeDamage());

                    $abilNames = $sword->getAbilityNames();
                    $abilCds   = $sword->getAbilityCooldowns();
                    $a1unlocked = $mast->canUseAbility($name, "ability1");
                    $a2unlocked = $mast->canUseAbility($name, "ability2");
                    $a1name = isset($abilNames["ability1"]) ? $abilNames["ability1"] : "Ability 1";
                    $a2name = isset($abilNames["ability2"]) ? $abilNames["ability2"] : "Ability 2";
                    $a1cd   = isset($abilCds["ability1"])   ? $abilCds["ability1"]   : 0;
                    $a2cd   = isset($abilCds["ability2"])   ? $abilCds["ability2"]   : 0;

                    $sender->sendMessage(TextFormat::YELLOW . "Tap: " . ($a1unlocked ? TextFormat::WHITE . $a1name . " §7(" . $a1cd . "s cd)" : TextFormat::RED . "[LOCKED Lv.25]"));
                    $sender->sendMessage(TextFormat::YELLOW . "Sneak+Tap: " . ($a2unlocked ? TextFormat::WHITE . $a2name . " §7(" . $a2cd . "s cd)" : TextFormat::RED . "[LOCKED Lv.50]"));
                }
            }
        }

        $sender->sendMessage(TextFormat::GOLD . "==============================");
        return true;
    }

    private function showList(Player $sender) {
        $mast = $this->plugin->getSwordMastery();
        $name = $sender->getName();

        $sender->sendMessage(TextFormat::GOLD . "==============================");
        $sender->sendMessage(TextFormat::GOLD . "  Available Swords");
        $sender->sendMessage(TextFormat::GOLD . "==============================");

        foreach ($this->plugin->getSwordManager()->getAllSwords() as $sword) {
            $owned = $mast->hasSword($name, $sword->getId()) ? " §a[OWNED]" : "";
            $sender->sendMessage(
                $sword->getRarityColor() . $sword->getDisplayName() .
                TextFormat::GRAY . " | Lv." . $sword->getLevelRequirement() .
                " | ID: " . $sword->getId() . $owned
            );
        }

        $sender->sendMessage(TextFormat::GRAY . "Use /sword equip <id> to equip an owned sword.");
        $sender->sendMessage(TextFormat::GOLD . "==============================");
        return true;
    }

    private function handleEquip(Player $sender, array $args) {
        if (count($args) < 2) {
            $sender->sendMessage(TextFormat::RED . "Usage: /sword equip <swordId>");
            return true;
        }

        $swordId = strtolower($args[1]);
        $this->plugin->getSwordManager()->equipSword($sender, $swordId);

        if ($this->plugin->getPlayerMode($sender) === "sword") {
            $this->plugin->updateWeaponSlot($sender);
        }

        return true;
    }

    private function handleForce(CommandSender $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only!");
            return true;
        }

        if (count($args) < 3) {
            $sender->sendMessage(TextFormat::RED . "Usage: /sword force <player> <swordId>");
            return true;
        }

        $target = $this->plugin->getServer()->getPlayerExact($args[1]);
        if ($target === null) {
            $sender->sendMessage(TextFormat::RED . "Player not found!");
            return true;
        }

        $swordId = strtolower($args[2]);
        if ($this->plugin->getSwordManager()->getSword($swordId) === null) {
            $sender->sendMessage(TextFormat::RED . "Unknown sword: " . $swordId);
            return true;
        }

        $this->plugin->getSwordManager()->forceSword($target, $swordId);
        $sender->sendMessage(TextFormat::GREEN . "Force-given " . $swordId . " to " . $target->getName());
        return true;
    }

    private function handleGive(CommandSender $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only!");
            return true;
        }

        if (count($args) < 3) {
            $sender->sendMessage(TextFormat::RED . "Usage: /sword give <player> <swordId>");
            return true;
        }

        $target = $this->plugin->getServer()->getPlayerExact($args[1]);
        if ($target === null) {
            $sender->sendMessage(TextFormat::RED . "Player not found!");
            return true;
        }

        $swordId = strtolower($args[2]);
        if ($this->plugin->getSwordManager()->getSword($swordId) === null) {
            $sender->sendMessage(TextFormat::RED . "Unknown sword: " . $swordId);
            return true;
        }

        $this->plugin->getSwordManager()->giveSword($target, $swordId);
        $sender->sendMessage(TextFormat::GREEN . "Given " . $swordId . " to " . $target->getName());
        return true;
    }

    private function handleRemove(CommandSender $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only!");
            return true;
        }

        if (count($args) < 2) {
            $sender->sendMessage(TextFormat::RED . "Usage: /sword remove <player> [swordId]");
            return true;
        }

        $target = $this->plugin->getServer()->getPlayerExact($args[1]);
        if ($target === null) {
            $sender->sendMessage(TextFormat::RED . "Player not found!");
            return true;
        }

        $swordId = isset($args[2]) ? strtolower($args[2]) : null;
        $this->plugin->getSwordManager()->removeSword($target, $swordId);
        $sender->sendMessage(TextFormat::GREEN . "Removed sword from " . $target->getName());
        return true;
    }
}