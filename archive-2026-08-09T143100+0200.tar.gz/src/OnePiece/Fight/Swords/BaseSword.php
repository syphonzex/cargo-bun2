<?php

namespace OnePiece\Fight\Swords;

use OnePiece\Fight\Main;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;

abstract class BaseSword {

    protected $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    abstract public function getId();
    abstract public function getDisplayName();
    abstract public function getItemId();
    abstract public function getMeleeDamage();
    abstract public function getLevelRequirement();
    abstract public function getRarity();
    abstract public function useAbility(Player $player, $ability);
    abstract public function getAbilityNames();
    abstract public function getAbilityCooldowns();

    public function getRarityColor() {
        switch ($this->getRarity()) {
            case "common":    return "§a";
            case "rare":      return "§9";
            case "legendary": return "§6";
            case "mythical":  return "§d";
            default:          return "§f";
        }
    }

    public function dealDamage(Player $attacker, $target, $damage) {
        if ($target instanceof Player) {
            if (!$this->plugin->canPvP($attacker, $target)) {
                $attacker->sendTip("§c[SWORD] Cannot hit this player!");
                return;
            }
            $damage = $this->plugin->applyDefenseReduction($target, $damage);
            if (method_exists($this->plugin, "capTournamentDamage")) {
                $damage = $this->plugin->capTournamentDamage($attacker, $target, "fight", $this->getRarity(), $damage);
                if ($damage <= 0) return;
            }
        }

        $damage = max(0.5, $damage);
        $this->plugin->getSwordMastery()->setAbilityDamage($attacker->getName(), $damage);

        $ev = new EntityDamageByEntityEvent($attacker, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage);
        $target->attack($damage, $ev);

        if (!$ev->isCancelled()) {
            $shownDamage = method_exists($ev, "getFinalDamage") ? $ev->getFinalDamage() : $ev->getDamage();
            $this->plugin->showDamageCounter($attacker, $shownDamage);
        }

        if ($this->plugin->getCombatPlugin() !== null) {
            if ($target instanceof Player) {
                $this->plugin->getCombatPlugin()->getCombatTag()->tagPlayer($attacker);
                $this->plugin->getCombatPlugin()->getCombatTag()->tagPlayer($target);
            }
        }
    }

    public function findFrontTarget(Player $player, $maxDist) {
        $dir   = $player->getDirectionVector();
        $start = $player->add(0, $player->getEyeHeight(), 0);
        $best  = null;
        $bestDist = $maxDist + 1;

        foreach ($player->getLevel()->getPlayers() as $t) {
            if ($t->getName() === $player->getName()) continue;
            if (!$this->plugin->canPvP($player, $t)) continue;
            $tp   = $t->add(0, 1, 0);
            $dist = $start->distance($tp);
            if ($dist > $maxDist || $dist <= 0) continue;
            $to   = $tp->subtract($start);
            $norm = new Vector3($to->x / $dist, $to->y / $dist, $to->z / $dist);
            $dot  = $dir->x * $norm->x + $dir->y * $norm->y + $dir->z * $norm->z;
            if ($dot > 0.45 && $dist < $bestDist) {
                $bestDist = $dist;
                $best     = $t;
            }
        }

        foreach ($player->getLevel()->getEntities() as $e) {
            if ($e instanceof Player) continue;
            if ($e->closed || !$e->isAlive()) continue;
            $npc     = "OnePiece\\NPC\\NPCEntity";
            $factory = "OnePieceTrades\\Factory\\FactoryEntity";
            if (!($e instanceof $npc) && !($e instanceof $factory)) continue;
            $tp   = $e->add(0, 1, 0);
            $dist = $start->distance($tp);
            if ($dist > $maxDist || $dist <= 0) continue;
            $to   = $tp->subtract($start);
            $norm = new Vector3($to->x / $dist, $to->y / $dist, $to->z / $dist);
            $dot  = $dir->x * $norm->x + $dir->y * $norm->y + $dir->z * $norm->z;
            if ($dot > 0.45 && $dist < $bestDist) {
                $bestDist = $dist;
                $best     = $e;
            }
        }

        return $best;
    }

    public function getNearbyTargets(Player $player, $radius) {
        $targets  = [];
        $radiusSq = $radius * $radius;

        foreach ($player->getLevel()->getPlayers() as $t) {
            if ($t->getName() === $player->getName()) continue;
            if (!$this->plugin->canPvP($player, $t)) continue;
            if ($player->distanceSquared($t) <= $radiusSq) {
                $targets[] = $t;
            }
        }

        foreach ($player->getLevel()->getEntities() as $e) {
            if ($e instanceof Player) continue;
            if ($e->closed || !$e->isAlive()) continue;
            $npc     = "OnePiece\\NPC\\NPCEntity";
            $factory = "OnePieceTrades\\Factory\\FactoryEntity";
            if (!($e instanceof $npc) && !($e instanceof $factory)) continue;
            if ($player->distanceSquared($e) <= $radiusSq) {
                $targets[] = $e;
            }
        }

        return $targets;
    }

    public function getSwordDamage(Player $player, $base) {
        $swordStat = $this->plugin->getSwordStatMultiplier($player);
        $mast      = $this->plugin->getSwordMastery()->getDamageMultiplier($player->getName());
        $mastLevel = $this->plugin->getSwordMastery()->getLevel($player->getName());

        if ($mastLevel < 50) {
            $tierMult = 0.55 + ($mastLevel / 50) * 0.20;
        } elseif ($mastLevel < 150) {
            $tierMult = 0.75 + (($mastLevel - 50) / 100) * 0.15;
        } elseif ($mastLevel < 300) {
            $tierMult = 0.90 + (($mastLevel - 150) / 150) * 0.10;
        } else {
            $tierMult = 1.0;
        }

        $haki = 1.0;
        $hakiPlugin = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin("OnePieceHaki");
        if ($hakiPlugin !== null && $hakiPlugin->isEnabled()) {
            try {
                $arm = $hakiPlugin->getArmament();
                if ($arm !== null && $arm->isActive($player)) {
                    $haki = $arm->getDamageBoost($player);
                }
            } catch (\Exception $e) {}
        }

        $masteryDamage = $base * 0.3 * $tierMult * $mast;
        $statDamage    = $base * 0.5 * $swordStat;
        return ($masteryDamage + $statDamage) * $haki;
    }
}