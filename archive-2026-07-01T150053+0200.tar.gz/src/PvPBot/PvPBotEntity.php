<?php

namespace PvPBot;

use pocketmine\entity\Human;
use pocketmine\entity\Entity;
use pocketmine\Player;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\protocol\AddPlayerPacket;
use pocketmine\network\protocol\PlayerListPacket;
use pocketmine\network\protocol\AnimatePacket;
use pocketmine\network\protocol\EntityEventPacket;
use pocketmine\network\protocol\MobEquipmentPacket;
use pocketmine\network\protocol\SetEntityDataPacket;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;

class PvPBotEntity extends Human {

    public $width = 0.6;
    public $height = 1.8;
    public $eyeHeight = 1.62;

    protected $gravity = 0.08;
    protected $drag = 0.02;
    protected $stepHeight = 0.6;

    private $difficulty = "medium";
    private $mode = "gapplepvp";
    private $arenaName = "";
    private $targetPlayerName = "";
    private $targetPlayer = null;

    private $attackCooldown = 0;
    private $comboCooldown = 0;
    private $comboCount = 0;
    private $maxCombo = 5;

    private $sprintTicks = 0;
    private $sprintResetTicks = 0;
    private $wtapTicks = 0;
    private $strafeDir = 0;
    private $strafeTicks = 0;

    private $reactionTimer = 0;

    private $gappleCount = 0;
    private $gappleCooldown = 0;
    private $eatingTicks = 0;
    private $isEating = false;

    private $arrowCount = 0;
    private $bowCooldown = 0;
    private $bowCharging = false;
    private $bowChargeTicks = 0;

    private $blockCount = 0;
    private $buildCooldown = 0;
    private $blocksPlaced = [];

    private $buildMode = "none";
    private $towerCount = 0;
    private $maxTowerHeight = 8;
    private $towerPhase = 0;
    private $bridgeDirection = null;
    private $bridgeLength = 0;
    private $maxBridgeLength = 15;
    private $isSneaking = false;
    private $buildLock = false;
    private $buildLockTicks = 0;

    private $switchDelay = 0;
    private $pendingSwitch = "";

    private $lastHealth = 20;
    private $armorPoints = 0;

    private $reachDistanceSq = 9.0;
    private $attackReachSq = 12.25;

    private $currentHeldItem = "sword";
    private $swordItem = null;
    private $bowItem = null;
    private $blockItem = null;
    private $gappleItem = null;
    private $pickaxeItem = null;

    private $jumpTicks = 0;
    private $consecutiveJumps = 0;
    private $blockClimbTicks = 0;
    private $wasOnGround = true;
    private $sprintJumpCooldown = 0;
    private $recentlyTowered = false;
    private $towerTopY = 0;
    private $postTowerBridgeTimer = 0;

    private $bedrockBridgeStepCooldown = 0;
    private $bedrockBridgeWalkPhase = 0;

    private $playerInCombo = false;
    private $comboHitCount = 0;
    private $lastHitTick = 0;
    private $playerLastY = 0;
    private $playerLastOnGround = true;
    private $comboPositioning = false;
    private $predictedPlayerPos = null;
    private $comboChaseTicks = 0;
    private $beingComboed = false;
    private $beingComboedTicks = 0;

    private $boxingHitCooldowns = [];

    private $survivalMode = false;
    private $survivalTicks = 0;
    private $wallsBuilt = 0;
    private $maxWalls = 4;

    // Mining variables
    private $isMining = false;
    private $miningTicks = 0;
    private $miningTarget = null;
    private $miningCooldown = 0;
    private $miningBreakTicks = 15;
    private $stuckTicks = 0;
    private $lastPos = null;
    private $lastPosCheckTick = 0;
    private $towerMining = false;
    private $towerMiningTicks = 0;
    private $towerMiningTarget = null;

    private $difficultySettings = [
        "easy" => [
            "reactionMin" => 8,
            "reactionMax" => 14,
            "hitChance" => 60,
            "comboChance" => 30,
            "maxCombo" => 3,
            "strafeChance" => 20,
            "wtapChance" => 20,
            "sprintResetChance" => 20,
            "speed" => 0.95,
            "gappleHealth" => 6,
            "gappleHealthThreshold" => 12,
            "bowChance" => 35,
            "bowAccuracy" => 0.45,
            "buildSpeed" => 12,
            "towerSpeed" => 14,
            "sprintJumpChance" => 50,
            "comboAggression" => 1.05,
            "openingDetection" => 40
        ],
        "medium" => [
            "reactionMin" => 4,
            "reactionMax" => 8,
            "hitChance" => 78,
            "comboChance" => 55,
            "maxCombo" => 5,
            "strafeChance" => 40,
            "wtapChance" => 40,
            "sprintResetChance" => 45,
            "speed" => 1.08,
            "gappleHealth" => 8,
            "gappleHealthThreshold" => 14,
            "bowChance" => 50,
            "bowAccuracy" => 0.60,
            "buildSpeed" => 8,
            "towerSpeed" => 10,
            "sprintJumpChance" => 70,
            "comboAggression" => 1.15,
            "openingDetection" => 60
        ],
        "hard" => [
            "reactionMin" => 1,
            "reactionMax" => 3,
            "hitChance" => 95,
            "comboChance" => 85,
            "maxCombo" => 10,
            "strafeChance" => 70,
            "wtapChance" => 75,
            "sprintResetChance" => 85,
            "speed" => 1.28,
            "gappleHealth" => 10,
            "gappleHealthThreshold" => 16,
            "bowChance" => 75,
            "bowAccuracy" => 0.85,
            "buildSpeed" => 4,
            "towerSpeed" => 6,
            "sprintJumpChance" => 95,
            "comboAggression" => 1.5,
            "openingDetection" => 95
        ]
    ];

    private $currentSettings = [];

    public static function createBaseNBT(Vector3 $pos, Vector3 $motion = null, $yaw = 0.0, $pitch = 0.0) {
        return new CompoundTag("", [
            new ListTag("Pos", [
                new DoubleTag("", $pos->x),
                new DoubleTag("", $pos->y),
                new DoubleTag("", $pos->z)
            ]),
            new ListTag("Motion", [
                new DoubleTag("", $motion !== null ? $motion->x : 0.0),
                new DoubleTag("", $motion !== null ? $motion->y : 0.0),
                new DoubleTag("", $motion !== null ? $motion->z : 0.0)
            ]),
            new ListTag("Rotation", [
                new FloatTag("", $yaw),
                new FloatTag("", $pitch)
            ])
        ]);
    }

    public function getName() {
        return "PvPBot";
    }

    public function getSaveId() {
        return "PvPBot";
    }

    public function initEntity() {
        parent::initEntity();

        $this->setMaxHealth(20);
        $this->setHealth(20);
        $this->lastHealth = 20;

        $this->setNameTag("§cPvP Bot");
        $this->setDataProperty(self::DATA_SHOW_NAMETAG, self::DATA_TYPE_BYTE, 1);
        $this->setDataProperty(15, self::DATA_TYPE_BYTE, 1);

        $this->currentSettings = $this->difficultySettings[$this->difficulty];
        $this->maxCombo = $this->currentSettings["maxCombo"];

        $this->swordItem = Item::get(Item::DIAMOND_SWORD, 0, 1);
        $this->bowItem = Item::get(Item::BOW, 0, 1);
        $this->blockItem = Item::get(Item::COBBLESTONE, 0, 64);
        $this->gappleItem = Item::get(Item::GOLDEN_APPLE, 0, 1);
        $this->pickaxeItem = Item::get(Item::IRON_PICKAXE, 0, 1);

        $this->dataProperties[self::DATA_NO_AI] = [self::DATA_TYPE_BYTE, 1];

        $this->calculateArmorPoints();
    }

    public function spawnTo(Player $player) {
        if ($player !== $this && !isset($this->hasSpawned[$player->getLoaderId()])) {
            $this->hasSpawned[$player->getLoaderId()] = $player;

            $add = new PlayerListPacket();
            $add->type = PlayerListPacket::TYPE_ADD;
            $add->entries[] = [$this->getUniqueId(), $this->getId(), $this->getNameTag(), $this->skinId, $this->skin];
            $player->dataPacket($add);

            $pk = new AddPlayerPacket();
            $pk->uuid = $this->getUniqueId();
            $pk->username = $this->getNameTag();
            $pk->eid = $this->getId();
            $pk->x = $this->x;
            $pk->y = $this->y;
            $pk->z = $this->z;
            $pk->yaw = $this->yaw;
            $pk->pitch = $this->pitch;
            $pk->item = $this->getInventory()->getItemInHand();
            $pk->metadata = $this->dataProperties;
            $player->dataPacket($pk);

            $this->getInventory()->sendArmorContents($player);

            $remove = new PlayerListPacket();
            $remove->type = PlayerListPacket::TYPE_REMOVE;
            $remove->entries[] = [$this->getUniqueId()];
            $player->dataPacket($remove);

            $this->calculateArmorPoints();
        }
    }

    public function setDifficulty($d) {
        $this->difficulty = $d;
        if (isset($this->difficultySettings[$d])) {
            $this->currentSettings = $this->difficultySettings[$d];
            $this->maxCombo = $this->currentSettings["maxCombo"];
        }
    }

    public function getDifficulty() {
        return $this->difficulty;
    }

    public function setMode($m) {
        $this->mode = $m;
    }

    public function getMode() {
        return $this->mode;
    }

    public function setArena($a) {
        $this->arenaName = $a;
    }

    public function getArena() {
        return $this->arenaName;
    }

    public function setTargetPlayer($n) {
        $this->targetPlayerName = $n;
    }

    public function setGappleCount($c) {
        $this->gappleCount = $c;
    }

    public function getGappleCount() {
        return $this->gappleCount;
    }

    public function setArrowCount($c) {
        $this->arrowCount = $c;
    }

    public function getArrowCount() {
        return $this->arrowCount;
    }

    public function setBlockCount($c) {
        $this->blockCount = $c;
    }

    public function getBlockCount() {
        return $this->blockCount;
    }

    public function getPlacedBlocks() {
        return $this->blocksPlaced;
    }

    public function setSwordItem(Item $item) {
        $this->swordItem = $item;
    }

    public function setPickaxeItem(Item $item) {
        $this->pickaxeItem = $item;
    }

    public function registerBoxingHit($playerName) {
        if (isset($this->boxingHitCooldowns[$playerName])) {
            return false;
        }
        $this->boxingHitCooldowns[$playerName] = 10;
        return true;
    }

    private function switchHeld($type) {
        if ($this->currentHeldItem === $type) return;
        if ($this->switchDelay > 0) return;

        $this->pendingSwitch = $type;
        $this->switchDelay = 3;
    }

    private function processSwitchDelay() {
        if ($this->switchDelay > 0) {
            $this->switchDelay--;
            if ($this->switchDelay <= 0 && $this->pendingSwitch !== "") {
                $this->currentHeldItem = $this->pendingSwitch;

                $item = $this->swordItem;
                if ($this->pendingSwitch === "bow") $item = $this->bowItem;
                elseif ($this->pendingSwitch === "block") $item = $this->blockItem;
                elseif ($this->pendingSwitch === "gapple") $item = $this->gappleItem;
                elseif ($this->pendingSwitch === "pickaxe") $item = $this->pickaxeItem;

                $this->getInventory()->setItemInHand($item);

                $pk = new MobEquipmentPacket();
                $pk->eid = $this->getId();
                $pk->item = $item;
                $pk->slot = 0;
                $pk->selectedSlot = 0;

                foreach ($this->hasSpawned as $p) {
                    $p->dataPacket($pk);
                }

                $this->pendingSwitch = "";
            }
        }
    }

    public function setSneaking($sneak = true) {
        if ($this->isSneaking === $sneak) return;
        $this->isSneaking = $sneak;
        $this->setDataFlag(self::DATA_FLAGS, self::DATA_FLAG_SNEAKING, $sneak);
    }

    public function calculateArmorPoints() {
        $inv = $this->getInventory();
        if ($inv === null) {
            $this->armorPoints = 0;
            return;
        }

        $p = 0;
        $ids = [
            [$inv->getHelmet(), [Item::LEATHER_CAP => 1, Item::GOLD_HELMET => 2, Item::CHAIN_HELMET => 2, Item::IRON_HELMET => 2, Item::DIAMOND_HELMET => 3]],
            [$inv->getChestplate(), [Item::LEATHER_TUNIC => 3, Item::GOLD_CHESTPLATE => 5, Item::CHAIN_CHESTPLATE => 5, Item::IRON_CHESTPLATE => 6, Item::DIAMOND_CHESTPLATE => 8]],
            [$inv->getLeggings(), [Item::LEATHER_PANTS => 2, Item::GOLD_LEGGINGS => 3, Item::CHAIN_LEGGINGS => 4, Item::IRON_LEGGINGS => 5, Item::DIAMOND_LEGGINGS => 6]],
            [$inv->getBoots(), [Item::LEATHER_BOOTS => 1, Item::GOLD_BOOTS => 1, Item::CHAIN_BOOTS => 1, Item::IRON_BOOTS => 2, Item::DIAMOND_BOOTS => 3]]
        ];

        foreach ($ids as $pair) {
            $piece = $pair[0];
            $map = $pair[1];
            if ($piece !== null && isset($map[$piece->getId()])) {
                $p += $map[$piece->getId()];
            }
        }

        $this->armorPoints = $p;
    }

    private function getTarget() {
        if ($this->targetPlayer !== null && $this->targetPlayer->isOnline() && $this->targetPlayer->isAlive()) {
            return $this->targetPlayer;
        }

        if ($this->targetPlayerName !== "") {
            $p = $this->server->getPlayer($this->targetPlayerName);
            if ($p !== null && $p->isOnline() && $p->isAlive()) {
                $this->targetPlayer = $p;
                return $p;
            }
        }

        return null;
    }

    public function attack($damage, EntityDamageEvent $source) {
        if ($source->getCause() === EntityDamageEvent::CAUSE_FALL) {
            $source->setCancelled(true);
            return;
        }

        if ($this->isEating) {
            $this->isEating = false;
            $this->eatingTicks = 0;
        }

        $this->calculateArmorPoints();

        if ($source instanceof EntityDamageByEntityEvent) {
            $defense = min(20, $this->armorPoints);
            $reduction = 0.55 + ($defense / 20.0) * 0.35;
            $finalDamage = $damage * (1.0 - $reduction);
            if ($finalDamage < 0.5) $finalDamage = 0.5;
            $source->setDamage($finalDamage);
            parent::attack($finalDamage, $source);
        } else {
            parent::attack($damage, $source);
        }

        if ($source->isCancelled()) return;

        if ($this->buildLock && $source instanceof EntityDamageByEntityEvent) {
            $this->cancelBuild();
        }

        $this->comboCooldown = 3;

        if ($source instanceof EntityDamageByEntityEvent) {
            $damager = $source->getDamager();
            if ($damager instanceof Player) {
                $this->beingComboed = true;
                $this->beingComboedTicks = 0;

                $motion = (new Vector3($this->x - $damager->x, $this->y - $damager->y, $this->z - $damager->z))->normalize();
                $this->motionX = $motion->x * 0.19;
                $this->motionZ = $motion->z * 0.19;
                $this->motionY = 0.5;

                if ($this->playerInCombo || $this->beingComboed) {
                    $this->reactionTimer = mt_rand(
                        max(1, (int)($this->currentSettings["reactionMin"] * 0.4)),
                        max(2, (int)($this->currentSettings["reactionMax"] * 0.4))
                    );
                } else {
                    $this->reactionTimer = mt_rand($this->currentSettings["reactionMin"], $this->currentSettings["reactionMax"]);
                }
            }
        }

        $this->updateNameTag();
    }

private function cancelBuild() {
    $this->buildLock = false;
    $this->buildLockTicks = 0;
    $this->buildMode = "none";
    $this->towerCount = 0;
    $this->towerPhase = 0;
    $this->bridgeLength = 0;
    $this->bridgeDirection = null;
    $this->recentlyTowered = false;
    $this->postTowerBridgeTimer = 0;
    $this->bedrockBridgeStepCooldown = 0;
    $this->bedrockBridgeWalkPhase = 0;
    $this->wallsBuilt = 0;
    $this->isMining = false;
    $this->miningTicks = 0;
    $this->miningTarget = null;
    $this->towerMining = false;
    $this->towerMiningTicks = 0;
    $this->towerMiningTarget = null;
    $this->setSneaking(false);
    $this->switchHeld("sword");
}

    private function checkSurvivalMode() {
        if ($this->isEating) return true;

        $hp = $this->getHealth();

        if ($hp <= 6) {
            if ($this->gappleCount > 0 && ($this->mode === "gapplepvp" || $this->mode === "builduhc")) {
                $this->survivalMode = true;
                return true;
            }

            $this->survivalMode = false;
            return false;
        }

        if ($hp > 6) {
            $this->survivalMode = false;
            $this->wallsBuilt = 0;
            return false;
        }

        return $this->survivalMode;
    }

    private function tickSurvival($target, $dx, $dy, $dz, $distSq, $tickDiff) {
        $this->survivalTicks += $tickDiff;
        $distHoriz = sqrt($distSq);

        if ($this->gappleCount <= 0 && !$this->isEating) {
            $this->survivalMode = false;
            $this->wallsBuilt = 0;
            return;
        }

        $this->runAway($target, $dx, $dz, $distHoriz, $tickDiff);

        if ($this->gappleCount > 0 && $this->gappleCooldown <= 0 && !$this->isEating) {
            $this->startEatingGapple();
        }

        if ($this->isEating) {
            $this->eatingTicks += $tickDiff;
            if ($this->eatingTicks >= 32) {
                $this->finishEating();
            }
        }

        if ($this->mode === "builduhc" && $this->blockCount > 0 && $this->wallsBuilt < $this->maxWalls) {
            $this->buildDefenseWall($target, $dx, $dz, $distHoriz, $tickDiff);
        }

        $this->tickGravityMove($tickDiff, false);
    }

    private function runAway($target, $dx, $dz, $distHoriz, $tickDiff) {
        if ($distHoriz <= 0) return;

        $awayX = -($dx / $distHoriz);
        $awayZ = -($dz / $distHoriz);

        $this->yaw = rad2deg(atan2($dx, -$dz));

        $speed = $this->currentSettings["speed"] * 0.18;

        $this->motionX = $awayX * $speed;
        $this->motionZ = $awayZ * $speed;

        if ($this->onGround && $this->sprintJumpCooldown <= 0) {
            $this->motionY = 0.42;
            $this->sprintJumpCooldown = mt_rand(3, 6);
        }

        if ($this->sprintTicks <= 0) $this->sprintTicks = 40;
    }

    private function buildDefenseWall($target, $dx, $dz, $distHoriz, $tickDiff) {
        if ($this->buildCooldown > 0) return;
        if ($this->blockCount <= 0) return;

        if ($this->currentHeldItem !== "block") {
            $this->switchHeld("block");
            return;
        }

        $botY = (int)floor($this->y);

        $nx = $dx / $distHoriz;
        $nz = $dz / $distHoriz;

        $wallX = (int)floor($this->x + $nx * 1.0);
        $wallZ = (int)floor($this->z + $nz * 1.0);

        $placedSomething = false;

        if ($this->canPlaceBlockAt($wallX, $botY, $wallZ)) {
            $this->placeBlock($wallX, $botY, $wallZ);
            $placedSomething = true;
        }

        if ($this->blockCount > 0 && $this->canPlaceBlockAt($wallX, $botY + 1, $wallZ)) {
            $this->placeBlock($wallX, $botY + 1, $wallZ);
            $placedSomething = true;
        }

        if ($placedSomething) {
            $this->wallsBuilt++;
            $this->buildCooldown = $this->currentSettings["buildSpeed"] + 5;
            $this->switchHeld("sword");
        }
    }

    private function updateNameTag() {
        $hp = round($this->getHealth(), 1);
        if ($this->lastHealth === $hp) return;
        $this->lastHealth = $hp;
        $this->setNameTag("§cPvP Bot §7[" . ucfirst($this->difficulty) . "]\n§a$hp §7/ §a" . $this->getMaxHealth());
    }

    public function knockBack(Entity $attacker, $damage, $x, $z, $base = 0.4) {
        // Blocked, KB handled manually in attack()
    }

    private function isKnockback() {
        return $this->attackTime > 0;
    }

    // ========== MINING METHODS ==========

    private function isStuck() {
        $currentTick = $this->server->getTick();

        if ($this->lastPos === null) {
            $this->lastPos = new Vector3($this->x, $this->y, $this->z);
            $this->lastPosCheckTick = $currentTick;
            return false;
        }

        if ($currentTick - $this->lastPosCheckTick < 10) {
            return $this->stuckTicks >= 20;
        }

        $dx = $this->x - $this->lastPos->x;
        $dz = $this->z - $this->lastPos->z;
        $movedSq = $dx * $dx + $dz * $dz;

        $this->lastPos = new Vector3($this->x, $this->y, $this->z);
        $this->lastPosCheckTick = $currentTick;

        if ($movedSq < 0.01) {
            $this->stuckTicks += 10;
        } else {
            $this->stuckTicks = max(0, $this->stuckTicks - 5);
        }

        return $this->stuckTicks >= 20;
    }

    private function getAdjacentPlacedCobblestone($target = null) {
        $x = (int)floor($this->x);
        $y = (int)floor($this->y);
        $z = (int)floor($this->z);

        $plugin = $this->server->getPluginManager()->getPlugin("PvPBot");
        $placedBlocks = $plugin->getPlacedBlocks();
        $arenaBlocks = isset($placedBlocks[$this->arenaName]) ? $placedBlocks[$this->arenaName] : [];

        if (empty($arenaBlocks)) return null;

        $directions = [
            [1, 0], [-1, 0], [0, 1], [0, -1]
        ];

        $preferredDirX = 0;
        $preferredDirZ = 0;
        if ($target !== null) {
            $tdx = $target->x - $this->x;
            $tdz = $target->z - $this->z;
            $tdist = sqrt($tdx * $tdx + $tdz * $tdz);
            if ($tdist > 0) {
                $preferredDirX = $tdx / $tdist;
                $preferredDirZ = $tdz / $tdist;
            }
        }

        $candidates = [];

        foreach ($directions as $dir) {
            $bx = $x + $dir[0];
            $bz = $z + $dir[1];

            for ($level = 0; $level <= 1; $level++) {
                $by = $y + $level;
                $key = $bx . ":" . $by . ":" . $bz;

                if (!isset($arenaBlocks[$key])) continue;

                $blockId = $this->getLevel()->getBlockIdAt($bx, $by, $bz);
                if ($blockId !== Block::COBBLESTONE) continue;

                $score = 0;

                $dot = $dir[0] * $preferredDirX + $dir[1] * $preferredDirZ;
                $score += $dot * 5;

                if ($level === 0) $score += 3;

                $candidates[] = [
                    "pos" => new Vector3($bx, $by, $bz),
                    "score" => $score
                ];
            }
        }

        if (empty($candidates)) return null;

        usort($candidates, function($a, $b) {
            return $b["score"] <=> $a["score"];
        });

        return $candidates[0]["pos"];
    }

    private function countSurroundingPlacedBlocks() {
        $x = (int)floor($this->x);
        $y = (int)floor($this->y);
        $z = (int)floor($this->z);

        $plugin = $this->server->getPluginManager()->getPlugin("PvPBot");
        $placedBlocks = $plugin->getPlacedBlocks();
        $arenaBlocks = isset($placedBlocks[$this->arenaName]) ? $placedBlocks[$this->arenaName] : [];

        $count = 0;
        $directions = [
            [1, 0], [-1, 0], [0, 1], [0, -1]
        ];

        foreach ($directions as $dir) {
            $bx = $x + $dir[0];
            $bz = $z + $dir[1];

            $keyFoot = $bx . ":" . $y . ":" . $bz;
            $keyHead = $bx . ":" . ($y + 1) . ":" . $bz;

            if (isset($arenaBlocks[$keyFoot]) || isset($arenaBlocks[$keyHead])) {
                $blockFoot = $this->getLevel()->getBlockIdAt($bx, $y, $bz);
                $blockHead = $this->getLevel()->getBlockIdAt($bx, $y + 1, $bz);
                if ($blockFoot !== Block::AIR || $blockHead !== Block::AIR) {
                    $count++;
                }
            }
        }

        return $count;
    }

    private function checkShouldMine($target) {
        if ($this->mode !== "builduhc") return false;
        if ($this->isMining) return true;
        if ($this->miningCooldown > 0) return false;
        if ($this->buildLock) return false;
        if ($this->isEating) return false;

        $surroundingBlocks = $this->countSurroundingPlacedBlocks();

        // Heavily boxed in - 3 or more sides blocked
        if ($surroundingBlocks >= 3) {
            $mineTarget = $this->getAdjacentPlacedCobblestone($target);
            if ($mineTarget !== null) {
                $this->startMining($mineTarget);
                return true;
            }
        }

        // Stuck and at least one side has placed blocks
        if ($surroundingBlocks >= 1 && $this->isStuck()) {
            $mineTarget = $this->getAdjacentPlacedCobblestone($target);
            if ($mineTarget !== null) {
                $this->startMining($mineTarget);
                return true;
            }
        }

        // 2 sides blocked and getting stuck
        if ($surroundingBlocks >= 2 && $this->stuckTicks >= 10) {
            $mineTarget = $this->getAdjacentPlacedCobblestone($target);
            if ($mineTarget !== null) {
                $this->startMining($mineTarget);
                return true;
            }
        }

        return false;
    }

    private function startMining(Vector3 $blockPos) {
        $this->isMining = true;
        $this->miningTicks = 0;
        $this->miningTarget = $blockPos;
        $this->stuckTicks = 0;

        // Realistic pause before switching like a real player
        $this->reactionTimer = mt_rand(2, 5);
        $this->switchHeld("pickaxe");
    }

    private function cancelMining() {
        $this->isMining = false;
        $this->miningTicks = 0;
        $this->miningTarget = null;
        $this->miningCooldown = 10;
        $this->stuckTicks = 0;
        $this->switchHeld("sword");
    }

    private function tickMining($target, $tickDiff) {
        if ($this->miningTarget === null) {
            $this->cancelMining();
            return;
        }

        $blockId = $this->getLevel()->getBlockIdAt(
            (int)$this->miningTarget->x,
            (int)$this->miningTarget->y,
            (int)$this->miningTarget->z
        );

        // Block already broken
        if ($blockId === Block::AIR) {
            $plugin = $this->server->getPluginManager()->getPlugin("PvPBot");
            $key = (int)$this->miningTarget->x . ":" . (int)$this->miningTarget->y . ":" . (int)$this->miningTarget->z;
            $plugin->clearPlacedBlockAt($this->arenaName, $key);

            $this->isMining = false;
            $this->miningTicks = 0;
            $this->miningTarget = null;
            $this->miningCooldown = 5;
            $this->stuckTicks = 0;

            // Realistic think pause
            $this->reactionTimer = mt_rand(1, 4);

            if ($this->checkShouldMine($target)) {
                return;
            }

            $this->switchHeld("sword");
            return;
        }

        // Verify still a placed cobblestone block
        $plugin = $this->server->getPluginManager()->getPlugin("PvPBot");
        $placedBlocks = $plugin->getPlacedBlocks();
        $arenaBlocks = isset($placedBlocks[$this->arenaName]) ? $placedBlocks[$this->arenaName] : [];
        $key = (int)$this->miningTarget->x . ":" . (int)$this->miningTarget->y . ":" . (int)$this->miningTarget->z;

        if (!isset($arenaBlocks[$key])) {
            $this->cancelMining();
            return;
        }

        // Switch to pickaxe if not holding it
        if ($this->currentHeldItem !== "pickaxe") {
            $this->switchHeld("pickaxe");
            $this->tickGravityMove($tickDiff, true);
            return;
        }

        // Face block being mined like a real player
        $dx = $this->miningTarget->x + 0.5 - $this->x;
        $dy = ($this->miningTarget->y + 0.5) - ($this->y + $this->eyeHeight);
        $dz = $this->miningTarget->z + 0.5 - $this->z;
        $dist = sqrt($dx * $dx + $dz * $dz);
        $this->yaw = rad2deg(atan2(-$dx, $dz));
        $this->pitch = rad2deg(-atan2($dy, max($dist, 0.01)));

        // Realistic arm swing - not every tick
        if ($this->miningTicks % 5 === 0) {
            $this->sendArmSwing();
        }

        $this->miningTicks += $tickDiff;

        // Iron pickaxe breaks cobblestone in ~15 ticks
        if ($this->miningTicks >= $this->miningBreakTicks) {
            $this->getLevel()->setBlock(
                $this->miningTarget,
                Block::get(Block::AIR),
                true,
                true
            );

            $plugin->clearPlacedBlockAt($this->arenaName, $key);

            $this->isMining = false;
            $this->miningTicks = 0;
            $this->miningTarget = null;
            $this->miningCooldown = 6;
            $this->stuckTicks = 0;

            // Realistic think pause after breaking
            $this->reactionTimer = mt_rand(2, 6);

            if ($this->checkShouldMine($target)) {
                return;
            }

            $this->switchHeld("sword");
        }

        // Stay still while mining - realistic
        $this->motionX = 0;
        $this->motionZ = 0;
        $this->tickGravityMove($tickDiff, true);
    }

    // ========== MAIN UPDATE ==========

    public function onUpdate($currentTick) {
        if ($this->closed) return false;

        if ($this->getLevel() === null) {
            $this->close();
            return false;
        }

        $tickDiff = $currentTick - $this->lastUpdate;
        if ($tickDiff <= 0) return false;
        $this->lastUpdate = $currentTick;

        if (!$this->isAlive()) {
            $this->onDeath();
            return false;
        }

        $this->entityBaseTick($tickDiff);
        $this->processSwitchDelay();

        if ($this->isKnockback()) {
            $this->motionY -= $this->gravity * $tickDiff;
            if ($this->motionY < -0.4) $this->motionY = -0.4;
            $this->move($this->motionX * $tickDiff, $this->motionY * $tickDiff, $this->motionZ * $tickDiff);
            parent::updateMovement();

            if ($this->attackCooldown > 0) $this->attackCooldown -= $tickDiff;
            if ($this->comboCooldown > 0) $this->comboCooldown -= $tickDiff;
            if ($this->gappleCooldown > 0) $this->gappleCooldown -= $tickDiff;
            if ($this->bowCooldown > 0) $this->bowCooldown -= $tickDiff;
            if ($this->buildCooldown > 0) $this->buildCooldown -= $tickDiff;
            if ($this->miningCooldown > 0) $this->miningCooldown -= $tickDiff;
            if ($this->sprintTicks > 0) $this->sprintTicks -= $tickDiff;
            if ($this->wtapTicks > 0) $this->wtapTicks -= $tickDiff;
            if ($this->strafeTicks > 0) $this->strafeTicks -= $tickDiff;
            if ($this->sprintResetTicks > 0) $this->sprintResetTicks -= $tickDiff;
            if ($this->buildLockTicks > 0) $this->buildLockTicks -= $tickDiff;
            if ($this->jumpTicks > 0) $this->jumpTicks -= $tickDiff;
            if ($this->blockClimbTicks > 0) $this->blockClimbTicks -= $tickDiff;
            if ($this->sprintJumpCooldown > 0) $this->sprintJumpCooldown -= $tickDiff;
            if ($this->postTowerBridgeTimer > 0) $this->postTowerBridgeTimer -= $tickDiff;
            if ($this->bedrockBridgeStepCooldown > 0) $this->bedrockBridgeStepCooldown -= $tickDiff;

            return true;
        }

        // Normal cooldown decrements
        if ($this->attackCooldown > 0) $this->attackCooldown -= $tickDiff;
        if ($this->comboCooldown > 0) $this->comboCooldown -= $tickDiff;
        if ($this->gappleCooldown > 0) $this->gappleCooldown -= $tickDiff;
        if ($this->bowCooldown > 0) $this->bowCooldown -= $tickDiff;
        if ($this->buildCooldown > 0) $this->buildCooldown -= $tickDiff;
        if ($this->miningCooldown > 0) $this->miningCooldown -= $tickDiff;
        if ($this->sprintTicks > 0) $this->sprintTicks -= $tickDiff;
        if ($this->wtapTicks > 0) $this->wtapTicks -= $tickDiff;
        if ($this->strafeTicks > 0) $this->strafeTicks -= $tickDiff;
        if ($this->sprintResetTicks > 0) $this->sprintResetTicks -= $tickDiff;
        if ($this->buildLockTicks > 0) $this->buildLockTicks -= $tickDiff;
        if ($this->jumpTicks > 0) $this->jumpTicks -= $tickDiff;
        if ($this->blockClimbTicks > 0) $this->blockClimbTicks -= $tickDiff;
        if ($this->sprintJumpCooldown > 0) $this->sprintJumpCooldown -= $tickDiff;
        if ($this->postTowerBridgeTimer > 0) $this->postTowerBridgeTimer -= $tickDiff;
        if ($this->bedrockBridgeStepCooldown > 0) $this->bedrockBridgeStepCooldown -= $tickDiff;

        if ($this->onGround && !$this->wasOnGround) {
            $this->consecutiveJumps = 0;
        }
        $this->wasOnGround = $this->onGround;

        if ($this->buildLockTicks <= 0 && $this->buildLock) {
            if ($this->buildMode === "none") {
                $this->buildLock = false;
            }
        }

        $target = $this->getTarget();

        // GAPPLE EATING PHASE
        if ($this->isEating) {
            $this->eatingTicks += $tickDiff;
            if ($this->eatingTicks >= 32) $this->finishEating();

            if ($target !== null) {
                $edx = $target->x - $this->x;
                $edy = $target->y - $this->y;
                $edz = $target->z - $this->z;
                $edist = sqrt($edx * $edx + $edz * $edz);
                if ($edist <= 0) $edist = 0.01;

                $this->yaw = rad2deg(atan2(-$edx, $edz));
                $this->pitch = rad2deg(-atan2($edy, $edist));

                $eSpeed = $this->currentSettings["speed"] * 0.16;

                if ($edist < 3.0) {
                    $this->motionX = (-$edx / $edist) * $eSpeed;
                    $this->motionZ = (-$edz / $edist) * $eSpeed;
                } elseif ($edist > 6.0) {
                    $this->motionX = ($edx / $edist) * $eSpeed;
                    $this->motionZ = ($edz / $edist) * $eSpeed;
                } else {
                    $sDir = mt_rand(0, 1) === 0 ? -1 : 1;
                    $this->motionX = (-$edz / $edist) * $sDir * $eSpeed;
                    $this->motionZ = ($edx / $edist) * $sDir * $eSpeed;
                }

                $this->checkJump();
            }

            $this->tickGravityMove($tickDiff, false);
            return true;
        }

        if ($this->reactionTimer > 0) {
            $this->reactionTimer -= $tickDiff;
            if (!$this->onGround) {
                $this->motionX = 0;
                $this->motionZ = 0;
            }
            $this->tickGravityMove($tickDiff, false);
            return true;
        }

        if ($target === null) {
            $this->motionX = 0;
            $this->motionZ = 0;
            $this->setSneaking(false);
            $this->tickGravityMove($tickDiff, true);
            return true;
        }

        $dx = $target->x - $this->x;
        $dy = $target->y - $this->y;
        $dz = $target->z - $this->z;
        $distSq = $dx * $dx + $dz * $dz;
        $distHoriz = sqrt($distSq);

        // SURVIVAL MODE
        if ($this->checkSurvivalMode()) {
            $this->setSneaking(false);
            $this->switchHeld("sword");
            $this->tickSurvival($target, $dx, $dy, $dz, $distSq, $tickDiff);
            return true;
        }

        // Normal gapple check
        $this->checkGapple();

        // MINING PHASE - escape being boxed in
        if ($this->mode === "builduhc" && ($this->isMining || $this->checkShouldMine($target))) {
            $this->tickMining($target, $tickDiff);
            return true;
        }

        // BUILD LOCK PHASE
        if ($this->buildLock && $this->buildMode !== "none") {
            $this->tickBuild($target, $dx, $dy, $dz, $distSq, $tickDiff);
            return true;
        }

        // Post-tower bridge check
        if ($this->recentlyTowered && $this->postTowerBridgeTimer > 0) {
            $botY = (int)floor($this->y);
            $targetY = (int)floor($target->y);

            if (abs($botY - $targetY) <= 2 && $distHoriz > 3 && $this->blockCount > 0) {
                $this->initiatePostTowerBridge($dx, $dz, $distHoriz);
                $this->tickBuild($target, $dx, $dy, $dz, $distSq, $tickDiff);
                return true;
            } else if ($distHoriz <= 3) {
                $this->recentlyTowered = false;
                $this->postTowerBridgeTimer = 0;
            }
        }

        if ($this->mode === "builduhc" && $this->blockCount > 0) {
            $shouldBuild = $this->decideBuild($target, $dx, $dy, $dz, $distSq);
            if ($shouldBuild) {
                $this->tickBuild($target, $dx, $dy, $dz, $distSq, $tickDiff);
                return true;
            }
        }

        if ($this->mode === "builduhc" && $this->arrowCount > 0 && $distSq > 64 && $distSq < 400 && $this->onGround) {
            $this->setSneaking(false);
            $this->tickBowCombat($target, $tickDiff, $distSq);
            return true;
        }

        $this->setSneaking(false);
        $this->switchHeld("sword");
        $this->tickMovement($target, $dx, $dy, $dz, $distSq, $tickDiff);
        $this->tickCombat($target, $distSq, $tickDiff);

        return true;
    }

    private function initiatePostTowerBridge($dx, $dz, $distHoriz) {
        if ($distHoriz <= 0) return;

        $nx = $dx / $distHoriz;
        $nz = $dz / $distHoriz;

        $this->buildMode = "bridge";
        $this->buildLock = true;
        $this->buildLockTicks = 120;
        $this->bridgeLength = 0;
        $this->bridgeDirection = new Vector3($nx, 0, $nz);
        $this->bedrockBridgeStepCooldown = 0;
        $this->bedrockBridgeWalkPhase = 0;
        $this->recentlyTowered = false;
        $this->postTowerBridgeTimer = 0;
    }

    private function decideBuild($target, $dx, $dy, $dz, $distSq) {
        $distHoriz = sqrt($distSq);
        $playerAbove = $dy > 2.5;

        if ($playerAbove && $distHoriz < 12 && $this->onGround) {
            $botFootY = (int)floor($this->y);
            $belowBot = $this->getLevel()->getBlockIdAt((int)floor($this->x), $botFootY - 1, (int)floor($this->z));

            if ($belowBot === Block::AIR) return false;

            $this->buildMode = "tower";
            $this->buildLock = true;
            $this->buildLockTicks = 100;
            $this->towerCount = 0;
            $this->towerPhase = 0;
            $this->towerTopY = 0;
            return true;
        }

        return false;
    }

    private function tickBuild($target, $dx, $dy, $dz, $distSq, $tickDiff) {
        if ($this->blockCount <= 0) {
            $this->cancelBuild();
            $this->tickGravityMove($tickDiff, true);
            return;
        }

        $distHoriz = sqrt($distSq);

        if ($dy < -1.5) {
            $this->cancelBuild();
            return;
        }

        if ($distHoriz <= 2.5 && abs($dy) <= 2.0) {
            $this->cancelBuild();
            return;
        }

        if ($this->switchDelay > 0) {
            $this->tickGravityMove($tickDiff, true);
            return;
        }

        if ($this->currentHeldItem !== "block") {
            $this->switchHeld("block");
            $this->tickGravityMove($tickDiff, true);
            return;
        }

        if ($this->buildMode === "tower") {
            $this->tickTower($target, $dx, $dy, $dz, $tickDiff);
        } elseif ($this->buildMode === "bridge") {
            $this->tickBedrockBridge($target, $dx, $dy, $dz, $distSq, $tickDiff);
        } else {
            $this->cancelBuild();
        }
    }

private function tickTower($target, $dx, $dy, $dz, $tickDiff) {
    $this->yaw = rad2deg(atan2(-$dx, $dz));
    
    $botCurrentY = (int)floor($this->y);
    $targetY = (int)floor($target->y);

    if ($this->towerCount >= $this->maxTowerHeight || $botCurrentY >= $targetY) {
        $distHoriz = sqrt($dx * $dx + $dz * $dz);

        if ($distHoriz > 4 && $this->blockCount > 0) {
            $nx = $dx / $distHoriz;
            $nz = $dz / $distHoriz;

            $this->buildMode = "bridge";
            $this->buildLockTicks = 120;
            $this->bridgeLength = 0;
            $this->bridgeDirection = new Vector3($nx, 0, $nz);
            $this->towerMining = false;
            $this->towerMiningTicks = 0;
            $this->towerMiningTarget = null;
        } else {
            $this->cancelBuild();
        }

        $this->tickGravityMove($tickDiff, false);
        return;
    }

    $botX = (int)floor($this->x);
    $botZ = (int)floor($this->z);
    $feetY = (int)floor($this->y);

    // Check for blocks blocking the tower path
    $blockAtHead = $this->getLevel()->getBlockIdAt($botX, $feetY + 1, $botZ);
    $blockAboveHead = $this->getLevel()->getBlockIdAt($botX, $feetY + 2, $botZ);

    $plugin = $this->server->getPluginManager()->getPlugin("PvPBot");
    if (!($plugin instanceof Main)) {
        $this->cancelBuild();
        return;
    }
    
    $placedBlocks = $plugin->getPlacedBlocks();
    $arenaBlocks = isset($placedBlocks[$this->arenaName]) ? $placedBlocks[$this->arenaName] : [];

    // Check if we need to start mining (only when not already mining)
    if (!$this->towerMining) {
        $blockToMine = null;

        // Check head level first
        if ($blockAtHead !== Block::AIR) {
            $key = $botX . ":" . ($feetY + 1) . ":" . $botZ;
            if (isset($arenaBlocks[$key])) {
                $blockToMine = new Vector3($botX, $feetY + 1, $botZ);
            }
        }
        
        // Check above head if head level is clear
        if ($blockToMine === null && $blockAboveHead !== Block::AIR) {
            $key = $botX . ":" . ($feetY + 2) . ":" . $botZ;
            if (isset($arenaBlocks[$key])) {
                $blockToMine = new Vector3($botX, $feetY + 2, $botZ);
            }
        }

        if ($blockToMine !== null) {
            // Start mining - set target and request pickaxe ONCE
            $this->towerMining = true;
            $this->towerMiningTicks = 0;
            $this->towerMiningTarget = $blockToMine;
            
            // Force immediate switch to pickaxe
            $this->currentHeldItem = "pickaxe";
            $this->pendingSwitch = "";
            $this->switchDelay = 0;
            $this->getInventory()->setItemInHand($this->pickaxeItem);
            
            $pk = new MobEquipmentPacket();
            $pk->eid = $this->getId();
            $pk->item = $this->pickaxeItem;
            $pk->slot = 0;
            $pk->selectedSlot = 0;
            foreach ($this->hasSpawned as $p) {
                $p->dataPacket($pk);
            }
        }
    }

    // MINING PHASE - break block above
    if ($this->towerMining && $this->towerMiningTarget !== null) {
        $this->pitch = -70;
        
        // Verify block still exists
        $blockId = $this->getLevel()->getBlockIdAt(
            (int)$this->towerMiningTarget->x,
            (int)$this->towerMiningTarget->y,
            (int)$this->towerMiningTarget->z
        );

        // Block is gone - finish mining
        if ($blockId === Block::AIR) {
            $key = (int)$this->towerMiningTarget->x . ":" . (int)$this->towerMiningTarget->y . ":" . (int)$this->towerMiningTarget->z;
            $plugin->clearPlacedBlockAt($this->arenaName, $key);
            
            $this->towerMining = false;
            $this->towerMiningTicks = 0;
            $this->towerMiningTarget = null;
            
            // Force immediate switch back to blocks
            $this->currentHeldItem = "block";
            $this->pendingSwitch = "";
            $this->switchDelay = 0;
            $this->getInventory()->setItemInHand($this->blockItem);
            
            $pk = new MobEquipmentPacket();
            $pk->eid = $this->getId();
            $pk->item = $this->blockItem;
            $pk->slot = 0;
            $pk->selectedSlot = 0;
            foreach ($this->hasSpawned as $p) {
                $p->dataPacket($pk);
            }
            
            $this->tickGravityMove($tickDiff, true);
            return;
        }

        // We're holding pickaxe now - mine the block
        // Mining animation
        if ($this->towerMiningTicks % 4 === 0) {
            $this->sendArmSwing();
        }

        $this->towerMiningTicks += $tickDiff;

        // Break block when done
        if ($this->towerMiningTicks >= $this->miningBreakTicks) {
            $this->getLevel()->setBlock(
                $this->towerMiningTarget,
                Block::get(Block::AIR),
                true,
                true
            );

            $key = (int)$this->towerMiningTarget->x . ":" . (int)$this->towerMiningTarget->y . ":" . (int)$this->towerMiningTarget->z;
            $plugin->clearPlacedBlockAt($this->arenaName, $key);

            $this->towerMining = false;
            $this->towerMiningTicks = 0;
            $this->towerMiningTarget = null;
            
            // Force immediate switch back to blocks
            $this->currentHeldItem = "block";
            $this->pendingSwitch = "";
            $this->switchDelay = 0;
            $this->getInventory()->setItemInHand($this->blockItem);
            
            $pk = new MobEquipmentPacket();
            $pk->eid = $this->getId();
            $pk->item = $this->blockItem;
            $pk->slot = 0;
            $pk->selectedSlot = 0;
            foreach ($this->hasSpawned as $p) {
                $p->dataPacket($pk);
            }
        }

        // Stay centered while mining
        $blockCenterX = floor($this->x) + 0.5;
        $blockCenterZ = floor($this->z) + 0.5;
        $this->motionX = ($blockCenterX - $this->x) * 0.3;
        $this->motionZ = ($blockCenterZ - $this->z) * 0.3;
        
        $this->tickGravityMove($tickDiff, false);
        return;
    }

    // NORMAL TOWERING - path is clear
    $this->pitch = 80;

    // Make sure holding blocks
    if ($this->currentHeldItem !== "block") {
        $this->currentHeldItem = "block";
        $this->pendingSwitch = "";
        $this->switchDelay = 0;
        $this->getInventory()->setItemInHand($this->blockItem);
        
        $pk = new MobEquipmentPacket();
        $pk->eid = $this->getId();
        $pk->item = $this->blockItem;
        $pk->slot = 0;
        $pk->selectedSlot = 0;
        foreach ($this->hasSpawned as $p) {
            $p->dataPacket($pk);
        }
        
        $this->tickGravityMove($tickDiff, true);
        return;
    }

    $blockCenterX = floor($this->x) + 0.5;
    $blockCenterZ = floor($this->z) + 0.5;
    $diffX = $blockCenterX - $this->x;
    $diffZ = $blockCenterZ - $this->z;

    if (abs($diffX) > 0.02 || abs($diffZ) > 0.02) {
        $this->motionX = $diffX * 0.6;
        $this->motionZ = $diffZ * 0.6;
    } else {
        $this->motionX = 0;
        $this->motionZ = 0;
        $this->x = $blockCenterX;
        $this->z = $blockCenterZ;
    }

    if ($this->buildCooldown > 0) {
        if ($this->onGround) {
            $this->motionY = 0;
        } else {
            $this->motionY -= $this->gravity * $tickDiff;
            if ($this->motionY < -0.4) $this->motionY = -0.4;
        }
        $this->move($this->motionX * $tickDiff, $this->motionY * $tickDiff, $this->motionZ * $tickDiff);
        parent::updateMovement();
        return;
    }

    if ($this->onGround) {
        $this->motionY = 0.5;
        $this->towerPhase = 1;
        $this->move($this->motionX * $tickDiff, $this->motionY * $tickDiff, $this->motionZ * $tickDiff);
        parent::updateMovement();
        return;
    }

    $this->motionY -= $this->gravity * $tickDiff;

    if ($this->towerPhase === 1 && $this->motionY <= 0) {
        $placeY = $feetY - 1;
        $blockAtPlace = $this->getLevel()->getBlockIdAt($botX, $placeY, $botZ);

        if ($blockAtPlace === Block::AIR) {
            if ($this->canPlaceBlockAt($botX, $placeY, $botZ)) {
                $this->placeBlock($botX, $placeY, $botZ);
                $this->towerCount++;
                $this->buildCooldown = $this->currentSettings["towerSpeed"];
                $this->buildLockTicks = 100;
            }
        }

        $this->towerPhase = 0;
    }

    if ($this->motionY < -0.4) $this->motionY = -0.4;
    $this->move($this->motionX * $tickDiff, $this->motionY * $tickDiff, $this->motionZ * $tickDiff);
    parent::updateMovement();
}

    private function tickBedrockBridge($target, $dx, $dy, $dz, $distSq, $tickDiff) {
        if ($this->bridgeDirection === null) {
            $this->cancelBuild();
            return;
        }

        if ($this->bridgeLength >= $this->maxBridgeLength) {
            $this->cancelBuild();
            $this->tickGravityMove($tickDiff, false);
            return;
        }

        $distHoriz = sqrt($distSq);
        if ($distHoriz <= 2.5 || $dy < -1.5) {
            $this->cancelBuild();
            return;
        }

        $botFootY = (int)floor($this->y);
        $botX = (int)floor($this->x);
        $botZ = (int)floor($this->z);

        $dirX = $this->bridgeDirection->x;
        $dirZ = $this->bridgeDirection->z;

        $stillHasGap = false;
        for ($i = 1; $i <= 5; $i++) {
            $cx = (int)floor($this->x + $dirX * $i);
            $cz = (int)floor($this->z + $dirZ * $i);
            if ($this->getLevel()->getBlockIdAt($cx, $botFootY - 1, $cz) === Block::AIR) {
                $stillHasGap = true;
                break;
            }
        }

        if (!$stillHasGap) {
            $this->cancelBuild();
            return;
        }

        $this->setSneaking(false);

        $lookYaw = rad2deg(atan2(-$dirX, $dirZ));
        $this->yaw = $lookYaw;
        $this->pitch = 45;

        $belowMe = $this->getLevel()->getBlockIdAt($botX, $botFootY - 1, $botZ);

        $nextX = (int)floor($this->x + $dirX * 1.0);
        $nextZ = (int)floor($this->z + $dirZ * 1.0);
        $nextGround = $this->getLevel()->getBlockIdAt($nextX, $botFootY - 1, $nextZ);

        if ($belowMe === Block::AIR) {
            if ($this->buildCooldown <= 0) {
                if ($this->canPlaceBlockAt($botX, $botFootY - 1, $botZ)) {
                    $this->placeBlock($botX, $botFootY - 1, $botZ);
                    $this->bridgeLength++;
                    $this->buildCooldown = $this->currentSettings["buildSpeed"];
                    $this->buildLockTicks = 120;
                } else {
                    $this->cancelBuild();
                    return;
                }
            }
            $this->motionX = 0;
            $this->motionZ = 0;
        } else {
            if ($nextGround === Block::AIR) {
                if ($this->buildCooldown <= 0) {
                    if ($this->canPlaceBlockAt($nextX, $botFootY - 1, $nextZ)) {
                        $this->placeBlock($nextX, $botFootY - 1, $nextZ);
                        $this->bridgeLength++;
                        $this->buildCooldown = $this->currentSettings["buildSpeed"];
                        $this->buildLockTicks = 120;
                    }
                }
                $speed = 0.12;
                $this->motionX = $dirX * $speed;
                $this->motionZ = $dirZ * $speed;
            } else {
                if ($this->blockCount > 0) {
                    $speed = 0.15;
                    $this->motionX = $dirX * $speed;
                    $this->motionZ = $dirZ * $speed;
                } else {
                    $this->cancelBuild();
                    return;
                }
            }
        }

        if ($this->onGround) {
            $this->motionY = 0;
        } else {
            $this->motionY -= $this->gravity * $tickDiff;
            if ($this->motionY < -0.4) $this->motionY = -0.4;
        }

        $this->move($this->motionX * $tickDiff, $this->motionY * $tickDiff, $this->motionZ * $tickDiff);
        parent::updateMovement();
    }

    private function canPlaceBlockAt($x, $y, $z) {
        if ($y < 1 || $y > 127) return false;

        $blockId = $this->getLevel()->getBlockIdAt($x, $y, $z);
        if ($blockId !== Block::AIR) return false;

        $below = $this->getLevel()->getBlockIdAt($x, $y - 1, $z);
        if ($below !== Block::AIR) return true;

        $north = $this->getLevel()->getBlockIdAt($x, $y, $z - 1);
        if ($north !== Block::AIR) return true;

        $south = $this->getLevel()->getBlockIdAt($x, $y, $z + 1);
        if ($south !== Block::AIR) return true;

        $east = $this->getLevel()->getBlockIdAt($x + 1, $y, $z);
        if ($east !== Block::AIR) return true;

        $west = $this->getLevel()->getBlockIdAt($x - 1, $y, $z);
        if ($west !== Block::AIR) return true;

        $above = $this->getLevel()->getBlockIdAt($x, $y + 1, $z);
        if ($above !== Block::AIR) return true;

        return false;
    }

    private function placeBlock($x, $y, $z) {
        $pos = new Vector3($x, $y, $z);
        $this->getLevel()->setBlock($pos, Block::get(Block::COBBLESTONE), true, true);
        $this->blocksPlaced[] = $pos;

        if (count($this->blocksPlaced) > 100) {
            array_shift($this->blocksPlaced);
        }

        $this->blockCount--;
        $this->sendArmSwing();
    }

    private function tickGravityMove($tickDiff, $stopXZ) {
        if ($this->onGround) {
            $this->motionY = 0;
        } else {
            $this->motionY -= $this->gravity * $tickDiff;
            if ($this->motionY < -0.4) $this->motionY = -0.4;
        }

        if ($stopXZ) {
            $this->move(0, $this->motionY * $tickDiff, 0);
        } else {
            $this->move($this->motionX * $tickDiff, $this->motionY * $tickDiff, $this->motionZ * $tickDiff);
        }
        parent::updateMovement();
    }

    private function checkGapple() {
        if ($this->gappleCount <= 0 || $this->gappleCooldown > 0 || $this->isEating) return;
        if ($this->buildLock) return;

        $hp = $this->getHealth();

        if ($hp > 6) {
            $target = $this->getTarget();
            if ($target !== null) {
                $dx = $target->x - $this->x;
                $dz = $target->z - $this->z;
                $distSq = $dx * $dx + $dz * $dz;
                if ($distSq < 36) return;
            }
        }

        $shouldEat = false;

        if ($hp <= $this->currentSettings["gappleHealth"]) {
            $shouldEat = true;
        } else if ($hp <= $this->currentSettings["gappleHealthThreshold"]) {
            $target = $this->getTarget();
            if ($target !== null) {
                $dx = $target->x - $this->x;
                $dz = $target->z - $this->z;
                $distSq = $dx * $dx + $dz * $dz;
                if ($distSq < 100) {
                    $shouldEat = mt_rand(1, 100) <= 70;
                }
            }
        }

        if ($shouldEat) {
            $this->startEatingGapple();
        }
    }

    private function startEatingGapple() {
        $this->isEating = true;
        $this->eatingTicks = 0;
        $this->gappleCooldown = 60;

        $this->currentHeldItem = "gapple";
        $this->getInventory()->setItemInHand($this->gappleItem);

        $this->broadcastHeldItem($this->gappleItem);

        $epk = new EntityEventPacket();
        $epk->eid = $this->getId();
        $epk->event = 9;

        foreach ($this->hasSpawned as $p) {
            $p->dataPacket($epk);
        }
    }

    private function finishEating() {
        $this->isEating = false;
        $this->eatingTicks = 0;
        $this->gappleCount--;
        $this->gappleCooldown = 60;

        $newHp = min($this->getMaxHealth(), $this->getHealth() + 4);
        $this->setHealth($newHp);
        $this->updateNameTag();

        $this->currentHeldItem = "sword";
        $this->pendingSwitch = "";
        $this->switchDelay = 0;
        $this->getInventory()->setItemInHand($this->swordItem);

        $this->broadcastHeldItem($this->swordItem);
    }

    private function broadcastHeldItem(Item $item) {
        $pk = new MobEquipmentPacket();
        $pk->eid = $this->getId();
        $pk->item = $item;
        $pk->slot = 0;
        $pk->selectedSlot = 0;

        foreach ($this->hasSpawned as $p) {
            $p->dataPacket($pk);
        }
    }

    public function cleanupBlocks() {
        foreach ($this->blocksPlaced as $pos) {
            if ($this->getLevel()->getBlockIdAt($pos->x, $pos->y, $pos->z) === Block::COBBLESTONE) {
                $this->getLevel()->setBlock($pos, Block::get(Block::AIR), true, true);
            }
        }
        $this->blocksPlaced = [];
    }

    private function tickBowCombat($target, $tickDiff, $distSq) {
        $this->switchHeld("bow");

        if ($this->switchDelay > 0) {
            $this->tickGravityMove($tickDiff, true);
            return;
        }

        $dx = $target->x - $this->x;
        $dy = $target->y - $this->y;
        $dz = $target->z - $this->z;
        $dist = sqrt($distSq);

        $this->yaw = rad2deg(atan2(-$dx, $dz));
        $this->pitch = rad2deg(-atan2($dy, $dist));

        if ($this->bowCooldown > 0) {
            $this->tickStrafe($target, $this->currentSettings["speed"] * 0.20);
            $this->checkJump();
            $this->tickGravityMove($tickDiff, false);
            return;
        }

        if (!$this->bowCharging) {
            if (mt_rand(1, 100) <= $this->currentSettings["bowChance"]) {
                $this->bowCharging = true;
                $this->bowChargeTicks = 0;
            } else {
                $this->bowCooldown = 20;
            }
        }

        if ($this->bowCharging) {
            $this->bowChargeTicks += $tickDiff;
            $this->motionX = 0;
            $this->motionZ = 0;

            if ($this->bowChargeTicks >= 20) {
                $this->shootArrow($target);
                $this->bowCharging = false;
                $this->bowChargeTicks = 0;
                $this->bowCooldown = 30;
            }
        }

        $this->tickGravityMove($tickDiff, false);
    }

    private function shootArrow($target) {
        if ($this->arrowCount <= 0) return;

        $this->arrowCount--;
        $this->sendArmSwing();

        $dx = $target->x - $this->x;
        $dy = ($target->y + $target->eyeHeight) - ($this->y + $this->eyeHeight);
        $dz = $target->z - $this->z;
        $dist = sqrt($dx * $dx + $dz * $dz);

        $dy += ($dist * 0.08);

        $acc = $this->currentSettings["bowAccuracy"];
        $sp = (1 - $acc) * 3;

        $dx += (mt_rand(-100, 100) / 100) * $sp;
        $dz += (mt_rand(-100, 100) / 100) * $sp;

        $yaw = rad2deg(atan2(-$dx, $dz));
        $pitch = rad2deg(-atan2($dy, $dist));

        $px = $this->x;
        $py = $this->y + $this->eyeHeight;
        $pz = $this->z;

        $nbt = new CompoundTag("", [
            new ListTag("Pos", [
                new DoubleTag("", $px),
                new DoubleTag("", $py),
                new DoubleTag("", $pz)
            ]),
            new ListTag("Motion", [
                new DoubleTag("", 0),
                new DoubleTag("", 0),
                new DoubleTag("", 0)
            ]),
            new ListTag("Rotation", [
                new FloatTag("", $yaw),
                new FloatTag("", $pitch)
            ])
        ]);

        $f = 2.0;
        $mx = -sin(deg2rad($yaw)) * cos(deg2rad($pitch)) * $f;
        $my = -sin(deg2rad($pitch)) * $f;
        $mz = cos(deg2rad($yaw)) * cos(deg2rad($pitch)) * $f;

        $chunk = $this->getLevel()->getChunk($px >> 4, $pz >> 4);
        if ($chunk === null) return;

        $arrow = Entity::createEntity("Arrow", $chunk, $nbt, $this);
        if ($arrow !== null) {
            $arrow->setMotion(new Vector3($mx, $my, $mz));
            $arrow->spawnToAll();
        }
    }

    private function tickMovement($target, $dx, $dy, $dz, $distSq, $tickDiff) {
        $dist = sqrt($distSq);

        if ($this->comboPositioning && $this->predictedPlayerPos !== null) {
            $realToPredX = $this->predictedPlayerPos->x - $target->x;
            $realToPredZ = $this->predictedPlayerPos->z - $target->z;
            $realToPredSq = $realToPredX * $realToPredX + $realToPredZ * $realToPredZ;

            if ($realToPredSq < 0.5) {
                $this->comboPositioning = false;
                $this->predictedPlayerPos = null;
            } else {
                $pdx = $this->predictedPlayerPos->x - $this->x;
                $pdz = $this->predictedPlayerPos->z - $this->z;
                $pDistSq = $pdx * $pdx + $pdz * $pdz;

                if ($pDistSq > 0.4) {
                    $dx = $pdx;
                    $dz = $pdz;
                    $dist = sqrt($pDistSq);
                    $distSq = $pDistSq;
                } else {
                    $this->comboPositioning = false;
                    $this->predictedPlayerPos = null;
                }
            }
        }

        $realDx = $target->x - $this->x;
        $realDz = $target->z - $this->z;
        $this->yaw = rad2deg(atan2(-$realDx, $realDz));
        $this->pitch = rad2deg(-atan2($dy, max($dist, 0.01)));

        $speed = $this->currentSettings["speed"] * 0.13;

        if ($this->sprintTicks > 0) {
            $speed = $this->currentSettings["speed"] * 0.17;
        }

        if ($this->playerInCombo || $this->comboChaseTicks > 0) {
            $speed *= $this->currentSettings["comboAggression"];
        }

        $isChasing = false;

        if ($distSq < 1.5) {
            if ($this->playerInCombo) {
                $this->tickComboStrafe($target, $speed);
                $isChasing = true;
            } else {
                $this->tickStrafe($target, $speed * 0.7);
                $isChasing = false;
            }
        } elseif ($distSq < $this->reachDistanceSq) {
            $this->tickApproach($dx, $dz, $dist, $speed, true);
            $isChasing = true;
        } else {
            $this->tickApproach($dx, $dz, $dist, $speed, false);
            $isChasing = true;
        }

        if ($isChasing) {
            $this->trySprintJump($distSq);
        }

        $jumpedThisTick = false;
        if ($this->onGround) {
            $prevMotionY = $this->motionY;
            $this->checkJump();
            $this->checkBlockClimb();
            if ($this->motionY > $prevMotionY) {
                $jumpedThisTick = true;
            }
        } else {
            $this->checkBlockClimb();
        }

        if ($this->onGround && !$jumpedThisTick) {
            $this->motionY = 0;
        } else if (!$this->onGround) {
            $this->motionY -= $this->gravity * $tickDiff;
            if ($this->motionY < -0.4) $this->motionY = -0.4;
        }

        $this->move($this->motionX * $tickDiff, $this->motionY * $tickDiff, $this->motionZ * $tickDiff);
        parent::updateMovement();
    }

    private function trySprintJump($distSq) {
        if ($this->sprintTicks <= 0) return;
        if ($this->sprintJumpCooldown > 0) return;
        if (!$this->onGround) return;

        $this->motionY = 0.42;
        $this->consecutiveJumps++;

        $this->sprintJumpCooldown = mt_rand(3, 8);
    }

    private function tickApproach($dx, $dz, $dist, $speed, $inRange) {
        if ($dist <= 0) return;

        if ($inRange && $this->sprintResetTicks <= 0 && !$this->playerInCombo) {
            if (mt_rand(1, 100) <= $this->currentSettings["sprintResetChance"]) {
                $this->sprintResetTicks = 6;
                $this->sprintTicks = 0;
                $this->motionX = 0;
                $this->motionZ = 0;
                return;
            }
        }

        if ($this->wtapTicks > 0) {
            $this->sprintTicks = 0;
            $this->motionX = 0;
            $this->motionZ = 0;
            return;
        }

        $this->motionX = ($dx / $dist) * $speed;
        $this->motionZ = ($dz / $dist) * $speed;

        if ($this->sprintTicks <= 0) {
            $this->sprintTicks = 40;
        }
    }

    private function tickStrafe($target, $speed) {
        if ($this->strafeTicks <= 0) {
            if (mt_rand(1, 100) <= $this->currentSettings["strafeChance"]) {
                $this->strafeDir = mt_rand(0, 1) === 0 ? -1 : 1;
                $this->strafeTicks = mt_rand(5, 12);
            }
        }

        $dx = $target->x - $this->x;
        $dz = $target->z - $this->z;
        $dist = sqrt($dx * $dx + $dz * $dz);

        if ($dist <= 0) return;

        $strafeSpeed = $speed * 0.65;
        $this->motionX = (-$dz / $dist) * $this->strafeDir * $strafeSpeed;
        $this->motionZ = ($dx / $dist) * $this->strafeDir * $strafeSpeed;
    }

    private function tickComboStrafe($target, $speed) {
        $dx = $target->x - $this->x;
        $dz = $target->z - $this->z;
        $dist = sqrt($dx * $dx + $dz * $dz);

        if ($dist <= 0) return;

        if ($this->wtapTicks > 0) {
            $this->motionX = 0;
            $this->motionZ = 0;
            return;
        }

        if ($this->strafeTicks <= 0) {
            if (mt_rand(1, 100) <= $this->currentSettings["strafeChance"]) {
                $this->strafeDir = mt_rand(0, 1) === 0 ? -1 : 1;
                $this->strafeTicks = mt_rand(3, 6);
            }
        }

        $forwardWeight = 0.88;
        $strafeWeight  = 0.22;

        $this->motionX = ($dx / $dist) * $speed * $forwardWeight
                       + (-$dz / $dist) * $this->strafeDir * $speed * $strafeWeight;
        $this->motionZ = ($dz / $dist) * $speed * $forwardWeight
                       + ($dx / $dist) * $this->strafeDir * $speed * $strafeWeight;
    }

    private function checkJump() {
        if (!$this->onGround) return;

        if ($this->isCollidedHorizontally) {
            $footY = (int)floor($this->y);
            $checkX = (int)floor($this->x + ($this->motionX > 0 ? 0.4 : -0.4));
            $checkZ = (int)floor($this->z + ($this->motionZ > 0 ? 0.4 : -0.4));

            $blockAtFoot = $this->getLevel()->getBlockIdAt($checkX, $footY, $checkZ);
            $blockAbove  = $this->getLevel()->getBlockIdAt($checkX, $footY + 1, $checkZ);
            $blockTop    = $this->getLevel()->getBlockIdAt($checkX, $footY + 2, $checkZ);

            if ($blockAtFoot !== Block::AIR && $blockAbove === Block::AIR && $blockTop === Block::AIR) {
                $this->motionY = 0.42;
                $this->jumpTicks = 10;
            }
            return;
        }

        $speed = sqrt($this->motionX * $this->motionX + $this->motionZ * $this->motionZ);
        if ($speed < 0.01) return;

        $nx = $this->motionX / $speed;
        $nz = $this->motionZ / $speed;

        $checkX = (int)floor($this->x + $nx * 0.7);
        $checkZ = (int)floor($this->z + $nz * 0.7);
        $footY = (int)floor($this->y);

        $blockAtFoot = $this->getLevel()->getBlockIdAt($checkX, $footY, $checkZ);
        $blockAtHead = $this->getLevel()->getBlockIdAt($checkX, $footY + 1, $checkZ);
        $blockTop    = $this->getLevel()->getBlockIdAt($checkX, $footY + 2, $checkZ);

        if ($blockAtFoot !== Block::AIR && $blockAtHead === Block::AIR && $blockTop === Block::AIR) {
            $this->motionY = 0.42;
            $this->jumpTicks = 10;
        }
    }

    private function checkBlockClimb() {
        if (!$this->onGround && $this->isCollidedHorizontally && $this->blockClimbTicks <= 0) {
            $footY = (int)floor($this->y);
            $checkX = (int)floor($this->x + ($this->motionX > 0 ? 0.3 : -0.3));
            $checkZ = (int)floor($this->z + ($this->motionZ > 0 ? 0.3 : -0.3));

            $blockInFront = $this->getLevel()->getBlockIdAt($checkX, $footY, $checkZ);
            $blockAbove = $this->getLevel()->getBlockIdAt($checkX, $footY + 1, $checkZ);
            $blockAtHead = $this->getLevel()->getBlockIdAt((int)floor($this->x), $footY + 1, (int)floor($this->z));

            if ($blockInFront !== Block::AIR && $blockAbove === Block::AIR && $blockAtHead === Block::AIR) {
                if ($this->motionY < 0.1) {
                    $this->motionY = 0.42;
                    $this->blockClimbTicks = 10;
                }
            }
        }
    }

    private function tickCombat($target, $distSq, $tickDiff) {
        if ($this->switchDelay > 0) return;

        $this->updateComboState($target, $tickDiff);

        if ($this->beingComboed) {
            $this->beingComboedTicks += $tickDiff;
            if ($this->beingComboedTicks > 20) {
                $this->beingComboed = false;
                $this->beingComboedTicks = 0;
            }
        }

        $canAttack = $this->playerInCombo || $this->beingComboed;
        if (!$canAttack) {
            if (!$this->findOpening($target, $distSq)) {
                if ($this->attackCooldown <= 0) {
                    $this->attackCooldown = 5;
                }
                return;
            }
        }

        if ($distSq > $this->attackReachSq) return;

        $attackCD = $this->getComboAttackDelay();
        if ($this->attackCooldown > 0) return;

        if (mt_rand(1, 100) > $this->currentSettings["hitChance"]) {
            $this->attackCooldown = $attackCD;
            return;
        }

        $this->sendArmSwing();

        $dmg = 1.0;
        $isCrit = false;

        if ($this->motionY < -0.1 && $this->onGround === false && $this->sprintTicks <= 0) {
            $isCrit = true;
            $dmg *= 1.5;
        }

        if ($this->swordItem !== null) {
            $id = $this->swordItem->getId();
            if ($id === Item::DIAMOND_SWORD) $dmg *= 7.0;
            elseif ($id === Item::IRON_SWORD) $dmg *= 6.0;
            elseif ($id === Item::STONE_SWORD) $dmg *= 5.0;
            elseif ($id === Item::WOODEN_SWORD || $id === Item::GOLD_SWORD) $dmg *= 4.0;
            elseif ($id === Item::STICK) $dmg *= 1.0;
        }

        $ev = new EntityDamageByEntityEvent($this, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $dmg);
        $target->attack($dmg, $ev);

        if (!$ev->isCancelled()) {
            $this->comboHitCount++;
            $this->lastHitTick = $this->server->getTick();
            $this->playerInCombo = true;

            $tdx = $target->x - $this->x;
            $tdz = $target->z - $this->z;
            $td = sqrt($tdx * $tdx + $tdz * $tdz);
            if ($td <= 0) $td = 0.01;

            $isSprinting = $this->sprintTicks > 0;

            $kbH = $isSprinting ? 0.5 : 0.4;
            $kbV = 0.4;

            $target->setMotion(new Vector3(
                ($tdx / $td) * $kbH,
                $kbV,
                ($tdz / $td) * $kbH
            ));

            $this->predictPlayerPosition($target, $tdx / $td, $tdz / $td, $kbH, $kbV);
        }

        if ($this->playerInCombo && $this->comboHitCount >= 2) {
            if (mt_rand(1, 100) <= $this->currentSettings["wtapChance"]) {
                $this->wtapTicks = 2;
            }
        }

        $this->attackCooldown = $attackCD;
    }

    private function updateComboState($target, $tickDiff) {
        $currentTick = $this->server->getTick();

        $wasInAir = !$this->playerLastOnGround;
        $nowOnGround = $target->onGround;
        $this->playerLastOnGround = $nowOnGround;

        if ($wasInAir && $nowOnGround) {
            $this->comboChaseTicks = 15;
        }

        if ($this->comboChaseTicks > 0) {
            $this->comboChaseTicks -= $tickDiff;
        }

        if ($this->playerInCombo) {
            $ticksSinceHit = $currentTick - $this->lastHitTick;

            if ($ticksSinceHit > 40) {
                $this->resetCombo();
            }
        }

        $this->playerLastY = $target->y;
    }

    private function resetCombo() {
        $this->playerInCombo = false;
        $this->comboHitCount = 0;
        $this->comboPositioning = false;
        $this->predictedPlayerPos = null;
        $this->comboChaseTicks = 0;
    }

    private function findOpening($target, $distSq) {
        if ($target->onGround && $this->playerLastY > $target->y + 0.15) {
            if (mt_rand(1, 100) <= $this->currentSettings["openingDetection"]) {
                return true;
            }
        }

        if (!$target->onGround && $target->motionY < -0.15) {
            if (mt_rand(1, 100) <= $this->currentSettings["openingDetection"] * 0.8) {
                return true;
            }
        }

        if ($target->isSprinting()) {
            $pdx = $this->x - $target->x;
            $pdz = $this->z - $target->z;
            $pDist = sqrt($pdx * $pdx + $pdz * $pdz);
            if ($pDist > 0) {
                $targetYaw = $target->yaw;
                $angleToUs = rad2deg(atan2(-$pdx, $pdz));
                $angleDiff = abs($targetYaw - $angleToUs);
                while ($angleDiff > 180) $angleDiff = abs($angleDiff - 360);

                if ($angleDiff < 60) {
                    return true;
                }
            }
        }

        if ($this->comboChaseTicks > 0) {
            return true;
        }

        if ($distSq <= $this->attackReachSq * 0.65) {
            if (mt_rand(1, 100) <= 85) {
                return true;
            }
        }

        if (mt_rand(1, 100) <= $this->currentSettings["openingDetection"] * 0.3) {
            return true;
        }

        return false;
    }

    private function getComboAttackDelay() {
        if (!$this->playerInCombo) {
            return 10;
        }

        if ($this->comboHitCount >= 5) {
            return 5;
        } else if ($this->comboHitCount >= 3) {
            return 6;
        } else if ($this->comboHitCount >= 1) {
            return 7;
        }

        return 8;
    }

    private function predictPlayerPosition($target, $dirX, $dirZ, $kbH, $kbV) {
        $playerMoving = abs($target->motionX) > 0.08 || abs($target->motionZ) > 0.08;
        if (!$playerMoving) {
            $this->comboPositioning = false;
            $this->predictedPlayerPos = null;
            return;
        }

        $horizontalDist = $kbH * 4 * 0.5;

        $predictedX = $target->x + $dirX * $horizontalDist;
        $predictedZ = $target->z + $dirZ * $horizontalDist;

        $this->predictedPlayerPos = new Vector3($predictedX, $target->y, $predictedZ);
        $this->comboPositioning = true;
    }

    private function sendArmSwing() {
        $pk = new AnimatePacket();
        $pk->eid = $this->getId();
        $pk->action = 1;

        foreach ($this->hasSpawned as $p) {
            $p->dataPacket($pk);
        }
    }

    private function onDeath() {
        $this->setSneaking(false);
        $this->cleanupBlocks();
        $plugin = $this->server->getPluginManager()->getPlugin("PvPBot");
        if ($plugin instanceof Main && $this->arenaName !== "") {
            $plugin->getServer()->getScheduler()->scheduleDelayedTask(
                new EndMatchTask($plugin, $this->arenaName, $this->targetPlayerName), 10
            );
        }
        $this->close();
    }

    public function entityBaseTick($tickDiff = 1, $EnchantL = 0) {
        if ($this->closed) return false;

        $hasUpdate = false;

        if ($this->y <= -16 && $this->isAlive()) {
            $ev = new EntityDamageEvent($this, EntityDamageEvent::CAUSE_VOID, 10);
            $this->attack(10, $ev);
            $hasUpdate = true;
        }

        if ($this->noDamageTicks > 0) {
            $this->noDamageTicks -= $tickDiff;
            if ($this->noDamageTicks < 0) $this->noDamageTicks = 0;
        }

        $this->age += $tickDiff;
        $this->ticksLived += $tickDiff;

        if ($this->attackTime > 0) $this->attackTime -= $tickDiff;

        foreach ($this->boxingHitCooldowns as $name => $cd) {
            $this->boxingHitCooldowns[$name] -= $tickDiff;
            if ($this->boxingHitCooldowns[$name] <= 0) {
                unset($this->boxingHitCooldowns[$name]);
            }
        }

        return $hasUpdate;
    }

    public function getDrops() {
        return [];
    }

    public function close() {
        $this->setSneaking(false);
        $this->cleanupBlocks();
        parent::close();
    }
}