<?php

namespace PvPBot;

use pocketmine\scheduler\PluginTask;

class DeleteWorldTask extends PluginTask {

    private $plugin;
    private $instanceName;

    public function __construct(Main $plugin, $instanceName) {
        parent::__construct($plugin);
        $this->plugin = $plugin;
        $this->instanceName = $instanceName;
    }

    public function onRun($currentTick) {
        $this->plugin->getWorldManager()->forceUnloadAndDelete($this->instanceName);
    }
}
