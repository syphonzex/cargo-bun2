<?php

namespace PvPBot;

use pocketmine\scheduler\PluginTask;
use pocketmine\math\Vector3;
use pocketmine\Player;

class MatchTask extends PluginTask {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct($plugin);
        $this->plugin = $plugin;
    }

    public function onRun($currentTick) {
        // Tick hologram refresh
        $this->plugin->getHologramManager()->onTick();

        $matches = $this->plugin->getActiveMatches();

        if (count($matches) === 0) return;

        foreach ($matches as $arenaName => $match) {
            if ($match["started"]) {
                $this->tickActiveMatch($arenaName, $match);
            } else {
                $this->tickWarmup($arenaName, $match);
            }
        }
    }

    private function tickWarmup($arenaName, $match) {
        $warmup = $match["warmup"];

        $p1 = $this->plugin->getServer()->getPlayer($match["player1"]);
        if ($p1 === null || !$p1->isOnline()) {
            $this->plugin->endMatch($arenaName, null, true);
            return;
        }

        if ($match["player2"] !== null) {
            $p2 = $this->plugin->getServer()->getPlayer($match["player2"]);
            if ($p2 === null || !$p2->isOnline()) {
                $this->plugin->endMatch($arenaName, null, true);
                return;
            }
        }

        if ($warmup > 0) {
            $color = "§a";
            if ($warmup <= 2) {
                $color = "§c";
            } elseif ($warmup <= 3) {
                $color = "§6";
            } elseif ($warmup <= 5) {
                $color = "§e";
            }

            $p1->sendTip($color . "Match starting in " . $warmup . "...");

            if ($match["player2"] !== null) {
                $p2 = $this->plugin->getServer()->getPlayer($match["player2"]);
                if ($p2 !== null) {
                    $p2->sendTip($color . "Match starting in " . $warmup . "...");
                }
            }

            $match["warmup"] = $warmup - 1;
            $this->plugin->setActiveMatch($arenaName, $match);
            return;
        }

        $match["started"] = true;
        $match["matchTime"] = 0;

        $p1->sendTip("§a§lFIGHT!");

        if ($match["player2"] !== null) {
            $p2 = $this->plugin->getServer()->getPlayer($match["player2"]);
            if ($p2 !== null) {
                $p2->sendTip("§a§lFIGHT!");
            }
        }

        if ($match["bot"] === true) {
            $this->plugin->setActiveMatch($arenaName, $match);
            $bot = $this->plugin->spawnBot($arenaName);

            if ($bot === null) {
                $p1->sendMessage("§cFailed to spawn bot");
                $this->plugin->endMatch($arenaName, null, true);
                return;
            }

            $match = $this->plugin->getActiveMatches()[$arenaName];
        }

        $this->plugin->setActiveMatch($arenaName, $match);
    }

    private function tickActiveMatch($arenaName, $match) {
        $match["matchTime"] = isset($match["matchTime"]) ? $match["matchTime"] + 1 : 1;

        $p1 = $this->plugin->getServer()->getPlayer($match["player1"]);
        if ($p1 === null || !$p1->isOnline()) {
            if ($match["player2"] !== null) {
                $this->plugin->endMatch($arenaName, $match["player2"]);
            } else {
                $this->plugin->endMatch($arenaName, "bot");
            }
            return;
        }

        if ($match["player2"] !== null) {
            $p2 = $this->plugin->getServer()->getPlayer($match["player2"]);
            if ($p2 === null || !$p2->isOnline()) {
                $this->plugin->endMatch($arenaName, $match["player1"]);
                return;
            }

            if ($match["mode"] === "boxing") {
                $hits = $this->plugin->getBoxingHits($arenaName);
                $p1Hits = $hits["player1"] ?? 0;
                $p2Hits = $hits["player2"] ?? 0;
                $p1->sendTip("§aYour hits: §f" . $p1Hits . " §7/ §f100\n§c" . $match["player2"] . " hits: §f" . $p2Hits . " §7/ §f100");
                $p2->sendTip("§aYour hits: §f" . $p2Hits . " §7/ §f100\n§c" . $match["player1"] . " hits: §f" . $p1Hits . " §7/ §f100");
            } elseif ($match["mode"] === "resistance") {
                $time = $this->formatTime($match["matchTime"]);
                $p1->sendTip("§e" . $time . "\n§7Practice Mode - §aResistance");
                $p2->sendTip("§e" . $time . "\n§7Practice Mode - §aResistance");
            } else {
                $this->sendMatchHud($p1, $p2, $match);
                $this->sendMatchHud($p2, $p1, $match);
            }
        } else {
            if (isset($match["botEntity"])) {
                $instanceName = $match["instance"];
                $level = $this->plugin->getServer()->getLevelByName($instanceName);
                $bot = ($level !== null) ? $level->getEntity($match["botEntity"]) : null;

                if ($bot === null || $bot->closed) {
                    return;
                }

                if ($match["mode"] === "boxing") {
                    $hits = $this->plugin->getBoxingHits($arenaName);
                    $p1Hits = $hits["player1"] ?? 0;
                    $botHits = $hits["player2"] ?? 0;
                    $p1->sendTip("§aYour hits: §f" . $p1Hits . " §7/ §f100\n§cBot hits: §f" . $botHits . " §7/ §f100");
                } elseif ($match["mode"] === "resistance") {
                    $time = $this->formatTime($match["matchTime"]);
                    $p1->sendTip("§e" . $time . "\n§7Practice Mode - §aResistance");
                } else {
                    $this->sendBotMatchHud($p1, $bot, $match);
                }
            }
        }

        if ($match["matchTime"] >= 300 && $match["mode"] !== "resistance" && $match["mode"] !== "boxing") {
            $this->handleTimeout($arenaName, $match);
            return;
        }

        $this->plugin->setActiveMatch($arenaName, $match);
    }

    private function sendMatchHud(Player $player, Player $opponent, $match) {
        $time = $this->formatTime($match["matchTime"]);
        $oppHp = round($opponent->getHealth(), 1);
        $oppMaxHp = $opponent->getMaxHealth();
        $bar = $this->buildHealthBar($oppHp, $oppMaxHp);
        $player->sendTip(
            "§e" . $time .
            "\n§c" . $opponent->getName() . " " . $bar . " §a" . $oppHp
        );
    }

    private function sendBotMatchHud($player, $bot, $match) {
        $time = $this->formatTime($match["matchTime"]);
        $botHp = round($bot->getHealth(), 1);
        $botMaxHp = $bot->getMaxHealth();
        $bar = $this->buildHealthBar($botHp, $botMaxHp);
        $player->sendTip(
            "§e" . $time .
            "\n§cBot " . $bar . " §a" . $botHp
        );
    }

    private function buildHealthBar($hp, $maxHp) {
        $bars = 10;
        $filled = max(0, (int)round(($hp / $maxHp) * $bars));
        $empty = $bars - $filled;

        $bar = "§a";
        if ($filled <= 3) {
            $bar = "§c";
        } elseif ($filled <= 6) {
            $bar = "§e";
        }

        return $bar . str_repeat("|", $filled) . "§7" . str_repeat("|", $empty);
    }

    private function formatTime($seconds) {
        $min = floor($seconds / 60);
        $sec = $seconds % 60;
        $minStr = ($min < 10) ? "0" . $min : "" . $min;
        $secStr = ($sec < 10) ? "0" . $sec : "" . $sec;
        return $minStr . ":" . $secStr;
    }

    private function handleTimeout($arenaName, $match) {
        $p1 = $this->plugin->getServer()->getPlayer($match["player1"]);

        if ($match["player2"] !== null) {
            $p2 = $this->plugin->getServer()->getPlayer($match["player2"]);

            if ($p1 !== null && $p2 !== null) {
                $p1Hp = $p1->getHealth();
                $p2Hp = $p2->getHealth();

                if ($p1Hp > $p2Hp) {
                    $this->plugin->endMatch($arenaName, $match["player1"]);
                } elseif ($p2Hp > $p1Hp) {
                    $this->plugin->endMatch($arenaName, $match["player2"]);
                } else {
                    $this->plugin->endMatch($arenaName, null, true);
                    if ($p1 !== null) $p1->sendMessage("§eDraw! Time ran out");
                    if ($p2 !== null) $p2->sendMessage("§eDraw! Time ran out");
                }
            } else {
                $this->plugin->endMatch($arenaName, null, true);
            }
        } else {
            if ($p1 !== null) {
                $instanceName = $match["instance"];
                $level = $this->plugin->getServer()->getLevelByName($instanceName);
                $bot = (isset($match["botEntity"]) && $level !== null) ? $level->getEntity($match["botEntity"]) : null;

                if ($bot !== null && !$bot->closed) {
                    $p1Hp = $p1->getHealth();
                    $botHp = $bot->getHealth();

                    if ($p1Hp > $botHp) {
                        $this->plugin->endMatch($arenaName, $match["player1"]);
                    } elseif ($botHp > $p1Hp) {
                        $this->plugin->endMatch($arenaName, "bot");
                    } else {
                        $this->plugin->endMatch($arenaName, null, true);
                        $p1->sendMessage("§eDraw! Time ran out");
                    }
                } else {
                    $this->plugin->endMatch($arenaName, $match["player1"]);
                }
            } else {
                $this->plugin->endMatch($arenaName, null, true);
            }
        }
    }
}
