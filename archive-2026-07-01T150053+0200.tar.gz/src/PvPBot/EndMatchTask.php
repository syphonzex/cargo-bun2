<?php

namespace PvPBot;

use pocketmine\scheduler\PluginTask;

class EndMatchTask extends PluginTask {

    private $plugin;
    private $arenaName;
    private $winner;

    public function __construct(Main $plugin, $arenaName, $winner) {
        parent::__construct($plugin);
        $this->plugin = $plugin;
        $this->arenaName = $arenaName;
        $this->winner = $winner;
    }

    public function onRun($currentTick) {
        $matches = $this->plugin->getActiveMatches();

        if (!isset($matches[$this->arenaName])) return;

        $this->plugin->endMatch($this->arenaName, $this->winner);
    }
}