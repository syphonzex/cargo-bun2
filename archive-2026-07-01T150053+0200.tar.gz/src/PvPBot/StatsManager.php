<?php

namespace PvPBot;

use pocketmine\Player;
use pocketmine\utils\Config;

class StatsManager {

    private $plugin;
    private $stats = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->loadStats();
    }

    private function loadStats() {
        $path = $this->plugin->getDataFolder() . "stats.yml";
        if (file_exists($path)) {
            $config = new Config($path, Config::YAML);
            $this->stats = $config->getAll();
        }
    }

    private function saveStats() {
        $path = $this->plugin->getDataFolder() . "stats.yml";
        $config = new Config($path, Config::YAML);
        $config->setAll($this->stats);
        $config->save();
    }

    private function getPlayerStats($name) {
        if (!isset($this->stats[$name])) {
            $this->stats[$name] = [
                "bot" => [
                    "wins" => 0,
                    "losses" => 0,
                    "modes" => []
                ],
                "pvp" => [
                    "wins" => 0,
                    "losses" => 0,
                    "modes" => []
                ]
            ];
        }
        return $this->stats[$name];
    }

    public function addWin($name, $mode, $type) {
        $stats = $this->getPlayerStats($name);

        $stats[$type]["wins"]++;

        if (!isset($stats[$type]["modes"][$mode])) {
            $stats[$type]["modes"][$mode] = ["wins" => 0, "losses" => 0];
        }
        $stats[$type]["modes"][$mode]["wins"]++;

        $this->stats[$name] = $stats;
        $this->saveStats();
    }

    public function addLoss($name, $mode, $type) {
        $stats = $this->getPlayerStats($name);

        $stats[$type]["losses"]++;

        if (!isset($stats[$type]["modes"][$mode])) {
            $stats[$type]["modes"][$mode] = ["wins" => 0, "losses" => 0];
        }
        $stats[$type]["modes"][$mode]["losses"]++;

        $this->stats[$name] = $stats;
        $this->saveStats();
    }

    public function showStats(Player $player) {
        $name = $player->getName();
        $stats = $this->getPlayerStats($name);

        $botWins = $stats["bot"]["wins"];
        $botLosses = $stats["bot"]["losses"];
        $botTotal = $botWins + $botLosses;
        $botWinrate = $botTotal > 0 ? round(($botWins / $botTotal) * 100, 1) : 0;

        $pvpWins = $stats["pvp"]["wins"];
        $pvpLosses = $stats["pvp"]["losses"];
        $pvpTotal = $pvpWins + $pvpLosses;
        $pvpWinrate = $pvpTotal > 0 ? round(($pvpWins / $pvpTotal) * 100, 1) : 0;

        $player->sendMessage("§e========== Your Stats ==========");
        $player->sendMessage("§6Bot Matches:");
        $player->sendMessage("  §aWins: §f$botWins §7| §cLosses: §f$botLosses §7| §eWinrate: §f$botWinrate%");

        if (count($stats["bot"]["modes"]) > 0) {
            $player->sendMessage("  §7Modes:");
            foreach ($stats["bot"]["modes"] as $mode => $modeStats) {
                $player->sendMessage("    §f$mode: §a" . $modeStats["wins"] . "W §c" . $modeStats["losses"] . "L");
            }
        }

        $player->sendMessage("§6PvP Matches:");
        $player->sendMessage("  §aWins: §f$pvpWins §7| §cLosses: §f$pvpLosses §7| §eWinrate: §f$pvpWinrate%");

        if (count($stats["pvp"]["modes"]) > 0) {
            $player->sendMessage("  §7Modes:");
            foreach ($stats["pvp"]["modes"] as $mode => $modeStats) {
                $player->sendMessage("    §f$mode: §a" . $modeStats["wins"] . "W §c" . $modeStats["losses"] . "L");
            }
        }

        $player->sendMessage("§e================================");
    }

    public function getWins($name, $type = null) {
        $stats = $this->getPlayerStats($name);

        if ($type === null) {
            return $stats["bot"]["wins"] + $stats["pvp"]["wins"];
        }

        return $stats[$type]["wins"];
    }

    public function getLosses($name, $type = null) {
        $stats = $this->getPlayerStats($name);

        if ($type === null) {
            return $stats["bot"]["losses"] + $stats["pvp"]["losses"];
        }

        return $stats[$type]["losses"];
    }

    public function getWinrate($name, $type = null) {
        $wins = $this->getWins($name, $type);
        $losses = $this->getLosses($name, $type);
        $total = $wins + $losses;

        if ($total === 0) return 0;

        return round(($wins / $total) * 100, 1);
    }

    public function resetStats($name) {
        unset($this->stats[$name]);
        $this->saveStats();
    }

    public function resetAllStats() {
        $this->stats = [];
        $this->saveStats();
    }

    /**
     * Returns the full raw stats array keyed by player name.
     * Used by HologramManager to build leaderboard/stats lines.
     */
    public function getAllStats(): array {
        return $this->stats;
    }
}