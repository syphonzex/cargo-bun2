<?php

namespace PvPBot;

use pocketmine\Player;
use pocketmine\math\Vector3;

class ArenaManager {

    private $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function createArena(Player $player, $name) {
        $config = $this->plugin->getArenaConfig();

        if ($config->exists($name)) {
            $player->sendMessage("§cArena $name already exists");
            return;
        }

        $config->set($name, [
            "spawns" => [
                "player1" => null,
                "player2" => null,
                "bot" => null
            ]
        ]);
        $config->save();

        $player->sendMessage("§aArena $name created. Set spawns with /pvpbot setspawn $name <player1|player2|bot>");
        $player->sendMessage("§7Note: Spawn positions are used as offsets from the template world origin.");
    }

    public function setSpawn(Player $player, $arenaName, $type) {
        $config = $this->plugin->getArenaConfig();

        if (!$config->exists($arenaName)) {
            $player->sendMessage("§cArena $arenaName does not exist");
            return;
        }

        $type = strtolower($type);
        if (!in_array($type, ["player1", "player2", "bot"])) {
            $player->sendMessage("§cInvalid type. Use: player1, player2, bot");
            return;
        }

        $arena = $config->get($arenaName);
        $arena["spawns"][$type] = [
            "x" => $player->x,
            "y" => $player->y,
            "z" => $player->z
        ];

        $config->set($arenaName, $arena);
        $config->save();

        $player->sendMessage("§aSpawn $type set for arena $arenaName at " . round($player->x, 1) . " " . round($player->y, 1) . " " . round($player->z, 1));
    }

    public function setLobby(Player $player) {
        $config = $this->plugin->getMainConfig();

        $config->set("lobby", [
            "x" => $player->x,
            "y" => $player->y,
            "z" => $player->z,
            "level" => $player->getLevel()->getName()
        ]);
        $config->save();

        $player->sendMessage("§aLobby location set");
    }

    public function deleteArena(Player $player, $name) {
        $config = $this->plugin->getArenaConfig();

        if (!$config->exists($name)) {
            $player->sendMessage("§cArena $name does not exist");
            return;
        }

        $config->remove($name);
        $config->save();

        $player->sendMessage("§aArena $name deleted");
    }

    public function listArenas(Player $player) {
        $config = $this->plugin->getArenaConfig();
        $arenas = $config->getAll();

        if (count($arenas) === 0) {
            $player->sendMessage("§eNo arenas created yet");
            return;
        }

        $player->sendMessage("§e=== Arenas ===");
        foreach ($arenas as $name => $data) {
            $p1 = $data["spawns"]["player1"] !== null ? "§a" : "§c";
            $p2 = $data["spawns"]["player2"] !== null ? "§a" : "§c";
            $bot = $data["spawns"]["bot"] !== null ? "§a" : "§c";
            $player->sendMessage("§7- §f$name §7| P1:$p1* §7P2:$p2* §7Bot:$bot*");
        }
    }

    public function getArenaConfig($arenaName) {
        return $this->plugin->getArenaConfig()->get($arenaName, null);
    }

    public function isArenaReady($name) {
        $config = $this->plugin->getArenaConfig();
        if (!$config->exists($name)) return false;
        $arena = $config->get($name);
        if ($arena["spawns"]["player1"] === null) return false;
        if ($arena["spawns"]["player2"] === null) return false;
        if ($arena["spawns"]["bot"] === null) return false;
        return true;
    }

    public function getAnyReadyArena() {
        $config = $this->plugin->getArenaConfig();
        $arenas = $config->getAll();
        foreach ($arenas as $name => $data) {
            if ($this->isArenaReady($name)) {
                return $name;
            }
        }
        return null;
    }

    public function countActiveInstances() {
        return count($this->plugin->getActiveMatches());
    }
}
