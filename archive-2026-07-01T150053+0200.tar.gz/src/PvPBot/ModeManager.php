<?php

namespace PvPBot;

use pocketmine\Player;
use pocketmine\item\Item;

class ModeManager {

    private $plugin;
    private $modes = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->registerModes();
    }

    private function registerModes() {
        $this->modes["gapplepvp"] = [
            "name" => "Gapple PvP",
            "armor" => [
                "helmet" => [Item::DIAMOND_HELMET, 0],
                "chestplate" => [Item::DIAMOND_CHESTPLATE, 0],
                "leggings" => [Item::DIAMOND_LEGGINGS, 0],
                "boots" => [Item::DIAMOND_BOOTS, 0]
            ],
            "items" => [
                [Item::DIAMOND_SWORD, 0, 1],
                [Item::GOLDEN_APPLE, 0, 16],
                [Item::STEAK, 0, 64]
            ],
            "botHand" => Item::DIAMOND_SWORD
        ];

$this->modes["builduhc"] = [
    "name" => "Build UHC",
    "armor" => [
        "helmet" => [Item::IRON_HELMET, 0],
        "chestplate" => [Item::IRON_CHESTPLATE, 0],
        "leggings" => [Item::IRON_LEGGINGS, 0],
        "boots" => [Item::IRON_BOOTS, 0]
    ],
    "items" => [
        [Item::IRON_SWORD, 0, 1],
        [Item::IRON_PICKAXE, 0, 1],
        [Item::BOW, 0, 1],
        [Item::ARROW, 0, 16],
        [Item::GOLDEN_APPLE, 0, 6],
        [Item::COBBLESTONE, 0, 64],
        [Item::COBBLESTONE, 0, 64],
        [Item::STEAK, 0, 64]
    ],
    "botHand" => Item::IRON_SWORD
];

        $this->modes["classic"] = [
            "name" => "Classic",
            "armor" => [
                "helmet" => [Item::IRON_HELMET, 0],
                "chestplate" => [Item::IRON_CHESTPLATE, 0],
                "leggings" => [Item::IRON_LEGGINGS, 0],
                "boots" => [Item::IRON_BOOTS, 0]
            ],
            "items" => [
                [Item::IRON_SWORD, 0, 1],
                [Item::STEAK, 0, 64]
            ],
            "botHand" => Item::IRON_SWORD
        ];

        $this->modes["boxing"] = [
            "name" => "Boxing",
            "armor" => [
                "helmet" => [Item::AIR, 0],
                "chestplate" => [Item::AIR, 0],
                "leggings" => [Item::AIR, 0],
                "boots" => [Item::AIR, 0]
            ],
            "items" => [
                [Item::STEAK, 0, 1]
            ],
            "botHand" => Item::STEAK
        ];

        $this->modes["resistance"] = [
            "name" => "Resistance",
            "armor" => [
                "helmet" => [Item::AIR, 0],
                "chestplate" => [Item::AIR, 0],
                "leggings" => [Item::AIR, 0],
                "boots" => [Item::AIR, 0]
            ],
            "items" => [
                [Item::STEAK, 0, 64]
            ],
            "botHand" => Item::STEAK
        ];
    }

    public function getModes() {
        return $this->modes;
    }

    public function getModeNames() {
        $names = [];
        foreach ($this->modes as $id => $data) {
            $names[$id] = $data["name"];
        }
        return $names;
    }

    public function modeExists($mode) {
        return isset($this->modes[$mode]);
    }

    public function applyKit(Player $player, $mode) {
        if (!isset($this->modes[$mode])) {
            $mode = "gapplepvp";
        }

        $kit = $this->modes[$mode];
        $inv = $player->getInventory();

        $inv->clearAll();
        $player->setHealth($player->getMaxHealth());
        $player->setFood(20);
        $player->removeAllEffects();

        $armor = $kit["armor"];
        $inv->setHelmet(Item::get($armor["helmet"][0], $armor["helmet"][1]));
        $inv->setChestplate(Item::get($armor["chestplate"][0], $armor["chestplate"][1]));
        $inv->setLeggings(Item::get($armor["leggings"][0], $armor["leggings"][1]));
        $inv->setBoots(Item::get($armor["boots"][0], $armor["boots"][1]));

        $slot = 0;
        foreach ($kit["items"] as $itemData) {
            $item = Item::get($itemData[0], $itemData[1], $itemData[2]);
            $inv->setItem($slot, $item);
            $slot++;
        }

        $inv->setHeldItemIndex(0);

        if ($mode === "resistance") {
            $quit = Item::get(Item::REDSTONE, 0, 1);
            $quit->setCustomName("§cQuit");
            $inv->setItem(8, $quit);
        }
    }

public function applyBotKit(PvPBotEntity $bot, $mode) {
    if (!isset($this->modes[$mode])) {
        $mode = "gapplepvp";
    }

    $kit = $this->modes[$mode];
    $inv = $bot->getInventory();

    if ($inv === null) {
        return;
    }

    $inv->clearAll();

    $armor = $kit["armor"];
    $inv->setHelmet(Item::get($armor["helmet"][0], $armor["helmet"][1]));
    $inv->setChestplate(Item::get($armor["chestplate"][0], $armor["chestplate"][1]));
    $inv->setLeggings(Item::get($armor["leggings"][0], $armor["leggings"][1]));
    $inv->setBoots(Item::get($armor["boots"][0], $armor["boots"][1]));

    $handItem = isset($kit["botHand"]) ? $kit["botHand"] : Item::DIAMOND_SWORD;
    $swordItem = Item::get($handItem, 0, 1);
    $inv->setItemInHand($swordItem);
    $bot->setSwordItem($swordItem);
    $bot->setPickaxeItem(Item::get(Item::IRON_PICKAXE, 0, 1));

    $bot->setGappleCount($this->getGappleCount($mode));
    $bot->setArrowCount($this->getArrowCount($mode));
    $bot->setBlockCount($this->getBlockCount($mode));
    $bot->calculateArmorPoints();
}

    public function getGappleCount($mode) {
        if (!isset($this->modes[$mode])) return 0;

        $kit = $this->modes[$mode];
        $count = 0;

        foreach ($kit["items"] as $itemData) {
            if ($itemData[0] === Item::GOLDEN_APPLE) {
                $count += $itemData[2];
            }
        }

        return $count;
    }

    public function getArrowCount($mode) {
        if (!isset($this->modes[$mode])) return 0;

        $kit = $this->modes[$mode];
        $count = 0;

        foreach ($kit["items"] as $itemData) {
            if ($itemData[0] === Item::ARROW) {
                $count += $itemData[2];
            }
        }

        return $count;
    }

    public function getBlockCount($mode) {
        if ($mode === "builduhc") {
            return 128;
        }
        return 0;
    }

    public function canBuild($mode) {
        return $mode === "builduhc";
    }

    public function getModeDamageMultiplier($mode) {
        return 1.0;
    }
}