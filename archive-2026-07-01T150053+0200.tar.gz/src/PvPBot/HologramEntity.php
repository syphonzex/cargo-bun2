<?php

namespace PvPBot;

use pocketmine\entity\Human;
use pocketmine\entity\Entity;
use pocketmine\network\protocol\AddPlayerPacket;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;

class HologramEntity extends Human {

    private $displayText = "";

    public function onUpdate($currentTick) {
        if ($this->closed) return false;
        return parent::onUpdate($currentTick);
    }

    public function setDisplayText($text) {
        $this->displayText = $text;
        $this->setDataProperty(Entity::DATA_NAMETAG, Entity::DATA_TYPE_STRING, $text);
    }

    public function getDisplayText() {
        return $this->displayText;
    }

    public function attack($damage, EntityDamageEvent $source) {
        $source->setCancelled(true);

        if (!($source instanceof EntityDamageByEntityEvent)) return;

        $damager = $source->getDamager();
        if (!($damager instanceof Player)) return;

        /** @var Main $plugin */
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("PvPBot");
        if ($plugin === null) return;

        $heldItem = $damager->getInventory()->getItemInHand();

        if ($heldItem->getId() === Item::BONE) {
            $removed = $plugin->getHologramManager()->removeNearest($damager->getPosition(), 8.0);
            if ($removed) {
                $damager->sendMessage("§a[Holograms] §fHologram removed.");
            }
        } else {
            $plugin->getHologramManager()->handleHologramHit($this->getId(), $damager);
        }
    }

    public function spawnTo(Player $player) {
        if (!isset($this->hasSpawned[$player->getLoaderId()])) {
            $this->hasSpawned[$player->getLoaderId()] = $player;

            $pk           = new AddPlayerPacket();
            $pk->uuid     = $this->getUniqueId();
            $pk->username = "";
            $pk->eid      = $this->getId();
            $pk->x        = $this->x;
            $pk->y        = $this->y;
            $pk->z        = $this->z;
            $pk->yaw      = $this->yaw;
            $pk->pitch    = $this->pitch;
            $pk->item     = Item::get(Item::AIR);
            $pk->metadata = [
                Entity::DATA_FLAGS        => [Entity::DATA_TYPE_BYTE, 1 << Entity::DATA_FLAG_INVISIBLE],
                Entity::DATA_NAMETAG      => [Entity::DATA_TYPE_STRING, $this->displayText],
                Entity::DATA_SHOW_NAMETAG => [Entity::DATA_TYPE_BYTE, 1],
                Entity::DATA_NO_AI        => [Entity::DATA_TYPE_BYTE, 1],
                Entity::DATA_LEAD_HOLDER  => [Entity::DATA_TYPE_LONG, -1],
                Entity::DATA_LEAD         => [Entity::DATA_TYPE_BYTE, 0],
            ];

            $player->dataPacket($pk);
            $this->inventory->sendArmorContents($player);
        }
    }

    public function getName() {
        return "Hologram";
    }
}