<?php

namespace PvPBot;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;
use pocketmine\utils\Config;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\level\sound\ClickSound;
use pocketmine\network\protocol\SetEntityDataPacket;

class HologramManager {

    private $plugin;
    private $leaderboards = [];
    private $statsHolos   = [];
    private $hologramConfig;
    private $tickCounter  = 0;
    public $hitCooldowns = [];
    private $playerHoloModes = [];

    const LINE_GAP      = 0.28;
    const TOP_PLAYERS   = 5;
    const REFRESH_TICKS = 200;

    const C_TITLE   = "§b§l";
    const C_DIVIDER = "§f";
    const C_GOLD    = "§6§l";
    const C_LABEL   = "§7";
    const C_VALUE   = "§a";
    const C_NAME    = "§f";
    const C_RANK    = "§e";

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->hologramConfig = new Config(
            $plugin->getDataFolder() . "holograms.yml",
            Config::YAML
        );
    }

    public function spawnLeaderboard(Position $pos, $mode = "bot") {
        $id = "lb_" . uniqid();
        $this->leaderboards[$id] = [
            "type"     => "leaderboard",
            "mode"     => $mode,
            "entities" => [],
            "x"        => $pos->x,
            "y"        => $pos->y,
            "z"        => $pos->z,
            "level"    => $pos->getLevel()->getName(),
        ];
        $this->buildLeaderboardLines($id);
        $this->saveHologramConfig();
        return $id;
    }

    public function spawnStatsHolo(Position $pos, $mode = "bot") {
        $id = "st_" . uniqid();
        $this->statsHolos[$id] = [
            "type"     => "stats",
            "mode"     => $mode,
            "entities" => [],
            "x"        => $pos->x,
            "y"        => $pos->y,
            "z"        => $pos->z,
            "level"    => $pos->getLevel()->getName(),
        ];
        $this->buildStatsLines($id);
        $this->saveHologramConfig();
        return $id;
    }

    public function removeHologram($id) {
        if (isset($this->leaderboards[$id])) {
            $this->destroyLines($this->leaderboards[$id]["entities"]);
            unset($this->leaderboards[$id]);
            unset($this->playerHoloModes[$id]);
            $this->saveHologramConfig();
            return true;
        }
        if (isset($this->statsHolos[$id])) {
            $this->destroyLines($this->statsHolos[$id]["entities"]);
            unset($this->statsHolos[$id]);
            unset($this->playerHoloModes[$id]);
            $this->saveHologramConfig();
            return true;
        }
        return false;
    }

    public function removeNearest(Position $pos, $maxDist = 5.0) {
        $bestId   = null;
        $bestDist = $maxDist;

        $all = array_merge($this->leaderboards, $this->statsHolos);
        foreach ($all as $id => $data) {
            if ($data["level"] !== $pos->getLevel()->getName()) continue;
            $dist = sqrt(
                ($data["x"] - $pos->x) ** 2 +
                ($data["z"] - $pos->z) ** 2
            );
            if ($dist < $bestDist) {
                $bestDist = $dist;
                $bestId   = $id;
            }
        }

        if ($bestId !== null) {
            return $this->removeHologram($bestId);
        }
        return false;
    }

    public function handleHologramHit($entityId, Player $hitter) {
        $playerName = $hitter->getName();

        foreach ($this->leaderboards as $id => &$data) {
            foreach ($data["entities"] as $holo) {
                if (!$holo->closed && $holo->getId() === $entityId) {
                    $cooldownKey = $id . "_" . $playerName;
                    if (isset($this->hitCooldowns[$cooldownKey])) return true;
                    $this->hitCooldowns[$cooldownKey] = true;

                    $currentMode = isset($this->playerHoloModes[$id][$playerName])
                        ? $this->playerHoloModes[$id][$playerName]
                        : $data["mode"];
                    $newMode = ($currentMode === "bot") ? "pvp" : "bot";

                    if (!isset($this->playerHoloModes[$id])) {
                        $this->playerHoloModes[$id] = [];
                    }
                    $this->playerHoloModes[$id][$playerName] = $newMode;

                    $lines = $this->getLeaderboardLines($newMode);
                    $this->sendPersonalView($hitter, $data["entities"], $lines);
                    $hitter->getLevel()->addSound(new ClickSound($hitter), [$hitter]);

                    $mgr = $this;
                    $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
                        new class($mgr, $cooldownKey) extends \pocketmine\scheduler\PluginTask {
                            private $mgr;
                            private $key;
                            public function __construct($mgr, $key) {
                                parent::__construct(\pocketmine\Server::getInstance()->getPluginManager()->getPlugin("PvPBot"));
                                $this->mgr = $mgr;
                                $this->key = $key;
                            }
                            public function onRun($tick) {
                                unset($this->mgr->hitCooldowns[$this->key]);
                            }
                        }, 20
                    );
                    return true;
                }
            }
        }

        foreach ($this->statsHolos as $id => &$data) {
            foreach ($data["entities"] as $holo) {
                if (!$holo->closed && $holo->getId() === $entityId) {
                    $cooldownKey = $id . "_" . $playerName;
                    if (isset($this->hitCooldowns[$cooldownKey])) return true;
                    $this->hitCooldowns[$cooldownKey] = true;

                    $currentMode = isset($this->playerHoloModes[$id][$playerName])
                        ? $this->playerHoloModes[$id][$playerName]
                        : $data["mode"];
                    $newMode = ($currentMode === "bot") ? "pvp" : "bot";

                    if (!isset($this->playerHoloModes[$id])) {
                        $this->playerHoloModes[$id] = [];
                    }
                    $this->playerHoloModes[$id][$playerName] = $newMode;

                    $lines = $this->getStatsLines($newMode, $playerName);
                    $this->sendPersonalView($hitter, $data["entities"], $lines);
                    $hitter->getLevel()->addSound(new ClickSound($hitter), [$hitter]);

                    $mgr = $this;
                    $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
                        new class($mgr, $cooldownKey) extends \pocketmine\scheduler\PluginTask {
                            private $mgr;
                            private $key;
                            public function __construct($mgr, $key) {
                                parent::__construct(\pocketmine\Server::getInstance()->getPluginManager()->getPlugin("PvPBot"));
                                $this->mgr = $mgr;
                                $this->key = $key;
                            }
                            public function onRun($tick) {
                                unset($this->mgr->hitCooldowns[$this->key]);
                            }
                        }, 20
                    );
                    return true;
                }
            }
        }

        return false;
    }

    private function sendPersonalView(Player $player, array $entities, array $lines) {
        foreach ($entities as $i => $holo) {
            if ($holo->closed) continue;
            $text = isset($lines[$i]) ? $lines[$i] : " ";
            $pk = new SetEntityDataPacket();
            $pk->eid = $holo->getId();
            $pk->metadata = [
                Entity::DATA_NAMETAG => [Entity::DATA_TYPE_STRING, $text]
            ];
            $player->dataPacket($pk);
        }
    }

    public function onTick() {
        $this->tickCounter++;
        if ($this->tickCounter < self::REFRESH_TICKS) return;
        $this->tickCounter = 0;
        foreach (array_keys($this->leaderboards) as $id) {
            $this->refreshLeaderboard($id);
        }
    }

    public function refreshLeaderboard($id) {
        if (!isset($this->leaderboards[$id])) return;
        $this->buildLeaderboardLines($id);
        $this->reapplyPersonalViews($id, "leaderboard");
    }

    private function reapplyPersonalViews($id, $type) {
        if (!isset($this->playerHoloModes[$id])) return;
        $data = $type === "leaderboard"
            ? (isset($this->leaderboards[$id]) ? $this->leaderboards[$id] : null)
            : (isset($this->statsHolos[$id]) ? $this->statsHolos[$id] : null);
        if ($data === null) return;

        foreach ($this->playerHoloModes[$id] as $playerName => $mode) {
            $player = $this->plugin->getServer()->getPlayer($playerName);
            if ($player === null || !$player->isOnline()) continue;
            if ($type === "leaderboard") {
                $lines = $this->getLeaderboardLines($mode);
            } else {
                $lines = $this->getStatsLines($mode, $playerName);
            }
            $this->sendPersonalView($player, $data["entities"], $lines);
        }
    }

    public function loadFromConfig() {
        $data = $this->hologramConfig->getAll();

        foreach ((isset($data["leaderboards"]) ? $data["leaderboards"] : []) as $id => $info) {
            $level = Server::getInstance()->getLevelByName($info["level"]);
            if ($level === null) continue;
            $this->leaderboards[$id] = [
                "type"     => "leaderboard",
                "mode"     => isset($info["mode"]) ? $info["mode"] : "bot",
                "entities" => [],
                "x"        => $info["x"],
                "y"        => $info["y"],
                "z"        => $info["z"],
                "level"    => $info["level"],
            ];
            $this->buildLeaderboardLines($id);
        }

        foreach ((isset($data["stats"]) ? $data["stats"] : []) as $id => $info) {
            $level = Server::getInstance()->getLevelByName($info["level"]);
            if ($level === null) continue;
            $this->statsHolos[$id] = [
                "type"     => "stats",
                "mode"     => isset($info["mode"]) ? $info["mode"] : "bot",
                "entities" => [],
                "x"        => $info["x"],
                "y"        => $info["y"],
                "z"        => $info["z"],
                "level"    => $info["level"],
            ];
            $this->buildStatsLines($id);
        }
    }

    public function closeAll() {
        foreach ($this->leaderboards as $data) {
            $this->destroyLines($data["entities"]);
        }
        foreach ($this->statsHolos as $data) {
            $this->destroyLines($data["entities"]);
        }
    }

    private function buildLeaderboardLines($id) {
        $data  = &$this->leaderboards[$id];
        $level = Server::getInstance()->getLevelByName($data["level"]);
        if ($level === null) return;
        $lines = $this->getLeaderboardLines($data["mode"]);
        $this->rebuildEntities($data, $lines, $level);
    }

    private function buildStatsLines($id) {
        $data  = &$this->statsHolos[$id];
        $level = Server::getInstance()->getLevelByName($data["level"]);
        if ($level === null) return;
        $lines = $this->getStatsLines($data["mode"], null);
        $this->rebuildEntities($data, $lines, $level);
    }

    private function rebuildEntities(&$data, $lines, Level $level) {
        $this->destroyLines($data["entities"]);
        $data["entities"] = [];

        $baseY = $data["y"] + (count($lines) - 1) * self::LINE_GAP;

        foreach ($lines as $i => $text) {
            $y    = $baseY - $i * self::LINE_GAP;
            $holo = $this->spawnLine($level, new Vector3($data["x"], $y, $data["z"]), $text);
            if ($holo !== null) {
                $data["entities"][] = $holo;
            }
        }
    }

    private function spawnLine(Level $level, Vector3 $pos, $text) {
        $chunk = $level->getChunk((int)($pos->x) >> 4, (int)($pos->z) >> 4, true);
        if ($chunk === null) return null;

        $nbt = new CompoundTag("", [
            new ListTag("Pos", [
                new DoubleTag("", $pos->x),
                new DoubleTag("", $pos->y),
                new DoubleTag("", $pos->z),
            ]),
            new ListTag("Motion", [
                new DoubleTag("", 0),
                new DoubleTag("", 0),
                new DoubleTag("", 0),
            ]),
            new ListTag("Rotation", [
                new FloatTag("", 0),
                new FloatTag("", 0),
            ]),
        ]);

        $holo = new HologramEntity($chunk, $nbt);
        $holo->setDisplayText($text);
        $holo->spawnToAll();
        return $holo;
    }

    private function destroyLines($entities) {
        foreach ($entities as $holo) {
            if ($holo instanceof HologramEntity && !$holo->closed) {
                $holo->close();
            }
        }
    }

    private function getLeaderboardLines($mode) {
        $modeLabel  = strtoupper($mode);
        $otherMode  = ($mode === "bot") ? "pvp" : "bot";
        $otherLabel = strtoupper($otherMode);
        $sm         = $this->plugin->getStatsManager();
        $statsAll   = $sm->getAllStats();

        $ranking = [];
        foreach ($statsAll as $playerName => $pStats) {
            $wins   = isset($pStats[$mode]["wins"])   ? $pStats[$mode]["wins"]   : 0;
            $losses = isset($pStats[$mode]["losses"]) ? $pStats[$mode]["losses"] : 0;
            $total  = $wins + $losses;
            $wr     = $total > 0 ? round(($wins / $total) * 100, 1) : 0.0;
            $ranking[] = [
                "name"   => $playerName,
                "wins"   => $wins,
                "losses" => $losses,
                "wr"     => $wr,
            ];
        }

        usort($ranking, function ($a, $b) {
            if ($b["wins"] !== $a["wins"]) return $b["wins"] - $a["wins"];
            return $b["wr"] > $a["wr"] ? 1 : ($b["wr"] < $a["wr"] ? -1 : 0);
        });

        $lines   = [];
        $lines[] = self::C_TITLE . "* " . $modeLabel . " LEADERBOARD *";
        $lines[] = self::C_DIVIDER . "--------------------";
        $lines[] = self::C_LABEL . "Hit to switch -> §e" . $otherLabel;
        $lines[] = self::C_DIVIDER . "--------------------";

        $shown = array_slice($ranking, 0, self::TOP_PLAYERS);
        if (empty($shown)) {
            $lines[] = self::C_LABEL . "  No data yet.";
        } else {
            foreach ($shown as $i => $entry) {
                $rank    = $i + 1;
                $medal   = $this->getMedal($rank);
                $lines[] = $medal . " §r" . self::C_NAME . $entry["name"]
                    . self::C_LABEL . " | " . self::C_VALUE . $entry["wins"] . "W"
                    . self::C_LABEL . " (" . $entry["wr"] . "%)";
            }
        }

        $lines[] = self::C_DIVIDER . "--------------------";
        $lines[] = self::C_LABEL . "Top " . self::TOP_PLAYERS . " players";
        return $lines;
    }

    private function getStatsLines($mode, $playerName = null) {
        $modeLabel  = strtoupper($mode);
        $otherMode  = ($mode === "bot") ? "pvp" : "bot";
        $otherLabel = strtoupper($otherMode);
        $allModeKeys = array_keys($this->plugin->getModeManager()->getModes());
        $modeCount   = max(count($allModeKeys), 1);
        $totalLines  = 4 + 1 + 1 + 3 + 1 + $modeCount + 1;

        $lines   = [];
        $lines[] = self::C_TITLE . "* " . $modeLabel . " STATS *";
        $lines[] = self::C_DIVIDER . "--------------------";
        $lines[] = self::C_LABEL . "Hit to switch -> §e" . $otherLabel;
        $lines[] = self::C_DIVIDER . "--------------------";

        if ($playerName === null) {
            $lines[] = self::C_LABEL . "  Hit to view your stats!";
            while (count($lines) < $totalLines) {
                $lines[] = " ";
            }
            return $lines;
        }

        $sm       = $this->plugin->getStatsManager();
        $statsAll = $sm->getAllStats();
        $pStats   = isset($statsAll[$playerName]) ? $statsAll[$playerName] : null;

        $lines[] = self::C_GOLD . $playerName;
        $lines[] = self::C_DIVIDER . "--------------------";

        if ($pStats === null) {
            $lines[] = self::C_LABEL . "  No stats yet.";
            $lines[] = " ";
            $lines[] = " ";
            $lines[] = self::C_DIVIDER . "  -- By Mode --";
            foreach ($allModeKeys as $mk) {
                $lines[] = self::C_LABEL . "  " . ucfirst($mk) . ": §a0W §c0L";
            }
        } else {
            $wins   = isset($pStats[$mode]["wins"])   ? $pStats[$mode]["wins"]   : 0;
            $losses = isset($pStats[$mode]["losses"]) ? $pStats[$mode]["losses"] : 0;
            $total  = $wins + $losses;
            $wr     = $total > 0 ? round(($wins / $total) * 100, 1) : 0.0;

            $lines[] = "  §aWins:   §f" . $wins;
            $lines[] = "  §cLosses: §f" . $losses;
            $lines[] = "  §eWinrate: §f" . $wr . "%";
            $lines[] = self::C_DIVIDER . "  -- By Mode --";

            $modeStats = isset($pStats[$mode]["modes"]) ? $pStats[$mode]["modes"] : [];
            foreach ($allModeKeys as $mk) {
                $mW = isset($modeStats[$mk]["wins"])   ? $modeStats[$mk]["wins"]   : 0;
                $mL = isset($modeStats[$mk]["losses"]) ? $modeStats[$mk]["losses"] : 0;
                $lines[] = self::C_LABEL . "  " . ucfirst($mk) . ": §a" . $mW . "W §c" . $mL . "L";
            }
        }

        $lines[] = self::C_DIVIDER . "--------------------";

        while (count($lines) < $totalLines) {
            $lines[] = " ";
        }

        return $lines;
    }

    private function getMedal($rank) {
        if ($rank === 1) return "§a§l#1";
        if ($rank === 2) return "§c§l#2";
        if ($rank === 3) return "§6§l#3";
        return self::C_RANK . "#" . $rank;
    }

    private function saveHologramConfig() {
        $lbs = [];
        foreach ($this->leaderboards as $id => $data) {
            $lbs[$id] = [
                "mode"  => $data["mode"],
                "x"     => $data["x"],
                "y"     => $data["y"],
                "z"     => $data["z"],
                "level" => $data["level"],
            ];
        }
        $sts = [];
        foreach ($this->statsHolos as $id => $data) {
            $sts[$id] = [
                "mode"  => $data["mode"],
                "x"     => $data["x"],
                "y"     => $data["y"],
                "z"     => $data["z"],
                "level" => $data["level"],
            ];
        }
        $this->hologramConfig->setAll([
            "leaderboards" => $lbs,
            "stats"        => $sts,
        ]);
        $this->hologramConfig->save();
    }

    public function getLeaderboards() { return $this->leaderboards; }
    public function getStatsHolos()   { return $this->statsHolos; }
}
