<?php

namespace PvPBot;

use pocketmine\scheduler\PluginTask;

class PrepareMatchTask extends PluginTask {

    private $plugin;
    private $playerName;
    private $opponentName;
    private $isBot;
    private $mode;
    private $type;
    private $countdown;
    private $done = false;

    public function __construct(Main $plugin, $playerName, $opponentName, $isBot, $mode, $type) {
        parent::__construct($plugin);
        $this->plugin = $plugin;
        $this->playerName = $playerName;
        $this->opponentName = $opponentName;
        $this->isBot = $isBot;
        $this->mode = $mode;
        $this->type = $type;
        $this->countdown = 3;
    }

    public function onRun($currentTick) {
        if ($this->done) return;

        $p1 = $this->plugin->getServer()->getPlayer($this->playerName);
        if ($p1 === null || !$p1->isOnline()) {
            $this->done = true;
            return;
        }

        if (!$this->isBot && $this->opponentName !== null) {
            $p2 = $this->plugin->getServer()->getPlayer($this->opponentName);
            if ($p2 === null || !$p2->isOnline()) {
                $p1->sendMessage("§cOpponent disconnected. Match cancelled.");
                $this->done = true;
                return;
            }
        }

        if ($this->countdown > 0) {
            $p1->sendTip("§ePreparing arena... §f" . $this->countdown);
            if (!$this->isBot && $this->opponentName !== null) {
                $p2 = $this->plugin->getServer()->getPlayer($this->opponentName);
                if ($p2 !== null) {
                    $p2->sendTip("§ePreparing arena... §f" . $this->countdown);
                }
            }
            $this->countdown--;
            return;
        }

        $this->done = true;

        $templateWorld = $this->plugin->getMainConfig()->get("template-world", "world");
        $worldManager = $this->plugin->getWorldManager();

        $instanceName = $worldManager->createInstance($templateWorld, $this->mode, $this->type);
        if ($instanceName === null) {
            $p1->sendMessage("§cFailed to create arena instance. Template world not found.");
            if (!$this->isBot && $this->opponentName !== null) {
                $p2 = $this->plugin->getServer()->getPlayer($this->opponentName);
                if ($p2 !== null) {
                    $p2->sendMessage("§cFailed to create arena instance.");
                }
            }
            return;
        }

        if (!$worldManager->loadInstance($instanceName)) {
            $p1->sendMessage("§cFailed to load arena instance.");
            $worldManager->forceUnloadAndDelete($instanceName);
            return;
        }

        $p2 = null;
        if (!$this->isBot && $this->opponentName !== null) {
            $p2 = $this->plugin->getServer()->getPlayer($this->opponentName);
        }

        $this->plugin->startMatch($instanceName, $p1, $p2, $this->isBot ? true : null);
    }
}