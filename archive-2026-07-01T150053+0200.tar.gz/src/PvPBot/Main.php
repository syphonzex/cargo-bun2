<?php

namespace PvPBot;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\entity\Effect;
use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\entity\Entity;
use pocketmine\block\Block;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\level\Position;

class Main extends PluginBase implements Listener {

    private $arenaConfig;
    private $playerConfig;
    private $config;

    private $arenaManager;
    private $queueManager;
    private $statsManager;
    private $modeManager;
    private $worldManager;
    private $hologramManager;

    private $placedBlocks = [];
    private $playerArena = [];
    private $playerSettings = [];
    private $activeMatches = [];
    private $playerLastPos = [];
    private $endingMatches = [];
    private $boxingHits = [];
    public $boxingHitCooldowns = [];

    public function onEnable() {
        $this->getServer()->getLogger()->info("§aPvPBot Enabled");
        @mkdir($this->getDataFolder());

        $this->saveDefaultConfig();
        $this->config = $this->getConfig();

        $this->arenaConfig = new Config($this->getDataFolder() . "arenas.yml", Config::YAML);
        $this->playerConfig = new Config($this->getDataFolder() . "players.yml", Config::YAML);

        Entity::registerEntity(PvPBotEntity::class, true);
        Entity::registerEntity(HologramEntity::class, true);

        $this->modeManager = new ModeManager($this);
        $this->worldManager = new WorldManager($this);
        $this->worldManager->cleanupInstanceWorlds();

        $this->arenaManager = new ArenaManager($this);
        $this->queueManager = new QueueManager($this);
        $this->statsManager = new StatsManager($this);
        $this->hologramManager = new HologramManager($this);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new MatchTask($this), 20);

        // Load persisted holograms one tick later so all levels are loaded
        $plugin = $this;
        $this->getServer()->getScheduler()->scheduleDelayedTask(
            new class($plugin) extends \pocketmine\scheduler\PluginTask {
                private $plugin;
                public function __construct($p) { parent::__construct($p); $this->plugin = $p; }
                public function onRun($tick) { $this->plugin->getHologramManager()->loadFromConfig(); }
            }, 20
        );
    }

    public function onDisable() {
        $this->arenaConfig->save();
        $this->playerConfig->save();
        if ($this->hologramManager !== null) {
            $this->hologramManager->closeAll();
        }

        foreach ($this->activeMatches as $arenaName => $match) {
            $this->endMatch($arenaName, null, true);
        }
    }

    public function getArenaConfig() {
        return $this->arenaConfig;
    }

    public function getPlayerConfig() {
        return $this->playerConfig;
    }

    public function getMainConfig() {
        return $this->config;
    }

    public function getArenaManager() {
        return $this->arenaManager;
    }

    public function getQueueManager() {
        return $this->queueManager;
    }

    public function getStatsManager() {
        return $this->statsManager;
    }

    public function getModeManager() {
        return $this->modeManager;
    }

    public function getWorldManager() {
        return $this->worldManager;
    }

    public function getHologramManager() {
        return $this->hologramManager;
    }

    public function getPlacedBlocks() {
        return $this->placedBlocks;
    }

    public function getPlayerArena() {
        return $this->playerArena;
    }

    public function getActiveMatches() {
        return $this->activeMatches;
    }

    public function setPlayerArena($player, $arena) {
        $this->playerArena[$player] = $arena;
    }

    public function removePlayerArena($player) {
        unset($this->playerArena[$player]);
    }

    public function setActiveMatch($arena, $data) {
        $this->activeMatches[$arena] = $data;
    }

    public function removeActiveMatch($arena) {
        unset($this->activeMatches[$arena]);
    }

    public function getBoxingHits($arenaName) {
        return isset($this->boxingHits[$arenaName]) ? $this->boxingHits[$arenaName] : ["player1" => 0, "player2" => 0];
    }

    private function canRegisterBoxingHit($arena, $playerName) {
        if (isset($this->boxingHitCooldowns[$arena][$playerName])) {
            return false;
        }
        $this->boxingHitCooldowns[$arena][$playerName] = true;
        $arenaRef = $arena;
        $nameRef = $playerName;
        $plugin = $this;
        $this->getServer()->getScheduler()->scheduleDelayedTask(new class($plugin, $arenaRef, $nameRef) extends \pocketmine\scheduler\PluginTask {
            private $plugin;
            private $arena;
            private $name;
            public function __construct($plugin, $arena, $name) {
                parent::__construct($plugin);
                $this->plugin = $plugin;
                $this->arena = $arena;
                $this->name = $name;
            }
            public function onRun($tick) {
                unset($this->plugin->boxingHitCooldowns[$this->arena][$this->name]);
            }
        }, 10);
        return true;
    }

    public function addPlacedBlock($arena, Vector3 $pos) {
        if (!isset($this->placedBlocks[$arena])) {
            $this->placedBlocks[$arena] = [];
        }
        $x = (int)floor($pos->x);
        $y = (int)floor($pos->y);
        $z = (int)floor($pos->z);
        $key = $x . ":" . $y . ":" . $z;
        $this->placedBlocks[$arena][$key] = new Vector3($x, $y, $z);
    }

    public function clearPlacedBlocks($arena) {
        unset($this->placedBlocks[$arena]);
    }

public function clearPlacedBlockAt($arena, $key) {
    if (isset($this->placedBlocks[$arena][$key])) {
        unset($this->placedBlocks[$arena][$key]);
    }
}

    public function getPlayerSettings($name) {
        if (isset($this->playerSettings[$name])) {
            return $this->playerSettings[$name];
        }

        $data = $this->playerConfig->get($name, null);

        if ($data === null) {
            $data = [
                "type" => "bot",
                "mode" => "gapplepvp",
                "difficulty" => "medium"
            ];
            $this->playerConfig->set($name, $data);
            $this->playerConfig->save();
        }

        $this->playerSettings[$name] = $data;
        return $data;
    }

    public function setPlayerSettings($name, $data) {
        $this->playerSettings[$name] = $data;
        $this->playerConfig->set($name, $data);
        $this->playerConfig->save();
    }

    public function saveLastPosition(Player $player) {
        $this->playerLastPos[$player->getName()] = [
            "x" => $player->x,
            "y" => $player->y,
            "z" => $player->z,
            "level" => $player->getLevel()->getName()
        ];
    }

    public function getLastPosition($name) {
        return isset($this->playerLastPos[$name]) ? $this->playerLastPos[$name] : null;
    }

    public function removeLastPosition($name) {
        unset($this->playerLastPos[$name]);
    }

    public function onCommand(CommandSender $sender, Command $cmd, $label, array $args) {
        if ($cmd->getName() !== "pvpbot") return false;

        if (!$sender instanceof Player) {
            $sender->sendMessage("Use this command in-game");
            return true;
        }

        if (count($args) < 1) {
            $this->sendHelp($sender);
            return true;
        }

        $sub = strtolower(array_shift($args));

        switch ($sub) {
            case "setup":
                if (!$sender->isOp()) {
                    $sender->sendMessage("§cNo permission");
                    return true;
                }
                if (count($args) < 1) {
                    $sender->sendMessage("§eUsage: /pvpbot setup <arenaName>");
                    return true;
                }
                $this->arenaManager->createArena($sender, $args[0]);
                break;

            case "setspawn":
                if (!$sender->isOp()) {
                    $sender->sendMessage("§cNo permission");
                    return true;
                }
                if (count($args) < 2) {
                    $sender->sendMessage("§eUsage: /pvpbot setspawn <arenaName> <player1|player2|bot>");
                    return true;
                }
                $this->arenaManager->setSpawn($sender, $args[0], $args[1]);
                break;

            case "settemplate":
                if (!$sender->isOp()) {
                    $sender->sendMessage("§cNo permission");
                    return true;
                }
                $worldName = $sender->getLevel()->getName();
                $this->config->set("template-world", $worldName);
                $this->config->save();
                $sender->sendMessage("§aTemplate world set to: §f$worldName");
                break;

            case "setlobby":
                if (!$sender->isOp()) {
                    $sender->sendMessage("§cNo permission");
                    return true;
                }
                $this->arenaManager->setLobby($sender);
                break;

            case "delete":
                if (!$sender->isOp()) {
                    $sender->sendMessage("§cNo permission");
                    return true;
                }
                if (count($args) < 1) {
                    $sender->sendMessage("§eUsage: /pvpbot delete <arenaName>");
                    return true;
                }
                $this->arenaManager->deleteArena($sender, $args[0]);
                break;

            case "list":
                $this->arenaManager->listArenas($sender);
                break;

            case "edit":
                $this->openEditForm($sender);
                break;

            case "join":
                if (FormAPI::isInSession($sender->getName())) {
                    $sender->sendMessage("§cFinish editing settings first");
                    return true;
                }
                $this->queueManager->joinQueue($sender);
                break;

            case "leave":
                $this->queueManager->leaveQueue($sender);
                break;

            case "stats":
                $this->statsManager->showStats($sender);
                break;

            case "holo":
            case "hologram":
                if (!$sender->isOp()) {
                    $sender->sendMessage("§cNo permission");
                    return true;
                }
                $this->handleHologramCommand($sender, $args);
                break;

            default:
                $this->sendHelp($sender);
        }

        return true;
    }

    private function sendHelp(Player $player) {
        $player->sendMessage("§e===== PvPBot Help =====");
        $player->sendMessage("§a/pvpbot edit §7- Edit match settings");
        $player->sendMessage("§a/pvpbot join §7- Join match queue");
        $player->sendMessage("§a/pvpbot leave §7- Leave match or queue");
        $player->sendMessage("§a/pvpbot stats §7- View your stats");
        $player->sendMessage("§a/pvpbot list §7- List arenas");

        if ($player->isOp()) {
            $player->sendMessage("§6/pvpbot setup <name> §7- Create arena layout");
            $player->sendMessage("§6/pvpbot setspawn <name> <type> §7- Set spawn point");
            $player->sendMessage("§6/pvpbot settemplate §7- Set current world as template");
            $player->sendMessage("§6/pvpbot setlobby §7- Set lobby");
            $player->sendMessage("§6/pvpbot delete <name> §7- Delete arena layout");
            $player->sendMessage("§6/pvpbot holo leaderboard [bot|pvp] §7- Spawn leaderboard hologram");
            $player->sendMessage("§6/pvpbot holo stats [bot|pvp] §7- Spawn stats hologram");
            $player->sendMessage("§6/pvpbot holo remove §7- Remove nearest hologram");
        }
    }

    private function handleHologramCommand(Player $sender, $args) {
        $sub = strtolower(isset($args[0]) ? array_shift($args) : "");

        switch ($sub) {
            case "leaderboard":
            case "lb":
                $mode = strtolower(isset($args[0]) ? $args[0] : "bot");
                if (!in_array($mode, ["bot", "pvp"])) $mode = "bot";
                $id = $this->hologramManager->spawnLeaderboard(
                    $sender->getPosition(), $mode
                );
                $sender->sendMessage("§a[Holograms] §fLeaderboard spawned (mode: §e" . strtoupper($mode) . "§f).");
                $sender->sendMessage("§7Hit to switch mode. §cHold §fBone §cand hit to remove.");
                break;

            case "stats":
            case "st":
                $mode = strtolower(isset($args[0]) ? $args[0] : "bot");
                if (!in_array($mode, ["bot", "pvp"])) $mode = "bot";
                $id = $this->hologramManager->spawnStatsHolo(
                    $sender->getPosition(), $mode
                );
                $sender->sendMessage("§a[Holograms] §fStats hologram spawned (mode: §e" . strtoupper($mode) . "§f).");
                $sender->sendMessage("§7Hit to switch mode. §cHold §fBone §cand hit to remove.");
                break;

            case "remove":
            case "rem":
                $removed = $this->hologramManager->removeNearest($sender->getPosition(), 6.0);
                if ($removed) {
                    $sender->sendMessage("§a[Holograms] §fNearest hologram removed.");
                } else {
                    $sender->sendMessage("§c[Holograms] No hologram found within 6 blocks.");
                }
                break;

            default:
                $sender->sendMessage("§eUsage:");
                $sender->sendMessage("§7  /pvpbot holo leaderboard [bot|pvp]");
                $sender->sendMessage("§7  /pvpbot holo stats [bot|pvp]");
                $sender->sendMessage("§7  /pvpbot holo remove");
        }
    }

    public function openEditForm(Player $player) {
        FormAPI::startEditSession($player, $this);
    }

    public function handleEditResponse(Player $player, $type, $mode, $difficulty) {
        $this->setPlayerSettings($player->getName(), [
            "type" => $type,
            "mode" => $mode,
            "difficulty" => $difficulty
        ]);
        $player->sendMessage("§aSettings saved! Type: $type | Mode: $mode | Difficulty: $difficulty");
    }

    public function startMatch($instanceName, $player1, $player2 = null, $bot = null) {
        $arenaName = $this->arenaManager->getAnyReadyArena();
        if ($arenaName === null) return;

        $arenaData = $this->arenaConfig->get($arenaName);
        if ($arenaData === null) return;

        $settings = $this->getPlayerSettings($player1->getName());
        $mode = $settings["mode"];

        $level = $this->getServer()->getLevelByName($instanceName);
        if ($level === null) {
            $player1->sendMessage("§cInstance world failed to load.");
            $this->worldManager->scheduleInstanceDelete($instanceName);
            return;
        }

        $this->saveLastPosition($player1);

        $p1Spawn = $arenaData["spawns"]["player1"];
        $player1->teleport(new Position($p1Spawn["x"], $p1Spawn["y"], $p1Spawn["z"], $level));
        $player1->getInventory()->clearAll();
        $player1->setHealth($player1->getMaxHealth());
        $player1->setFood(20);
        $player1->removeAllEffects();

        $this->modeManager->applyKit($player1, $mode);

        if ($mode === "resistance" || $mode === "boxing") {
            $this->getServer()->dispatchCommand($player1, "kitkb Resistance");
        }

        $matchData = [
            "arena" => $arenaName,
            "instance" => $instanceName,
            "mode" => $mode,
            "player1" => $player1->getName(),
            "player2" => null,
            "bot" => null,
            "botEntity" => null,
            "warmup" => $this->config->get("warmup-time", 5),
            "started" => false,
            "matchTime" => 0
        ];

        if ($mode === "boxing") {
            $this->boxingHits[$instanceName] = ["player1" => 0, "player2" => 0];
        }

        if ($player2 !== null) {
            $this->saveLastPosition($player2);

            $p2Spawn = $arenaData["spawns"]["player2"];
            $player2->teleport(new Position($p2Spawn["x"], $p2Spawn["y"], $p2Spawn["z"], $level));
            $player2->getInventory()->clearAll();
            $player2->setHealth($player2->getMaxHealth());
            $player2->setFood(20);
            $player2->removeAllEffects();

            $this->modeManager->applyKit($player2, $mode);
            if ($mode === "resistance" || $mode === "boxing") {
                $this->getServer()->dispatchCommand($player2, "kitkb Resistance");
            }
            $matchData["player2"] = $player2->getName();
            $this->setPlayerArena($player2->getName(), $instanceName);
        } else {
            $matchData["bot"] = true;
        }

        $this->setPlayerArena($player1->getName(), $instanceName);
        $this->setActiveMatch($instanceName, $matchData);

        $player1->sendMessage("§eMatch starting in " . $matchData["warmup"] . " seconds...");
        if ($player2 !== null) {
            $player2->sendMessage("§eMatch starting in " . $matchData["warmup"] . " seconds...");
        }
    }

    public function spawnBot($instanceName) {
        if (!isset($this->activeMatches[$instanceName])) return null;

        $match = $this->activeMatches[$instanceName];
        $arenaName = $match["arena"];
        $arenaData = $this->arenaConfig->get($arenaName);
        if ($arenaData === null) return null;

        $settings = $this->getPlayerSettings($match["player1"]);
        $difficulty = $settings["difficulty"];
        $mode = $settings["mode"];

        $botSpawn = $arenaData["spawns"]["bot"];
        if ($botSpawn === null) return null;

        $level = $this->getServer()->getLevelByName($instanceName);
        if ($level === null) return null;

        $pos = new Vector3($botSpawn["x"], $botSpawn["y"], $botSpawn["z"]);

        $p1 = $this->getServer()->getPlayer($match["player1"]);
        $skinData = null;
        $skinId = "Standard_Custom";

        if ($p1 !== null) {
            $skinData = $p1->getSkinData();
            $skinId = $p1->getSkinId();
        }

        $nbt = PvPBotEntity::createBaseNBT($pos);
        $chunk = $level->getChunk($pos->x >> 4, $pos->z >> 4, true);
        if ($chunk === null) return null;

        $bot = new PvPBotEntity($chunk, $nbt);

        if ($skinData !== null) {
            $bot->setSkin($skinData, $skinId);
        }

        $bot->setDifficulty($difficulty);
        $bot->setMode($mode);
        $bot->setArena($instanceName);
        $bot->setTargetPlayer($match["player1"]);

        $this->modeManager->applyBotKit($bot, $mode);
        $bot->spawnToAll();

        $this->activeMatches[$instanceName]["botEntity"] = $bot->getId();

        return $bot;
    }

    public function endMatch($instanceName, $winner = null, $forced = false) {
        if (!isset($this->activeMatches[$instanceName])) return;
        if (isset($this->endingMatches[$instanceName])) return;
        $this->endingMatches[$instanceName] = true;

        $match = $this->activeMatches[$instanceName];

        $level = $this->getServer()->getLevelByName($instanceName);

        if (isset($match["botEntity"]) && $match["botEntity"] !== null && $level !== null) {
            $entity = $level->getEntity($match["botEntity"]);
            if ($entity !== null && !$entity->closed) {
                if ($entity instanceof PvPBotEntity) {
                    $botBlocks = $entity->getPlacedBlocks();
                    foreach ($botBlocks as $pos) {
                        $blockId = $level->getBlockIdAt($pos->x, $pos->y, $pos->z);
                        if ($blockId !== Block::AIR) {
                            $level->setBlock($pos, Block::get(Block::AIR), false, false);
                        }
                    }
                }
                $entity->close();
            }
        }

        $this->clearPlacedBlocks($instanceName);

        $lobbyPos = $this->getLobbyPosition();

        $p1 = $this->getServer()->getPlayer($match["player1"]);
        if ($p1 !== null) {
            if (($match["mode"] === "resistance" || $match["mode"] === "boxing")) {
                $this->getServer()->dispatchCommand($p1, "kit-remove");
            }
            $p1->getInventory()->clearAll();
            $p1->removeAllEffects();
            $p1->setHealth($p1->getMaxHealth());
            $p1->setFood(20);

            if ($lobbyPos !== null) {
                $p1->teleport($lobbyPos);
            } else {
                $lastPos = $this->getLastPosition($match["player1"]);
                if ($lastPos !== null) {
                    $lvl = $this->getServer()->getLevelByName($lastPos["level"]);
                    if ($lvl === null) $lvl = $this->getServer()->getDefaultLevel();
                    $p1->teleport(new Position($lastPos["x"], $lastPos["y"], $lastPos["z"], $lvl));
                }
            }

            $this->removePlayerArena($match["player1"]);
            $this->removeLastPosition($match["player1"]);

            if (!$forced && $winner !== null && $match["mode"] !== "resistance") {
                $type = $match["player2"] === null ? "bot" : "pvp";

                if ($winner === $match["player1"]) {
                    $p1->sendMessage("§a§lYou won the match!");
                    $this->statsManager->addWin($match["player1"], $match["mode"], $type);
                } else {
                    $p1->sendMessage("§c§lYou lost the match!");
                    $this->statsManager->addLoss($match["player1"], $match["mode"], $type);
                }
            } elseif ($forced) {
                $p1->sendMessage("§eMatch ended");
            }
        }

        if ($match["player2"] !== null) {
            $p2 = $this->getServer()->getPlayer($match["player2"]);
            if ($p2 !== null) {
                if (($match["mode"] === "resistance" || $match["mode"] === "boxing")) {
                    $this->getServer()->dispatchCommand($p2, "kit-remove");
                }
                $p2->getInventory()->clearAll();
                $p2->removeAllEffects();
                $p2->setHealth($p2->getMaxHealth());
                $p2->setFood(20);

                if ($lobbyPos !== null) {
                    $p2->teleport($lobbyPos);
                } else {
                    $lastPos = $this->getLastPosition($match["player2"]);
                    if ($lastPos !== null) {
                        $lvl = $this->getServer()->getLevelByName($lastPos["level"]);
                        if ($lvl === null) $lvl = $this->getServer()->getDefaultLevel();
                        $p2->teleport(new Position($lastPos["x"], $lastPos["y"], $lastPos["z"], $lvl));
                    }
                }

                $this->removePlayerArena($match["player2"]);
                $this->removeLastPosition($match["player2"]);

                if (!$forced && $winner !== null && $match["mode"] !== "resistance") {
                    if ($winner === $match["player2"]) {
                        $p2->sendMessage("§a§lYou won the match!");
                        $this->statsManager->addWin($match["player2"], $match["mode"], "pvp");
                    } else {
                        $p2->sendMessage("§c§lYou lost the match!");
                        $this->statsManager->addLoss($match["player2"], $match["mode"], "pvp");
                    }
                } elseif ($forced) {
                    $p2->sendMessage("§eMatch ended");
                }
            }
        }

        $this->removeActiveMatch($instanceName);
        unset($this->endingMatches[$instanceName]);
        unset($this->boxingHits[$instanceName]);
        unset($this->boxingHitCooldowns[$instanceName]);

        $this->worldManager->scheduleInstanceDelete($instanceName);
    }

    public function getLobbyPosition() {
        $lobby = $this->config->get("lobby", null);
        if ($lobby === null) return null;
        if (!isset($lobby["x"]) || !isset($lobby["y"]) || !isset($lobby["z"])) return null;

        $levelName = isset($lobby["level"]) ? $lobby["level"] : "world";
        $level = $this->getServer()->getLevelByName($levelName);
        if ($level === null) {
            $level = $this->getServer()->getDefaultLevel();
        }

        return new \pocketmine\level\Position($lobby["x"], $lobby["y"], $lobby["z"], $level);
    }

    public function onPlayerChat(PlayerChatEvent $event) {
        $player = $event->getPlayer();
        $message = $event->getMessage();

        if (FormAPI::isInSession($player->getName())) {
            $event->setCancelled(true);
            FormAPI::handleChat($player, $message, $this);
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $event) {
        $name = $event->getPlayer()->getName();

        FormAPI::cancelSession($name);
        $this->queueManager->removeFromQueue($name);

        if (isset($this->playerArena[$name])) {
            $arena = $this->playerArena[$name];
            if (isset($this->activeMatches[$arena])) {
                $match = $this->activeMatches[$arena];
                if ($match["player2"] !== null) {
                    $winner = $match["player1"] === $name ? $match["player2"] : $match["player1"];
                    $this->endMatch($arena, $winner);
                } else {
                    $this->endMatch($arena, null, true);
                }
            }
        }
    }

    public function onPlayerDeath(PlayerDeathEvent $event) {
        $player = $event->getEntity();
        $name = $player->getName();

        if (!isset($this->playerArena[$name])) return;

        $arena = $this->playerArena[$name];
        if (!isset($this->activeMatches[$arena])) return;

        $match = $this->activeMatches[$arena];

        if ($match["mode"] === "resistance" || $match["mode"] === "boxing") {
            $event->setDrops([]);
            $event->setDeathMessage("");
            return;
        }

        $event->setDrops([]);
        $event->setDeathMessage("");

        if ($match["player2"] !== null) {
            $winner = $match["player1"] === $name ? $match["player2"] : $match["player1"];
        } else {
            $winner = "bot";
        }

        $this->getServer()->getScheduler()->scheduleDelayedTask(
            new EndMatchTask($this, $arena, $winner), 40
        );
    }

   /* public function onPlayerRespawn(PlayerRespawnEvent $event) {
        $player = $event->getPlayer();
        $name = $player->getName();

        if (isset($this->playerArena[$name])) return;

        $lobbyPos = $this->getLobbyPosition();
        if ($lobbyPos !== null) {
            $event->setRespawnPosition($lobbyPos);
        }
    } */

    public function onPlayerInteract(PlayerInteractEvent $event) {
        $player = $event->getPlayer();
        $item = $event->getItem();
        if ($item->getId() === \pocketmine\item\Item::REDSTONE && $item->getCustomName() === "§cQuit") {
            $event->setCancelled();
            $this->queueManager->leaveQueue($player);
        }
    }

    public function onBlockPlace(BlockPlaceEvent $event) {
        $player = $event->getPlayer();
        $name = $player->getName();

        if (!isset($this->playerArena[$name])) return;

        $arena = $this->playerArena[$name];

        if (!isset($this->activeMatches[$arena])) {
            $event->setCancelled();
            return;
        }

        $match = $this->activeMatches[$arena];

        if (!$match["started"]) {
            $event->setCancelled();
            return;
        }

        if (!$this->modeManager->canBuild($match["mode"])) {
            $event->setCancelled();
            return;
        }

        $block = $event->getBlock();
        $this->addPlacedBlock($arena, new Vector3((int)floor($block->x), (int)floor($block->y), (int)floor($block->z)));
    }

    public function onBlockBreak(BlockBreakEvent $event) {
        $player = $event->getPlayer();
        $name = $player->getName();

        if (!isset($this->playerArena[$name])) return;

        $arena = $this->playerArena[$name];

        if (!isset($this->activeMatches[$arena])) {
            $event->setCancelled();
            return;
        }

        $match = $this->activeMatches[$arena];

        if (!$match["started"]) {
            $event->setCancelled();
            return;
        }

        if (!$this->modeManager->canBuild($match["mode"])) {
            $event->setCancelled();
            return;
        }

        $block = $event->getBlock();
        $key = $block->x . ":" . $block->y . ":" . $block->z;
        if (!isset($this->placedBlocks[$arena][$key])) {
            $event->setCancelled();
        }
    }

    public function onEntityDamage(EntityDamageEvent $event) {
        if ($event instanceof EntityDamageByEntityEvent) {
            $entity  = $event->getEntity();
            $damager = $event->getDamager();

            if ($entity instanceof HologramEntity) {
                $event->setCancelled();
                return;
            }
        }

        if (!($event instanceof EntityDamageByEntityEvent)) {
            $entity = $event->getEntity();

            if ($entity instanceof Player && isset($this->playerArena[$entity->getName()])) {
                $arena = $this->playerArena[$entity->getName()];
                if (isset($this->activeMatches[$arena])) {
                    $match = $this->activeMatches[$arena];
                    if (!$match["started"]) {
                        $event->setCancelled();
                    }
                }
            }

            if ($entity instanceof PvPBotEntity) {
                $arenaName = $entity->getArena();
                if ($arenaName !== "" && isset($this->activeMatches[$arenaName])) {
                    $match = $this->activeMatches[$arenaName];
                    if (!$match["started"]) {
                        $event->setCancelled();
                    }
                }
            }

            return;
        }

        $entity = $event->getEntity();
        $damager = $event->getDamager();

        if ($entity instanceof Player && isset($this->playerArena[$entity->getName()])) {
            $arena = $this->playerArena[$entity->getName()];
            if (isset($this->activeMatches[$arena])) {
                $match = $this->activeMatches[$arena];
                if (!$match["started"]) {
                    $event->setCancelled();
                    return;
                }

                if ($match["mode"] === "resistance") {
                    $playerRef = $entity;
                    $maxHp = $entity->getMaxHealth();
                    $this->getServer()->getScheduler()->scheduleDelayedTask(new class($playerRef, $maxHp) extends \pocketmine\scheduler\PluginTask {
                        private $player;
                        private $maxHp;
                        public function __construct($player, $maxHp) {
                            parent::__construct(\pocketmine\Server::getInstance()->getPluginManager()->getPlugin("PvPBot"));
                            $this->player = $player;
                            $this->maxHp = $maxHp;
                        }
                        public function onRun($tick) {
                            if ($this->player->isOnline() && $this->player->isAlive()) {
                                $this->player->setHealth($this->maxHp);
                            }
                        }
                    }, 1);
                    return;
                }

                if ($match["mode"] === "boxing" && $damager !== null) {
                    if (!isset($this->boxingHits[$arena])) {
                        $this->boxingHits[$arena] = ["player1" => 0, "player2" => 0];
                    }

                    $damagerName = ($damager instanceof Player) ? $damager->getName() : "bot";

                    $playerRef = $entity;
                    $maxHp = $entity->getMaxHealth();
                    $this->getServer()->getScheduler()->scheduleDelayedTask(new class($playerRef, $maxHp) extends \pocketmine\scheduler\PluginTask {
                        private $player;
                        private $maxHp;
                        public function __construct($player, $maxHp) {
                            parent::__construct(\pocketmine\Server::getInstance()->getPluginManager()->getPlugin("PvPBot"));
                            $this->player = $player;
                            $this->maxHp = $maxHp;
                        }
                        public function onRun($tick) {
                            if ($this->player->isOnline() && $this->player->isAlive()) {
                                $this->player->setHealth($this->maxHp);
                            }
                        }
                    }, 1);

                    if ($damager instanceof PvPBotEntity) {
                        $settings = $this->getPlayerSettings($match["player1"]);
                        $botPoints = 1;
                        $this->boxingHits[$arena]["player2"] += $botPoints;
                        $botHits = $this->boxingHits[$arena]["player2"];
                        $p1Hits = $this->boxingHits[$arena]["player1"];
                        $p1 = $this->getServer()->getPlayer($match["player1"]);
                        if ($p1 !== null) {
                            $p1->sendTip("§aYour hits: §f" . $p1Hits . " §7/ §f100\n§cBot hits: §f" . $botHits . " §7/ §f100");
                        }
                        if ($botHits >= 100) {
                            $this->getServer()->getScheduler()->scheduleDelayedTask(
                                new EndMatchTask($this, $arena, "bot"), 20
                            );
                        }
                    } elseif ($damager instanceof Player && $match["player2"] !== null) {
                        if ($damagerName === $match["player1"]) {
                            if ($this->canRegisterBoxingHit($arena, $damagerName)) {
                                $this->boxingHits[$arena]["player1"]++;
                            }
                        } else {
                            if ($this->canRegisterBoxingHit($arena, $damagerName)) {
                                $this->boxingHits[$arena]["player2"]++;
                            }
                        }
                        $p1Hits = $this->boxingHits[$arena]["player1"];
                        $p2Hits = $this->boxingHits[$arena]["player2"];
                        $p1 = $this->getServer()->getPlayer($match["player1"]);
                        $p2 = $this->getServer()->getPlayer($match["player2"]);
                        if ($p1 !== null) $p1->sendTip("§aYour hits: §f" . $p1Hits . " §7/ §f100\n§c" . $match["player2"] . " hits: §f" . $p2Hits . " §7/ §f100");
                        if ($p2 !== null) $p2->sendTip("§aYour hits: §f" . $p2Hits . " §7/ §f100\n§c" . $match["player1"] . " hits: §f" . $p1Hits . " §7/ §f100");

                        if ($this->boxingHits[$arena]["player1"] >= 100) {
                            $this->getServer()->getScheduler()->scheduleDelayedTask(
                                new EndMatchTask($this, $arena, $match["player1"]), 20
                            );
                        } elseif ($this->boxingHits[$arena]["player2"] >= 100) {
                            $this->getServer()->getScheduler()->scheduleDelayedTask(
                                new EndMatchTask($this, $arena, $match["player2"]), 20
                            );
                        }
                    }
                    return;
                }

                if ($damager instanceof Player) {
                    $dName = $damager->getName();

                    if ($match["player2"] !== null) {
                        if ($dName !== $match["player1"] && $dName !== $match["player2"]) {
                            $event->setCancelled();
                            return;
                        }
                    } else {
                        $event->setCancelled();
                        return;
                    }
                }
            }
        }

        if ($entity instanceof PvPBotEntity && $damager instanceof Player) {
            $arenaName = $entity->getArena();
            if ($arenaName !== "" && isset($this->activeMatches[$arenaName])) {
                $match = $this->activeMatches[$arenaName];
                if (!$match["started"]) {
                    $event->setCancelled();
                    return;
                }

                if ($damager->getName() !== $match["player1"]) {
                    $event->setCancelled();
                    return;
                }

                if ($match["mode"] === "boxing") {
                    if (isset($this->boxingHits[$arenaName])) {
                        if (!($entity instanceof PvPBotEntity) || $entity->registerBoxingHit($damager->getName())) {
                            $this->boxingHits[$arenaName]["player1"]++;
                            $hits = $this->boxingHits[$arenaName]["player1"];
                            $damager->sendTip("§aYour hits: §f" . $hits . " §7/ §f100\n§cBot hits: §f" . $this->boxingHits[$arenaName]["player2"] . " §7/ §f100");
                            if ($hits >= 100) {
                                $this->getServer()->getScheduler()->scheduleDelayedTask(
                                    new EndMatchTask($this, $arenaName, $damager->getName()), 20
                                );
                            }
                        }
                    }
                    $botRef = $entity;
                    $maxHp = $entity->getMaxHealth();
                    $this->getServer()->getScheduler()->scheduleDelayedTask(new class($botRef, $maxHp) extends \pocketmine\scheduler\PluginTask {
                        private $bot;
                        private $maxHp;
                        public function __construct($bot, $maxHp) {
                            parent::__construct(\pocketmine\Server::getInstance()->getPluginManager()->getPlugin("PvPBot"));
                            $this->bot = $bot;
                            $this->maxHp = $maxHp;
                        }
                        public function onRun($tick) {
                            if (!$this->bot->closed && $this->bot->isAlive()) {
                                $this->bot->setHealth($this->maxHp);
                            }
                        }
                    }, 1);
                    return;
                }

                if ($match["mode"] === "resistance") {
                    $botRef = $entity;
                    $maxHp = $entity->getMaxHealth();
                    $this->getServer()->getScheduler()->scheduleDelayedTask(new class($botRef, $maxHp) extends \pocketmine\scheduler\PluginTask {
                        private $bot;
                        private $maxHp;
                        public function __construct($bot, $maxHp) {
                            parent::__construct(\pocketmine\Server::getInstance()->getPluginManager()->getPlugin("PvPBot"));
                            $this->bot = $bot;
                            $this->maxHp = $maxHp;
                        }
                        public function onRun($tick) {
                            if (!$this->bot->closed && $this->bot->isAlive()) {
                                $this->bot->setHealth($this->maxHp);
                            }
                        }
                    }, 1);
                    return;
                }
            }
        }

        if ($entity instanceof Player && $damager instanceof Player) {
            if (!isset($this->playerArena[$entity->getName()]) && !isset($this->playerArena[$damager->getName()])) {
                return;
            }
        }
    }
}