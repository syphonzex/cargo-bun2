<?php

namespace PvPBot;

class WorldManager {

    private $plugin;
    private $instanceCounter = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function cleanupInstanceWorlds() {
        $worldsPath = $this->plugin->getServer()->getDataPath() . "worlds/";
        if (!is_dir($worldsPath)) return;

        $modes = array_keys($this->plugin->getModeManager()->getModes());
        $pattern = implode("|", array_map("preg_quote", $modes));

        $entries = scandir($worldsPath);
        foreach ($entries as $entry) {
            if ($entry === "." || $entry === "..") continue;
            if (preg_match("/^(" . $pattern . ")_(bot|pvp)_(\d+)$/i", $entry)) {
                $fullPath = $worldsPath . $entry;
                if (is_dir($fullPath)) {
                    $this->deleteDirectory($fullPath);
                }
            }
        }
    }

    public function createInstance($templateWorld, $mode, $type) {
        if (!isset($this->instanceCounter[$mode . "_" . $type])) {
            $this->instanceCounter[$mode . "_" . $type] = 0;
        }

        $this->instanceCounter[$mode . "_" . $type]++;
        $instanceName = $mode . "_" . $type . "_" . $this->instanceCounter[$mode . "_" . $type];

        $worldsPath = $this->plugin->getServer()->getDataPath() . "worlds/";
        $src = $worldsPath . $templateWorld;
        $dst = $worldsPath . $instanceName;

        if (!is_dir($src)) {
            return null;
        }

        if (is_dir($dst)) {
            $this->deleteDirectory($dst);
        }

        $this->copyDirectory($src, $dst);

        $lockFile = $dst . "/session.lock";
        if (file_exists($lockFile)) {
            @unlink($lockFile);
        }

        return $instanceName;
    }

    public function loadInstance($instanceName) {
        $server = $this->plugin->getServer();
        if ($server->isLevelLoaded($instanceName)) {
            return true;
        }
        return $server->loadLevel($instanceName);
    }

    public function scheduleInstanceDelete($instanceName) {
        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
            new DeleteWorldTask($this->plugin, $instanceName),
            200
        );
    }

    public function forceUnloadAndDelete($instanceName) {
        $server = $this->plugin->getServer();
        $level = $server->getLevelByName($instanceName);
        if ($level !== null) {
            $server->unloadLevel($level, true);
        }
        $worldsPath = $server->getDataPath() . "worlds/";
        $path = $worldsPath . $instanceName;
        if (is_dir($path)) {
            $this->deleteDirectory($path);
        }
    }

    private function copyDirectory($src, $dst) {
        @mkdir($dst, 0755, true);
        $items = scandir($src);
        foreach ($items as $item) {
            if ($item === "." || $item === "..") continue;
            $srcPath = $src . "/" . $item;
            $dstPath = $dst . "/" . $item;
            if (is_dir($srcPath)) {
                $this->copyDirectory($srcPath, $dstPath);
            } else {
                copy($srcPath, $dstPath);
            }
        }
    }

    public function deleteDirectory($path) {
        if (!is_dir($path)) return;
        $items = scandir($path);
        foreach ($items as $item) {
            if ($item === "." || $item === "..") continue;
            $full = $path . "/" . $item;
            if (is_dir($full)) {
                $this->deleteDirectory($full);
            } else {
                @unlink($full);
            }
        }
        @rmdir($path);
    }
}
