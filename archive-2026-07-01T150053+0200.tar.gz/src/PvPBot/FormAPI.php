<?php

namespace PvPBot;

use pocketmine\Player;

class FormAPI {

    private static $editSession = [];

    public static function startEditSession(Player $player, Main $plugin) {
        $name = $player->getName();
        $settings = $plugin->getPlayerSettings($name);

        self::$editSession[$name] = [
            "step" => 1,
            "type" => $settings["type"],
            "mode" => $settings["mode"],
            "difficulty" => $settings["difficulty"]
        ];

        self::sendStep1($player);
    }

    public static function isInSession($name) {
        return isset(self::$editSession[$name]);
    }

    public static function cancelSession($name) {
        unset(self::$editSession[$name]);
    }

    public static function getSession($name) {
        return isset(self::$editSession[$name]) ? self::$editSession[$name] : null;
    }

    public static function handleChat(Player $player, $message, Main $plugin) {
        $name = $player->getName();

        if (!isset(self::$editSession[$name])) {
            return false;
        }

        $session = self::$editSession[$name];
        $step = $session["step"];
        $msg = strtolower(trim($message));

        if ($msg === "cancel") {
            unset(self::$editSession[$name]);
            $player->sendMessage("§cEdit cancelled");
            return true;
        }

        switch ($step) {
            case 1:
                if ($msg === "1" || $msg === "bot") {
                    self::$editSession[$name]["type"] = "bot";
                    self::$editSession[$name]["step"] = 2;
                    self::sendStep2($player, $plugin);
                } elseif ($msg === "2" || $msg === "pvp") {
                    self::$editSession[$name]["type"] = "pvp";
                    self::$editSession[$name]["step"] = 2;
                    self::sendStep2($player, $plugin);
                } else {
                    $player->sendMessage("§cInvalid option. Type 1 for Bot or 2 for PvP");
                }
                break;

            case 2:
                $modes = array_keys($plugin->getModeManager()->getModes());
                $modeIndex = ((int)$msg) - 1;

                if (isset($modes[$modeIndex])) {
                    self::$editSession[$name]["mode"] = $modes[$modeIndex];

                    if (self::$editSession[$name]["type"] === "bot") {
                        self::$editSession[$name]["step"] = 3;
                        self::sendStep3($player);
                    } else {
                        self::finishSession($player, $plugin);
                    }
                } elseif (in_array($msg, $modes)) {
                    self::$editSession[$name]["mode"] = $msg;

                    if (self::$editSession[$name]["type"] === "bot") {
                        self::$editSession[$name]["step"] = 3;
                        self::sendStep3($player);
                    } else {
                        self::finishSession($player, $plugin);
                    }
                } else {
                    $player->sendMessage("§cInvalid mode. Choose a number from the list");
                }
                break;

            case 3:
                $difficulties = ["easy", "medium", "hard"];

                if ($msg === "1" || $msg === "easy") {
                    self::$editSession[$name]["difficulty"] = "easy";
                    self::finishSession($player, $plugin);
                } elseif ($msg === "2" || $msg === "medium") {
                    self::$editSession[$name]["difficulty"] = "medium";
                    self::finishSession($player, $plugin);
                } elseif ($msg === "3" || $msg === "hard") {
                    self::$editSession[$name]["difficulty"] = "hard";
                    self::finishSession($player, $plugin);
                } else {
                    $player->sendMessage("§cInvalid option. Type 1 for Easy, 2 for Medium, or 3 for Hard");
                }
                break;
        }

        return true;
    }

    private static function sendStep1(Player $player) {
        $player->sendMessage("§e===== PvP Settings =====");
        $player->sendMessage("§7Select Match Type:");
        $player->sendMessage("§a[1] §fBot §7- Fight against AI");
        $player->sendMessage("§a[2] §fPvP §7- Fight against players");
        $player->sendMessage("§7Type a number or §ccancel §7to exit");
    }

    private static function sendStep2(Player $player, Main $plugin) {
        $modes = $plugin->getModeManager()->getModes();

        $player->sendMessage("§e===== Select Mode =====");
        $i = 1;
        foreach ($modes as $id => $data) {
            $player->sendMessage("§a[$i] §f" . $data["name"]);
            $i++;
        }
        $player->sendMessage("§7Type a number or §ccancel §7to exit");
    }

    private static function sendStep3(Player $player) {
        $player->sendMessage("§e===== Bot Difficulty =====");
        $player->sendMessage("§a[1] §fEasy §7- Slow reactions, weak combos");
        $player->sendMessage("§a[2] §fMedium §7- Normal skill level");
        $player->sendMessage("§a[3] §fHard §7- Fast reactions, strong combos");
        $player->sendMessage("§7Type a number or §ccancel §7to exit");
    }

    private static function finishSession(Player $player, Main $plugin) {
        $name = $player->getName();
        $session = self::$editSession[$name];

        $plugin->handleEditResponse($player, $session["type"], $session["mode"], $session["difficulty"]);

        unset(self::$editSession[$name]);
    }
}