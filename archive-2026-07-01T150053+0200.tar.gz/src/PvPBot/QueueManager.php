<?php

namespace PvPBot;

use pocketmine\Player;

class QueueManager {

    private $plugin;
    private $pvpQueue = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function joinQueue(Player $player) {
        $name = $player->getName();

        if (isset($this->plugin->getPlayerArena()[$name])) {
            $player->sendMessage("§cYou are already in a match");
            return;
        }

        if ($this->isInQueue($name)) {
            $player->sendMessage("§cYou are already in queue");
            return;
        }

        $maxInstances = $this->plugin->getMainConfig()->get("max-instances", 10);
        if ($this->plugin->getArenaManager()->countActiveInstances() >= $maxInstances) {
            $player->sendMessage("§cAll arenas are currently full. Try again shortly.");
            return;
        }

        $arenaName = $this->plugin->getArenaManager()->getAnyReadyArena();
        if ($arenaName === null) {
            $player->sendMessage("§cNo arena has been configured yet. Ask an admin to set one up.");
            return;
        }

        $settings = $this->plugin->getPlayerSettings($name);
        $type = $settings["type"];
        $mode = $settings["mode"];

        if ($type === "bot") {
            $player->sendMessage("§ePreparing your arena...");
            $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(
                new PrepareMatchTask($this->plugin, $name, null, true, $mode, "bot"),
                20
            );
        } else {
            if (!isset($this->pvpQueue[$mode])) {
                $this->pvpQueue[$mode] = [];
            }

            if (count($this->pvpQueue[$mode]) > 0) {
                $opponentName = array_shift($this->pvpQueue[$mode]);
                $opponent = $this->plugin->getServer()->getPlayer($opponentName);

                if ($opponent === null || !$opponent->isOnline()) {
                    $this->pvpQueue[$mode][$name] = $name;
                    $player->sendMessage("§eSearching for opponent...");
                    return;
                }

                $player->sendMessage("§aOpponent found! Preparing arena...");
                $opponent->sendMessage("§aOpponent found! Preparing arena...");

                $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(
                    new PrepareMatchTask($this->plugin, $name, $opponentName, false, $mode, "pvp"),
                    20
                );
            } else {
                $this->pvpQueue[$mode][$name] = $name;
                $player->sendMessage("§eSearching for opponent in $mode...");
            }
        }
    }

    public function leaveQueue(Player $player) {
        $name = $player->getName();

        if (isset($this->plugin->getPlayerArena()[$name])) {
            $arena = $this->plugin->getPlayerArena()[$name];
            $matches = $this->plugin->getActiveMatches();

            if (isset($matches[$arena])) {
                $match = $matches[$arena];
                if ($match["player2"] !== null) {
                    $winner = $match["player1"] === $name ? $match["player2"] : $match["player1"];
                    $this->plugin->endMatch($arena, $winner);
                } else {
                    $this->plugin->endMatch($arena, "bot");
                }
            }

            $player->sendMessage("§cYou left the match");
            return;
        }

        if ($this->removeFromQueue($name)) {
            $player->sendMessage("§cYou left the queue");
        } else {
            $player->sendMessage("§cYou are not in queue or match");
        }
    }

    public function removeFromQueue($name) {
        foreach ($this->pvpQueue as $mode => $players) {
            if (isset($this->pvpQueue[$mode][$name])) {
                unset($this->pvpQueue[$mode][$name]);
                return true;
            }
        }
        return false;
    }

    public function isInQueue($name) {
        foreach ($this->pvpQueue as $mode => $players) {
            if (isset($players[$name])) {
                return true;
            }
        }
        return false;
    }

    public function getQueueCount($mode) {
        if (!isset($this->pvpQueue[$mode])) return 0;
        return count($this->pvpQueue[$mode]);
    }
}
