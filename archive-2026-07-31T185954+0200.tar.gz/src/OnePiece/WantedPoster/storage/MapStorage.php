<?php
namespace OnePiece\WantedPoster\storage;

use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\CompoundTag;

final class MapStorage {

    private static $instance = null;
    private $path = "";
    private $loadedMaps = [];

    public static function get() {
        return self::$instance;
    }

    public static function init($path) {
        if (self::$instance === null) {
            self::$instance = new MapStorage($path);
        }
    }

    private function __construct($path) {
        @mkdir($path, 0755, true);
        $this->path = $path;
    }

    public function getNextMapId() {
        for ($i = 10; true; ++$i) {
            if (!$this->existsMap($i)) return $i;
        }
    }

    public function getMapData($mapId) {
        if ($this->loadMapData($mapId)) {
            return $this->loadedMaps[$mapId];
        }
        return null;
    }

    public function loadMapData($mapId) {
        if (isset($this->loadedMaps[$mapId])) {
            return true;
        }

        $path = $this->path . "map_" . $mapId . ".dat";
        if (file_exists($path)) {
            $stream = new NBT(NBT::BIG_ENDIAN);
            $stream->readCompressed(file_get_contents($path));
            $this->loadedMaps[$mapId] = $stream->getData();
            return true;
        }
        return false;
    }

    public function existsMap($mapId) {
        return isset($this->loadedMaps[$mapId]) || file_exists($this->path . "map_" . $mapId . ".dat");
    }

    public function saveMapData($mapId, CompoundTag $nbt) {
        $stream = new NBT(NBT::BIG_ENDIAN);
        $stream->setData($nbt);
        $buffer = $stream->writeCompressed();
        if ($buffer !== null) {
            file_put_contents($this->path . "map_" . $mapId . ".dat", $buffer);
        }
    }
}