<?php
namespace OnePiece\WantedPoster;

use pocketmine\block\Block;
use pocketmine\block\ItemFrame as ItemFrameBlock;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\ByteArrayTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\scheduler\Task;
use pocketmine\tile\ItemFrame as ItemFrameTile;
use pocketmine\tile\Tile;
use OnePiece\WantedPoster\storage\MapStorage;

class PosterSpawnTask extends Task {

    private $plugin;

    public function __construct(Loader $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun($currentTick) {
        $bountyPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceBounty");
        if ($bountyPlugin === null) return;

        $bm = $bountyPlugin->getBountyManager();
        $pm = $this->plugin->getPosterManager();
        $positions = $pm->getPositions();

        if (empty($positions)) return;

        $onlinePlayers = $this->plugin->getServer()->getOnlinePlayers();
        $eligible = [];

        foreach ($onlinePlayers as $player) {
            $bounty = $bm->getBounty($player->getName());
            if ($bounty >= 100) {
                $eligible[] = $player;
            }
        }

        if (empty($eligible)) {
            $this->clearAllPosters($positions);
            return;
        }

        shuffle($eligible);

        foreach ($positions as $idx => $pos) {
            $player = $eligible[$idx % count($eligible)];
            $current = $pm->getActivePoster($idx);

            if ($current !== null && strtolower($current["player"]) === strtolower($player->getName())) {
                continue;
            }

            $bounty = $bm->getBounty($player->getName());
            $this->placePoster($idx, $pos, $player->getName(), $bounty);
        }
    }

    private function placePoster($posIdx, $pos, $playerName, $bounty) {
        $server = $this->plugin->getServer();
        $pm = $this->plugin->getPosterManager();

        $worldName = $pos["world"];
        if (!$server->isLevelLoaded($worldName)) {
            $server->loadLevel($worldName);
        }
        $level = $server->getLevelByName($worldName);
        if ($level === null) return;

        $x         = (int)$pos["x"];
        $y         = (int)$pos["y"];
        $z         = (int)$pos["z"];
        $frameFace = isset($pos["face"]) ? (int)$pos["face"] : 2;

        $blockPos = new Vector3($x, $y, $z);

        $level->setBlock($blockPos, new ItemFrameBlock($frameFace), true, true);

        $nbt = new CompoundTag("", [
            new StringTag("id", Tile::ITEM_FRAME),
            new IntTag("x", $x),
            new IntTag("y", $y),
            new IntTag("z", $z),
            new ByteTag("ItemRotation", 0),
            new FloatTag("ItemDropChance", 0.0)
        ]);

        $tile = Tile::createTile(
            Tile::ITEM_FRAME,
            $level->getChunk($x >> 4, $z >> 4),
            $nbt
        );

        $mapId = MapStorage::get()->getNextMapId();
        $raw = $this->plugin->createPosterRaw($playerName, $bounty);
        if ($raw === null) return;

        MapStorage::get()->saveMapData($mapId, new CompoundTag("", [
            new ByteArrayTag("rawImage", $raw)
        ]));

        $item = new Item(Item::FILLED_MAP, 0, 1);
        $item->setCustomName("Wanted: " . $playerName);
        $item->setNamedTag(new CompoundTag("", [
            new StringTag("map_uuid", (string)$mapId),
            new ByteTag("locked_image", 1),
            new StringTag("wanted_player", strtolower($playerName)),
            new IntTag("wanted_bounty", (int)$bounty)
        ]));

        if ($tile instanceof ItemFrameTile) {
            $tile->setItem($item, true);
            $tile->spawnToAll();
        }

        $pm->setActivePoster($posIdx, $playerName, $mapId);
    }

    private function clearAllPosters($positions) {
        $server = $this->plugin->getServer();
        $pm = $this->plugin->getPosterManager();

        foreach ($positions as $idx => $pos) {
            if ($pm->getActivePoster($idx) === null) continue;

            $worldName = $pos["world"];
            if (!$server->isLevelLoaded($worldName)) continue;
            $level = $server->getLevelByName($worldName);
            if ($level === null) continue;

            $blockPos = new Vector3($pos["x"], $pos["y"], $pos["z"]);
            $level->setBlock($blockPos, Block::get(Block::AIR), true, true);
            $pm->clearActivePoster($idx);
        }
    }
}