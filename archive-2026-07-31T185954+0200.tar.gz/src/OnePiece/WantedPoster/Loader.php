<?php
namespace OnePiece\WantedPoster;

use pocketmine\plugin\PluginBase;
use OnePiece\WantedPoster\command\PosterCommand;
use OnePiece\WantedPoster\command\WantedMapCommand;
use OnePiece\WantedPoster\command\WantedPlaceCommand;
use OnePiece\WantedPoster\storage\MapStorage;
use OnePiece\WantedPoster\protocol\v80\ClientboundMapItemDataPacket as Cv80;
use OnePiece\WantedPoster\protocol\v80\MapInfoRequestPacket as Mv80;
use OnePiece\WantedPoster\protocol\v70\ClientboundMapItemDataPacket as Cv70;
use OnePiece\WantedPoster\protocol\v70\MapInfoRequestPacket as Mv70;
use OnePiece\SeaEvent\SeaEventManager;
use OnePiece\SeaEvent\SeaEventCommand;
use OnePiece\SeaEvent\SeaEventSpawnTask;
use OnePiece\SeaEvent\StormZoneTask;
use OnePiece\SeaEvent\SeaSharkEntity;
use OnePiece\SeaEvent\SeaBeastEntity;
use OnePiece\FruitSpawn\FruitSpawnManager;
use OnePiece\FruitSpawn\FruitSpawnCommand;
use OnePiece\FruitSpawn\FruitSpawnTask;
use OnePiece\FruitSpawn\FruitRadarTask;
use OnePiece\FruitSpawn\FruitItemEntity;
use OnePiece\Gamepasses\GamepassManager;
use OnePiece\Gamepasses\GamepassCommand;
use OnePiece\Team\AllyManager;
use OnePiece\Team\CrewManager;
use OnePiece\Team\AllyCommand;
use OnePiece\Team\CrewCommand;
use OnePiece\Team\TeamListener;
use pocketmine\entity\Entity;

class Loader extends PluginBase {

    private static $instance = null;
    public $placeData = [];
    public $addPosPending = [];

    private $posterManager;
    private $flagQuestManager;
    private $seaEventManager;
    private $fruitSpawnManager;
    private $fruitRadarTask;
    private $gamepassManager;
    private $allyManager;
    private $crewManager;

    public static function get() {
        return self::$instance;
    }

    public function onEnable() {
        if (!extension_loaded("gd")) {
            $this->getLogger()->critical("GD extension is required");
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        self::$instance = $this;

        @mkdir($this->getDataFolder());
        @mkdir($this->getDataFolder() . "maps/", 0755, true);

        MapStorage::init($this->getDataFolder() . "maps/");

        $this->posterManager    = new PosterManager($this);
        $this->flagQuestManager = new FlagQuestManager($this);
        $this->seaEventManager  = new SeaEventManager($this);
        $this->fruitSpawnManager = new FruitSpawnManager($this);
        $this->gamepassManager   = new GamepassManager($this);
        $this->allyManager       = new AllyManager($this);
        $this->crewManager       = new CrewManager($this);

        Entity::registerEntity(SeaSharkEntity::class, true);
        Entity::registerEntity(SeaBeastEntity::class, false);
        Entity::registerEntity(FruitItemEntity::class, true, ["FruitItem"]);

        $this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new TeamListener($this->allyManager, $this->crewManager), $this);

        $map = $this->getServer()->getCommandMap();
        $map->register("wantedposter", new WantedMapCommand($this));
        $map->register("wantedposter", new WantedPlaceCommand($this));
        $map->register("wantedposter", new PosterCommand($this));
        $map->register("onepiece", new SeaEventCommand($this));
        $map->register("onepiece", new FruitSpawnCommand($this));
        $map->register("onepiece", new GamepassCommand($this));
        $map->register("onepiece", new GamepassCommand($this));
        $map->register("onepiece", new GamepassCommand($this));
        $map->register("onepiece", new AllyCommand($this->allyManager));
        $map->register("onepiece", new CrewCommand($this->crewManager));

        $network = $this->getServer()->getNetwork();
        $network->registerPacket(Cv80::NETWORK_ID, Cv80::class);
        $network->registerPacket(Mv80::NETWORK_ID, Mv80::class);
        $network->registerPacket(Cv70::NETWORK_ID, Cv70::class);
        $network->registerPacket(Mv70::NETWORK_ID, Mv70::class);

        $this->getServer()->getScheduler()->scheduleRepeatingTask(
            new PosterSpawnTask($this),
            20 * 120
        );

        $this->getServer()->getScheduler()->scheduleRepeatingTask(
            new SeaEventSpawnTask($this),
            20 * 30
        );

        $this->getServer()->getScheduler()->scheduleRepeatingTask(
            new StormZoneTask($this),
            4
        );

        $this->getServer()->getScheduler()->scheduleRepeatingTask(
            new FruitSpawnTask($this),
            600
        );

        $this->fruitRadarTask = new FruitRadarTask($this);
        $this->getServer()->getScheduler()->scheduleRepeatingTask(
            $this->fruitRadarTask,
            0
        );
    }

    public function onDisable() {
        self::$instance = null;
    }

    public function getPosterManager() {
        return $this->posterManager;
    }

    public function getFlagQuestManager() {
        return $this->flagQuestManager;
    }

    public function getSeaEventManager() {
        return $this->seaEventManager;
    }

    public function getFruitSpawnManager() {
        return $this->fruitSpawnManager;
    }

    public function getGamepassManager() {
        return $this->gamepassManager;
    }

    public function getAllyManager() {
        return $this->allyManager;
    }

    public function getCrewManager() {
        return $this->crewManager;
    }

    public function getFruitRadarTask() {
        return $this->fruitRadarTask;
    }

    public function hasRadarPass($playerName) {
        return $this->fruitSpawnManager->hasRadarPass($playerName);
    }

    public function giveRadarPass($playerName) {
        $this->fruitSpawnManager->giveRadarPass($playerName);
    }

    public function removeRadarPass($playerName) {
        $this->fruitSpawnManager->removeRadarPass($playerName);
    }

    public function activateRadarForPlayer($playerName) {
        if (!$this->hasRadarPass($playerName)) return false;
        $this->fruitRadarTask->activateRadar($playerName);
        return true;
    }

    public function createPosterRaw($playerName, $bounty) {
        $target = $this->getServer()->getPlayerExact($playerName);
        if ($target === null || !$target->isOnline()) return null;

        $skinData = $target->getSkinData();
        $W = 128;
        $H = 128;
        $img = imagecreatetruecolor($W, $H);
        imagealphablending($img, true);

        $cPaper   = imagecolorallocate($img, 224, 196, 140);
        $cBorder  = imagecolorallocate($img, 180, 140, 60);
        $cBorder2 = imagecolorallocate($img, 140, 100, 30);
        $cBlack   = imagecolorallocate($img, 10, 10, 10);
        $cStrip   = imagecolorallocate($img, 196, 168, 108);
        $cStripDk = imagecolorallocate($img, 170, 140, 80);
        $cWhiteT  = imagecolorallocate($img, 240, 220, 170);

        imagefill($img, 0, 0, $cPaper);

        imagefilledrectangle($img, 0, 0, $W-1, $H-1, $cBorder);
        imagefilledrectangle($img, 5, 5, $W-6, $H-6, $cBorder2);
        imagefilledrectangle($img, 7, 7, $W-8, $H-8, $cPaper);

        $wText = "WANTED";
        $wX = (int)(($W - strlen($wText) * 12) / 2);
        imagestring($img, 5, $wX, 9, $wText, $cBlack);

        $portrait = $this->createUpperBodyPortrait($skinData);
        if ($portrait !== null) {
            $pW   = imagesx($portrait);
            $pH   = imagesy($portrait);
            $dstW = 80;
            $dstH = (int)($dstW * $pH / $pW);
            $dstX = (int)(($W - $dstW) / 2);
            $dstY = 22;
            imagecopyresampled($img, $portrait, $dstX, $dstY, 0, 0, $dstW, $dstH, $pW, $pH);
            imagedestroy($portrait);
        }

        imagefilledrectangle($img, 7, 88, $W-8, $H-8, $cStrip);
        imageline($img, 7, 88, $W-8, 88, $cStripDk);

        $aText = "DEAD OR ALIVE";
        $aX = (int)(($W - strlen($aText) * 6) / 2);
        imagestring($img, 2, $aX, 91, $aText, $cBlack);

        $name  = substr($playerName, 0, 13);
        $nLine = "{ " . $name . " }";
        $nX    = (int)(($W - strlen($nLine) * 7) / 2);
        imagestring($img, 3, $nX, 103, $nLine, $cBlack);

        $bText = "Reward: B$" . number_format((int)$bounty);
        $bX    = (int)(($W - strlen($bText) * 6) / 2);
        imagestring($img, 2, $bX, 115, $bText, $cBlack);

        $raw = "";
        for ($y = 0; $y < $H; $y++) {
            for ($x = 0; $x < $W; $x++) {
                $c    = imagecolorat($img, $x, $y);
                $raw .= chr(($c >> 16) & 0xff);
                $raw .= chr(($c >> 8)  & 0xff);
                $raw .= chr($c & 0xff);
                $raw .= chr(255);
            }
        }
        imagedestroy($img);
        return $raw;
    }

    private function createUpperBodyPortrait($skinData) {
        $len = strlen($skinData);
        if ($len === 64 * 32 * 4) {
            $skin = $this->skinDataToImage($skinData, 64, 32);
            $is64 = false;
        } elseif ($len === 64 * 64 * 4) {
            $skin = $this->skinDataToImage($skinData, 64, 64);
            $is64 = true;
        } else {
            return null;
        }
        if ($skin === null) return null;

        $out = imagecreatetruecolor(16, 20);
        imagealphablending($out, false);
        imagesavealpha($out, true);
        $trans = imagecolorallocatealpha($out, 0, 0, 0, 127);
        imagefill($out, 0, 0, $trans);
        imagealphablending($out, true);

        imagecopyresized($out, $skin, 4, 0,  8,  8, 8, 8, 8, 8);
        imagecopyresized($out, $skin, 4, 0, 40,  8, 8, 8, 8, 8);

        imagecopyresized($out, $skin, 4, 8, 20, 20, 8, 12, 8, 12);
        if ($is64) {
            imagecopyresized($out, $skin, 4, 8, 20, 36, 8, 12, 8, 12);
        }

        if ($is64) {
            imagecopyresized($out, $skin,  0, 8, 44, 20, 4, 12, 4, 12);
            imagecopyresized($out, $skin,  0, 8, 44, 36, 4, 12, 4, 12);
            imagecopyresized($out, $skin, 12, 8, 36, 52, 4, 12, 4, 12);
            imagecopyresized($out, $skin, 12, 8, 52, 52, 4, 12, 4, 12);
        } else {
            imagecopyresized($out, $skin,  0, 8, 44, 20, 4, 12, 4, 12);
            imagecopyresized($out, $skin, 12, 8, 44, 20, 4, 12, 4, 12);
        }

        imagedestroy($skin);
        return $out;
    }

    private function skinDataToImage($skinData, $width, $height) {
        $expected = $width * $height * 4;
        if (strlen($skinData) < $expected) return null;

        $img = imagecreatetruecolor($width, $height);
        imagealphablending($img, false);
        imagesavealpha($img, true);

        $i = 0;
        for ($y = 0; $y < $height; $y++) {
            for ($x = 0; $x < $width; $x++) {
                $r = ord($skinData[$i++]);
                $g = ord($skinData[$i++]);
                $b = ord($skinData[$i++]);
                $a = ord($skinData[$i++]);
                $gdAlpha = 127 - (int)floor(($a / 255) * 127);
                $color   = imagecolorallocatealpha($img, $r, $g, $b, $gdAlpha);
                imagesetpixel($img, $x, $y, $color);
            }
        }

        return $img;
    }
}