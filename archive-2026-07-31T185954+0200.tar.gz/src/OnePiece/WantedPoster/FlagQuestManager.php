<?php
namespace OnePiece\WantedPoster;

class FlagQuestManager {

    private $plugin;
    private $dataFile;
    private $quests = [];

    public function __construct(Loader $plugin) {
        $this->plugin = $plugin;
        $this->dataFile = $plugin->getDataFolder() . "flag_quests.json";
        $this->load();
    }

    private function load() {
        if (file_exists($this->dataFile)) {
            $data = json_decode(file_get_contents($this->dataFile), true);
            if (is_array($data)) {
                $this->quests = $data;
            }
        }
    }

    private function save() {
        file_put_contents($this->dataFile, json_encode($this->quests, JSON_PRETTY_PRINT));
    }

    public function hasQuest($hunterName) {
        return isset($this->quests[strtolower($hunterName)]);
    }

    public function getQuest($hunterName) {
        return isset($this->quests[strtolower($hunterName)]) ? $this->quests[strtolower($hunterName)] : null;
    }

    public function setQuest($hunterName, $targetName, $reward) {
        $this->quests[strtolower($hunterName)] = [
            "target" => strtolower($targetName),
            "reward" => (int)$reward
        ];
        $this->save();
    }

    public function removeQuest($hunterName) {
        unset($this->quests[strtolower($hunterName)]);
        $this->save();
    }
}
