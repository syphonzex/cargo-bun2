<?php
namespace OnePiece\WantedPoster\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\item\Item;
use pocketmine\nbt\tag\ByteArrayTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use OnePiece\WantedPoster\Loader;
use OnePiece\WantedPoster\storage\MapStorage;

class WantedMapCommand extends Command {

    private $plugin;

    public function __construct(Loader $plugin) {
        parent::__construct("wantedmap", "Generate a wanted poster map", "/wantedmap <player> <bounty>");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("Use in-game");
            return true;
        }

        if (count($args) < 2) {
            $sender->sendMessage("Usage: /wantedmap <player> <bounty>");
            return true;
        }

        $target = array_shift($args);
        $online = $this->plugin->getServer()->getPlayerExact($target);
        if ($online === null || !$online->isOnline()) {
            $sender->sendMessage("Player must be online");
            return true;
        }

        $bounty = preg_replace('/[^0-9]/', '', implode("", $args));
        if ($bounty === "") $bounty = 0;

        $mapId = MapStorage::get()->getNextMapId();
        $raw = $this->plugin->createPosterRaw($target, (int)$bounty);
        if ($raw === null) {
            $sender->sendMessage("Failed to generate poster");
            return true;
        }

        MapStorage::get()->saveMapData($mapId, new CompoundTag("", [
            new ByteArrayTag("rawImage", $raw)
        ]));

        $item = new Item(Item::FILLED_MAP, 0, 1);
        $item->setCustomName("Wanted Poster: " . $target);
        $item->setNamedTag(new CompoundTag("", [
            new StringTag("map_uuid", (string)$mapId),
            new ByteTag("locked_image", 1)
        ]));

        $sender->getInventory()->addItem($item);
        $sender->sendMessage("Wanted poster map created for " . $target . " bounty " . $bounty);
        return true;
    }
}