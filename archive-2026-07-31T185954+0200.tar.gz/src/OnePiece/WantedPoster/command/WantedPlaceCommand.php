<?php
namespace OnePiece\WantedPoster\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use OnePiece\WantedPoster\Loader;

class WantedPlaceCommand extends Command {

    private $plugin;

    public function __construct(Loader $plugin) {
        parent::__construct("wantedplace", "Place a wanted poster on wall", "/wantedplace <player> <bounty>");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("Use in-game");
            return true;
        }

        if (count($args) < 2) {
            $sender->sendMessage("Usage: /wantedplace <player> <bounty>");
            return true;
        }

        $target = array_shift($args);
        $online = $this->plugin->getServer()->getPlayerExact($target);
        if ($online === null || !$online->isOnline()) {
            $sender->sendMessage("Player must be online");
            return true;
        }

        $bounty = preg_replace('/[^0-9]/', '', implode("", $args));
        if ($bounty === "") $bounty = 0;

        $this->plugin->placeData[strtolower($sender->getName())] = [
            "target" => $target,
            "bounty" => (int)$bounty
        ];

        $sender->sendMessage("Tap a wall to place the wanted poster");
        return true;
    }
}