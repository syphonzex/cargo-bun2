<?php
namespace OnePiece\WantedPoster\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use OnePiece\WantedPoster\Loader;

class PosterCommand extends Command {

    private $plugin;

    public function __construct(Loader $plugin) {
        parent::__construct("poster", "Manage bounty poster spawn positions", "/poster <addpos|removepos|listpos>");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage("§cNo permission.");
            return true;
        }

        if (empty($args)) {
            $this->sendHelp($sender);
            return true;
        }

        $sub = strtolower($args[0]);

        switch ($sub) {
            case "addpos":
                return $this->handleAddPos($sender);
            case "removepos":
                return $this->handleRemovePos($sender, $args);
            case "listpos":
                return $this->handleListPos($sender);
            default:
                $this->sendHelp($sender);
                return true;
        }
    }

    private function handleAddPos(CommandSender $sender) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cIn-game only.");
            return true;
        }

        $this->plugin->addPosPending[strtolower($sender->getName())] = true;
        $sender->sendMessage("§eTap a wall block to set the poster position.");
        return true;
    }

    private function handleRemovePos(CommandSender $sender, array $args) {
        if (!isset($args[1]) || !is_numeric($args[1])) {
            $sender->sendMessage("§cUsage: /poster removepos <id>");
            return true;
        }

        $id = (int)$args[1];
        if ($this->plugin->getPosterManager()->removePosition($id)) {
            $sender->sendMessage("§aPosition #" . $id . " removed.");
        } else {
            $sender->sendMessage("§cPosition #" . $id . " not found.");
        }
        return true;
    }

    private function handleListPos(CommandSender $sender) {
        $positions = $this->plugin->getPosterManager()->getPositions();
        if (empty($positions)) {
            $sender->sendMessage("§7No poster positions set.");
            return true;
        }

        $sender->sendMessage("§6[Poster Positions]");
        foreach ($positions as $idx => $pos) {
            $active = $this->plugin->getPosterManager()->getActivePoster($idx);
            $status = $active !== null ? "§aActive: §f" . $active["player"] : "§7Empty";
            $sender->sendMessage("§f#" . ($idx + 1) . " §7" . $pos["world"] . " " . $pos["x"] . "/" . $pos["y"] . "/" . $pos["z"] . " - " . $status);
        }
        return true;
    }

    private function sendHelp(CommandSender $sender) {
        $sender->sendMessage("§6[Poster Commands]");
        $sender->sendMessage("§f/poster addpos         §7Save your position as a poster slot");
        $sender->sendMessage("§f/poster removepos <id> §7Remove a poster slot");
        $sender->sendMessage("§f/poster listpos        §7List all poster slots");
    }
}
