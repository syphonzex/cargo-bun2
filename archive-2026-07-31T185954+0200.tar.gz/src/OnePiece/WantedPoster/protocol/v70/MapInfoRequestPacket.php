<?php
namespace OnePiece\WantedPoster\protocol\v70;

use pocketmine\network\protocol\p70\DataPacket;
use pocketmine\network\protocol\p70\Info;

class MapInfoRequestPacket extends DataPacket {

    const NETWORK_ID = Info::MAP_INFO_REQUEST_PACKET;
    public $mapId;

    public function decode() {
        $this->mapId = $this->getLong();
    }

    public function encode() {
        $this->reset();
        $this->putLong($this->mapId);
    }
}