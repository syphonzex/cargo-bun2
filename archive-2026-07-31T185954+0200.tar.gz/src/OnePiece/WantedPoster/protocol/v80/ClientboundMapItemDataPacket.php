<?php
namespace OnePiece\WantedPoster\protocol\v80;

use pocketmine\network\protocol\DataPacket;
use pocketmine\network\protocol\Info;

class ClientboundMapItemDataPacket extends DataPacket {

    const NETWORK_ID = Info::CLIENTBOUND_MAP_ITEM_DATA_PACKET;
    const BITFLAG_TEXTURE_UPDATE = 0x02;

    public $mapId;
    public $scale = 0;
    public $width = 128;
    public $height = 128;
    public $xOffset = 0;
    public $yOffset = 0;
    public $colors;
    public $isColorArray = true;

    public function decode() {
    }

    public function encode() {
        $this->reset();
        $this->putLong($this->mapId);

        $type = 0x00;
        if (strlen($this->colors) > 0) {
            $type |= self::BITFLAG_TEXTURE_UPDATE;
        }

        $this->putInt($type);

        if (($type & self::BITFLAG_TEXTURE_UPDATE) !== 0) {
            $this->putByte($this->scale);
            $this->putInt($this->width);
            $this->putInt($this->height);
            $this->putInt($this->xOffset);
            $this->putInt($this->yOffset);

            if ($this->isColorArray) {
                return;
            } else {
                $this->put($this->colors);
            }
        }
    }
}