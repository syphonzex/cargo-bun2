<?php
namespace OnePiece\WantedPoster;

use pocketmine\math\Vector3;

class PosterManager {

    private $plugin;
    private $dataFile;
    private $positions = [];
    private $activePosters = [];

    public function __construct(Loader $plugin) {
        $this->plugin = $plugin;
        $this->dataFile = $plugin->getDataFolder() . "positions.json";
        $this->load();
    }

    private function load() {
        if (file_exists($this->dataFile)) {
            $data = json_decode(file_get_contents($this->dataFile), true);
            if (is_array($data)) {
                $this->positions = $data;
            }
        }
    }

    private function save() {
        file_put_contents($this->dataFile, json_encode($this->positions, JSON_PRETTY_PRINT));
    }

    public function addPosition($world, $x, $y, $z, $face) {
        $this->positions[] = [
            "world" => $world,
            "x"     => (int)$x,
            "y"     => (int)$y,
            "z"     => (int)$z,
            "face"  => (int)$face
        ];
        $this->save();
        return count($this->positions);
    }

    public function removePosition($id) {
        $idx = $id - 1;
        if (!isset($this->positions[$idx])) return false;
        array_splice($this->positions, $idx, 1);
        $this->save();
        return true;
    }

    public function getPositions() {
        return $this->positions;
    }

    public function getActivePosters() {
        return $this->activePosters;
    }

    public function getActivePoster($posIdx) {
        return isset($this->activePosters[$posIdx]) ? $this->activePosters[$posIdx] : null;
    }

    public function setActivePoster($posIdx, $playerName, $mapId) {
        $this->activePosters[$posIdx] = [
            "player" => $playerName,
            "mapId"  => $mapId
        ];
    }

    public function clearActivePoster($posIdx) {
        unset($this->activePosters[$posIdx]);
    }

    public function clearAllActivePosters() {
        $this->activePosters = [];
    }
}
