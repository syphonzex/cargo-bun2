<?php
namespace OnePiece\WantedPoster;

use pocketmine\block\Block;
use pocketmine\block\ItemFrame as ItemFrameBlock;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\entity\Item as ItemEntity;
use pocketmine\event\entity\EntitySpawnEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\item\Item;
use pocketmine\nbt\tag\ByteArrayTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;
use pocketmine\tile\ItemFrame as ItemFrameTile;
use pocketmine\tile\Tile;
use OnePiece\WantedPoster\protocol\v80\ClientboundMapItemDataPacket;
use OnePiece\WantedPoster\protocol\v80\MapInfoRequestPacket;
use OnePiece\WantedPoster\protocol\v70\ClientboundMapItemDataPacket as Cv70;
use OnePiece\WantedPoster\protocol\v70\MapInfoRequestPacket as Mv70;
use OnePiece\WantedPoster\storage\MapStorage;

class EventListener implements Listener {

    /** @priority NORMAL */
    public function onReceive(DataPacketReceiveEvent $event) {
        $packet = $event->getPacket();

        if ($packet instanceof MapInfoRequestPacket) {
            $nbt = MapStorage::get()->getMapData($packet->mapId);
            if ($nbt instanceof CompoundTag && isset($nbt["rawImage"])) {
                $pk = new ClientboundMapItemDataPacket();
                $pk->colors = $nbt["rawImage"];
                $pk->isColorArray = false;
                $pk->mapId = $packet->mapId;
                $event->getPlayer()->dataPacket($pk);
            }
        } elseif ($packet instanceof Mv70) {
            $nbt = MapStorage::get()->getMapData($packet->mapId);
            if ($nbt instanceof CompoundTag && isset($nbt["rawImage"])) {
                $pk = new Cv70();
                $pk->colors = $nbt["rawImage"];
                $pk->isColorArray = false;
                $pk->mapId = $packet->mapId;
                $event->getPlayer()->dataPacket($pk);
            }
        }
    }

    /** @priority NORMAL */
    public function onInteract(PlayerInteractEvent $event) {
        $player = $event->getPlayer();
        $block  = $event->getBlock();
        $loader = Loader::get();
        $name   = strtolower($player->getName());

        if (isset($loader->addPosPending[$name])) {
            if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
                $tappedFace = $event->getFace();

                // Only allow wall faces (not top/bottom)
                if ($tappedFace < 2) {
                    $player->sendMessage("§cTap a wall side (not top or bottom).");
                    $event->setCancelled(true);
                    return;
                }

                $wallBlock = $event->getBlock();

                // Frame goes on the air block adjacent to the wall, on the tapped face
                $frameBlock = $wallBlock->getSide($tappedFace);
                $world      = $wallBlock->getLevel()->getFolderName();

                // Meta: same mapping PMMP uses in ItemFrame::place()
                $faceMeta = [2 => 3, 3 => 2, 4 => 1, 5 => 0];
                $frameFace = $faceMeta[$tappedFace];

                $id = $loader->getPosterManager()->addPosition(
                    $world,
                    $frameBlock->x, $frameBlock->y, $frameBlock->z,
                    $frameFace
                );

                $player->sendMessage("§aPoster position #" . $id . " set at §f" . $frameBlock->x . "/" . $frameBlock->y . "/" . $frameBlock->z . " §ain §f" . $world . " §7(face=" . $frameFace . ")");
                unset($loader->addPosPending[$name]);
                $event->setCancelled(true);
                return;
            }
        }

        if ($block->getId() === Block::ITEM_FRAME_BLOCK) {
            $tile = $block->getLevel()->getTile($block);
            if ($tile instanceof ItemFrameTile) {
                $item = $tile->getItem();
                if ($item !== null && $item->getId() === Item::FILLED_MAP) {
                    $tag = $item->getNamedTag();
                    if ($tag instanceof CompoundTag && isset($tag["locked_image"]) && (int)$tag["locked_image"] === 1) {
                        $event->setCancelled(true);
                        $tile->spawnTo($player);

                        if (isset($tag["wanted_player"]) && isset($tag["wanted_bounty"])) {
                            $this->handleFlagQuest($player, (string)$tag["wanted_player"], (int)$tag["wanted_bounty"]);
                        }
                        return;
                    }
                }
            }
        }

        if ($event->getAction() !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;

        if (!isset($loader->placeData[$name])) return;

        $data = $loader->placeData[$name];
        $face = $event->getFace();
        $pos  = $block->getSide($face);

        $faces = [2 => 3, 3 => 2, 4 => 1, 5 => 0];

        if (!isset($faces[$face])) {
            $player->sendMessage("Tap a wall side");
            $event->setCancelled(true);
            return;
        }

        $frameFace = $faces[$face];
        $player->getLevel()->setBlock($pos, new ItemFrameBlock($frameFace), true, true);

        $nbt = new CompoundTag("", [
            new StringTag("id", Tile::ITEM_FRAME),
            new IntTag("x", $pos->x),
            new IntTag("y", $pos->y),
            new IntTag("z", $pos->z),
            new ByteTag("ItemRotation", 0),
            new FloatTag("ItemDropChance", 0.0)
        ]);

        $tile = Tile::createTile(
            Tile::ITEM_FRAME,
            $player->level->getChunk($pos->x >> 4, $pos->z >> 4),
            $nbt
        );

        $mapId = MapStorage::get()->getNextMapId();
        $raw   = $loader->createPosterRaw($data["target"], $data["bounty"]);
        if ($raw === null) {
            $player->sendMessage("Target player must be online");
            unset($loader->placeData[$name]);
            $event->setCancelled(true);
            return;
        }

        MapStorage::get()->saveMapData($mapId, new CompoundTag("", [
            new ByteArrayTag("rawImage", $raw)
        ]));

        $item = new Item(Item::FILLED_MAP, 0, 1);
        $item->setNamedTag(new CompoundTag("", [
            new StringTag("map_uuid", (string)$mapId),
            new ByteTag("locked_image", 1)
        ]));

        if ($tile instanceof ItemFrameTile) {
            $tile->setItem($item, true);
            $tile->spawnToAll();
        }

        $player->sendMessage("Wanted poster placed");
        unset($loader->placeData[$name]);
        $event->setCancelled(true);
    }

    /** @priority NORMAL */
    public function onPlayerDeath(PlayerDeathEvent $event) {
        $victim = $event->getEntity();
        if (!($victim instanceof Player)) return;

        $cause = $victim->getLastDamageCause();
        if (!($cause instanceof EntityDamageByEntityEvent)) return;

        $killer = $cause->getDamager();
        if (!($killer instanceof Player)) return;
        if ($killer->getName() === $victim->getName()) return;

        $loader = Loader::get();
        $fqm    = $loader->getFlagQuestManager();
        $killerName = $killer->getName();
        $victimName = strtolower($victim->getName());

        $quest = $fqm->getQuest($killerName);
        if ($quest === null) return;

        if ($quest["target"] !== $victimName) return;

        $reward = $quest["reward"];
        $fqm->removeQuest($killerName);

        $berryPlugin = $loader->getServer()->getPluginManager()->getPlugin("OnePieceBerry");
        if ($berryPlugin !== null) {
            $berryPlugin->getBerryManager()->add($killerName, $reward);
        }

        $killer->sendMessage("");
        $killer->sendMessage("§6★ §eBounty Collected!");
        $killer->sendMessage("§7You hunted down §f" . $victim->getName() . " §7and earned §6" . number_format($reward) . " Berries§7!");
        $killer->sendMessage("");
    }

    private function handleFlagQuest(Player $player, $targetName, $bounty) {
        $loader  = Loader::get();
        $fqm     = $loader->getFlagQuestManager();
        $hunter  = $player->getName();

        if (strtolower($hunter) === $targetName) {
            $player->sendMessage("§cYou can't place a bounty on yourself.");
            return;
        }

        $reward = $bounty * 10;

        if ($fqm->hasQuest($hunter)) {
            $existing = $fqm->getQuest($hunter);
            if ($existing["target"] === $targetName) {
                $player->sendMessage("§eYou already have a bounty flag on §f" . $targetName . "§e.");
                $player->sendMessage("§7Kill them to earn §6" . number_format($existing["reward"]) . " Berries§7.");
                return;
            }
            $fqm->removeQuest($hunter);
        }

        $fqm->setQuest($hunter, $targetName, $reward);

        $player->sendMessage("");
        $player->sendMessage("§6[Bounty Flag]");
        $player->sendMessage("§eTarget: §f" . $targetName);
        $player->sendMessage("§eReward: §6" . number_format($reward) . " Berries");
        $player->sendMessage("§7Kill this player to collect the reward!");
        $player->sendMessage("");
    }

    /**
     * @priority NORMAL
     */
    public function onPlayerJoin(PlayerJoinEvent $event) {
        $player = $event->getPlayer();
        $loader = Loader::get();
        if ($loader !== null && $loader->hasRadarPass($player->getName())) {
            $loader->activateRadarForPlayer($player->getName());
        }
    }

    /**
     * @priority NORMAL
     */
    /**
     * @priority NORMAL
     */
public function onEntitySpawn(EntitySpawnEvent $event) {
    $entity = $event->getEntity();
    if (!($entity instanceof ItemEntity)) return;
    $item = $entity->getItem();
    if ($item === null) return;
    if ($item->getId() !== \pocketmine\item\Item::GOLDEN_APPLE) return;
    $name = $item->getCustomName();
    if ($name === null || $name === "") return;
    $ref = new \ReflectionProperty(ItemEntity::class, "age");
    $ref->setAccessible(true);
    $ref->setValue($entity, -10000);
}
}