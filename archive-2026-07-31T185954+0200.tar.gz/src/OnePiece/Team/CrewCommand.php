<?php
namespace OnePiece\Team;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class CrewCommand extends Command {

    private $crewManager;

    public function __construct(CrewManager $manager) {
        parent::__construct("crew");
        $this->crewManager = $manager;
        $this->setDescription("Manage your crew");
        $this->setUsage("/crew <create|invite|accept|decline|leave|kick|info|list|disband>");
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage(TextFormat::RED . "In-game only.");
            return true;
        }

        if (empty($args)) {
            $this->showHelp($sender);
            return true;
        }

        $sub = strtolower($args[0]);

        switch ($sub) {

            case "create":
                if (!isset($args[1])) {
                    $sender->sendMessage(TextFormat::RED . "Usage: /crew create <name>");
                    return true;
                }
                $crewName = $args[1];
                $result   = $this->crewManager->createCrew($crewName, $sender->getName());
                switch ($result) {
                    case "exists":
                        $sender->sendMessage(TextFormat::RED . "A crew named '" . $crewName . "' already exists.");
                        break;
                    case "already_in":
                        $sender->sendMessage(TextFormat::RED . "You are already in a crew. Leave it first.");
                        break;
                    case "ok":
                        $sender->sendMessage(TextFormat::GREEN . "Crew '" . $crewName . "' created! You are the Captain.");
                        break;
                }
                return true;

            case "invite":
                if (!isset($args[1])) {
                    $sender->sendMessage(TextFormat::RED . "Usage: /crew invite <player>");
                    return true;
                }
                $myCrewKey = $this->crewManager->getCrewOf($sender->getName());
                if ($myCrewKey === null) {
                    $sender->sendMessage(TextFormat::RED . "You are not in a crew.");
                    return true;
                }
                $crew = $this->crewManager->getCrew($myCrewKey);
                if (!$this->crewManager->isOwner($sender->getName(), $myCrewKey)) {
                    $sender->sendMessage(TextFormat::RED . "Only the crew Captain can invite players.");
                    return true;
                }
                $target = $sender->getServer()->getPlayerExact($args[1]);
                if ($target === null || !$target->isOnline()) {
                    $sender->sendMessage(TextFormat::RED . $args[1] . " is not online.");
                    return true;
                }
                $result = $this->crewManager->invitePlayer($myCrewKey, $target->getName());
                switch ($result) {
                    case "no_crew":
                        $sender->sendMessage(TextFormat::RED . "Crew not found.");
                        break;
                    case "full":
                        $sender->sendMessage(TextFormat::RED . "Your crew is full (" . CrewManager::MAX_CREW_SIZE . " members).");
                        break;
                    case "target_in_crew":
                        $sender->sendMessage(TextFormat::RED . $target->getName() . " is already in a crew.");
                        break;
                    case "ok":
                        $sender->sendMessage(TextFormat::GREEN . "Invited " . $target->getName() . " to your crew.");
                        $target->sendMessage(TextFormat::GOLD . "[Crew] " . $sender->getName() . " invited you to join '" . $crew["name"] . "'!");
                        $target->sendMessage(TextFormat::YELLOW . "Type /crew accept to join or /crew decline to refuse.");
                        break;
                }
                return true;

            case "accept":
                if (!$this->crewManager->hasInvite($sender->getName())) {
                    $sender->sendMessage(TextFormat::RED . "You have no pending crew invite.");
                    return true;
                }
                $crewKey = $this->crewManager->getInviteFrom($sender->getName());
                $result  = $this->crewManager->acceptInvite($sender->getName());
                switch ($result) {
                    case "no_invite":
                        $sender->sendMessage(TextFormat::RED . "No invite found.");
                        break;
                    case "crew_gone":
                        $sender->sendMessage(TextFormat::RED . "That crew no longer exists.");
                        break;
                    case "full":
                        $sender->sendMessage(TextFormat::RED . "The crew is full.");
                        break;
                    case "already_in":
                        $sender->sendMessage(TextFormat::RED . "You are already in a crew.");
                        break;
                    case "ok":
                        $crew = $this->crewManager->getCrew($crewKey);
                        $crewDisplayName = $crew !== null ? $crew["name"] : $crewKey;
                        $sender->sendMessage(TextFormat::GREEN . "You joined crew '" . $crewDisplayName . "'!");
                        foreach ($sender->getServer()->getOnlinePlayers() as $p) {
                            if ($this->crewManager->areCrewmates($p->getName(), $sender->getName())) {
                                $p->sendMessage(TextFormat::GOLD . "[Crew] " . $sender->getName() . " joined the crew!");
                            }
                        }
                        break;
                }
                return true;

            case "decline":
                if (!$this->crewManager->hasInvite($sender->getName())) {
                    $sender->sendMessage(TextFormat::RED . "You have no pending crew invite.");
                    return true;
                }
                $this->crewManager->declineInvite($sender->getName());
                $sender->sendMessage(TextFormat::YELLOW . "Crew invite declined.");
                return true;

            case "leave":
                $result = $this->crewManager->leaveCrew($sender->getName());
                switch ($result) {
                    case "not_in":
                        $sender->sendMessage(TextFormat::RED . "You are not in a crew.");
                        break;
                    case "disbanded":
                        $sender->sendMessage(TextFormat::YELLOW . "You were the Captain. Crew disbanded.");
                        break;
                    case "ok":
                        $sender->sendMessage(TextFormat::YELLOW . "You left your crew.");
                        break;
                }
                return true;

            case "kick":
                if (!isset($args[1])) {
                    $sender->sendMessage(TextFormat::RED . "Usage: /crew kick <player>");
                    return true;
                }
                $myCrewKey = $this->crewManager->getCrewOf($sender->getName());
                if ($myCrewKey === null) {
                    $sender->sendMessage(TextFormat::RED . "You are not in a crew.");
                    return true;
                }
                if (!$this->crewManager->isOwner($sender->getName(), $myCrewKey)) {
                    $sender->sendMessage(TextFormat::RED . "Only the Captain can kick members.");
                    return true;
                }
                $result = $this->crewManager->kickMember($myCrewKey, $args[1]);
                switch ($result) {
                    case "no_crew":
                        $sender->sendMessage(TextFormat::RED . "Crew not found.");
                        break;
                    case "not_member":
                        $sender->sendMessage(TextFormat::RED . $args[1] . " is not in your crew.");
                        break;
                    case "cant_kick_owner":
                        $sender->sendMessage(TextFormat::RED . "You cannot kick yourself. Use /crew leave.");
                        break;
                    case "ok":
                        $sender->sendMessage(TextFormat::YELLOW . "Kicked " . $args[1] . " from the crew.");
                        $kicked = $sender->getServer()->getPlayerExact($args[1]);
                        if ($kicked !== null && $kicked->isOnline()) {
                            $kicked->sendMessage(TextFormat::RED . "[Crew] You were kicked from the crew by " . $sender->getName() . ".");
                        }
                        break;
                }
                return true;

            case "disband":
                $myCrewKey = $this->crewManager->getCrewOf($sender->getName());
                if ($myCrewKey === null) {
                    $sender->sendMessage(TextFormat::RED . "You are not in a crew.");
                    return true;
                }
                if (!$this->crewManager->isOwner($sender->getName(), $myCrewKey)) {
                    $sender->sendMessage(TextFormat::RED . "Only the Captain can disband the crew.");
                    return true;
                }
                $crew = $this->crewManager->getCrew($myCrewKey);
                foreach ($crew["members"] as $m) {
                    $mp = $sender->getServer()->getPlayerExact($m);
                    if ($mp !== null && $mp->isOnline() && $mp->getName() !== $sender->getName()) {
                        $mp->sendMessage(TextFormat::RED . "[Crew] The crew was disbanded by the Captain.");
                    }
                }
                $this->crewManager->disbandCrew($myCrewKey);
                $sender->sendMessage(TextFormat::YELLOW . "Crew disbanded.");
                return true;

            case "info":
                $crewKey = $this->crewManager->getCrewOf($sender->getName());
                if (isset($args[1])) $crewKey = strtolower($args[1]);
                if ($crewKey === null) {
                    $sender->sendMessage(TextFormat::RED . "You are not in a crew. Use /crew info <name> to look up a crew.");
                    return true;
                }
                $crew = $this->crewManager->getCrew($crewKey);
                if ($crew === null) {
                    $sender->sendMessage(TextFormat::RED . "Crew not found.");
                    return true;
                }
                $bountyPlugin = $sender->getServer()->getPluginManager()->getPlugin("OnePieceBounty");
                $total        = $this->crewManager->getCrewTotalBounty($crewKey, $bountyPlugin);

                $sender->sendMessage(TextFormat::GOLD . "=== " . $crew["name"] . " ===");
                $sender->sendMessage(TextFormat::YELLOW . "Captain: " . TextFormat::WHITE . $crew["owner"]);
                $sender->sendMessage(TextFormat::YELLOW . "Members: " . TextFormat::WHITE . count($crew["members"]) . "/" . CrewManager::MAX_CREW_SIZE);
                $sender->sendMessage(TextFormat::YELLOW . "Total Bounty: " . TextFormat::GOLD . number_format($total) . " Berries");
$sender->sendMessage(TextFormat::YELLOW . "Roster:");
$allBounties = $bountyPlugin !== null ? $bountyPlugin->getBountyManager()->getTopBounties(99999) : [];
foreach ($crew["members"] as $m) {
    $online = $sender->getServer()->getPlayerExact($m) !== null ? TextFormat::GREEN . "(online)" : TextFormat::GRAY . "(offline)";
    $memberBounty = 0;
    foreach ($allBounties as $bName => $bAmount) {
        if (strtolower($bName) === strtolower($m)) {
            $memberBounty = $bAmount;
            break;
        }
    }
    $bounty = $bountyPlugin !== null ? TextFormat::GOLD . number_format($memberBounty) . "B" : "";
    $captain = ($m === $crew["owner"]) ? TextFormat::GOLD . " [Captain]" : "";
    $sender->sendMessage(TextFormat::WHITE . "  " . $m . " " . $online . " " . $bounty . $captain);
}
                return true;

            case "list":
                $crews = $this->crewManager->getAllCrews();
                if (empty($crews)) {
                    $sender->sendMessage(TextFormat::YELLOW . "No crews exist yet.");
                    return true;
                }
                $bountyPlugin = $sender->getServer()->getPluginManager()->getPlugin("OnePieceBounty");
                $sender->sendMessage(TextFormat::GOLD . "=== All Crews ===");
                foreach ($crews as $key => $crew) {
                    $total = $this->crewManager->getCrewTotalBounty($key, $bountyPlugin);
                    $sender->sendMessage(TextFormat::YELLOW . $crew["name"] . TextFormat::GRAY . " (" . count($crew["members"]) . " members) " . TextFormat::GOLD . number_format($total) . "B");
                }
                return true;

            default:
                $this->showHelp($sender);
                return true;
        }
    }

    private function showHelp(Player $player) {
        $player->sendMessage(TextFormat::GOLD . "=== Crew System ===");
        $player->sendMessage(TextFormat::YELLOW . "/crew create <name> " . TextFormat::GRAY . "- Create a crew");
        $player->sendMessage(TextFormat::YELLOW . "/crew invite <player> " . TextFormat::GRAY . "- Invite a player");
        $player->sendMessage(TextFormat::YELLOW . "/crew accept " . TextFormat::GRAY . "- Accept invite");
        $player->sendMessage(TextFormat::YELLOW . "/crew decline " . TextFormat::GRAY . "- Decline invite");
        $player->sendMessage(TextFormat::YELLOW . "/crew leave " . TextFormat::GRAY . "- Leave crew");
        $player->sendMessage(TextFormat::YELLOW . "/crew kick <player> " . TextFormat::GRAY . "- Kick member");
        $player->sendMessage(TextFormat::YELLOW . "/crew disband " . TextFormat::GRAY . "- Disband crew");
        $player->sendMessage(TextFormat::YELLOW . "/crew info [name] " . TextFormat::GRAY . "- Crew info");
        $player->sendMessage(TextFormat::YELLOW . "/crew list " . TextFormat::GRAY . "- List all crews");
    }
}