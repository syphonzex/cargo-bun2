<?php
namespace OnePiece\Team;

class AllyManager {

    private $plugin;
    private $allies  = [];
    private $dataPath;

    const MAX_ALLIES = 4;

    public function __construct($plugin) {
        $this->plugin   = $plugin;
        $this->dataPath = $plugin->getDataFolder() . "allies.json";
        $this->load();
    }

    private function load() {
        if (!file_exists($this->dataPath)) return;
        $data = json_decode(file_get_contents($this->dataPath), true);
        if (is_array($data)) $this->allies = $data;
    }

    public function save() {
        file_put_contents($this->dataPath, json_encode($this->allies, JSON_PRETTY_PRINT));
    }

    public function addAlly($playerName, $targetName) {
        $a = strtolower($playerName);
        $b = strtolower($targetName);

        if (!isset($this->allies[$a])) $this->allies[$a] = [];
        if (!isset($this->allies[$b])) $this->allies[$b] = [];

        if (in_array($b, $this->allies[$a])) return "already";
        if (count($this->allies[$a]) >= self::MAX_ALLIES) return "full_a";
        if (count($this->allies[$b]) >= self::MAX_ALLIES) return "full_b";

        $this->allies[$a][] = $b;
        $this->allies[$b][] = $a;
        $this->save();
        return "ok";
    }

    public function removeAlly($playerName, $targetName) {
        $a = strtolower($playerName);
        $b = strtolower($targetName);

        if (isset($this->allies[$a])) {
            $this->allies[$a] = array_values(array_filter($this->allies[$a], function($n) use ($b) { return $n !== $b; }));
        }
        if (isset($this->allies[$b])) {
            $this->allies[$b] = array_values(array_filter($this->allies[$b], function($n) use ($a) { return $n !== $a; }));
        }
        $this->save();
    }

public function areAllies($nameA, $nameB) {
    if (!$this->isInAllowedWorld($nameA) || !$this->isInAllowedWorld($nameB)) {
        return false;
    }

    $a = strtolower($nameA);
    $b = strtolower($nameB);

    return isset($this->allies[$a]) && in_array($b, $this->allies[$a]);
}

private function isInAllowedWorld($playerName) {
    $player = $this->plugin->getServer()->getPlayerExact($playerName);
    if ($player === null || !$player->isOnline()) {
        return true;
    }

    return in_array($player->getLevel()->getName(), ["OP", "Sea2", "sea3"]);
}

    public function getAllies($playerName) {
        $name = strtolower($playerName);
        return isset($this->allies[$name]) ? $this->allies[$name] : [];
    }

    public function removeAllAllies($playerName) {
        $name = strtolower($playerName);
        if (!isset($this->allies[$name])) return;
        foreach ($this->allies[$name] as $other) {
            if (isset($this->allies[$other])) {
                $this->allies[$other] = array_values(array_filter($this->allies[$other], function($n) use ($name) { return $n !== $name; }));
            }
        }
        unset($this->allies[$name]);
        $this->save();
    }
}