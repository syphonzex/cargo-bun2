<?php
namespace OnePiece\Team;

use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class TeamListener implements Listener {

    private $allyManager;
    private $crewManager;

    public function __construct(AllyManager $ally, CrewManager $crew) {
        $this->allyManager = $ally;
        $this->crewManager = $crew;
    }

    public function onEntityDamage(EntityDamageEvent $event) {
        if (!($event instanceof EntityDamageByEntityEvent)) return;

        $damager = $event->getDamager();
        $victim  = $event->getEntity();

        if (!($damager instanceof Player) || !($victim instanceof Player)) return;

        $damagerName = $damager->getName();
        $victimName  = $victim->getName();

        if ($this->isAbilityDamage($damager)) return;

        $inFriendlyPvP = $this->areInFriendlyPvPTogether($damagerName, $victimName);
        if ($inFriendlyPvP) return;

        if ($this->allyManager->areAllies($damagerName, $victimName)) {
            $event->setCancelled(true);
            $damager->sendTip(TextFormat::YELLOW . "You cannot harm your ally!");
            return;
        }

        if ($this->crewManager->areCrewmates($damagerName, $victimName)) {
            $event->setCancelled(true);
            $damager->sendTip(TextFormat::GOLD . "You cannot harm your crewmate!");
            return;
        }
    }

    private function isAbilityDamage(Player $damager) {
        $devilPlugin = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin === null || !$devilPlugin->isEnabled()) return false;
        return $devilPlugin->getAbilityDamage($damager->getName()) !== null;
    }

    private function areInFriendlyPvPTogether($nameA, $nameB) {
        $combatPlugin = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin("OnePieceCombat");
        if ($combatPlugin === null || !$combatPlugin->isEnabled()) return false;

        $manager = $combatPlugin->getFriendlyPvPManager();
        if ($manager === null) return false;

        if (!$manager->isInFriendlyPvP($nameA) || !$manager->isInFriendlyPvP($nameB)) return false;

        $opponent = $manager->getFriendlyOpponent($nameA);
        return $opponent !== null && strtolower($opponent) === strtolower($nameB);
    }

    public function onPlayerQuit(PlayerQuitEvent $event) {
    }
}