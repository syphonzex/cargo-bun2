<?php
namespace OnePiece\Team;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class AllyCommand extends Command {

    private $allyManager;

    public function __construct(AllyManager $manager) {
        parent::__construct("ally");
        $this->allyManager = $manager;
        $this->setDescription("Manage your allies");
        $this->setUsage("/ally <player|remove <player>|list|clear>");
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage(TextFormat::RED . "In-game only.");
            return true;
        }

        if (empty($args)) {
            $this->showHelp($sender);
            return true;
        }

        $sub = strtolower($args[0]);

        if ($sub === "list") {
            $allies = $this->allyManager->getAllies($sender->getName());
            if (empty($allies)) {
                $sender->sendMessage(TextFormat::YELLOW . "You have no allies.");
                return true;
            }
            $sender->sendMessage(TextFormat::GOLD . "Your allies (" . count($allies) . "/" . AllyManager::MAX_ALLIES . "):");
            foreach ($allies as $a) {
                $sender->sendMessage(TextFormat::YELLOW . "  " . $a);
            }
            return true;
        }

        if ($sub === "remove") {
            if (!isset($args[1])) {
                $sender->sendMessage(TextFormat::RED . "Usage: /ally remove <player>");
                return true;
            }
            $target = $args[1];
            if (!$this->allyManager->areAllies($sender->getName(), $target)) {
                $sender->sendMessage(TextFormat::RED . $target . " is not your ally.");
                return true;
            }
            $this->allyManager->removeAlly($sender->getName(), $target);
            $sender->sendMessage(TextFormat::YELLOW . "Removed " . $target . " from allies.");
            $targetPlayer = $sender->getServer()->getPlayerExact($target);
            if ($targetPlayer !== null && $targetPlayer->isOnline()) {
                $targetPlayer->sendMessage(TextFormat::YELLOW . $sender->getName() . " removed you as an ally.");
            }
            return true;
        }

        if ($sub === "clear") {
            $this->allyManager->removeAllAllies($sender->getName());
            $sender->sendMessage(TextFormat::YELLOW . "All allies cleared.");
            return true;
        }

        $targetName = $args[0];
        if (strtolower($targetName) === strtolower($sender->getName())) {
            $sender->sendMessage(TextFormat::RED . "You cannot ally yourself.");
            return true;
        }

        $target = $sender->getServer()->getPlayerExact($targetName);
        if ($target === null || !$target->isOnline()) {
            $sender->sendMessage(TextFormat::RED . $targetName . " is not online.");
            return true;
        }

        $result = $this->allyManager->addAlly($sender->getName(), $target->getName());
        switch ($result) {
            case "already":
                $sender->sendMessage(TextFormat::YELLOW . $target->getName() . " is already your ally.");
                break;
            case "full_a":
                $sender->sendMessage(TextFormat::RED . "You have reached the ally limit (" . AllyManager::MAX_ALLIES . ").");
                break;
            case "full_b":
                $sender->sendMessage(TextFormat::RED . $target->getName() . " has reached their ally limit.");
                break;
            case "ok":
                $sender->sendMessage(TextFormat::GREEN . $target->getName() . " is now your ally! You cannot damage each other.");
                $target->sendMessage(TextFormat::GREEN . $sender->getName() . " added you as an ally! You cannot damage each other.");
                break;
        }
        return true;
    }

    private function showHelp(Player $player) {
        $player->sendMessage(TextFormat::GOLD . "=== Ally System ===");
        $player->sendMessage(TextFormat::YELLOW . "/ally <player> " . TextFormat::GRAY . "- Add ally");
        $player->sendMessage(TextFormat::YELLOW . "/ally remove <player> " . TextFormat::GRAY . "- Remove ally");
        $player->sendMessage(TextFormat::YELLOW . "/ally list " . TextFormat::GRAY . "- List allies");
        $player->sendMessage(TextFormat::YELLOW . "/ally clear " . TextFormat::GRAY . "- Clear all allies");
    }
}