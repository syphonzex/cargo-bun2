<?php
namespace OnePiece\Team;

class CrewManager {

    private $plugin;
    private $crews    = [];
    private $members  = [];
    private $invites  = [];
    private $dataPath;

    const MAX_CREW_SIZE = 10;

    public function __construct($plugin) {
        $this->plugin   = $plugin;
        $this->dataPath = $plugin->getDataFolder() . "crews.json";
        $this->load();
    }

    private function load() {
        if (!file_exists($this->dataPath)) return;
        $data = json_decode(file_get_contents($this->dataPath), true);
        if (!is_array($data)) return;

        $this->crews = isset($data["crews"]) ? $data["crews"] : [];
        foreach ($this->crews as $crewName => $crew) {
            foreach ($crew["members"] as $member) {
                $this->members[strtolower($member)] = $crewName;
            }
        }
    }

    public function save() {
        file_put_contents($this->dataPath, json_encode(["crews" => $this->crews], JSON_PRETTY_PRINT));
    }

    public function createCrew($crewName, $ownerName) {
        $key = strtolower($crewName);
        if (isset($this->crews[$key])) return "exists";
        if ($this->getCrewOf($ownerName) !== null) return "already_in";

        $this->crews[$key] = [
            "name"    => $crewName,
            "owner"   => strtolower($ownerName),
            "members" => [strtolower($ownerName)]
        ];
        $this->members[strtolower($ownerName)] = $key;
        $this->save();
        return "ok";
    }

    public function disbandCrew($crewName) {
        $key = strtolower($crewName);
        if (!isset($this->crews[$key])) return;
        foreach ($this->crews[$key]["members"] as $m) {
            unset($this->members[strtolower($m)]);
        }
        unset($this->crews[$key]);
        $this->save();
    }

    public function invitePlayer($crewName, $targetName) {
        $key = strtolower($crewName);
        if (!isset($this->crews[$key])) return "no_crew";
        if (count($this->crews[$key]["members"]) >= self::MAX_CREW_SIZE) return "full";
        if ($this->getCrewOf($targetName) !== null) return "target_in_crew";

        $this->invites[strtolower($targetName)] = $key;
        return "ok";
    }

    public function acceptInvite($playerName) {
        $name = strtolower($playerName);
        if (!isset($this->invites[$name])) return "no_invite";
        $key = $this->invites[$name];
        unset($this->invites[$name]);

        if (!isset($this->crews[$key])) return "crew_gone";
        if (count($this->crews[$key]["members"]) >= self::MAX_CREW_SIZE) return "full";
        if ($this->getCrewOf($playerName) !== null) return "already_in";

        $this->crews[$key]["members"][] = $name;
        $this->members[$name] = $key;
        $this->save();
        return "ok";
    }

    public function declineInvite($playerName) {
        unset($this->invites[strtolower($playerName)]);
    }

    public function hasInvite($playerName) {
        return isset($this->invites[strtolower($playerName)]);
    }

    public function getInviteFrom($playerName) {
        $name = strtolower($playerName);
        if (!isset($this->invites[$name])) return null;
        return $this->invites[$name];
    }

    public function leaveCrew($playerName) {
        $name = strtolower($playerName);
        $key  = isset($this->members[$name]) ? $this->members[$name] : null;
        if ($key === null) return "not_in";

        if ($this->crews[$key]["owner"] === $name) {
            $this->disbandCrew($key);
            return "disbanded";
        }

        $this->crews[$key]["members"] = array_values(array_filter($this->crews[$key]["members"], function($m) use ($name) { return $m !== $name; }));
        unset($this->members[$name]);
        $this->save();
        return "ok";
    }

    public function kickMember($crewName, $targetName) {
        $key  = strtolower($crewName);
        $name = strtolower($targetName);
        if (!isset($this->crews[$key])) return "no_crew";
        if (!in_array($name, $this->crews[$key]["members"])) return "not_member";
        if ($this->crews[$key]["owner"] === $name) return "cant_kick_owner";

        $this->crews[$key]["members"] = array_values(array_filter($this->crews[$key]["members"], function($m) use ($name) { return $m !== $name; }));
        unset($this->members[$name]);
        $this->save();
        return "ok";
    }

    public function getCrewOf($playerName) {
        $name = strtolower($playerName);
        return isset($this->members[$name]) ? $this->members[$name] : null;
    }

    public function getCrew($crewName) {
        $key = strtolower($crewName);
        return isset($this->crews[$key]) ? $this->crews[$key] : null;
    }

public function areCrewmates($nameA, $nameB) {
    if (!$this->isInAllowedWorld($nameA) || !$this->isInAllowedWorld($nameB)) {
        return false;
    }

    $crewA = $this->getCrewOf($nameA);
    $crewB = $this->getCrewOf($nameB);

    if ($crewA === null || $crewB === null) return false;

    return $crewA === $crewB;
}

private function isInAllowedWorld($playerName) {
    $player = $this->plugin->getServer()->getPlayerExact($playerName);
    if ($player === null || !$player->isOnline()) {
        return true;
    }

    return in_array($player->getLevel()->getName(), ["OP", "Sea2", "sea3"]);
}

    public function isOwner($playerName, $crewName) {
        $key = strtolower($crewName);
        if (!isset($this->crews[$key])) return false;
        return $this->crews[$key]["owner"] === strtolower($playerName);
    }

public function getCrewTotalBounty($crewName, $bountyPlugin) {
    $key = strtolower($crewName);
    if (!isset($this->crews[$key])) return 0;
    if ($bountyPlugin === null) return 0;
    $bm = $bountyPlugin->getBountyManager();
    if ($bm === null) return 0;
    $total = 0;
    $allBounties = $bm->getTopBounties(99999);
    foreach ($this->crews[$key]["members"] as $member) {
        foreach ($allBounties as $bName => $bAmount) {
            if (strtolower($bName) === strtolower($member)) {
                $total += $bAmount;
                break;
            }
        }
    }
    return $total;
}

    public function getAllCrews() { return $this->crews; }
}