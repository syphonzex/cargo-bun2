<?php
namespace OnePiece\Gamepasses;

use pocketmine\Server;

class GamepassManager {

    private $plugin;
    private $dataFile;
    private $data = [];

    const WORLD_BOSSES = [
        "OP"   => ["enel", "law"],
        "Sea2" => ["swan", "diamond", "aokiji", "whitebeard"],
    ];

    const PASS_FRUIT_NOTIFIER  = "fruit_notifier";
    const PASS_EXP_2X_15       = "exp_2x_15";
    const PASS_EXP_2X_30       = "exp_2x_30";
    const PASS_EXP_2X_60       = "exp_2x_60";
    const PASS_BOSS_RESPAWN    = "boss_respawn";
    const PASS_STORAGE_PLUS    = "storage_plus";

    const EXP_PASS_DURATIONS = [
        self::PASS_EXP_2X_15 => 900,   // 15 minutes
        self::PASS_EXP_2X_30 => 1800,  // 30 minutes
        self::PASS_EXP_2X_60 => 3600,  // 60 minutes
    ];

    public function __construct($plugin) {
        $this->plugin   = $plugin;
        $this->dataFile = $plugin->getDataFolder() . "gamepasses.json";
        $this->load();
    }

    private function load() {
        if (file_exists($this->dataFile)) {
            $d = json_decode(file_get_contents($this->dataFile), true);
            if (is_array($d)) $this->data = $d;
        }
    }

    public function save() {
        file_put_contents($this->dataFile, json_encode($this->data, JSON_PRETTY_PRINT));
    }

    private function getPlayerData($name) {
        $key = strtolower($name);
        if (!isset($this->data[$key])) {
            $this->data[$key] = [];
        }
        return $this->data[$key];
    }

    private function setPlayerData($name, array $d) {
        $this->data[strtolower($name)] = $d;
        $this->save();
    }

    public function hasPass($playerName, $pass) {
        $d = $this->getPlayerData($playerName);
        return isset($d[$pass]) && $d[$pass] === true;
    }

    public function givePass($playerName, $pass) {
        $d        = $this->getPlayerData($playerName);
        $d[$pass] = true;
        $this->setPlayerData($playerName, $d);
    }

    public function removePass($playerName, $pass) {
        $d = $this->getPlayerData($playerName);
        unset($d[$pass]);
        $this->setPlayerData($playerName, $d);
    }

    public function getPasses($playerName) {
        return $this->getPlayerData($playerName);
    }

    // ─── Fruit Notifier ──────────────────────────────────────

    public function giveFruitNotifier($playerName) {
        $this->givePass($playerName, self::PASS_FRUIT_NOTIFIER);
        $loader = \OnePiece\WantedPoster\Loader::get();
        if ($loader !== null) {
            $loader->getFruitSpawnManager()->giveRadarPass($playerName);
            $loader->activateRadarForPlayer($playerName);
        }
    }

    public function removeFruitNotifier($playerName) {
        $this->removePass($playerName, self::PASS_FRUIT_NOTIFIER);
        $loader = \OnePiece\WantedPoster\Loader::get();
        if ($loader !== null) {
            $loader->getFruitSpawnManager()->removeRadarPass($playerName);
        }
    }

    public function hasFruitNotifier($playerName) {
        return $this->hasPass($playerName, self::PASS_FRUIT_NOTIFIER);
    }

    // ─── 2x EXP ──────────────────────────────────────────────

    public function giveExpBoost($playerName, $pass) {
        if (!isset(self::EXP_PASS_DURATIONS[$pass])) return;
        $d                     = $this->getPlayerData($playerName);
        $duration              = self::EXP_PASS_DURATIONS[$pass];
        $currentExpiry         = isset($d[$pass . "_expires"]) ? $d[$pass . "_expires"] : 0;
        $base                  = max(time(), $currentExpiry);
        $d[$pass]              = true;
        $d[$pass . "_expires"] = $base + $duration;
        $this->setPlayerData($playerName, $d);
    }

    public function hasExpBoost($playerName) {
        $d = $this->getPlayerData($playerName);
        $dirty = false;
        foreach (array_keys(self::EXP_PASS_DURATIONS) as $pass) {
            if (!isset($d[$pass])) continue;
            if (!isset($d[$pass . "_expires"])) return true;
            if (time() < $d[$pass . "_expires"]) return true;
            unset($d[$pass], $d[$pass . "_expires"]);
            $dirty = true;
        }
        if ($dirty) $this->setPlayerData($playerName, $d);
        return false;
    }

    public function getExpBoostExpiry($playerName) {
        $d      = $this->getPlayerData($playerName);
        $latest = 0;
        foreach (array_keys(self::EXP_PASS_DURATIONS) as $pass) {
            if (isset($d[$pass . "_expires"]) && $d[$pass . "_expires"] > $latest) {
                $latest = $d[$pass . "_expires"];
            }
        }
        return $latest;
    }

    public function getExpMultiplier($playerName) {
        return $this->hasExpBoost($playerName) ? 2.0 : 1.0;
    }

    // ─── Boss Respawn ─────────────────────────────────────────

    public function hasBossRespawn($playerName) {
        return $this->hasPass($playerName, self::PASS_BOSS_RESPAWN);
    }

    public function giveBossRespawn($playerName) {
        $this->givePass($playerName, self::PASS_BOSS_RESPAWN);
    }

    public function removeBossRespawn($playerName) {
        $this->removePass($playerName, self::PASS_BOSS_RESPAWN);
    }

    public function triggerBossRespawn($player) {
        $worldName = $player->getLevel()->getFolderName();
        $bosses    = self::WORLD_BOSSES[$worldName] ?? [];

        if (empty($bosses)) {
            $player->sendMessage("§cNo bosses registered for world §f" . $worldName . "§c.");
            return false;
        }

        $npcPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceNPC");
        if ($npcPlugin === null || !$npcPlugin->isEnabled()) {
            $player->sendMessage("§cNPC system unavailable.");
            return false;
        }

        $mgr     = $npcPlugin->getNPCManager();
        $spawned = [];

        foreach ($bosses as $bossId) {
            $npcData = $mgr->get($bossId);
            if ($npcData === null) continue;
            $spawnCount = isset($npcData["spawns"]) ? count($npcData["spawns"]) : 1;
            for ($num = 0; $num < $spawnCount; $num++) {
                $mgr->clearRespawnCooldown($bossId, $num);
            }
            if ($mgr->spawnNPC($bossId)) {
                $spawned[] = $bossId;
            }
        }

        if (empty($spawned)) {
            $player->sendMessage("§cNo bosses could be respawned — are they already alive?");
            return false;
        }

        $this->removePass($player->getName(), self::PASS_BOSS_RESPAWN);
        $player->sendMessage("§6[Boss Respawn] §eForce-respawned: §f" . implode(", ", $spawned));
        $player->sendMessage("§7Your Boss Respawn pass has been consumed.");
        return true;
    }

    // ─── +1 Fruit Storage ────────────────────────────────────

    public function hasStoragePlus($playerName) {
        return $this->hasPass($playerName, self::PASS_STORAGE_PLUS);
    }

    public function giveStoragePlus($playerName) {
        $this->givePass($playerName, self::PASS_STORAGE_PLUS);
    }

    public function removeStoragePlus($playerName) {
        $this->removePass($playerName, self::PASS_STORAGE_PLUS);
    }

    public function getStorageSlots($playerName) {
        return $this->hasStoragePlus($playerName)
            ? \OnePiece\Berry\FruitStorageManager::MAX_SLOTS + 1
            : \OnePiece\Berry\FruitStorageManager::MAX_SLOTS;
    }
}