<?php
namespace OnePiece\Gamepasses;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class GamepassCommand extends Command {

    private $plugin;

    public function __construct($plugin) {
        parent::__construct(
            "gamepass",
            "Manage gamepasses",
            "/gamepass <give|remove|list|info> [player] [pass]"
        );
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage("§cNo permission.");
            return true;
        }

        if (empty($args)) {
            $this->sendHelp($sender);
            return true;
        }

        switch (strtolower($args[0])) {
            case "give":    return $this->handleGive($sender, $args);
            case "remove":  return $this->handleRemove($sender, $args);
            case "list":    return $this->handleList($sender, $args);
            case "info":    return $this->handleInfo($sender);
            case "boss":    return $this->handleBoss($sender, $args);
            default:        $this->sendHelp($sender); return true;
        }
    }

    private function handleGive(CommandSender $sender, array $args) {
        if (count($args) < 3) {
            $sender->sendMessage("§cUsage: /gamepass give <player> <pass>");
            return true;
        }

        $target     = $this->plugin->getServer()->getPlayerExact($args[1]);
        $playerName = $args[1];
        $pass       = strtolower($args[2]);
        $gm         = $this->plugin->getGamepassManager();

        if (!$this->isValidPass($pass)) {
            $sender->sendMessage("§cInvalid pass. Valid: " . implode(", ", $this->getValidPasses()));
            return true;
        }

        switch ($pass) {
            case GamepassManager::PASS_FRUIT_NOTIFIER:
                $gm->giveFruitNotifier($playerName);
                break;
            case GamepassManager::PASS_EXP_2X_15:
            case GamepassManager::PASS_EXP_2X_30:
            case GamepassManager::PASS_EXP_2X_60:
                $gm->giveExpBoost($playerName, $pass);
                break;
            case GamepassManager::PASS_BOSS_RESPAWN:
                $gm->giveBossRespawn($playerName);
                break;
            case GamepassManager::PASS_STORAGE_PLUS:
                $gm->giveStoragePlus($playerName);
                break;
        }

        $sender->sendMessage("§aGave §f" . $this->getPassName($pass) . " §apass to §f" . $playerName . "§a.");
        if ($target !== null) {
            $target->sendMessage("§6[Gamepass] §eYou received: §f" . $this->getPassName($pass) . "§e!");
            $this->sendPassActivationMessage($target, $pass, $gm);
        }
        return true;
    }

    private function handleRemove(CommandSender $sender, array $args) {
        if (count($args) < 3) {
            $sender->sendMessage("§cUsage: /gamepass remove <player> <pass>");
            return true;
        }

        $playerName = $args[1];
        $pass       = strtolower($args[2]);
        $gm         = $this->plugin->getGamepassManager();

        if (!$this->isValidPass($pass)) {
            $sender->sendMessage("§cInvalid pass.");
            return true;
        }

        switch ($pass) {
            case GamepassManager::PASS_FRUIT_NOTIFIER:
                $gm->removeFruitNotifier($playerName);
                break;
            case GamepassManager::PASS_BOSS_RESPAWN:
                $gm->removeBossRespawn($playerName);
                break;
            case GamepassManager::PASS_STORAGE_PLUS:
                $gm->removeStoragePlus($playerName);
                break;
            default:
                $gm->removePass($playerName, $pass);
                break;
        }

        $sender->sendMessage("§cRemoved §f" . $this->getPassName($pass) . " §cfrom §f" . $playerName . "§c.");
        $target = $this->plugin->getServer()->getPlayerExact($playerName);
        if ($target !== null) {
            $target->sendMessage("§c[Gamepass] §7Your §f" . $this->getPassName($pass) . " §7pass was removed.");
        }
        return true;
    }

    private function handleList(CommandSender $sender, array $args) {
        $playerName = isset($args[1]) ? $args[1] : ($sender instanceof Player ? $sender->getName() : null);
        if ($playerName === null) {
            $sender->sendMessage("§cUsage: /gamepass list <player>");
            return true;
        }

        $gm     = $this->plugin->getGamepassManager();
        $passes = $gm->getPasses($playerName);

        $sender->sendMessage("§6[Gamepasses] §fPasses for §e" . $playerName . "§f:");
        if (empty($passes)) {
            $sender->sendMessage("§7  None.");
            return true;
        }

        $expPasses = [GamepassManager::PASS_EXP_2X_15, GamepassManager::PASS_EXP_2X_30, GamepassManager::PASS_EXP_2X_60];
        $shownExp  = false;
        foreach ($this->getValidPasses() as $pass) {
            if (in_array($pass, $expPasses)) {
                if (!$shownExp && $gm->hasExpBoost($playerName)) {
                    $expiry = $gm->getExpBoostExpiry($playerName);
                    $remain = max(0, $expiry - time());
                    $mins   = (int)($remain / 60);
                    $secs   = $remain % 60;
                    $sender->sendMessage("§a  + §f2x EXP §7(" . $mins . "m " . $secs . "s remaining)");
                    $shownExp = true;
                }
            } elseif (isset($passes[$pass]) && $passes[$pass]) {
                $sender->sendMessage("§a  + §f" . $this->getPassName($pass));
            }
        }
        return true;
    }

    private function handleInfo(CommandSender $sender) {
        $sender->sendMessage("§6[Available Gamepasses]");
        $sender->sendMessage("§f  fruit_notifier  §7- Devil Fruit Radar (permanent)");
        $sender->sendMessage("§f  exp_2x_15       §7- 2x EXP for 15 minutes");
        $sender->sendMessage("§f  exp_2x_30       §7- 2x EXP for 30 minutes");
        $sender->sendMessage("§f  exp_2x_60       §7- 2x EXP for 60 minutes");
        $sender->sendMessage("§f  boss_respawn    §7- Force respawn world bosses (one-time)");
        $sender->sendMessage("§f  storage_plus    §7- +1 Fruit Storage slot (permanent)");
        return true;
    }

    private function handleBoss(CommandSender $sender, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cIn-game only.");
            return true;
        }
        $target = isset($args[1])
            ? $this->plugin->getServer()->getPlayerExact($args[1])
            : $sender;

        if ($target === null) {
            $sender->sendMessage("§cPlayer not found.");
            return true;
        }

        $gm = $this->plugin->getGamepassManager();
        if (!$gm->hasBossRespawn($target->getName()) && !$sender->isOp()) {
            $sender->sendMessage("§cYou don't have the Boss Respawn pass.");
            return true;
        }
        $gm->triggerBossRespawn($target);
        return true;
    }

    private function sendPassActivationMessage(Player $player, $pass, GamepassManager $gm) {
        switch ($pass) {
            case GamepassManager::PASS_EXP_2X_15:
                $player->sendMessage("§a[2x EXP] §eYour 2x EXP boost is now active for §f15 minutes§e!");
                break;
            case GamepassManager::PASS_EXP_2X_30:
                $player->sendMessage("§a[2x EXP] §eYour 2x EXP boost is now active for §f30 minutes§e!");
                break;
            case GamepassManager::PASS_EXP_2X_60:
                $player->sendMessage("§a[2x EXP] §eYour 2x EXP boost is now active for §f60 minutes§e!");
                break;
            case GamepassManager::PASS_FRUIT_NOTIFIER:
                $player->sendMessage("§6[Fruit Notifier] §eYour Devil Fruit Radar is now active!");
                break;
            case GamepassManager::PASS_BOSS_RESPAWN:
                $player->sendMessage("§6[Boss Respawn] §eYou can now force-respawn world bosses anytime! Use §f/gamepass boss§e.");
                break;
            case GamepassManager::PASS_STORAGE_PLUS:
                $player->sendMessage("§6[Storage+] §eYour fruit storage has been expanded to §f" .
                    $gm->getStorageSlots($player->getName()) . " slots§e!");
                break;
        }
    }

    private function isValidPass($pass) {
        return in_array($pass, $this->getValidPasses());
    }

    private function getValidPasses() {
        return [
            GamepassManager::PASS_FRUIT_NOTIFIER,
            GamepassManager::PASS_EXP_2X_15,
            GamepassManager::PASS_EXP_2X_30,
            GamepassManager::PASS_EXP_2X_60,
            GamepassManager::PASS_BOSS_RESPAWN,
            GamepassManager::PASS_STORAGE_PLUS,
        ];
    }

    private function getPassName($pass) {
        $names = [
            GamepassManager::PASS_FRUIT_NOTIFIER => "Fruit Notifier",
            GamepassManager::PASS_EXP_2X_15      => "2x EXP (15min)",
            GamepassManager::PASS_EXP_2X_30      => "2x EXP (30min)",
            GamepassManager::PASS_EXP_2X_60      => "2x EXP (60min)",
            GamepassManager::PASS_BOSS_RESPAWN    => "Boss Respawn",
            GamepassManager::PASS_STORAGE_PLUS    => "Storage+",
        ];
        return $names[$pass] ?? $pass;
    }

    private function sendHelp(CommandSender $sender) {
        $sender->sendMessage("§6[Gamepass Commands]");
        $sender->sendMessage("§f/gamepass give <player> <pass>    §7Give a pass");
        $sender->sendMessage("§f/gamepass remove <player> <pass>  §7Remove a pass");
        $sender->sendMessage("§f/gamepass list [player]           §7List player passes");
        $sender->sendMessage("§f/gamepass info                    §7List all pass IDs");
        $sender->sendMessage("§f/gamepass boss [player]           §7Trigger boss respawn");
    }
}