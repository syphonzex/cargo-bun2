<?php
namespace OnePiece\FruitSpawn;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class FruitSpawnCommand extends Command {

    private $plugin;

    public function __construct($plugin) {
        parent::__construct("fruitspawn", "Manage fruit spawn locations", "/fruitspawn <addpos|removepos|list|settimer|status|force>");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage("§cNo permission.");
            return true;
        }

        if (empty($args)) { $this->sendHelp($sender); return true; }

        switch (strtolower($args[0])) {
            case "addpos":    return $this->handleAddPos($sender);
            case "removepos": return $this->handleRemovePos($sender, $args);
            case "list":      return $this->handleList($sender, $args);
            case "settimer":  return $this->handleSetTimer($sender, $args);
            case "status":    return $this->handleStatus($sender);
            case "force":     return $this->handleForce($sender, $args);
            default:          $this->sendHelp($sender); return true;
        }
    }

    private function handleAddPos(CommandSender $sender) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cIn-game only.");
            return true;
        }
        $sm        = $this->plugin->getFruitSpawnManager();
        $worldName = $sender->getLevel()->getFolderName();
        $x         = (int)$sender->x;
        $y         = (int)$sender->y;
        $z         = (int)$sender->z;
        $idx       = $sm->addSpawnLocation($worldName, $x, $y, $z);
        $sender->sendMessage("§aFruit spawn #" . $idx . " added at §f{$x}, {$y}, {$z} §ain §f{$worldName}");
        return true;
    }

    private function handleRemovePos(CommandSender $sender, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cIn-game only.");
            return true;
        }
        if (!isset($args[1]) || !is_numeric($args[1])) {
            $sender->sendMessage("§cUsage: /fruitspawn removepos <index>");
            return true;
        }
        $sm        = $this->plugin->getFruitSpawnManager();
        $worldName = $sender->getLevel()->getFolderName();
        $idx       = (int)$args[1] - 1;
        if ($sm->removeSpawnLocation($worldName, $idx)) {
            $sender->sendMessage("§aRemoved spawn #" . ($idx + 1) . " in §f{$worldName}");
        } else {
            $sender->sendMessage("§cIndex not found.");
        }
        return true;
    }

    private function handleList(CommandSender $sender, array $args) {
        $sm        = $this->plugin->getFruitSpawnManager();
        $worldName = ($sender instanceof Player) ? $sender->getLevel()->getFolderName() : ($args[1] ?? null);
        if ($worldName === null) {
            $sender->sendMessage("§cUsage: /fruitspawn list [world]");
            return true;
        }
        $locs = $sm->getSpawnLocations($worldName);
        if (empty($locs)) {
            $sender->sendMessage("§7No spawn locations in §f{$worldName}§7.");
            return true;
        }
        $sender->sendMessage("§6Fruit spawns in §f{$worldName}§6:");
        foreach ($locs as $i => $loc) {
            $timer = $sm->getRespawnTimer($worldName);
            $sender->sendMessage("  §f#" . ($i + 1) . " §7-> " . $loc["x"] . ", " . $loc["y"] . ", " . $loc["z"]);
        }
        $sender->sendMessage("§7Respawn timer: §f" . $sm->getRespawnTimer($worldName) . "s");
        return true;
    }

    private function handleSetTimer(CommandSender $sender, array $args) {
        if (count($args) < 3) {
            $sender->sendMessage("§cUsage: /fruitspawn settimer <world> <seconds>");
            return true;
        }
        $worldName = $args[1];
        $seconds   = (int)$args[2];
        if ($seconds < 30) {
            $sender->sendMessage("§cMinimum timer is 30 seconds.");
            return true;
        }
        $this->plugin->getFruitSpawnManager()->setRespawnTimer($worldName, $seconds);
        $mins = round($seconds / 60, 1);
        $sender->sendMessage("§aRespawn timer for §f{$worldName} §aset to §f{$seconds}s §7({$mins} min)");
        return true;
    }

    private function handleStatus(CommandSender $sender) {
        $sm     = $this->plugin->getFruitSpawnManager();
        $all    = $sm->getAllLocations();
        $sender->sendMessage("§6[Fruit Spawn Status]");
        if (empty($all)) {
            $sender->sendMessage("§7No worlds configured.");
            return true;
        }
        foreach ($all as $worldName => $locs) {
            $active  = $sm->getActiveSpawn($worldName);
            $timer   = $sm->getRespawnTimer($worldName);
            $spawnStr = $active !== null ? "§aActive: §f" . $active["fruitId"] : "§7None spawned";
            $sender->sendMessage("§f{$worldName} §7| §f" . count($locs) . " §7spots | Timer: §f{$timer}s §7| " . $spawnStr);
        }
        return true;
    }

    private function handleForce(CommandSender $sender, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cIn-game only.");
            return true;
        }
        $sm        = $this->plugin->getFruitSpawnManager();
        $worldName = $sender->getLevel()->getFolderName();
        $level     = $sender->getLevel();
        $locs      = $sm->getSpawnLocations($worldName);

        if (empty($locs)) {
            $sender->sendMessage("§cNo spawn locations set for §f{$worldName}§c.");
            return true;
        }

        if ($sm->hasActiveSpawn($worldName)) {
            $sender->sendMessage("§cA fruit is already spawned in §f{$worldName}§c.");
            return true;
        }

        $fruitId = isset($args[1]) ? $args[1] : $sm->rollFruit();
        if ($fruitId === null) {
            $sender->sendMessage("§cCould not roll a fruit (all paused?).");
            return true;
        }

        $loc  = $locs[array_rand($locs)];
        $task = new FruitSpawnTask($this->plugin);
        $task->spawnFruitItem($sm, $level, $fruitId, $loc["x"], $loc["y"], $loc["z"]);
        $sender->sendMessage("§aForce spawned §f{$fruitId} §ain §f{$worldName}§a.");
        return true;
    }

    private function sendHelp(CommandSender $sender) {
        $sender->sendMessage("§6[Fruit Spawn Commands]");
        $sender->sendMessage("§f/fruitspawn addpos              §7Save your position as a spawn");
        $sender->sendMessage("§f/fruitspawn removepos <index>   §7Remove a spawn location");
        $sender->sendMessage("§f/fruitspawn list [world]        §7List spawn locations");
        $sender->sendMessage("§f/fruitspawn settimer <world> <s>§7Set respawn timer in seconds");
        $sender->sendMessage("§f/fruitspawn status              §7Show active spawns");
        $sender->sendMessage("§f/fruitspawn force [fruitId]     §7Force spawn a fruit now");
    }
}
