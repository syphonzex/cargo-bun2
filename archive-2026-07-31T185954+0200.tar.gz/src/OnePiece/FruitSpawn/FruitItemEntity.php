<?php
namespace OnePiece\FruitSpawn;

use pocketmine\entity\Entity;
use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\network\protocol\AddItemEntityPacket;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\ShortTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;
use pocketmine\Server;

class FruitItemEntity extends Entity {

    const NETWORK_ID = 64;

    public $width  = 0.25;
    public $height = 0.25;
    public $canCollide = false;

    protected $gravity = 0.04;
    protected $drag    = 0.02;

private $fruitId = "";
private $item = null;
private $pickupDelay = 0;
private $despawnTicks = 0;
private $maxDespawnTicks = 12000;

    public function getName()   { return "FruitItem"; }
    public function getSaveId() { return "FruitItem"; }

public function initEntity() {
    parent::initEntity();
    $this->setMaxHealth(5);
    $this->setHealth(5);

    $this->age = 0;

    $this->fruitId = isset($this->namedtag->FruitSpawn)
        ? $this->namedtag->FruitSpawn->getValue()
        : "";

    if (isset($this->namedtag->Item)) {
        $this->item = \pocketmine\nbt\NBT::getItemHelper($this->namedtag->Item);
    }

    $this->pickupDelay = isset($this->namedtag->PickupDelay)
        ? (int)$this->namedtag->PickupDelay->getValue()
        : 0;

    $this->despawnTicks = isset($this->namedtag->DespawnTicks)
        ? (int)$this->namedtag->DespawnTicks->getValue()
        : 0;
}

    public function getItem() { return $this->item; }
    public function getFruitId() { return $this->fruitId; }

public function onUpdate($currentTick) {
    if ($this->closed) return false;

    $tickDiff = $currentTick - $this->lastUpdate;
    if ($tickDiff <= 0) return true;
    $this->lastUpdate = $currentTick;

    $this->entityBaseTick($tickDiff);
    if ($this->closed) return false;

    if ($this->pickupDelay > 0) {
        $this->pickupDelay -= $tickDiff;
        if ($this->pickupDelay < 0) {
            $this->pickupDelay = 0;
        }
    }

    $this->motionX = 0.0;
    $this->motionY = 0.0;
    $this->motionZ = 0.0;
    $this->age = 0;

    if ($this->pickupDelay <= 0 && $this->item !== null) {
        foreach ($this->level->getPlayers() as $player) {
            if (!$player->isAlive() || !$player->spawned) continue;
            if ($this->distanceSquared($player) > 2.25) continue;

            $this->onPickup($player);
            return false;
        }
    }

    $this->scheduleUpdate();
    return true;
}

    private function onPickup(Player $player) {
        if ($this->item === null || $this->closed) return;

        $worldName = $this->level->getFolderName();
        $sm        = $this->getSpawnManager();
        if ($sm !== null) {
            $sm->clearActiveSpawn($worldName);
        }

        if ($player->getInventory()->canAddItem($this->item)) {
            $player->getInventory()->addItem($this->item);
            $player->sendMessage("§6You've found a devil fruit! §eUse §f/storage §eto store it!");
        } else {
            // Spawn a FruitItemEntity so the 10-minute despawn applies
            $pos   = $player->getPosition();
            $chunk = $this->level->getChunk($pos->getFloorX() >> 4, $pos->getFloorZ() >> 4, true);
            if ($chunk !== null) {
$itemNbt = new CompoundTag("", [
    "Pos" => new ListTag("Pos", [
        new DoubleTag("", $pos->x),
        new DoubleTag("", $pos->y + 0.5),
        new DoubleTag("", $pos->z)
    ]),
    "Motion" => new ListTag("Motion", [
        new DoubleTag("", 0.0),
        new DoubleTag("", 0.0),
        new DoubleTag("", 0.0)
    ]),
    "Rotation" => new ListTag("Rotation", [
        new FloatTag("", 0.0),
        new FloatTag("", 0.0)
    ]),
    "FruitSpawn" => new StringTag("FruitSpawn", $this->fruitId),
    "Item" => NBT::putItemHelper($this->item),
    "PickupDelay" => new ShortTag("PickupDelay", 0),
    "DespawnTicks" => new ShortTag("DespawnTicks", 0)
]);
                $drop = new FruitItemEntity($chunk, $itemNbt);
                $drop->spawnToAll();
            }
            $player->sendMessage("§eYour inventory was full — fruit dropped!");
        }

        $this->close();
    }

    private function getSpawnManager() {
        $loader = \OnePiece\WantedPoster\Loader::get();
        return $loader !== null ? $loader->getFruitSpawnManager() : null;
    }

public function entityBaseTick($tickDiff = 1, $EnchantL = 0) {
    if ($this->closed) return false;

    $this->ticksLived += $tickDiff;
    $this->despawnTicks += $tickDiff;
    $this->age = 0;

    if ($this->despawnTicks >= $this->maxDespawnTicks) {
        $worldName = $this->level->getFolderName();
        $sm = $this->getSpawnManager();
        if ($sm !== null) {
            $sm->clearActiveSpawn($worldName);
        }
        $this->close();
        return false;
    }

    return true;
}

    public function spawnTo(Player $player) {
        if (isset($this->hasSpawned[$player->getLoaderId()])) return;
        if (!isset($player->usedChunks[Level::chunkHash($this->chunk->getX(), $this->chunk->getZ())])) return;

        $this->hasSpawned[$player->getLoaderId()] = $player;

        if ($this->item === null) return;

        $pk          = new AddItemEntityPacket();
        $pk->eid     = $this->getId();
        $pk->item    = $this->item;
        $pk->x       = $this->x;
        $pk->y       = $this->y;
        $pk->z       = $this->z;
        $pk->speedX  = 0.0;
        $pk->speedY  = 0.0;
        $pk->speedZ  = 0.0;
        $player->dataPacket($pk);
    }

    public function getDrops() { return []; }
}