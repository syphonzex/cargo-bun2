<?php
namespace OnePiece\FruitSpawn;

use pocketmine\scheduler\Task;
use pocketmine\Server;

class FruitRadarTask extends Task {

    private $plugin;
    private $activating  = [];
    private $verifyTimer = [];

    public function __construct($plugin) {
        $this->plugin = $plugin;
    }

    public function activateRadar($playerName) {
        $this->activating[strtolower($playerName)] = Server::getInstance()->getTick();
    }

    public function onRun($currentTick) {
        $sm     = $this->plugin->getFruitSpawnManager();
        $server = Server::getInstance();

        // Every 100 ticks (5 seconds), verify all active spawns still have a living entity
        if ($currentTick % 100 === 0) {
            foreach ($sm->getActiveSpawnsAll() as $worldName => $spawn) {
                if (!$server->isLevelLoaded($worldName)) continue;
                $level = $server->getLevelByName($worldName);
                if ($level === null) continue;

                $found = false;
                foreach ($level->getEntities() as $e) {
                    if ($e instanceof FruitItemEntity && $e->getId() === $spawn["entityId"] && !$e->closed) {
                        $found = true;
                        break;
                    }
                }
                if (!$found) {
                    $sm->clearActiveSpawn($worldName);
                }
            }
        }

        foreach ($server->getOnlinePlayers() as $player) {
            if (!$player->isAlive() || !$player->spawned) continue;
            if (!$this->plugin->hasRadarPass($player->getName())) continue;

            $name      = strtolower($player->getName());
            $worldName = $player->getLevel()->getFolderName();
            $spawn     = $sm->getActiveSpawn($worldName);

            // Activation animation
            if (isset($this->activating[$name])) {
                $elapsed = $currentTick - $this->activating[$name];
                if ($elapsed < 60) {
                    $dots = str_repeat(".", (int)($elapsed / 15) % 4);
                    //$player->sendTip("§6[Fruit Radar] §eTurning on" . $dots);
                    continue;
                }
                unset($this->activating[$name]);
            }

            if ($spawn === null) {
                if ($currentTick % 40 === 0) {
                    //$player->sendTip("§6[Fruit Radar] §7No fruit in this world.");
                }
                continue;
            }

            $fx = $spawn["x"] ?? null;
            $fz = $spawn["z"] ?? null;

            if ($fx === null) continue;

            $dx   = $player->x - $fx;
            $dz   = $player->z - $fz;
            $dist = (int)sqrt($dx * $dx + $dz * $dz);

            $fruit = $this->getFruitDisplayInfo($spawn["fruitId"]);
            $player->sendTip("§6[Fruit Radar] §eFruit Detected: §f{$dist} §eblocks away");
        }
    }

    private function getFruitDisplayInfo($fruitId) {
        $devilPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin !== null && $devilPlugin->isEnabled()) {
            $fruit = $devilPlugin->getFruitManager()->getFruit($fruitId);
            if ($fruit !== null) {
                return ["color" => $fruit->getRarityColor(), "name" => $fruit->getDisplayName()];
            }
        }
        return ["color" => "§f", "name" => $fruitId];
    }
}