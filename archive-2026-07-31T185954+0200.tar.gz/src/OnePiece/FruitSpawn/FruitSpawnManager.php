<?php
namespace OnePiece\FruitSpawn;

use pocketmine\Server;

class FruitSpawnManager {

    private $plugin;
    private $dataFile;
    private $data = [];

    // spawn locations: worldName -> [["x"=>,"y"=>,"z"=>], ...]
    private $spawnLocations = [];

    // active spawned fruit: worldName -> ["entityId"=>int, "fruitId"=>str, "spawnedAt"=>tick]
    private $activeSpawns = [];

    // respawn timer per world in seconds (default 15 min)
    private $respawnTimers = [];

    // last despawn time per world (unix timestamp)
    private $lastDespawn = [];

    private $radarPassFile;
    private $radarPassHolders = [];

    const DEFAULT_RESPAWN = 900; // 15 minutes

    public function __construct($plugin) {
        $this->plugin         = $plugin;
        $this->dataFile       = $plugin->getDataFolder() . "fruit_spawns.json";
        $this->radarPassFile  = $plugin->getDataFolder() . "radar_pass.json";
        $this->load();
        $this->loadRadarPasses();
    }

    private function load() {
        if (file_exists($this->dataFile)) {
            $d = json_decode(file_get_contents($this->dataFile), true);
            if (is_array($d)) $this->data = $d;
        }
        $this->spawnLocations = $this->data["locations"]      ?? [];
        $this->respawnTimers  = $this->data["respawn_timers"] ?? [];
        $this->lastDespawn    = $this->data["last_despawn"]   ?? [];
        // Active spawns are runtime-only — entities don't survive restarts
        $this->activeSpawns   = [];
    }

    public function save() {
        $this->data["locations"]      = $this->spawnLocations;
        $this->data["respawn_timers"] = $this->respawnTimers;
        $this->data["last_despawn"]   = $this->lastDespawn;
        // Never save activeSpawns - entities don't survive restarts
        unset($this->data["activeSpawns"]);
        file_put_contents($this->dataFile, json_encode($this->data, JSON_PRETTY_PRINT));
    }

    public function addSpawnLocation($worldName, $x, $y, $z) {
        if (!isset($this->spawnLocations[$worldName])) {
            $this->spawnLocations[$worldName] = [];
        }
        $this->spawnLocations[$worldName][] = ["x" => (int)$x, "y" => (int)$y, "z" => (int)$z];
        $this->save();
        return count($this->spawnLocations[$worldName]);
    }

    public function removeSpawnLocation($worldName, $index) {
        if (!isset($this->spawnLocations[$worldName][$index])) return false;
        array_splice($this->spawnLocations[$worldName], $index, 1);
        $this->save();
        return true;
    }

    public function getSpawnLocations($worldName) {
        return $this->spawnLocations[$worldName] ?? [];
    }

    public function getAllLocations() {
        return $this->spawnLocations;
    }

    public function setRespawnTimer($worldName, $seconds) {
        $this->respawnTimers[$worldName] = (int)$seconds;
        $this->save();
    }

    public function getRespawnTimer($worldName) {
        return $this->respawnTimers[$worldName] ?? self::DEFAULT_RESPAWN;
    }

    public function isSpawnDue($worldName) {
        if (isset($this->activeSpawns[$worldName])) return false;
        $last   = $this->lastDespawn[$worldName] ?? 0;
        $timer  = $this->getRespawnTimer($worldName);
        return (time() - $last) >= $timer;
    }

    public function registerActiveSpawn($worldName, $entityId, $fruitId, $x = 0, $y = 0, $z = 0) {
        $this->activeSpawns[$worldName] = [
            "entityId"  => $entityId,
            "fruitId"   => $fruitId,
            "x"         => (float)$x,
            "y"         => (float)$y,
            "z"         => (float)$z,
            "spawnedAt" => Server::getInstance()->getTick(),
        ];
    }

    public function clearActiveSpawn($worldName) {
        if (isset($this->activeSpawns[$worldName])) {
            unset($this->activeSpawns[$worldName]);
            $this->lastDespawn[$worldName] = time();
            $this->save();
        }
    }

    public function getActiveSpawn($worldName) {
        return $this->activeSpawns[$worldName] ?? null;
    }

    public function getActiveSpawnForEntity($entityId) {
        foreach ($this->activeSpawns as $worldName => $spawn) {
            if ($spawn["entityId"] === $entityId) return [$worldName, $spawn];
        }
        return null;
    }

    public function hasActiveSpawn($worldName) {
        return isset($this->activeSpawns[$worldName]);
    }

    public function isShopPaused($fruitId) {
        $berryPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceBerry");
        if ($berryPlugin === null || !$berryPlugin->isEnabled()) return false;
        return $berryPlugin->isFruitPaused($fruitId);
    }

    public function rollFruit() {
        $berryPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceBerry");
        if ($berryPlugin === null || !$berryPlugin->isEnabled()) return null;

        $gm = $berryPlugin->getGachaManager();
        if ($gm === null) return null;

        $fruitId = $gm->rollFruit();
        if ($this->isShopPaused($fruitId)) return null;
        return $fruitId;
    }

    public function getActiveSpawnsAll() {
        return $this->activeSpawns;
    }

    // ─── Radar Pass ───────────────────────────────────────────

    private function loadRadarPasses() {
        if (!file_exists($this->radarPassFile)) return;
        $d = json_decode(file_get_contents($this->radarPassFile), true);
        if (is_array($d)) $this->radarPassHolders = $d;
    }

    public function saveRadarPasses() {
        file_put_contents($this->radarPassFile, json_encode($this->radarPassHolders, JSON_PRETTY_PRINT));
    }

    public function giveRadarPass($playerName) {
        $this->radarPassHolders[strtolower($playerName)] = true;
        $this->saveRadarPasses();
    }

    public function removeRadarPass($playerName) {
        unset($this->radarPassHolders[strtolower($playerName)]);
        $this->saveRadarPasses();
    }

    public function hasRadarPass($playerName) {
        return isset($this->radarPassHolders[strtolower($playerName)]);
    }
}