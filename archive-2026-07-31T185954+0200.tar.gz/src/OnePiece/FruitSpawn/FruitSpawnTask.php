<?php
namespace OnePiece\FruitSpawn;

use pocketmine\item\Item;
use pocketmine\level\sound\SplashSound;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\ShortTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class FruitSpawnTask extends Task {

    private $plugin;

    public function __construct($plugin) {
        $this->plugin = $plugin;
    }

    private function normalizeWorldName($worldName) {
        if ($worldName === "OP1") return "OP";
        if ($worldName === "Sea21") return "Sea2";
        return $worldName;
    }

    public function onRun($currentTick) {
        $sm     = $this->plugin->getFruitSpawnManager();
        $server = Server::getInstance();

        foreach ($sm->getAllLocations() as $worldName => $locations) {
            $baseWorldName = $this->normalizeWorldName($worldName);

            if (empty($locations)) continue;
            if (!$sm->isSpawnDue($baseWorldName)) continue;

            if (!$server->isLevelLoaded($worldName)) $server->loadLevel($worldName);
            $level = $server->getLevelByName($worldName);
            if ($level === null) continue;

            $fruitId = $sm->rollFruit();
            if ($fruitId === null) continue;

            $loc = $locations[array_rand($locations)];
            $this->spawnFruitItem($sm, $level, $fruitId, $loc["x"], $loc["y"], $loc["z"]);
        }
    }

    public function spawnFruitItem($sm, $level, $fruitId, $x, $y, $z) {
        $devilPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin === null || !$devilPlugin->isEnabled()) return;

        $fm    = $devilPlugin->getFruitManager();
        $fruit = $fm->getFruit($fruitId);
        if ($fruit === null) return;

        $item = Item::get(Item::GOLDEN_APPLE, 0, 1);
        $item->setCustomName($fruit->getRarityColor() . $fruit->getDisplayName());

        $worldName = $level->getName();
        $baseWorldName = $this->normalizeWorldName($worldName);

        $level->loadChunk($x >> 4, $z >> 4, true);
        $chunk = $level->getChunk($x >> 4, $z >> 4, true);
        if ($chunk === null) return;

        $itemTag = \pocketmine\nbt\NBT::putItemHelper($item);
        $itemTag->setName("Item");

        $nbt = new CompoundTag("", [
            "Pos"         => new ListTag("Pos", [
                new DoubleTag("", $x + 0.5),
                new DoubleTag("", (float)$y + 0.2),
                new DoubleTag("", $z + 0.5),
            ]),
            "Motion"      => new ListTag("Motion", [
                new DoubleTag("", 0.0),
                new DoubleTag("", 0.0),
                new DoubleTag("", 0.0),
            ]),
            "Rotation"    => new ListTag("Rotation", [
                new FloatTag("", 0.0),
                new FloatTag("", 0.0),
            ]),
            "Health"      => new ShortTag("Health", 5),
            "Age"         => new ShortTag("Age", -10000),
            "PickupDelay" => new ShortTag("PickupDelay", 0),
            "FruitSpawn"  => new StringTag("FruitSpawn", $fruitId),
        ]);
        $nbt->Item = $itemTag;

        $entity = new FruitItemEntity($chunk, $nbt);
        $entity->spawnToAll();

        $sm->registerActiveSpawn($baseWorldName, $entity->getId(), $fruitId, $x + 0.5, (float)$y + 0.2, $z + 0.5);

        $pos = new Vector3($x + 0.5, (float)$y + 0.2, $z + 0.5);
        $level->addSound(new SplashSound($pos));
    }
}