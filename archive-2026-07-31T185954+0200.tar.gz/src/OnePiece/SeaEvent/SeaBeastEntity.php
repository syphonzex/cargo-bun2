<?php
namespace OnePiece\SeaEvent;

use pocketmine\entity\Entity;
use pocketmine\entity\Living;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\level\Level;
use pocketmine\level\particle\DustParticle;
use pocketmine\math\Vector2;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\level\sound\GhastSound;
use pocketmine\level\sound\ExplodeSound;
use pocketmine\network\protocol\AddEntityPacket;
use OnePiece\SeaEvent\SeaCombatHelper;
use pocketmine\Player;
use pocketmine\Server;

class SeaBeastEntity extends Living {

    const NETWORK_ID = 41;

    public $width  = 4.0;
    public $height = 4.0;

    protected $gravity    = 0.0;
    protected $drag       = 0.0;

    public $beastLevel = 1;
    public $posIdx     = -1;

    private $spawnX;
    private $spawnY;
    private $spawnZ;

    private $baseTarget       = null;
    private $moveTime         = 0;
    private $attackDelay      = 0;
    private $beamDelay        = 0;
    private $lastAttackerName = null;
    private $rewardGiven      = false;
    private $lastDamageTick   = 0;

    const AGGRO_RANGE = 10000.0;
    const SPEED       = 0.6;
    const HOVER_RANGE = 4.0;

    public function __construct($chunk, $nbt) {
        parent::__construct($chunk, $nbt);
    }

    public function getName()   { return "Sea Beast"; }
    public function getSaveId() { return "SeaBeast"; }

    public function initEntity() {
        parent::initEntity();

        $this->beastLevel = isset($this->namedtag->BeastLevel) ? (int)$this->namedtag->BeastLevel->getValue() : 1;
        $this->posIdx     = isset($this->namedtag->PosIdx)     ? (int)$this->namedtag->PosIdx->getValue()     : -1;

        $maxHp = SeaEventManager::BEAST_HP;
        $this->setMaxHealth($maxHp);
        $this->setHealth($maxHp);

        $this->spawnX = $this->x;
        $this->spawnY = $this->y;
        $this->spawnZ = $this->z;

        $this->lastDamageTick = Server::getInstance()->getTick();

        $this->setNameTag("§dSea Beast §7[Lv.§f100§7]");
        $this->setNameTagVisible(true);
        $this->setDataProperty(self::DATA_NO_AI,       self::DATA_TYPE_BYTE, 1);
        $this->setDataProperty(self::DATA_LEAD,        self::DATA_TYPE_BYTE, 0);
        $this->setDataProperty(self::DATA_LEAD_HOLDER, self::DATA_TYPE_LONG, -1);
    }

    private function getSeaManager() {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceMISC");
        return $plugin !== null ? $plugin->getSeaEventManager() : null;
    }

    private function distToSpawnSq() {
        $dx = $this->x - $this->spawnX;
        $dz = $this->z - $this->spawnZ;
        return $dx * $dx + $dz * $dz;
    }

    private function checkTarget() {
        if ($this->distToSpawnSq() > 25.0) {
            $this->baseTarget = new Vector3($this->spawnX, $this->spawnY, $this->spawnZ);
            $this->motionX = 0.0;
            $this->motionZ = 0.0;
            return;
        }

        if ($this->baseTarget instanceof Player) {
            if (!$this->baseTarget->isAlive() || $this->baseTarget->closed || !$this->baseTarget->spawned) {
                $this->baseTarget = null;
            } elseif ($this->distanceSquared($this->baseTarget) > 25.0) {
                $this->baseTarget = null;
            }
        }

        if (!($this->baseTarget instanceof Player)) {
            $near  = PHP_INT_MAX;
            $found = null;
            foreach ($this->level->getPlayers() as $p) {
                if (!$p->isAlive() || !$p->spawned || $p->closed) continue;
                if (!$p->isSurvival() && !$p->isAdventure()) continue;
                $d = $this->distanceSquared($p);
                if ($d > self::AGGRO_RANGE || $d >= $near) continue;
                $near  = $d;
                $found = $p;
            }
            if ($found !== null) {
                $this->baseTarget = $found;
                $this->moveTime   = 0;
            } else {
                if ($this->moveTime <= 0 || !($this->baseTarget instanceof Vector3)) {
                    $x = mt_rand(1, 4);
                    $z = mt_rand(1, 4);
                    $y = mt_rand(-1, 1);
                    $this->moveTime   = mt_rand(60, 200);
                    $this->baseTarget = new Vector3(
                        $this->spawnX + (mt_rand(0,1) ? $x : -$x),
                        $this->spawnY + $y,
                        $this->spawnZ + (mt_rand(0,1) ? $z : -$z)
                    );
                }
            }
        }
    }

    private function updateMove($tickDiff) {
        if ($this->attackTime > 0) {
            $this->x += $this->motionX * $tickDiff;
            $this->y += $this->motionY * $tickDiff;
            $this->z += $this->motionZ * $tickDiff;
            $this->updateMovement();
            return null;
        }

        $this->checkTarget();

        if ($this->baseTarget !== null) {
            $x    = $this->baseTarget->x - $this->x;
            $y    = $this->baseTarget->y - $this->y;
            $z    = $this->baseTarget->z - $this->z;
            $diff = abs($x) + abs($z);

            if ($x * $x + $z * $z < 0.5) {
                $this->motionX = 0;
                $this->motionZ = 0;
            } elseif ($diff > 0) {
                $this->motionX = self::SPEED * 0.15 * ($x / $diff);
                $this->motionZ = self::SPEED * 0.15 * ($z / $diff);
                $this->motionY = self::SPEED * 0.27 * ($y / ($diff > 0 ? $diff : 1));
            }

            if ($diff > 0) {
                $this->yaw   = -atan2($x / $diff, $z / $diff) * 180 / M_PI;
                $this->pitch = $y == 0 ? 0 : rad2deg(-atan2($y, sqrt($x * $x + $z * $z)));
            }
        }

        $dx = $this->motionX * $tickDiff;
        $dy = $this->motionY * $tickDiff;
        $dz = $this->motionZ * $tickDiff;

        $be = new Vector2($this->x + $dx, $this->z + $dz);
        $this->x += $dx;
        $this->y += $dy;
        $this->z += $dz;
        $af = new Vector2($this->x, $this->z);

        if ($be->x != $af->x || $be->y != $af->y) {
            $this->moveTime -= 90 * $tickDiff;
        }

        $this->updateMovement();
        return $this->baseTarget;
    }

    private function shootBeam(Player $target) {
        $sx = $this->x;
        $sy = $this->y + 2;
        $sz = $this->z;
        $tx = $target->x;
        $ty = $target->y + 1;
        $tz = $target->z;

        $dx  = $tx - $sx;
        $dy  = $ty - $sy;
        $dz  = $tz - $sz;
        $len = sqrt($dx * $dx + $dy * $dy + $dz * $dz);
        if ($len <= 0) return;

        $steps = (int)min($len * 2, 24);
        for ($i = 0; $i <= $steps; $i++) {
            $t  = $i / $steps;
            $this->level->addParticle(new DustParticle(
                new Vector3($sx + $dx * $t, $sy + $dy * $t, $sz + $dz * $t),
                200, 0, 255
            ));
        }
    }

    public function attack($damage, EntityDamageEvent $source) {
        if ($this->closed || !$this->isAlive()) return;

        $attackerName = null;
        if ($source instanceof EntityDamageByEntityEvent) {
            $raw = $source->getDamager();
            if ($raw instanceof Player) {
                $attackerName           = $raw->getName();
                $this->lastAttackerName = $attackerName;
                $this->baseTarget       = $raw;
                $this->moveTime         = 0;

                $scaledDamage = SeaCombatHelper::scalePlayerToEntityDamage($raw, $source->getFinalDamage(), "beast");
                $source->setDamage($scaledDamage);

                $motion = (new Vector3($this->x - $raw->x, $this->y - $raw->y, $this->z - $raw->z))->normalize();
                $this->motionX = $motion->x * 0.19;
                $this->motionY = $motion->y * 0.19;
                $this->motionZ = $motion->z * 0.19;
            }
        }

        if ($attackerName !== null) {
            $sm = $this->getSeaManager();
            if ($sm !== null) {
                $sm->recordEntityDamage($this->getId(), $attackerName, max(1, $source->getFinalDamage()));
            }
            $this->lastDamageTick = Server::getInstance()->getTick();
            $attacker = Server::getInstance()->getPlayerExact($attackerName);
            if ($attacker !== null) {
                $attacker->sendTip("§d[Sea Beast Lv." . $this->beastLevel . "] " . $this->getHpBar() . " §f" . number_format((int)$this->getHealth()) . "§7/§f" . number_format((int)$this->getMaxHealth()));
            }
            foreach ($this->level->getPlayers() as $p) {
                $pct = $this->getMaxHealth() > 0 ? round(($this->getHealth() / $this->getMaxHealth()) * 100, 1) : 0;
                $p->sendPopup("§d[SEA BEAST Lv." . $this->beastLevel . "] §f" . number_format((int)$this->getHealth()) . "§7/§f" . number_format((int)$this->getMaxHealth()) . " §7(" . $pct . "%)");
            }
        }

        if ($attackerName !== null) {
            $attacker = \pocketmine\Server::getInstance()->getPlayerExact($attackerName);
            if ($attacker !== null) {
                $scaledDamage = SeaCombatHelper::scalePlayerToEntityDamage($attacker, $source->getFinalDamage(), "beast");
                $source->setDamage($scaledDamage);
            }
        }

        parent::attack($damage, $source);
    }

public function kill() {
    if ($this->rewardGiven) return;
    $this->rewardGiven = true;

    $sm          = $this->getSeaManager();
    $berryPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceBerry");
    $statsPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceStats");
    $qualified   = [];

    if ($sm !== null) {
        $data     = $sm->getEntityData($this->getId());
        $totalDmg = $data !== null ? array_sum($data["damageLog"]) : 0;

        if ($data !== null && $totalDmg > 0) {
            foreach ($data["damageLog"] as $pName => $dmg) {
                if (($dmg / $totalDmg) >= 0.10) $qualified[] = $pName;
            }
        }

        if (!empty($qualified)) {
            $bm = $berryPlugin !== null ? $berryPlugin->getBerryManager() : null;
            foreach ($qualified as $pName) {
                $player = Server::getInstance()->getPlayerExact($pName);
                if ($player === null || !$player->isOnline()) continue;

                if ($bm !== null) {
                    $bm->add($pName, SeaEventManager::BEAST_REWARD);
                    $player->sendMessage("");
                    $player->sendMessage("§d* §eSea Beast Defeated!");
                    $player->sendMessage("§7You earned §6" . number_format(SeaEventManager::BEAST_REWARD) . " Berries§7!");
                    $player->sendMessage("");
                }

                if ($statsPlugin !== null && $statsPlugin->isEnabled()) {
                    $statsPlugin->getStatManager()->addLevels($player, 3);
                }
            }
        }

        $sm->removeActiveEntity($this->getId());
    }

    $this->tryDropDevilFruit();

    parent::kill();
}

    private function tryDropDevilFruit() {
        if (mt_rand(1, 1000) > 50) return;

        $devilPlugin = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin === null || !$devilPlugin->isEnabled()) return;

        $fm = $devilPlugin->getFruitManager();
        if ($fm === null) return;

        $allFruits = $fm->getAllFruits();
        if (empty($allFruits)) return;

        // Group by rarity
        $byRarity = ["common" => [], "rare" => [], "legendary" => [], "mythical" => []];
        foreach ($allFruits as $fruit) {
            $r = $fruit->getRarity();
            if (isset($byRarity[$r])) $byRarity[$r][] = $fruit;
        }
        $byRarity = array_filter($byRarity, function($arr) { return !empty($arr); });
        if (empty($byRarity)) return;

        // Equal chance per rarity tier
        $rarities   = array_keys($byRarity);
        $pickedRarity = $rarities[array_rand($rarities)];
        $fruits     = $byRarity[$pickedRarity];
        $fruit      = $fruits[array_rand($fruits)];

        $item = Item::get(Item::GOLDEN_APPLE, 0, 1);
        $item->setCustomName($fruit->getRarityColor() . $fruit->getDisplayName());

        $spawnPos = new \pocketmine\math\Vector3($this->spawnX, $this->spawnY + 1, $this->spawnZ);
        $this->level->dropItem($spawnPos, $item);
    }

    public function knockBack(Entity $attacker, $damage, $x, $z, $base = 0.4) {}

    private function getHpBar() {
        $pct  = $this->getMaxHealth() > 0 ? $this->getHealth() / $this->getMaxHealth() : 0;
        $fill = (int)round($pct * 10);
        return "§d" . str_repeat("|", $fill) . "§7" . str_repeat("|", 10 - $fill);
    }

    public function onUpdate($currentTick) {
        if ($this->closed) return false;

        if (!$this->isAlive()) {
            if (++$this->deadTicks >= 10) {
                $this->despawnFromAll();
                $this->close();
            }
            return $this->deadTicks < 10;
        }

        $tickDiff = $currentTick - $this->lastUpdate;
        if ($tickDiff <= 0) return true;
        $this->lastUpdate = $currentTick;

        $this->entityBaseTick($tickDiff);
        if ($this->closed) return false;

        $sm   = $this->getSeaManager();
        $data = $sm !== null ? $sm->getEntityData($this->getId()) : null;

        if (!$this->isAlive() && $sm !== null && $data !== null) {
            $sm->removeActiveEntity($this->getId());
        }

        if ($sm === null || $data === null) {
            if (!$this->closed) $this->close();
            return !$this->closed;
        }

        if ($currentTick - $this->lastDamageTick >= SeaEventManager::DESPAWN_TICKS) {
            $sm->removeActiveEntity($this->getId());
            $this->close();
            return false;
        }

        $target = $this->updateMove($tickDiff);

        if ($target instanceof Player && $target->isAlive()) {
            if ($this->beamDelay <= 0) {
                $dist = $this->distanceSquared($target);
                if ($dist <= 2500) {
                    $this->shootBeam($target);
                    $this->beamDelay = 30;

                    if ($dist <= 64) {
                        $rawDmg = SeaEventManager::BEAST_DAMAGE;
                        $dmg    = SeaCombatHelper::scaleEntityToPlayerDamage($target, $rawDmg, SeaCombatHelper::BEAST_DAMAGE_CAP);
                        $ev     = new EntityDamageByEntityEvent($this, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $dmg);
                        $target->attack($dmg, $ev);
                        $target->sendTip("§d! Sea Beast fires a beam!");
                        $this->attackDelay = 40;
                    }
                }
            }
        }

        if ($this->attackDelay > 0) $this->attackDelay -= $tickDiff;
        if ($this->beamDelay > 0)   $this->beamDelay   -= $tickDiff;
        if ($this->moveTime > 0)    $this->moveTime     -= $tickDiff;

        $tag = "§dSea Beast §7[Lv.§f" . $this->beastLevel . "§7]\n" . $this->getHpBar() . "\n§f" . number_format((int)$this->getHealth()) . "§7/§f" . number_format((int)$this->getMaxHealth());
        $this->setNameTag($tag);

        if (!$this->closed) $this->scheduleUpdate();
        return !$this->closed;
    }

    public function entityBaseTick($tickDiff = 1, $EnchantL = 0) {
        if ($this->closed) return false;

        if (!$this->isAlive()) {
            $this->despawnFromAll();
            $this->close();
            return false;
        }

        if (count($this->effects) > 0) {
            foreach ($this->effects as $effect) {
                if ($effect->canTick()) $effect->applyEffect($this);
                $effect->setDuration($effect->getDuration() - $tickDiff);
                if ($effect->getDuration() <= 0) $this->removeEffect($effect->getId());
            }
        }

        if ($this->noDamageTicks > 0) {
            $this->noDamageTicks -= $tickDiff;
            if ($this->noDamageTicks < 0) $this->noDamageTicks = 0;
        }

        $this->age        += $tickDiff;
        $this->ticksLived += $tickDiff;
        if ($this->attackTime > 0) $this->attackTime -= $tickDiff;

        return true;
    }

    public function getDrops()        { return []; }
    public function getXpDropAmount() { return 0; }

    public function spawnTo(Player $player) {
        if (isset($this->hasSpawned[$player->getLoaderId()])) return;
        if (!isset($player->usedChunks[Level::chunkHash($this->chunk->getX(), $this->chunk->getZ())])) return;

        $this->hasSpawned[$player->getLoaderId()] = $player;

        $pk            = new AddEntityPacket();
        $pk->eid       = $this->getId();
        $pk->type      = self::NETWORK_ID;
        $pk->x         = $this->x;
        $pk->y         = $this->y;
        $pk->z         = $this->z;
        $pk->speedX    = 0.0;
        $pk->speedY    = 0.0;
        $pk->speedZ    = 0.0;
        $pk->yaw       = $this->yaw;
        $pk->pitch     = $this->pitch;
        $pk->metadata  = $this->dataProperties;
        $player->dataPacket($pk);
    }
}