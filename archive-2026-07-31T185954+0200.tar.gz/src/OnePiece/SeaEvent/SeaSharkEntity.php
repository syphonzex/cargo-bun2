<?php
namespace OnePiece\SeaEvent;

use pocketmine\entity\Creature;
use pocketmine\entity\Entity;
use pocketmine\entity\Living;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\level\Level;
use pocketmine\math\Math;
use pocketmine\math\Vector2;
use pocketmine\math\Vector3;
use pocketmine\network\protocol\AddEntityPacket;
use OnePiece\SeaEvent\SeaCombatHelper;
use pocketmine\Player;
use pocketmine\Server;

class SeaSharkEntity extends Living {

    const NETWORK_ID = 17;

    public $width  = 0.9;
    public $height = 0.9;

    protected $gravity    = 0.08;
    protected $drag       = 0.02;
    protected $stepHeight = 0.6;

    public $sharkLevel = 1;
    public $posIdx     = -1;

    private $spawnX;
    private $spawnY;
    private $spawnZ;

    private $baseTarget       = null;
    private $moveTime         = 0;
    private $stayTime         = 0;
    private $attackDelay      = 0;
    private $lastAttackerName = null;
    private $rewardGiven      = false;
    private $lastDamageTick   = 0;

    const AGGRO_RANGE  = 256.0;
    const LEASH_RANGE  = 900.0;
    const SPEED        = 1.3;

    public function __construct($chunk, $nbt) {
        parent::__construct($chunk, $nbt);
    }

    public function getName()   { return "Sea Shark"; }
    public function getSaveId() { return "SeaShark"; }

    public function initEntity() {
        parent::initEntity();

        $this->sharkLevel = isset($this->namedtag->SharkLevel) ? (int)$this->namedtag->SharkLevel->getValue() : 1;
        $this->posIdx     = isset($this->namedtag->PosIdx)     ? (int)$this->namedtag->PosIdx->getValue()     : -1;

        $maxHp = SeaEventManager::SHARK_HP[$this->sharkLevel] ?? 80;
        $this->setMaxHealth($maxHp);
        $this->setHealth($maxHp);

        $this->spawnX = $this->x;
        $this->spawnY = $this->y;
        $this->spawnZ = $this->z;

        $this->lastDamageTick = Server::getInstance()->getTick();

        $this->setNameTag("§bSea Shark §7[Lv.§f" . $this->sharkLevel . "§7]");
        $this->setNameTagVisible(true);
        $this->setDataProperty(self::DATA_NO_AI,       self::DATA_TYPE_BYTE, 1);
        $this->setDataProperty(self::DATA_LEAD,        self::DATA_TYPE_BYTE, 0);
        $this->setDataProperty(self::DATA_LEAD_HOLDER, self::DATA_TYPE_LONG, -1);
    }

    private function getSeaManager() {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceMISC");
        return $plugin !== null ? $plugin->getSeaEventManager() : null;
    }

    private function checkTarget() {
        if ($this->attackTime > 0) return;

        if ($this->baseTarget instanceof Player) {
            if (!$this->baseTarget->isAlive() || $this->baseTarget->closed || !$this->baseTarget->spawned) {
                $this->baseTarget = null;
            } elseif ($this->distanceSquared($this->baseTarget) > self::LEASH_RANGE) {
                $this->baseTarget = null;
            }
        }

        if (!($this->baseTarget instanceof Player)) {
            $near  = PHP_INT_MAX;
            $found = null;
            foreach ($this->level->getPlayers() as $p) {
                if (!$p->isAlive() || !$p->spawned || $p->closed) continue;
                if (!$p->isSurvival() && !$p->isAdventure()) continue;
                $d = $this->distanceSquared($p);
                if ($d > self::AGGRO_RANGE || $d >= $near) continue;
                $near  = $d;
                $found = $p;
            }
            if ($found !== null) {
                $this->baseTarget = $found;
                $this->moveTime   = 0;
            } else {
                if ($this->moveTime <= 0 || !($this->baseTarget instanceof Vector3)) {
                    $x = mt_rand(5, 20);
                    $z = mt_rand(5, 20);
                    $this->moveTime   = mt_rand(100, 400);
                    $this->baseTarget = new Vector3(
                        $this->spawnX + (mt_rand(0, 1) ? $x : -$x),
                        $this->spawnY,
                        $this->spawnZ + (mt_rand(0, 1) ? $z : -$z)
                    );
                }
            }
        }
    }

    private function updateMove($tickDiff) {
        if ($this->attackTime > 0) {
            $this->move($this->motionX * $tickDiff, $this->motionY * $tickDiff, $this->motionZ * $tickDiff);
            if ($this->onGround) $this->motionY = 0;
            else $this->motionY -= $this->gravity;
            $this->updateMovement();
            return null;
        }

        $this->checkTarget();

        if ($this->baseTarget !== null) {
            $x    = $this->baseTarget->x - $this->x;
            $y    = $this->baseTarget->y - $this->y;
            $z    = $this->baseTarget->z - $this->z;
            $diff = abs($x) + abs($z);

            if ($diff < 0.7) {
                $this->motionX = 0;
                $this->motionZ = 0;
            } elseif ($diff > 0) {
                $this->motionX = self::SPEED * 0.15 * ($x / $diff);
                $this->motionZ = self::SPEED * 0.15 * ($z / $diff);
            }

            if ($diff > 0) {
                $this->yaw   = -atan2($x / $diff, $z / $diff) * 180 / M_PI;
                $this->pitch = $y == 0 ? 0 : rad2deg(-atan2($y, sqrt($x * $x + $z * $z)));
            }
        }

        $dx = $this->motionX * $tickDiff;
        $dz = $this->motionZ * $tickDiff;

        $blockBelow = $this->level->getBlockIdAt((int)$this->x, (int)($this->y - 0.1), (int)$this->z);
        $blockAt    = $this->level->getBlockIdAt((int)$this->x, (int)$this->y, (int)$this->z);
        $blockAbove = $this->level->getBlockIdAt((int)$this->x, (int)($this->y + 1), (int)$this->z);

        $inWater  = ($blockAt === 8 || $blockAt === 9);
        $aboveWater = ($blockAbove !== 8 && $blockAbove !== 9);

        if ($inWater && $aboveWater) {
            $this->motionY = 0.04;
        } elseif ($inWater && !$aboveWater) {
            $this->motionY = 0.0;
        } elseif (!$inWater) {
            $this->motionY -= $this->gravity;
        }

        if ($this->isCollidedHorizontally && $this->onGround) {
            $this->motionY = 0.42;
        }

        if ($this->stayTime > 0) {
            $this->stayTime -= $tickDiff;
            $this->move(0, $this->motionY * $tickDiff, 0);
        } else {
            $be = new Vector2($this->x + $dx, $this->z + $dz);
            $this->move($dx, $this->motionY * $tickDiff, $dz);
            $af = new Vector2($this->x, $this->z);
            if (($be->x != $af->x || $be->y != $af->y)) {
                $this->moveTime -= 90 * $tickDiff;
            }
        }

        if ($this->onGround) {
            $this->motionY = 0;
        } elseif (!($this->level->getBlockIdAt((int)$this->x, (int)$this->y, (int)$this->z) === 8 || $this->level->getBlockIdAt((int)$this->x, (int)$this->y, (int)$this->z) === 9)) {
            if ($this->motionY > -$this->gravity * 4) {
                $this->motionY = -$this->gravity * 4;
            } else {
                $this->motionY -= $this->gravity;
            }
        }

        $this->updateMovement();
        return $this->baseTarget;
    }

    public function attack($damage, EntityDamageEvent $source) {
        if ($this->closed || !$this->isAlive()) return;

        $attackerName = null;
        if ($source instanceof EntityDamageByEntityEvent) {
            $raw = $source->getDamager();
            if ($raw instanceof Player) {
                $attackerName           = $raw->getName();
                $this->lastAttackerName = $attackerName;
                $this->baseTarget       = $raw;
                $this->moveTime         = 0;

                $scaledDamage = SeaCombatHelper::scalePlayerToEntityDamage($raw, $source->getFinalDamage(), "shark");
                $source->setDamage($scaledDamage);

                $motion = (new Vector3($this->x - $raw->x, $this->y - $raw->y, $this->z - $raw->z))->normalize();
                $this->motionX = $motion->x * 0.19;
                $this->motionZ = $motion->z * 0.19;
                $this->motionY = 0.5;
            }
        }

        if ($attackerName !== null) {
            $sm = $this->getSeaManager();
            if ($sm !== null) {
                $sm->recordEntityDamage($this->getId(), $attackerName, max(1, $source->getFinalDamage()));
            }
            $this->lastDamageTick = Server::getInstance()->getTick();
            $attacker = Server::getInstance()->getPlayerExact($attackerName);
            if ($attacker !== null) {
                $attacker->sendTip("§b[Shark Lv." . $this->sharkLevel . "] " . $this->getHpBar() . " §f" . number_format((int)$this->getHealth()) . "§7/§f" . number_format((int)$this->getMaxHealth()));
            }
        }

        // Scale damage from player using their stats
        if ($attackerName !== null) {
            $attacker = \pocketmine\Server::getInstance()->getPlayerExact($attackerName);
            if ($attacker !== null) {
                $scaledDamage = SeaCombatHelper::scalePlayerToEntityDamage($attacker, $source->getFinalDamage(), "shark");
                $source->setDamage($scaledDamage);
            }
        }

        parent::attack($damage, $source);
    }

public function kill() {
    if ($this->rewardGiven) return;
    $this->rewardGiven = true;

    $sm          = $this->getSeaManager();
    $reward      = SeaEventManager::SHARK_REWARDS[$this->sharkLevel] ?? 3000;
    $berryPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceBerry");
    $statsPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceStats");

    $expPercents = [1 => 0.60, 2 => 0.70, 3 => 0.80, 4 => 0.90];

    if ($sm !== null) {
        $data = $sm->getEntityData($this->getId());
        if ($data !== null && $berryPlugin !== null) {
            $bm = $berryPlugin->getBerryManager();
            foreach ($data["damageLog"] as $pName => $dmg) {
                $player = Server::getInstance()->getPlayerExact($pName);
                if ($player === null || !$player->isOnline()) continue;

                $bm->add($pName, $reward);
                $player->sendMessage("§b* §eYou earned §6" . number_format($reward) . " Berries §efor slaying a Lv." . $this->sharkLevel . " Sea Shark!");

                if ($statsPlugin !== null && $statsPlugin->isEnabled()) {
                    $statManager = $statsPlugin->getStatManager();
                    if ($this->sharkLevel >= 5) {
                        $statManager->addLevels($player, 1);
                    } elseif (isset($expPercents[$this->sharkLevel])) {
                        $statManager->addExpPercent($player, $expPercents[$this->sharkLevel]);
                    }
                }
            }
        }
        $sm->removeActiveEntity($this->getId());
    }

    parent::kill();
}

    public function knockBack(Entity $attacker, $damage, $x, $z, $base = 0.4) {}

    private function getHpBar() {
        $pct  = $this->getMaxHealth() > 0 ? $this->getHealth() / $this->getMaxHealth() : 0;
        $fill = (int)round($pct * 10);
        return "§a" . str_repeat("|", $fill) . "§7" . str_repeat("|", 10 - $fill);
    }

    public function onUpdate($currentTick) {
        if ($this->closed) return false;

        if (!$this->isAlive()) {
            if (++$this->deadTicks >= 10) {
                $this->despawnFromAll();
                $this->close();
            }
            return $this->deadTicks < 10;
        }

        $tickDiff = $currentTick - $this->lastUpdate;
        if ($tickDiff <= 0) return true;
        $this->lastUpdate = $currentTick;

        $this->entityBaseTick($tickDiff);
        if ($this->closed) return false;

        $sm   = $this->getSeaManager();
        $data = $sm !== null ? $sm->getEntityData($this->getId()) : null;

        // Stale entry cleanup - if entity is dead but still in manager, remove it
        if (!$this->isAlive() && $sm !== null && $data !== null) {
            $sm->removeActiveEntity($this->getId());
        }

        if ($sm === null || $data === null) {
            if (!$this->closed) $this->close();
            return !$this->closed;
        }

        if ($currentTick - $this->lastDamageTick >= SeaEventManager::DESPAWN_TICKS) {
            $sm->removeActiveEntity($this->getId());
$this->close();
            return false;
        }

        $target = $this->updateMove($tickDiff);

        if ($target instanceof Player && $target->isAlive()) {
            $dist = $this->distanceSquared($target);
            if ($this->attackDelay <= 0 && $dist <= 4.0) {
                $rawDmg  = SeaEventManager::SHARK_DAMAGE[$this->sharkLevel] ?? 2.0;
                $dmg     = SeaCombatHelper::scaleEntityToPlayerDamage($target, $rawDmg, SeaCombatHelper::SHARK_DAMAGE_CAP);
                $ev      = new EntityDamageByEntityEvent($this, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $dmg);
                $target->attack($dmg, $ev);
                $this->attackDelay = 20;
            }
        }

        if ($this->attackDelay > 0) $this->attackDelay -= $tickDiff;
        if ($this->moveTime > 0)    $this->moveTime    -= $tickDiff;

        $tag = "§bSea Shark §7[Lv.§f" . $this->sharkLevel . "§7]\n" . $this->getHpBar() . "\n§f" . number_format((int)$this->getHealth()) . "§7/§f" . number_format((int)$this->getMaxHealth());
        $this->setNameTag($tag);

        if (!$this->closed) $this->scheduleUpdate();
        return !$this->closed;
    }

    public function entityBaseTick($tickDiff = 1, $EnchantL = 0) {
        if ($this->closed) return false;

        if (!$this->isAlive()) {
            $this->despawnFromAll();
            $this->close();
            return false;
        }

        if (count($this->effects) > 0) {
            foreach ($this->effects as $effect) {
                if ($effect->canTick()) $effect->applyEffect($this);
                $effect->setDuration($effect->getDuration() - $tickDiff);
                if ($effect->getDuration() <= 0) $this->removeEffect($effect->getId());
            }
        }

        if ($this->noDamageTicks > 0) {
            $this->noDamageTicks -= $tickDiff;
            if ($this->noDamageTicks < 0) $this->noDamageTicks = 0;
        }

        $this->age        += $tickDiff;
        $this->ticksLived += $tickDiff;
        if ($this->attackTime > 0) $this->attackTime -= $tickDiff;

        return true;
    }

    public function getDrops()        { return []; }
    public function getXpDropAmount() { return 0; }

    public function spawnTo(Player $player) {
        if (isset($this->hasSpawned[$player->getLoaderId()])) return;
        if (!isset($player->usedChunks[Level::chunkHash($this->chunk->getX(), $this->chunk->getZ())])) return;

        $this->hasSpawned[$player->getLoaderId()] = $player;

        $pk            = new AddEntityPacket();
        $pk->eid       = $this->getId();
        $pk->type      = self::NETWORK_ID;
        $pk->x         = $this->x;
        $pk->y         = $this->y;
        $pk->z         = $this->z;
        $pk->speedX    = 0.0;
        $pk->speedY    = 0.0;
        $pk->speedZ    = 0.0;
        $pk->yaw       = $this->yaw;
        $pk->pitch     = $this->pitch;
        $pk->metadata  = $this->dataProperties;
        $player->dataPacket($pk);
    }
}