<?php
namespace OnePiece\SeaEvent;

use pocketmine\entity\Effect;
use pocketmine\entity\Entity;
use pocketmine\entity\Lightning;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\WhiteSmokeParticle;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\WaterDripParticle;
use pocketmine\level\particle\BubbleParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\sound\AnvilFallSound;
use pocketmine\level\sound\ExplodeSound;
use pocketmine\level\sound\GhastSound;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class StormZoneTask extends Task {

    private $plugin;
    private $tickCount  = 0;

    // Stores per-storm fixed data set once when storm spawns
    // [stormIdx] = [
    //   "cloudY"   => float,  // fixed cloud height forever
    //   "playerY"  => float,  // fixed Y used for lightning forever
    //   "surfaceY" => float,  // fixed surface Y forever
    //   "cx"       => float,  // storm center X
    //   "cz"       => float,  // storm center Z
    // ]
    private $stormData  = [];

    // Tracks nausea cooldown per player [playerName] => lastNauseaTick
    private $nauseaCooldown = [];

    public function __construct($plugin) {
        $this->plugin = $plugin;
    }

    public function onRun($currentTick) {
        $this->tickCount++;
        $sm     = $this->plugin->getSeaEventManager();
        $server = Server::getInstance();

        foreach ($sm->getActiveStorms() as $idx => $storm) {
            $worldName = $storm["world"];
            $cx        = (float)$storm["x"];
            $cz        = (float)$storm["z"];
            $r         = SeaEventManager::STORM_RADIUS;

            if (!$server->isLevelLoaded($worldName)) continue;
            $level = $server->getLevelByName($worldName);
            if ($level === null) continue;

            // Initialize storm data ONCE - never changes after this
            if (!isset($this->stormData[$idx])) {
                // Find surface Y once
                $surfaceY = 64;
                for ($sy = 70; $sy >= 40; $sy--) {
                    $bid = $level->getBlockIdAt((int)$cx, $sy, (int)$cz);
                    if ($bid !== 0 && $bid !== 8 && $bid !== 9) { $surfaceY = $sy + 1; break; }
                    if ($bid === 8 || $bid === 9)               { $surfaceY = $sy + 1; break; }
                }

                // Find any online player to get initial Y reference
                // If no player found yet, default to surfaceY
                $initY = (float)$surfaceY;
                foreach ($level->getPlayers() as $p) {
                    if ($p->isOnline() && $p->isAlive()) {
                        $dx = $p->x - $cx;
                        $dz = $p->z - $cz;
                        if (sqrt($dx * $dx + $dz * $dz) <= $r) {
                            $initY = (float)$p->y;
                            break;
                        }
                    }
                }

                // Store everything permanently for this storm
                $this->stormData[$idx] = [
                    "cloudY"   => $initY + 15.0,
                    "playerY"  => $initY,
                    "surfaceY" => (float)$surfaceY,
                    "cx"       => $cx,
                    "cz"       => $cz,
                ];
            }

            // Always use fixed stored values - never recalculate
            $cloudY   = $this->stormData[$idx]["cloudY"];
            $playerY  = $this->stormData[$idx]["playerY"];
            $surfaceY = $this->stormData[$idx]["surfaceY"];

            // Get all players in level and players inside storm
            $allPlayers     = $level->getPlayers();
            $playersInStorm = [];

            foreach ($allPlayers as $p) {
                if (!$p->isOnline() || !$p->isAlive()) continue;
                $dx   = $p->x - $cx;
                $dz   = $p->z - $cz;
                $dist = sqrt($dx * $dx + $dz * $dz);

                if ($dist <= $r) {
                    $playersInStorm[] = $p;
                    $pName = $p->getName();

                    // Send tip once on entry
                    if (!isset($this->nauseaCooldown[$pName . "_entered"])) {
                        $p->sendTip("§9SEA STORM");
                        $this->nauseaCooldown[$pName . "_entered"] = true;
                    }
                } else {
                    // Reset entry tip flag when player leaves
                    $pName = $p->getName();
                    if (isset($this->nauseaCooldown[$pName . "_entered"])) {
                        unset($this->nauseaCooldown[$pName . "_entered"]);
                    }
                }
            }

            // ringPlayers - who sees the boundary ring
            // Storm effects always run regardless of players inside
            $ringPlayers = !empty($allPlayers) ? $allPlayers : [];
            if (empty($ringPlayers)) continue;

            // Storm boundary smoke ring - always runs
            if ($this->tickCount % 2 === 0) {
                $points = 16;
                for ($i = 0; $i < $points; $i++) {
                    $a  = ($i / $points) * M_PI * 2 + ($this->tickCount * 0.05);
                    $px = $cx + cos($a) * $r;
                    $pz = $cz + sin($a) * $r;
                    $py = $surfaceY + mt_rand(0, 2);
                    $level->addParticle(new SmokeParticle(new Vector3($px, $py, $pz)), $ringPlayers);
                    if ($i % 4 === 0) {
                        $level->addParticle(new WhiteSmokeParticle(new Vector3($px, $py + 1, $pz)), $ringPlayers);
                    }
                }

                // Interior dust
                for ($i = 0; $i < 4; $i++) {
                    $a   = mt_rand(0, 628) / 100.0;
                    $d   = mt_rand(0, (int)($r * 8)) / 10.0;
                    $ipx = $cx + cos($a) * $d;
                    $ipz = $cz + sin($a) * $d;
                    $ipy = $surfaceY + mt_rand(0, 3);
                    $level->addParticle(new DustParticle(new Vector3($ipx, $ipy, $ipz), 80, 80, 100), $ringPlayers);
                }
            }

            // Cloud layer - always runs using fixed cloudY
            if ($this->tickCount % 2 === 0) {
                $cloudParticles = 16;
                for ($i = 0; $i < $cloudParticles; $i++) {
                    $a      = mt_rand(0, 628) / 100.0;
                    $d      = mt_rand(0, (int)($r * 10)) / 10.0;
                    $cloudX = $cx + cos($a) * $d;
                    $cloudZ = $cz + sin($a) * $d;

                    // Fixed cloudY - never changes
                    $offsets = [
                        [ 0.0,  0.0],
                        [ 0.5,  0.0],
                        [-0.5,  0.0],
                        [ 0.0,  0.5],
                        [ 0.0, -0.5],
                        [ 0.3,  0.3],
                        [-0.3,  0.3],
                        [ 0.3, -0.3],
                    ];
                    foreach ($offsets as $off) {
                        $level->addParticle(new WhiteSmokeParticle(new Vector3(
                            $cloudX + $off[0],
                            $cloudY, // always fixed
                            $cloudZ + $off[1]
                        )), $ringPlayers);
                    }

                    if ($i % 3 === 0) {
                        $level->addParticle(new DustParticle(new Vector3(
                            $cloudX + 0.25,
                            $cloudY - 0.5,
                            $cloudZ + 0.25
                        ), 200, 200, 210), $ringPlayers);
                    }
                }
            }

            // Rain - Blue dust particles falling from cloud
            $rainCount = 50; // Increased for better rain coverage
            for ($i = 0; $i < $rainCount; $i++) {
                $a          = mt_rand(0, 628) / 100.0;
                $rainSpread = mt_rand(1, (int)($r * 10)) / 10.0;
                $rx         = $cx + cos($a) * $rainSpread;
                $rz         = $cz + sin($a) * $rainSpread;

                // Dense blue dust particles from just below cloud to surface
                // Creates a beautiful blue rain curtain effect
                for ($rainY = $cloudY - 2; $rainY >= $surfaceY + 1; $rainY -= 0.5) {
                    // Bright blue dust (light blue) - main rain color
                    $level->addParticle(new DustParticle(new Vector3(
                        $rx, $rainY, $rz
                    ), 120, 180, 255), $ringPlayers);
                    
                    // Every 2 blocks add darker blue for depth
                    if ((int)($rainY * 2) % 4 === 0) {
                        $level->addParticle(new DustParticle(new Vector3(
                            $rx + 0.1, $rainY, $rz
                        ), 80, 140, 220), $ringPlayers);
                    }
                    
                    // Every 3 blocks add cyan tint for variety
                    if ((int)($rainY * 2) % 6 === 0) {
                        $level->addParticle(new DustParticle(new Vector3(
                            $rx - 0.1, $rainY, $rz + 0.1
                        ), 100, 200, 255), $ringPlayers);
                    }
                }

                // Water drip particles for realism (less frequent)
                if ($i % 3 === 0) {
                    for ($rainY = $cloudY - 2; $rainY >= $surfaceY + 1; $rainY -= 2.0) {
                        $level->addParticle(new WaterDripParticle(new Vector3($rx, $rainY, $rz)), $ringPlayers);
                    }
                }

                // Splash at surface - blue dust particles
                $splashOffsets = [
                    [ 0.0,  0.0],
                    [ 0.2,  0.0],
                    [-0.2,  0.0],
                    [ 0.0,  0.2],
                    [ 0.0, -0.2],
                    [ 0.15, 0.15],
                    [-0.15, 0.15],
                ];
                foreach ($splashOffsets as $so) {
                    // Bright blue splash
                    $level->addParticle(new DustParticle(new Vector3(
                        $rx + $so[0],
                        $surfaceY + 0.1,
                        $rz + $so[1]
                    ), 100, 180, 255), $ringPlayers);
                }

                // Surface impact effects
                if ($i % 2 === 0) {
                    // Water drip at surface
                    $level->addParticle(new WaterDripParticle(new Vector3(
                        $rx, $surfaceY + 0.1, $rz
                    )), $ringPlayers);
                    
                    // Blue dust splash
                    $level->addParticle(new DustParticle(new Vector3(
                        $rx, $surfaceY + 0.2, $rz
                    ), 120, 200, 255), $ringPlayers);
                }
                
                // Bubble splash occasionally
                if ($i % 4 === 0) {
                    $level->addParticle(new BubbleParticle(new Vector3(
                        $rx, $surfaceY + 0.3, $rz
                    )), $ringPlayers);
                }
            }

            // Nausea for players inside storm - 5 seconds on 5 seconds off loop
            // 5 seconds = 100 ticks
            foreach ($playersInStorm as $p) {
                $pName = $p->getName();

                if (!isset($this->nauseaCooldown[$pName])) {
                    $this->nauseaCooldown[$pName] = 0;
                }

                $lastTick = $this->nauseaCooldown[$pName];

                // Apply nausea every 40 ticks, duration 140 ticks
                if ($this->tickCount - $lastTick >= 40) {
                    $nausea = Effect::getEffect(Effect::NAUSEA);
                    $nausea->setDuration(140); // 7 seconds duration
                    $nausea->setAmplifier(0);
                    $nausea->setVisible(false);
                    $p->addEffect($nausea);

                    // Store tick when nausea was last applied
                    $this->nauseaCooldown[$pName] = $this->tickCount;
                }
            }

            // Clean up nausea cooldown for players who left storm
            foreach ($allPlayers as $p) {
                $pName = $p->getName();
                $dx    = $p->x - $cx;
                $dz    = $p->z - $cz;
                if (sqrt($dx * $dx + $dz * $dz) > $r) {
                    // Remove nausea when they leave
                    if (isset($this->nauseaCooldown[$pName])) {
                        $p->removeEffect(Effect::NAUSEA);
                        unset($this->nauseaCooldown[$pName]);
                    }
                }
            }

            // Lightning always runs every 40 ticks using fixed stored Y
            if ($this->tickCount % 40 === 0) {
                $this->strikeLightning($level, $cx, $surfaceY, $cz, $r, $playersInStorm, $idx);
            }
        }

        // Clean up storm data for removed storms
        foreach (array_keys($this->stormData) as $idx) {
            $activeStorms = $sm->getActiveStorms();
            if (!isset($activeStorms[$idx])) {
                unset($this->stormData[$idx]);
            }
        }
    }

    private function strikeLightning($level, $cx, $surfaceY, $cz, $r, array $playersInStorm, $idx) {
        $roll       = mt_rand(1, 3);
        $hitsPlayer = ($roll === 1);

        // Always use fixed stored playerY for lightning Y
        $fixedY = isset($this->stormData[$idx])
            ? $this->stormData[$idx]["playerY"]
            : (float)$surfaceY;

        if ($hitsPlayer && !empty($playersInStorm)) {
            // Hit a random player inside the storm
            $target = $playersInStorm[array_rand($playersInStorm)];
            $lx     = $target->x;
            $lz     = $target->z;
            $ly     = $fixedY; // fixed Y always
        } else {
            // Random location inside storm at fixed Y
            $a  = mt_rand(0, 628) / 100.0;
            $d  = mt_rand(0, (int)($r * 10)) / 10.0;
            $lx = $cx + cos($a) * $d;
            $lz = $cz + sin($a) * $d;
            $ly = $fixedY; // fixed Y always
        }

        $chunk = $level->getChunk((int)$lx >> 4, (int)$lz >> 4, true);
        if ($chunk === null) return;

        $nbt = new CompoundTag("", [
            "Pos"      => new ListTag("Pos", [
                new DoubleTag("", $lx),
                new DoubleTag("", $ly),
                new DoubleTag("", $lz),
            ]),
            "Motion"   => new ListTag("Motion", [
                new DoubleTag("", 0.0),
                new DoubleTag("", 0.0),
                new DoubleTag("", 0.0),
            ]),
            "Rotation" => new ListTag("Rotation", [
                new FloatTag("", 0.0),
                new FloatTag("", 0.0),
            ]),
        ]);

        $lightning = new Lightning($chunk, $nbt);
        $lightning->spawnToAll();

        $level->addSound(new ExplodeSound(new Vector3($lx, $ly, $lz)));
        $level->addSound(new AnvilFallSound(new Vector3($lx, $ly, $lz)));
        $level->addSound(new GhastSound(new Vector3($lx, $ly, $lz)));

        // Only damage players inside the storm
        if ($hitsPlayer && !empty($playersInStorm)) {
            $target = $playersInStorm[array_rand($playersInStorm)];
            if ($target->isAlive()) {
                $dmg = mt_rand(4, 8);
                $ev  = new EntityDamageByEntityEvent(
                    $lightning,
                    $target,
                    EntityDamageEvent::CAUSE_LIGHTNING,
                    $dmg
                );
                $target->attack($dmg, $ev);
                $target->sendTip("§9 You were struck by lightning! (-" . $dmg . " HP)");
            }
        }
    }
}