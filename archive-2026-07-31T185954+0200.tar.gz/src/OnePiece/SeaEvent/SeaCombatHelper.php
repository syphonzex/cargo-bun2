<?php
namespace OnePiece\SeaEvent;

use pocketmine\Player;
use pocketmine\Server;

class SeaCombatHelper {

    const SHARK_DAMAGE_CAP = 12.0;
    const BEAST_DAMAGE_CAP = 24.0;
    const KAEN_DAMAGE_CAP = 20.0;

    public static function scalePlayerToEntityDamage(Player $player, $baseDamage, $entityType = "shark") {
        $server = Server::getInstance();
        $name   = $player->getName();

        $strengthMult = 1.0;

        $statsPlugin = $server->getPluginManager()->getPlugin("OnePieceStats");
        if ($statsPlugin !== null && $statsPlugin->isEnabled()) {
            $sm = $statsPlugin->getStatManager();
            if ($sm !== null && $sm->isLoaded($player)) {
                $sp = $sm->getStatPlayer($player);
                if ($sp !== null) {
                    $scaler       = $statsPlugin->getStatScaler();
                    $strengthMult = $scaler->getAttackMultiplier(min(100, $sp->getStat("strength")));
                }
            }
        }

        $scaled = $baseDamage * $strengthMult;

        // Hard cap per hit to prevent one-shotting
        $cap = $entityType === "beast" ? self::BEAST_DAMAGE_CAP : ($entityType === "kaen" ? self::KAEN_DAMAGE_CAP : self::SHARK_DAMAGE_CAP);
        return min($cap, max(0.5, $scaled));
    }

    public static function scaleEntityToPlayerDamage(Player $player, $rawDamage, $cap) {
        $server = Server::getInstance();

        $defenseReduction = 0.0;
        $armamentReduction = 0.0;

        $statsPlugin = $server->getPluginManager()->getPlugin("OnePieceStats");
        if ($statsPlugin !== null && $statsPlugin->isEnabled()) {
            $sm = $statsPlugin->getStatManager();
            if ($sm !== null && $sm->isLoaded($player)) {
                $sp = $sm->getStatPlayer($player);
                if ($sp !== null) {
                    $scaler      = $statsPlugin->getStatScaler();
                    $defenseStat = min(100, $sp->getStat("defense"));
                    // derive reduction from defenseMultiplier: multiplier = 1/(1-reduction)
                    // so reduction = 1 - 1/multiplier
                    try {
                        $defMult          = $scaler->getDefenseMultiplier($defenseStat);
                        $defenseReduction = max(0.0, 1.0 - (1.0 / max(1.0, $defMult)));
                    } catch (\Exception $e) {
                        $defenseReduction = 0.0;
                    }
                }
            }
        }

        $hakiPlugin = $server->getPluginManager()->getPlugin("OnePieceHaki");
        if ($hakiPlugin !== null && $hakiPlugin->isEnabled()) {
            $armament = $hakiPlugin->getArmament();
            if ($armament !== null && $armament->isActive($player)) {
                $defenseBoost      = $armament->getDefenseBoost($player);
                $armamentReduction = 1.0 - (1.0 / $defenseBoost);
            }
        }

        $totalReduction = min(0.85, $defenseReduction + $armamentReduction);
        $damage         = min($cap, $rawDamage) * (1.0 - $totalReduction);
        return max(0.5, $damage);
    }
}