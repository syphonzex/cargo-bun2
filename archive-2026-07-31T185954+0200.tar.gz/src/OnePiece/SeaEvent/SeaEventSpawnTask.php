<?php
namespace OnePiece\SeaEvent;

use pocketmine\block\Block;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\level\sound\SplashSound;
use pocketmine\level\sound\FizzSound;
use pocketmine\level\sound\GhastSound;
use pocketmine\level\sound\ExplodeSound;
use pocketmine\level\sound\AnvilFallSound;
use pocketmine\math\Vector3;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class SeaEventSpawnTask extends Task {

    private $plugin;

    public function __construct($plugin) {
        $this->plugin = $plugin;
    }

    public function onRun($currentTick) {
        $sm      = $this->plugin->getSeaEventManager();
        $server  = Server::getInstance();

        foreach ($sm->getEnabledWorlds() as $worldName) {
            if (!$server->isLevelLoaded($worldName)) $server->loadLevel($worldName);
            $level = $server->getLevelByName($worldName);
            if ($level === null) continue;

            foreach ($level->getPlayers() as $player) {
                if (!$player->isAlive() || !$player->spawned) continue;
                if (!$this->isNearWater($level, $player)) continue;
                if (mt_rand(1, 100) > SeaEventManager::EVENT_SPAWN_CHANCE) continue;

                $type = $sm->rollEventType();

                if ($type === SeaEventManager::TYPE_SHARK  && $sm->countActiveByType(SeaEventManager::TYPE_SHARK)  >= SeaEventManager::MAX_ACTIVE_SHARKS) continue;
                if ($type === SeaEventManager::TYPE_BEAST  && $sm->countActiveByType(SeaEventManager::TYPE_BEAST)  >= SeaEventManager::MAX_ACTIVE_BEASTS) continue;
                if ($type === SeaEventManager::TYPE_KAEN   && $sm->countActiveByType(SeaEventManager::TYPE_KAEN)   >= SeaEventManager::MAX_ACTIVE_KAEN)   continue;
                if ($type === SeaEventManager::TYPE_STORM  && count($sm->getActiveStorms())                        >= SeaEventManager::MAX_ACTIVE_STORMS) continue;

                $dir    = $player->getDirectionVector();
                $dist   = mt_rand(20, 50);
                $spawnX = (int)($player->x + $dir->x * $dist + mt_rand(-6, 6));
                $spawnZ = (int)($player->z + $dir->z * $dist + mt_rand(-6, 6));

                if ($sm->isTooCloseToExisting($spawnX, $spawnZ, $worldName)) continue;
                if ($this->isTooCloseToZone($spawnX, $spawnZ, $worldName)) continue;

                if ($type === SeaEventManager::TYPE_STORM) {
                    $idx = count($sm->getActiveStorms());
                    $sm->activateStorm($idx, $spawnX, $spawnZ, $worldName);
                    $this->spawnStormLightning($level, $spawnX, $spawnZ);
break;
                }

                $spawnY = $this->findWaterSurface($level, $spawnX, $spawnZ);
                if ($spawnY === null) continue;

                if ($type === SeaEventManager::TYPE_SHARK) {
                    $this->spawnShark($sm, $level, $spawnX, $spawnY, $spawnZ, mt_rand(1, 5));
                } elseif ($type === SeaEventManager::TYPE_KAEN) {
                    $this->spawnKaen($sm, $level, $spawnX, $spawnY + 3, $spawnZ);
                } else {
                    $this->spawnBeast($sm, $level, $spawnX, $spawnY + 3, $spawnZ);
                }
                break;
            }
        }

        foreach ($sm->getActiveStorms() as $idx => $storm) {
            if ($currentTick - $storm["tick"] >= SeaEventManager::STORM_DURATION) {
                $sm->deactivateStorm($idx);
                $lv = $server->getLevelByName($storm["world"]);
                if ($lv !== null) {
}
            }
        }
    }

    private function isNearWater($level, $player) {
        $px = (int)$player->x;
        $py = (int)$player->y;
        $pz = (int)$player->z;

        for ($dx = -3; $dx <= 3; $dx++) {
            for ($dz = -3; $dz <= 3; $dz++) {
                for ($dy = -1; $dy <= 1; $dy++) {
                    $bid = $level->getBlockIdAt($px + $dx, $py + $dy, $pz + $dz);
                    if ($bid === Block::WATER || $bid === Block::STILL_WATER) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private function findWaterSurface($level, $x, $z) {
        for ($y = 15; $y >= 8; $y--) {
            $bid = $level->getBlockIdAt($x, $y, $z);
            if ($bid === Block::WATER || $bid === Block::STILL_WATER) {
                return $y;
            }
        }
        return null;
    }

    private function isTooCloseToZone($x, $z, $worldName) {
        $seaPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceSea");
        if ($seaPlugin === null || !$seaPlugin->isEnabled()) return false;

        $seaZone = $seaPlugin->getSeaZone();
        if ($seaZone === null) return false;

        $zones = $seaZone->getAllZones($worldName);
        $buffer = 30;

        foreach ($zones as $zone) {
            $min = $zone["min"];
            $max = $zone["max"];
            if (
                $x >= ($min["x"] - $buffer) && $x <= ($max["x"] + $buffer) &&
                $z >= ($min["z"] - $buffer) && $z <= ($max["z"] + $buffer)
            ) {
                return true;
            }
        }
        return false;
    }

    public function forceSpawn($sm, $level, $x, $y, $z, $type, $sharkLevel = 1) {
        if ($type === SeaEventManager::TYPE_SHARK) {
            $this->spawnShark($sm, $level, $x, $y, $z, $sharkLevel);
        } elseif ($type === SeaEventManager::TYPE_BEAST) {
            $this->spawnBeast($sm, $level, $x, $y + 3, $z);
        } elseif ($type === SeaEventManager::TYPE_STORM) {
            $idx = count($sm->getActiveStorms());
            $sm->activateStorm($idx, $x, $z, $level->getFolderName());
        } elseif ($type === SeaEventManager::TYPE_KAEN) {
            $this->spawnKaen($sm, $level, $x, $y + 3, $z);
        }
    }

    public function spawnShark($sm, $level, $x, $y, $z, $sharkLevel) {
        $level->loadChunk($x >> 4, $z >> 4, true);
        $chunk = $level->getChunk($x >> 4, $z >> 4, true);
        if ($chunk === null) return;

        $nbt = new CompoundTag("", [
            "Pos"        => new ListTag("Pos", [new DoubleTag("", $x + 0.5), new DoubleTag("", (float)$y), new DoubleTag("", $z + 0.5)]),
            "Motion"     => new ListTag("Motion", [new DoubleTag("", 0.0), new DoubleTag("", 0.0), new DoubleTag("", 0.0)]),
            "Rotation"   => new ListTag("Rotation", [new FloatTag("", 0.0), new FloatTag("", 0.0)]),
            "SharkLevel" => new IntTag("SharkLevel", $sharkLevel),
            "PosIdx"     => new IntTag("PosIdx", -1),
        ]);

        $entity = new SeaSharkEntity($chunk, $nbt);
        foreach ($level->getPlayers() as $p) {
            $entity->spawnTo($p);
        }
        $sm->registerActiveEntity($entity->getId(), SeaEventManager::TYPE_SHARK, $sharkLevel, $x, $z);


    }

    public function spawnBeast($sm, $level, $x, $y, $z) {
        $level->loadChunk($x >> 4, $z >> 4, true);
        $chunk = $level->getChunk($x >> 4, $z >> 4, true);
        if ($chunk === null) return;

        $nbt = new CompoundTag("", [
            "Pos"        => new ListTag("Pos", [new DoubleTag("", $x + 0.5), new DoubleTag("", (float)$y), new DoubleTag("", $z + 0.5)]),
            "Motion"     => new ListTag("Motion", [new DoubleTag("", 0.0), new DoubleTag("", 0.0), new DoubleTag("", 0.0)]),
            "Rotation"   => new ListTag("Rotation", [new FloatTag("", 0.0), new FloatTag("", 0.0)]),
            "BeastLevel" => new IntTag("BeastLevel", 100),
            "PosIdx"     => new IntTag("PosIdx", -1),
        ]);

        $entity = new SeaBeastEntity($chunk, $nbt);
        foreach ($level->getPlayers() as $p) {
            $entity->spawnTo($p);
        }
        $sm->registerActiveEntity($entity->getId(), SeaEventManager::TYPE_BEAST, 100, $x, $z);

        
    }

public function spawnKaen($sm, $level, $x, $y, $z) {
    $level->loadChunk($x >> 4, $z >> 4, true);
    $chunk = $level->getChunk($x >> 4, $z >> 4, true);
    if ($chunk === null) return;

    $nbt = new CompoundTag("", [
        "Pos"      => new ListTag("Pos", [new DoubleTag("", $x + 0.5), new DoubleTag("", (float)$y), new DoubleTag("", $z + 0.5)]),
        "Motion"   => new ListTag("Motion", [new DoubleTag("", 0.0), new DoubleTag("", 0.0), new DoubleTag("", 0.0)]),
        "Rotation" => new ListTag("Rotation", [new FloatTag("", 0.0), new FloatTag("", 0.0)]),
        "KaenLevel" => new IntTag("KaenLevel", 1),
        "PosIdx"    => new IntTag("PosIdx", -1),
    ]);

    $entity = new SeaKaenEntity($chunk, $nbt);
    foreach ($level->getPlayers() as $p) {
        $entity->spawnTo($p);
    }
    $sm->registerActiveEntity($entity->getId(), SeaEventManager::TYPE_KAEN, 1, $x, $z);
}

    private function spawnStormLightning($level, $x, $z) {
        $level->loadChunk($x >> 4, $z >> 4, true);
        $chunk = $level->getChunk($x >> 4, $z >> 4, true);
        if ($chunk === null) return;

        $y = 16.0;
        for ($ty = 20; $ty >= 8; $ty--) {
            $bid = $level->getBlockIdAt($x, $ty, $z);
            if ($bid !== 0) { $y = (float)($ty + 1); break; }
        }

        $nbt = new \pocketmine\nbt\tag\CompoundTag("", [
            "Pos"      => new \pocketmine\nbt\tag\ListTag("Pos", [
                new \pocketmine\nbt\tag\DoubleTag("", $x + 0.5),
                new \pocketmine\nbt\tag\DoubleTag("", $y),
                new \pocketmine\nbt\tag\DoubleTag("", $z + 0.5),
            ]),
            "Motion"   => new \pocketmine\nbt\tag\ListTag("Motion", [
                new \pocketmine\nbt\tag\DoubleTag("", 0.0),
                new \pocketmine\nbt\tag\DoubleTag("", 0.0),
                new \pocketmine\nbt\tag\DoubleTag("", 0.0),
            ]),
            "Rotation" => new \pocketmine\nbt\tag\ListTag("Rotation", [
                new \pocketmine\nbt\tag\FloatTag("", 0.0),
                new \pocketmine\nbt\tag\FloatTag("", 0.0),
            ]),
        ]);

        $lightning = new \pocketmine\entity\Lightning($chunk, $nbt);
        foreach ($level->getPlayers() as $p) {
            $lightning->spawnTo($p);
        }

        $pos = new Vector3($x + 0.5, $y, $z + 0.5);
        $level->addSound(new ExplodeSound($pos));
        $level->addSound(new AnvilFallSound($pos));
    }
}
