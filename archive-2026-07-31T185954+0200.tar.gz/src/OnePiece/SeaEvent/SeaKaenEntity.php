<?php
namespace OnePiece\SeaEvent;

use pocketmine\entity\Entity;
use pocketmine\entity\Living;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\level\Level;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\EntityFlameParticle;
use pocketmine\level\particle\LargeExplodeParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\math\Vector2;
use pocketmine\math\Vector3;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\Player;
use pocketmine\Server;

class SeaKaenEntity extends Living {

    const NETWORK_ID = 43; // Blaze

    public $width  = 0.6;
    public $height = 1.8;

    protected $gravity = 0.0;
    protected $drag    = 0.0;

    public $kaenLevel = 1;
    public $posIdx    = -1;

    private $spawnX;
    private $spawnY;
    private $spawnZ;

    private $baseTarget     = null;
    private $moveTime       = 0;
    private $attackDelay    = 0;
    private $beamDelay      = 0;
    private $auraTickOffset = 0;
    private $rewardGiven    = false;
    private $lastDamageTick = 0;
    private $lastAttackerName = null;

    const AGGRO_RANGE = 10000.0;
    const SPEED       = 0.45;

    public function __construct($chunk, $nbt) {
        parent::__construct($chunk, $nbt);
    }

    public function getName()   { return "Kaen"; }
    public function getSaveId() { return "SeaKaen"; }

    public function initEntity() {
        parent::initEntity();

        $this->kaenLevel = isset($this->namedtag->KaenLevel) ? (int)$this->namedtag->KaenLevel->getValue() : 1;
        $this->posIdx    = isset($this->namedtag->PosIdx)    ? (int)$this->namedtag->PosIdx->getValue()    : -1;

        $this->setMaxHealth(SeaEventManager::KAEN_HP);
        $this->setHealth(SeaEventManager::KAEN_HP);

        $this->spawnX = $this->x;
        $this->spawnY = $this->y;
        $this->spawnZ = $this->z;

        $this->auraTickOffset = mt_rand(0, 31);
        $this->lastDamageTick = Server::getInstance()->getTick();

        $this->setNameTag("§6Kaen §7[Sea Flame]\n§c" . str_repeat("|", 10) . "\n§f" . SeaEventManager::KAEN_HP . "§7/§f" . SeaEventManager::KAEN_HP);
        $this->setNameTagVisible(true);
        $this->setDataProperty(self::DATA_NO_AI,       self::DATA_TYPE_BYTE, 1);
        $this->setDataProperty(self::DATA_LEAD,        self::DATA_TYPE_BYTE, 0);
        $this->setDataProperty(self::DATA_LEAD_HOLDER, self::DATA_TYPE_LONG, -1);
    }

    private function getSeaManager() {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceMISC");
        return $plugin !== null ? $plugin->getSeaEventManager() : null;
    }

    private function checkTarget() {
        if ($this->baseTarget instanceof Player) {
            if (!$this->baseTarget->isAlive() || $this->baseTarget->closed || !$this->baseTarget->spawned) {
                $this->baseTarget = null;
            } elseif ($this->distanceSquared($this->baseTarget) > 40000.0) {
                $this->baseTarget = null;
            }
        }

        if (!($this->baseTarget instanceof Player)) {
            $near  = PHP_INT_MAX;
            $found = null;
            foreach ($this->level->getPlayers() as $p) {
                if (!$p->isAlive() || !$p->spawned || $p->closed) continue;
                if (!$p->isSurvival() && !$p->isAdventure()) continue;
                $d = $this->distanceSquared($p);
                if ($d > self::AGGRO_RANGE || $d >= $near) continue;
                $near  = $d;
                $found = $p;
            }
            if ($found !== null) {
                $this->baseTarget = $found;
                $this->moveTime   = 0;
            } else {
                if ($this->moveTime <= 0 || !($this->baseTarget instanceof Vector3)) {
                    $x = mt_rand(2, 5);
                    $z = mt_rand(2, 5);
                    $y = mt_rand(-1, 1);
                    $this->moveTime   = mt_rand(60, 160);
                    $this->baseTarget = new Vector3(
                        $this->spawnX + (mt_rand(0, 1) ? $x : -$x),
                        $this->spawnY + $y,
                        $this->spawnZ + (mt_rand(0, 1) ? $z : -$z)
                    );
                }
            }
        }
    }

    private function updateMove($tickDiff) {
        $this->checkTarget();

        if ($this->baseTarget !== null) {
            $x    = $this->baseTarget->x - $this->x;
            $y    = $this->baseTarget->y - $this->y;
            $z    = $this->baseTarget->z - $this->z;
            $diff = abs($x) + abs($z);

            if ($x * $x + $z * $z < 0.8) {
                $this->motionX = 0;
                $this->motionZ = 0;
            } elseif ($diff > 0) {
                $this->motionX = self::SPEED * 0.15 * ($x / $diff);
                $this->motionZ = self::SPEED * 0.15 * ($z / $diff);
                $this->motionY = self::SPEED * 0.20 * ($y / ($diff > 0 ? $diff : 1));
            }

            if ($diff > 0) {
                $this->yaw   = -atan2($x / $diff, $z / $diff) * 180 / M_PI;
                $this->pitch = $y == 0 ? 0 : rad2deg(-atan2($y, sqrt($x * $x + $z * $z)));
            }
        }

        $this->x += $this->motionX * $tickDiff;
        $this->y += $this->motionY * $tickDiff;
        $this->z += $this->motionZ * $tickDiff;

        if ($this->moveTime > 0) $this->moveTime -= $tickDiff;

        $this->updateMovement();
        return $this->baseTarget;
    }

    private function spawnAura($currentTick) {
        $t = ($currentTick + $this->auraTickOffset) % 32;
        
        // Reduced particle frequency - only spawn every 4 ticks instead of every tick
        if ($t % 4 !== 0) return;
        
        // Reduced from 3 layers to 2
        $layers = 2;

        for ($layer = 0; $layer < $layers; $layer++) {
            $angleOffset = ($layer / $layers) * M_PI * 2;
            // Reduced from 12 steps to 6
            $steps = 6;
            for ($i = 0; $i < $steps; $i++) {
                $progress = $i / $steps;
                $angle    = $angleOffset + $progress * M_PI * 2 + ($t * 0.2);
                // Increased radius to move particles away from center
                $radius   = 1.2 - $progress * 0.3;
                $height   = $progress * 2.0;

                $px = $this->x + cos($angle) * $radius;
                $py = $this->y + $height;
                $pz = $this->z + sin($angle) * $radius;

                $pos = new Vector3($px, $py, $pz);

                // Only spawn flame particles every other step
                if ($i % 2 === 0) {
                    $this->level->addParticle(new FlameParticle($pos));
                }
            }
        }

        // Reduced smoke particles - only spawn every 8 ticks instead of every 4
        if ($t % 8 === 0) {
            // Reduced from 5 smoke particles to 2
            for ($i = 0; $i < 2; $i++) {
                $angle = mt_rand(0, 628) / 100.0;
                // Increased radius to keep smoke away from center
                $r = mt_rand(10, 15) / 10.0;
                $this->level->addParticle(new SmokeParticle(new Vector3(
                    $this->x + cos($angle) * $r,
                    $this->y + 2.2 + mt_rand(0, 6) / 10.0,
                    $this->z + sin($angle) * $r
                )));
            }
        }
    }

    private function shootFireball(Player $target) {
        $sx = $this->x;
        $sy = $this->y + 1.0;
        $sz = $this->z;
        $tx = $target->x;
        $ty = $target->y + 1.0;
        $tz = $target->z;

        $dx  = $tx - $sx;
        $dy  = $ty - $sy;
        $dz  = $tz - $sz;
        $len = sqrt($dx * $dx + $dy * $dy + $dz * $dz);
        if ($len <= 0) return;

$steps = (int)min($len * 1.5, 20);
if ($steps <= 0) return;
$players = $this->level->getPlayers();

        for ($i = 0; $i <= $steps; $i++) {
            $t  = $i / $steps;
            $px = $sx + $dx * $t;
            $py = $sy + $dy * $t;
            $pz = $sz + $dz * $t;
            $pos = new Vector3($px, $py, $pz);

            // Reduced particle frequency
            if ($i % 2 === 0) { // Only every other step
                $this->level->addParticle(new FlameParticle($pos), $players);
            }
            // Removed EntityFlameParticle from trail
            // Removed extra flame particles
        }

        // Impact particles
        $impact = new Vector3($tx, $ty, $tz);
        // Reduced from 8 impact particles to 4
        for ($i = 0; $i < 4; $i++) {
            $a  = mt_rand(0, 628) / 100.0;
            $r  = mt_rand(2, 6) / 10.0; // Reduced radius
            $this->level->addParticle(new FlameParticle(new Vector3(
                $tx + cos($a) * $r,
                $ty + mt_rand(0, 3) / 10.0,
                $tz + sin($a) * $r
            )), $players);
        }
        $this->level->addParticle(new LargeExplodeParticle($impact), $players);
        // Removed HugeExplodeParticle for less visual clutter
    }

    public function attack($damage, EntityDamageEvent $source) {
        if ($this->closed || !$this->isAlive()) return;

        $attackerName = null;
        if ($source instanceof EntityDamageByEntityEvent) {
            $raw = $source->getDamager();
            if ($raw instanceof Player) {
                $attackerName           = $raw->getName();
                $this->lastAttackerName = $attackerName;
                $this->baseTarget       = $raw;
                $this->moveTime         = 0;

                $scaledDamage = SeaCombatHelper::scalePlayerToEntityDamage($raw, $source->getFinalDamage(), "kaen");
                $source->setDamage($scaledDamage);

                $motion = (new Vector3($this->x - $raw->x, $this->y - $raw->y, $this->z - $raw->z))->normalize();
                $this->motionX = $motion->x * 0.15;
                $this->motionY = $motion->y * 0.15;
                $this->motionZ = $motion->z * 0.15;
            }
        }

        if ($attackerName !== null) {
            $sm = $this->getSeaManager();
            if ($sm !== null) {
                $sm->recordEntityDamage($this->getId(), $attackerName, max(1, $source->getFinalDamage()));
            }
            $this->lastDamageTick = Server::getInstance()->getTick();
            $attacker = Server::getInstance()->getPlayerExact($attackerName);
            if ($attacker !== null) {
                $attacker->sendTip("§6[Kaen] " . $this->getHpBar() . " §f" . number_format((int)$this->getHealth()) . "§7/§f" . number_format((int)$this->getMaxHealth()));
            }
            foreach ($this->level->getPlayers() as $p) {
                $pct = $this->getMaxHealth() > 0 ? round(($this->getHealth() / $this->getMaxHealth()) * 100, 1) : 0;
                $p->sendPopup("§6[KAEN - Sea Flame] §f" . number_format((int)$this->getHealth()) . "§7/§f" . number_format((int)$this->getMaxHealth()) . " §7(" . $pct . "%)");
            }
        }

        parent::attack($damage, $source);
    }

    public function kill() {
        if ($this->rewardGiven) return;
        $this->rewardGiven = true;

        $sm          = $this->getSeaManager();
        $berryPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceBerry");
        $statsPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceStats");
        $qualified   = [];

        if ($sm !== null) {
            $data     = $sm->getEntityData($this->getId());
            $totalDmg = $data !== null ? array_sum($data["damageLog"]) : 0;

            if ($data !== null && $totalDmg > 0) {
                foreach ($data["damageLog"] as $pName => $dmg) {
                    if (($dmg / $totalDmg) >= 0.10) $qualified[] = $pName;
                }
            }

            if (!empty($qualified)) {
                $bm = $berryPlugin !== null ? $berryPlugin->getBerryManager() : null;
                foreach ($qualified as $pName) {
                    $player = Server::getInstance()->getPlayerExact($pName);
                    if ($player === null || !$player->isOnline()) continue;

                    if ($bm !== null) {
                        $bm->add($pName, SeaEventManager::KAEN_REWARD);
                        $player->sendMessage("");
                        $player->sendMessage("§6* §eKaen Defeated!");
                        $player->sendMessage("§7You earned §6" . number_format(SeaEventManager::KAEN_REWARD) . " Berries§7!");
                        $player->sendMessage("");
                    }

                    if ($statsPlugin !== null && $statsPlugin->isEnabled()) {
                        $statsPlugin->getStatManager()->addLevels($player, 2);
                    }
                }
            }

            $sm->removeActiveEntity($this->getId());
        }

        parent::kill();
    }

    public function knockBack(Entity $attacker, $damage, $x, $z, $base = 0.4) {}

    private function getHpBar() {
        $pct  = $this->getMaxHealth() > 0 ? $this->getHealth() / $this->getMaxHealth() : 0;
        $fill = (int)round($pct * 10);
        return "§c" . str_repeat("|", $fill) . "§7" . str_repeat("|", 10 - $fill);
    }

    public function onUpdate($currentTick) {
        if ($this->closed) return false;

        if (!$this->isAlive()) {
            if (++$this->deadTicks >= 10) {
                $this->despawnFromAll();
                $this->close();
            }
            return $this->deadTicks < 10;
        }

        $tickDiff = $currentTick - $this->lastUpdate;
        if ($tickDiff <= 0) return true;
        $this->lastUpdate = $currentTick;

        $this->entityBaseTick($tickDiff);
        if ($this->closed) return false;

        $sm   = $this->getSeaManager();
        $data = $sm !== null ? $sm->getEntityData($this->getId()) : null;

        if (!$this->isAlive() && $sm !== null && $data !== null) {
            $sm->removeActiveEntity($this->getId());
        }

        if ($sm === null || $data === null) {
            if (!$this->closed) $this->close();
            return !$this->closed;
        }

        if ($currentTick - $this->lastDamageTick >= SeaEventManager::DESPAWN_TICKS) {
            $sm->removeActiveEntity($this->getId());
            $this->close();
            return false;
        }

        $this->spawnAura($currentTick);

        $target = $this->updateMove($tickDiff);

        if ($target instanceof Player && $target->isAlive()) {
            if ($this->beamDelay <= 0) {
                $dist = $this->distanceSquared($target);
                if ($dist <= 3600) {
                    $this->shootFireball($target);
                    $this->beamDelay = 35;

                    if ($dist <= 81) {
                        $rawDmg = SeaEventManager::KAEN_DAMAGE;
                        $dmg    = SeaCombatHelper::scaleEntityToPlayerDamage($target, $rawDmg, SeaCombatHelper::KAEN_DAMAGE_CAP);
                        $ev     = new EntityDamageByEntityEvent($this, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $dmg);
                        $target->attack($dmg, $ev);
                        $target->sendTip("§6! Kaen launches a fireball!");
                        $this->attackDelay = 35;
                    }
                }
            }
        }

        if ($this->attackDelay > 0) $this->attackDelay -= $tickDiff;
        if ($this->beamDelay > 0)   $this->beamDelay   -= $tickDiff;

        $tag = "§6Kaen §7[Sea Flame]\n" . $this->getHpBar() . "\n§f" . number_format((int)$this->getHealth()) . "§7/§f" . number_format((int)$this->getMaxHealth());
        $this->setNameTag($tag);

        if (!$this->closed) $this->scheduleUpdate();
        return !$this->closed;
    }

    public function entityBaseTick($tickDiff = 1, $EnchantL = 0) {
        if ($this->closed) return false;

        if (!$this->isAlive()) {
            $this->despawnFromAll();
            $this->close();
            return false;
        }

        if (count($this->effects) > 0) {
            foreach ($this->effects as $effect) {
                if ($effect->canTick()) $effect->applyEffect($this);
                $effect->setDuration($effect->getDuration() - $tickDiff);
                if ($effect->getDuration() <= 0) $this->removeEffect($effect->getId());
            }
        }

        if ($this->noDamageTicks > 0) {
            $this->noDamageTicks -= $tickDiff;
            if ($this->noDamageTicks < 0) $this->noDamageTicks = 0;
        }

        $this->age        += $tickDiff;
        $this->ticksLived += $tickDiff;
        if ($this->attackTime > 0) $this->attackTime -= $tickDiff;

        return true;
    }

    public function getDrops()        { return []; }
    public function getXpDropAmount() { return 0; }

    public function spawnTo(Player $player) {
        if (isset($this->hasSpawned[$player->getLoaderId()])) return;
        if (!isset($player->usedChunks[Level::chunkHash($this->chunk->getX(), $this->chunk->getZ())])) return;

        $this->hasSpawned[$player->getLoaderId()] = $player;

        $pk           = new AddEntityPacket();
        $pk->eid      = $this->getId();
        $pk->type     = self::NETWORK_ID;
        $pk->x        = $this->x;
        $pk->y        = $this->y;
        $pk->z        = $this->z;
        $pk->speedX   = 0.0;
        $pk->speedY   = 0.0;
        $pk->speedZ   = 0.0;
        $pk->yaw      = $this->yaw;
        $pk->pitch    = $this->pitch;
        $pk->metadata = $this->dataProperties;
        $player->dataPacket($pk);
    }
}