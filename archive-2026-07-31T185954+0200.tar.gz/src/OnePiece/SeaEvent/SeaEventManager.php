<?php
namespace OnePiece\SeaEvent;

use pocketmine\Server;

class SeaEventManager {

    private $plugin;
    private $dataFile;
    private $data = [];

    private $enabledWorlds  = [];
    private $activeEntities = [];
    private $activeStorms   = [];

    const TYPE_SHARK = "shark";
    const TYPE_BEAST = "beast";
    const TYPE_STORM = "storm";
    const TYPE_KAEN = "kaen";

    const SHARK_REWARDS = [1 => 3000, 2 => 7000, 3 => 15000, 4 => 28000, 5 => 50000];
    const BEAST_REWARD  = 100000;
    const STORM_RADIUS  = 20;
    const KAEN_REWARD = 50000;

    const SHARK_HP     = [1 => 80,  2 => 160, 3 => 280, 4 => 500,  5 => 900];
    const SHARK_DAMAGE = [1 => 2.0, 2 => 3.5, 3 => 5.5, 4 => 8.0,  5 => 12.0];
    const BEAST_HP     = 10000;
    const BEAST_DAMAGE = 18.0;
    const KAEN_HP     = 1000;
    const KAEN_DAMAGE = 14.0;

    const EVENT_SPAWN_CHANCE  = 20;
    const STORM_SPAWN_CHANCE  = 10;
    const MIN_SPAWN_DIST      = 80;
    const MAX_ACTIVE_SHARKS   = 3;
    const MAX_ACTIVE_BEASTS   = 1;
    const MAX_ACTIVE_STORMS   = 2;
    const MAX_ACTIVE_KAEN = 1;

    const TYPE_WEIGHTS = [
        self::TYPE_SHARK => 80,
        self::TYPE_BEAST => 65,
        self::TYPE_STORM => 70,
        self::TYPE_KAEN  => 65,
    ];

    const DESPAWN_TICKS  = 1200;
    const STORM_DURATION = 2400;

    public function __construct($plugin) {
        $this->plugin   = $plugin;
        $this->dataFile = $plugin->getDataFolder() . "sea_events.json";
        $this->load();
    }

    private function load() {
        if (file_exists($this->dataFile)) {
            $d = json_decode(file_get_contents($this->dataFile), true);
            if (is_array($d)) $this->data = $d;
        }
        if (!isset($this->data["worlds"])) $this->data["worlds"] = [];
        $this->enabledWorlds = $this->data["worlds"];
    }

    private function save() {
        $this->data["worlds"] = $this->enabledWorlds;
        file_put_contents($this->dataFile, json_encode($this->data, JSON_PRETTY_PRINT));
    }

    public function enableWorld($worldName) {
        if (!in_array($worldName, $this->enabledWorlds)) {
            $this->enabledWorlds[] = $worldName;
            $this->save();
            return true;
        }
        return false;
    }

    public function disableWorld($worldName) {
        $idx = array_search($worldName, $this->enabledWorlds);
        if ($idx !== false) {
            array_splice($this->enabledWorlds, $idx, 1);
            $this->save();
            return true;
        }
        return false;
    }

    public function isWorldEnabled($worldName) {
        return in_array($worldName, $this->enabledWorlds);
    }

    public function getEnabledWorlds() { return $this->enabledWorlds; }

    public function rollEventType() {
        $total = array_sum(self::TYPE_WEIGHTS);
        $roll  = mt_rand(1, $total);
        $sum   = 0;
        foreach (self::TYPE_WEIGHTS as $type => $weight) {
            $sum += $weight;
            if ($roll <= $sum) return $type;
        }
        return self::TYPE_SHARK;
    }

    public function registerActiveEntity($entityId, $type, $level, $x, $z) {
        $this->activeEntities[$entityId] = [
            "type"           => $type,
            "level"          => $level,
            "x"              => $x,
            "z"              => $z,
            "lastDamageTick" => Server::getInstance()->getTick(),
            "damageLog"      => []
        ];
    }

    public function recordEntityDamage($entityId, $playerName, $amount) {
        if (!isset($this->activeEntities[$entityId])) return;
        $this->activeEntities[$entityId]["lastDamageTick"] = Server::getInstance()->getTick();
        if (!isset($this->activeEntities[$entityId]["damageLog"][$playerName])) {
            $this->activeEntities[$entityId]["damageLog"][$playerName] = 0;
        }
        $this->activeEntities[$entityId]["damageLog"][$playerName] += $amount;
    }

    public function getEntityData($entityId) {
        return $this->activeEntities[$entityId] ?? null;
    }

    public function removeActiveEntity($entityId) {
        unset($this->activeEntities[$entityId]);
    }

    public function getActiveEntities() { return $this->activeEntities; }

    public function countActiveByType($type) {
        $count = 0;
        foreach ($this->activeEntities as $data) {
            if ($data["type"] === $type) $count++;
        }
        return $count;
    }

    public function isStormActive($idx) {
        return isset($this->activeStorms[$idx]);
    }

    public function activateStorm($idx, $x, $z, $worldName) {
        $this->activeStorms[$idx] = [
            "tick"  => Server::getInstance()->getTick(),
            "x"     => $x,
            "z"     => $z,
            "world" => $worldName
        ];
    }

    public function deactivateStorm($idx) {
        unset($this->activeStorms[$idx]);
    }

    public function getActiveStorms() { return $this->activeStorms; }

    public function isTooCloseToExisting($x, $z, $worldName) {
        $minDistSq = self::MIN_SPAWN_DIST * self::MIN_SPAWN_DIST;
        foreach ($this->activeEntities as $data) {
            $dx = $data["x"] - $x;
            $dz = $data["z"] - $z;
            if ($dx * $dx + $dz * $dz < $minDistSq) return true;
        }
        foreach ($this->activeStorms as $storm) {
            if ($storm["world"] !== $worldName) continue;
            $dx = $storm["x"] - $x;
            $dz = $storm["z"] - $z;
            if ($dx * $dx + $dz * $dz < $minDistSq) return true;
        }
        return false;
    }
}
