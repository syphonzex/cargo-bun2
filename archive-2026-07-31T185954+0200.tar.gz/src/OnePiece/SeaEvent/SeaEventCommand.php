<?php
namespace OnePiece\SeaEvent;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class SeaEventCommand extends Command {

    private $plugin;

    public function __construct($plugin) {
        parent::__construct("seaevent", "Manage sea events", "/seaevent <enable|disable|status|start|info>");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage("§cNo permission.");
            return true;
        }

        if (empty($args)) {
            $this->sendHelp($sender);
            return true;
        }

        switch (strtolower($args[0])) {
            case "enable":  return $this->handleEnable($sender, $args);
            case "disable": return $this->handleDisable($sender, $args);
            case "status":  return $this->handleStatus($sender);
            case "start":   return $this->handleStart($sender, $args);
            case "info":    return $this->handleInfo($sender);
            default:
                $this->sendHelp($sender);
                return true;
        }
    }

    private function handleEnable(CommandSender $sender, array $args) {
        $sm = $this->plugin->getSeaEventManager();

        if (isset($args[1])) {
            $worldName = $args[1];
        } elseif ($sender instanceof Player) {
            $worldName = $sender->getLevel()->getFolderName();
        } else {
            $sender->sendMessage("§cUsage: /seaevent enable <world>");
            return true;
        }

        if ($sm->enableWorld($worldName)) {
            $sender->sendMessage("§aSea events §lenabled§r§a in world: §f" . $worldName);
        } else {
            $sender->sendMessage("§eSea events are already enabled in §f" . $worldName);
        }
        return true;
    }

    private function handleDisable(CommandSender $sender, array $args) {
        $sm = $this->plugin->getSeaEventManager();

        if (isset($args[1])) {
            $worldName = $args[1];
        } elseif ($sender instanceof Player) {
            $worldName = $sender->getLevel()->getFolderName();
        } else {
            $sender->sendMessage("§cUsage: /seaevent disable <world>");
            return true;
        }

        if ($sm->disableWorld($worldName)) {
            $sender->sendMessage("§cSea events §ldisabled§r§c in world: §f" . $worldName);
        } else {
            $sender->sendMessage("§eSea events are not enabled in §f" . $worldName);
        }
        return true;
    }

    private function handleStatus(CommandSender $sender) {
        $sm     = $this->plugin->getSeaEventManager();
        $worlds = $sm->getEnabledWorlds();

        $sender->sendMessage("§6[Sea Events Status]");
        if (empty($worlds)) {
            $sender->sendMessage("§7No worlds enabled. Use §f/seaevent enable§7.");
        } else {
            $sender->sendMessage("§aEnabled worlds: §f" . implode(", ", $worlds));
        }
        $sender->sendMessage("§7Active sharks: §f" . $sm->countActiveByType(SeaEventManager::TYPE_SHARK) . "§7/§f" . SeaEventManager::MAX_ACTIVE_SHARKS);
        $sender->sendMessage("§7Active beasts: §f" . $sm->countActiveByType(SeaEventManager::TYPE_BEAST) . "§7/§f" . SeaEventManager::MAX_ACTIVE_BEASTS);
        $sender->sendMessage("§7Active storms: §f" . count($sm->getActiveStorms()) . "§7/§f" . SeaEventManager::MAX_ACTIVE_STORMS);
        $sender->sendMessage("§7Active kaen: §f" . $sm->countActiveByType(SeaEventManager::TYPE_KAEN) . "§7/§f" . SeaEventManager::MAX_ACTIVE_KAEN);
        return true;
    }

    private function handleStart(CommandSender $sender, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cIn-game only.");
            return true;
        }

        $sm        = $this->plugin->getSeaEventManager();
        $level     = $sender->getLevel();
        $dir       = $sender->getDirectionVector();
        $dist      = 20;
        $x         = (int)($sender->x + $dir->x * $dist);
        $z         = (int)($sender->z + $dir->z * $dist);

        $type = isset($args[1]) && in_array(strtolower($args[1]), ["shark", "beast", "storm", "kaen"])
            ? strtolower($args[1])
            : $sm->rollEventType();

        $spawnTask = new SeaEventSpawnTask($this->plugin);

        if ($type === SeaEventManager::TYPE_STORM) {
            $spawnTask->forceSpawn($sm, $level, $x, 64, $z, $type);
            $sender->sendMessage("§aForce-spawned a §9storm §adirectly ahead of you.");
            return true;
        }

        $y = 12;
        for ($ty = 15; $ty >= 8; $ty--) {
            $bid = $level->getBlockIdAt($x, $ty, $z);
            if ($bid === 8 || $bid === 9) { $y = $ty; break; }
        }

        $sharkLevel = isset($args[2]) ? max(1, min(5, (int)$args[2])) : mt_rand(1, 5);

        if ($type === SeaEventManager::TYPE_SHARK) {
            $spawnTask->spawnShark($sm, $level, $x, $y, $z, $sharkLevel);
            $sender->sendMessage("§aForce-spawned a §bLv." . $sharkLevel . " Shark §adirectly ahead of you.");
        } elseif ($type === SeaEventManager::TYPE_KAEN) {
            $spawnTask->spawnKaen($sm, $level, $x, $y + 3, $z);
            $sender->sendMessage("§aForce-spawned §6Kaen §adirectly ahead of you.");
        } else {
            $spawnTask->spawnBeast($sm, $level, $x, $y + 3, $z);
            $sender->sendMessage("§aForce-spawned a §dSea Beast §adirectly ahead of you.");
        }
        return true;
    }

    private function handleInfo(CommandSender $sender) {
        $sm     = $this->plugin->getSeaEventManager();
        $active = $sm->getActiveEntities();
        $storms = $sm->getActiveStorms();

        $sender->sendMessage("§6[Sea Events Info]");
        $sender->sendMessage("§7Enabled worlds: §f" . implode(", ", $sm->getEnabledWorlds() ?: ["none"]));
        $sender->sendMessage("§7Active entities: §f" . count($active));
        foreach ($active as $eid => $data) {
            $lvlStr = $data["type"] === SeaEventManager::TYPE_BEAST ? "100" : $data["level"];
            $sender->sendMessage("  §f" . ucfirst($data["type"]) . " §7Lv." . $lvlStr . " | Pos: " . (int)$data["x"] . "/" . (int)$data["z"] . " | Damagers: " . count($data["damageLog"]));
        }
        $sender->sendMessage("§7Active storms: §f" . count($storms));
        foreach ($storms as $idx => $storm) {
            $sender->sendMessage("  §9Storm §7#" . ($idx+1) . " @ " . (int)$storm["x"] . "/" . (int)$storm["z"] . " in §f" . $storm["world"]);
        }
        return true;
    }

    private function sendHelp(CommandSender $sender) {
        $sender->sendMessage("§6[Sea Event Commands]");
        $sender->sendMessage("§f/seaevent enable [world]              §7Enable sea events in a world");
        $sender->sendMessage("§f/seaevent disable [world]             §7Disable sea events in a world");
        $sender->sendMessage("§f/seaevent status                      §7Show enabled worlds and active counts");
        $sender->sendMessage("§f/seaevent start [shark|beast|storm] [level] §7Force spawn near you");
        $sender->sendMessage("§f/seaevent info                        §7Show all active events");
    }
}
