<?php

namespace OnePiece\Devil;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use pocketmine\item\Item;

class FruitCommand extends Command {

    /** @var Main */
    private $plugin;

    public function __construct(Main $plugin, $name, $description, $usage) {
        parent::__construct($name, $description, $usage);
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage(TextFormat::RED . "This command can only be used in-game.");
            return true;
        }

        $cmd = $this->getName();

        // /fruits — list all fruits
        if ($cmd === "fruits") {
            return $this->handleList($sender);
        }

        // /fruit <subcommand>
        if ($cmd === "fruit") {
            if (count($args) === 0) {
                return $this->handleHelp($sender);
            }

            $sub = strtolower($args[0]);

            switch ($sub) {
                case "help":
                    return $this->handleHelp($sender);
                case "info":
                    return $this->handleInfo($sender);
                case "remove":
                    return $this->handleRemove($sender);
                case "give":
                    return $this->handleGive($sender, $args);
                case "spawn":
                    return $this->handleSpawn($sender, $args);
                case "revoke":
                    return $this->handleRevoke($sender, $args);
                default:
                    $sender->sendMessage(TextFormat::RED . "Unknown subcommand. Use /fruit help");
                    return true;
            }
        }

        return true;
    }

    // ========================
    // /fruit help
    // ========================

    private function handleHelp(Player $sender) {
        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        $sender->sendMessage(TextFormat::GOLD . "  Devil Fruit Commands");
        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        $sender->sendMessage(TextFormat::YELLOW . "/fruit info " . TextFormat::GRAY . "- View your current fruit");
        $sender->sendMessage(TextFormat::YELLOW . "/fruit remove " . TextFormat::GRAY . "- Remove your fruit");
        $sender->sendMessage(TextFormat::YELLOW . "/fruits " . TextFormat::GRAY . "- List all available fruits");
        if ($sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "/fruit give <player> <fruitId> " . TextFormat::GRAY . "- Give fruit (OP)");
            $sender->sendMessage(TextFormat::RED . "/fruit spawn <fruitId> " . TextFormat::GRAY . "- Spawn fruit item (OP)");
            $sender->sendMessage(TextFormat::RED . "/fruit revoke <player> " . TextFormat::GRAY . "- Remove player's fruit (OP)");
        }
        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        $sender->sendMessage(TextFormat::GRAY . "How to eat: Hold a named Golden Apple and eat it!");
        $sender->sendMessage(TextFormat::GRAY . "How to use: Hold Blaze Rod and tap (or sneak+tap)");
        return true;
    }

    // ========================
    // /fruit info
    // ========================

    private function handleInfo(Player $sender) {
        $fruitManager = $this->plugin->getFruitManager();

        if (!$fruitManager->playerHasFruit($sender)) {
            $sender->sendMessage(TextFormat::GRAY . "You don't have a Devil Fruit.");
            return true;
        }

        $fruit = $fruitManager->getPlayerFruit($sender);
        if ($fruit === null) {
            $sender->sendMessage(TextFormat::RED . "Error loading your fruit data.");
            return true;
        }

        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        $sender->sendMessage($fruit->getRarityColor() . "  " . $fruit->getDisplayName());
        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        $sender->sendMessage(TextFormat::WHITE . $fruit->getDescription());
        $sender->sendMessage(TextFormat::GRAY . "Type: " . ucfirst($fruit->getType()));
        $sender->sendMessage(TextFormat::GRAY . "Rarity: " . $fruit->getRarityColor() . ucfirst($fruit->getRarity()));
        $sender->sendMessage("");

        $abilities = $fruit->getAbilityNames();
        $cooldowns = $fruit->getAbilityCooldowns();

        $sender->sendMessage(TextFormat::YELLOW . "Abilities:");
        if (isset($abilities["ability1"])) {
            $cd1 = isset($cooldowns["ability1"]) ? $cooldowns["ability1"] : "?";
            $sender->sendMessage(TextFormat::WHITE . "  1. " . $abilities["ability1"] . TextFormat::GRAY . " (Tap Blaze Rod) [" . $cd1 . "s CD]");
        }
        if (isset($abilities["ability2"])) {
            $cd2 = isset($cooldowns["ability2"]) ? $cooldowns["ability2"] : "?";
            $sender->sendMessage(TextFormat::WHITE . "  2. " . $abilities["ability2"] . TextFormat::GRAY . " (Sneak + Blaze Rod) [" . $cd2 . "s CD]");
        }

        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        return true;
    }

    // ========================
    // /fruit remove
    // ========================

    private function handleRemove(Player $sender) {
        if (!$this->plugin->isInOPWorld($sender)) {
            $sender->sendMessage(TextFormat::RED . "You can only remove fruits in the OP world!");
            return true;
        }

        $fruitManager = $this->plugin->getFruitManager();

        if (!$fruitManager->playerHasFruit($sender)) {
            $sender->sendMessage(TextFormat::RED . "You don't have a Devil Fruit to remove.");
            return true;
        }

        $fruitName = $fruitManager->getPlayerFruitName($sender);
        $fruitManager->removeFruitFromPlayer($sender);

        $sender->sendMessage(TextFormat::GREEN . "Your " . $fruitName . " has been removed.");
        $sender->sendMessage(TextFormat::GRAY . "You can now eat a new Devil Fruit.");

        return true;
    }

    // ========================
    // /fruit give <player> <fruitId> (OP only)
    // ========================

    private function handleGive(Player $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "You need to be OP to use this command!");
            return true;
        }

        if (count($args) < 3) {
            $sender->sendMessage(TextFormat::RED . "Usage: /fruit give <player> <fruitId>");
            return true;
        }

        $targetName = $args[1];
        $fruitId = strtolower($args[2]);

        $target = $this->plugin->getServer()->getPlayerExact($targetName);
        if ($target === null) {
            $sender->sendMessage(TextFormat::RED . "Player not found or not online.");
            return true;
        }

        $fruitManager = $this->plugin->getFruitManager();

        if (!$fruitManager->fruitExists($fruitId)) {
            $sender->sendMessage(TextFormat::RED . "Fruit '" . $fruitId . "' does not exist!");
            $sender->sendMessage(TextFormat::GRAY . "Use /fruits to see available fruits.");
            return true;
        }

        $fruit = $fruitManager->getFruit($fruitId);
        $fruitManager->giveFruitToPlayer($target, $fruitId);

        $sender->sendMessage(TextFormat::GREEN . "# Gave " . $fruit->getDisplayName() . " to " . $targetName);
        $target->sendMessage(TextFormat::GOLD . "> You received the " . $fruit->getDisplayName() . "!");
        $target->sendMessage(TextFormat::RED . "! You are now weak to water!");

        return true;
    }

    // ========================
    // /fruit spawn <fruitId> (OP only)
    // ========================

    private function handleSpawn(Player $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "You need to be OP to use this command!");
            return true;
        }

        if (count($args) < 2) {
            $sender->sendMessage(TextFormat::RED . "Usage: /fruit spawn <fruitId>");
            return true;
        }

        $fruitId = strtolower($args[1]);
        $fruitManager = $this->plugin->getFruitManager();

        if (!$fruitManager->fruitExists($fruitId)) {
            $sender->sendMessage(TextFormat::RED . "Fruit '" . $fruitId . "' does not exist!");
            return true;
        }

        $fruit = $fruitManager->getFruit($fruitId);

        $item = Item::get(Item::GOLDEN_APPLE, 0, 1);
        $item->setCustomName($fruit->getRarityColor() . $fruit->getDisplayName());

        $sender->getInventory()->addItem($item);
        $sender->sendMessage(TextFormat::GREEN . "# Spawned " . $fruit->getDisplayName() . " in your inventory!");

        return true;
    }

    private function handleRevoke(Player $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "You need to be OP to use this command!");
            return true;
        }

        if (count($args) < 2) {
            $sender->sendMessage(TextFormat::RED . "Usage: /fruit revoke <player>");
            return true;
        }

        $targetName = $args[1];
        $target = $this->plugin->getServer()->getPlayerExact($targetName);

        if ($target === null) {
            $sender->sendMessage(TextFormat::RED . "Player not found or not online.");
            return true;
        }

        $fruitManager = $this->plugin->getFruitManager();

        if (!$fruitManager->playerHasFruit($target)) {
            $sender->sendMessage(TextFormat::RED . $targetName . " doesn't have a Devil Fruit.");
            return true;
        }

        $fruitName = $fruitManager->getPlayerFruitName($target);
        $fruitManager->removeFruitFromPlayer($target);

        $sender->sendMessage(TextFormat::GREEN . "# Revoked " . $fruitName . " from " . $targetName);
        $target->sendMessage(TextFormat::RED . "! Your " . $fruitName . " was removed!");

        return true;
    }

    // ========================
    // /fruits — list all
    // ========================

    private function handleList(Player $sender) {
        $fruitManager = $this->plugin->getFruitManager();
        $allFruits = $fruitManager->getAllFruits();

        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        $sender->sendMessage(TextFormat::GOLD . "  Available Devil Fruits");
        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");

        if (empty($allFruits)) {
            $sender->sendMessage(TextFormat::GRAY . "No fruits registered yet.");
        } else {
            foreach ($allFruits as $fruit) {
                $sender->sendMessage(
                    $fruit->getRarityColor() . "- " . $fruit->getDisplayName() .
                    TextFormat::GRAY . " (" . $fruit->getId() . ") " .
                    TextFormat::DARK_GRAY . "[" . ucfirst($fruit->getType()) . "]"
                );
            }
        }

        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        return true;
    }
}