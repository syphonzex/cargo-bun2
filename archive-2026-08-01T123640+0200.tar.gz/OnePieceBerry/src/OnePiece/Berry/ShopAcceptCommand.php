<?php

namespace OnePiece\Berry;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class ShopAcceptCommand extends Command {

    private $plugin;
    private $pendingPurchase = [];

    public function __construct(Main $plugin) {
        parent::__construct("shopaccept", "Accept a Party Shop purchase", "/shopaccept <slot>");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cIn-game only.");
            return true;
        }

        if (!isset($args[0])) {
            $sender->sendMessage("§cUsage: /shopaccept <slot>");
            return true;
        }

        $name = strtolower($sender->getName());
        $slot = (int)$args[0] - 1;

        $sm    = $this->plugin->getPartyShopManager();
        $phm   = $this->plugin->getPartyHatManager();
        $entry = $sm->getStockEntry($slot);

        if ($entry === null) {
            $sender->sendMessage("§cInvalid slot. Use /opevent shop to see available items.");
            return true;
        }

        if (isset($this->pendingPurchase[$name]) && $this->pendingPurchase[$name]["slot"] === $slot) {
            if (time() - $this->pendingPurchase[$name]["time"] <= 30) {
                unset($this->pendingPurchase[$name]);
                $this->processPurchase($sender, $slot, $entry);
                return true;
            }
            unset($this->pendingPurchase[$name]);
        }

        $color = $sm->getRarityColor($entry["rarity"]);
        $hats  = $phm->get($sender->getName());

        if ($entry["type"] === "fruit") {
            $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
            $displayName = $entry["id"];
            if ($devilPlugin !== null && $devilPlugin->isEnabled()) {
                $fruit = $devilPlugin->getFruitManager()->getFruit($entry["id"]);
                if ($fruit !== null) $displayName = $fruit->getDisplayName();
            }
            $itemName = $color . $displayName;
        } else {
            $itemName = $entry["name"];
        }

        if (!$phm->has($sender->getName(), $entry["price"])) {
            $sender->sendMessage("§cNot enough Sunglasses! Need §e" . $entry["price"] . " §cyou have §e" . $hats);
            return true;
        }

        $this->pendingPurchase[$name] = ["slot" => $slot, "time" => time()];

        $sender->sendMessage("§6§l================================");
        $sender->sendMessage("§6§l  Confirm Purchase");
        $sender->sendMessage("§6§l================================");
        $sender->sendMessage("§7  Item:  " . $itemName);
        $sender->sendMessage("§7  Price: §e" . $entry["price"] . " Sunglasses");
        $sender->sendMessage("§7  Yours: §e" . $hats . " Sunglasses");
        $sender->sendMessage("§6§l--------------------------------");
        $sender->sendMessage("§aRun §f/shopaccept " . ($slot + 1) . " §aagain to confirm!");
        $sender->sendMessage("§7(Expires in 30 seconds)");
        $sender->sendMessage("§6§l================================");
        return true;
    }

    private function processPurchase(Player $player, $slot, array $entry) {
        $sm  = $this->plugin->getPartyShopManager();
        $phm = $this->plugin->getPartyHatManager();

        $currentEntry = $sm->getStockEntry($slot);
        if ($currentEntry === null || $currentEntry["id"] !== $entry["id"]) {
            $player->sendMessage("§cThis item is no longer available!");
            return;
        }

        if (!$phm->has($player->getName(), $entry["price"])) {
            $player->sendMessage("§cNot enough Sunglasses!");
            return;
        }

        $phm->remove($player->getName(), $entry["price"]);
        $sm->removeStockEntry($slot);

        $color = $sm->getRarityColor($entry["rarity"]);

        if ($entry["type"] === "fruit") {
            $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
            if ($devilPlugin === null || !$devilPlugin->isEnabled()) {
                $player->sendMessage("§cDevil fruit system not available! Refunding...");
                $phm->add($player->getName(), $entry["price"]);
                return;
            }
            $fm    = $devilPlugin->getFruitManager();
            $fruit = $fm->getFruit($entry["id"]);
            if ($fruit === null) {
                $player->sendMessage("§cFruit not found! Refunding...");
                $phm->add($player->getName(), $entry["price"]);
                return;
            }

            $item = \pocketmine\item\Item::get(\pocketmine\item\Item::GOLDEN_APPLE, 0, 1);
            $item->setCustomName($fruit->getRarityColor() . $fruit->getDisplayName());

            if ($player->getInventory()->canAddItem($item)) {
                $player->getInventory()->addItem($item);
            } else {
                $storage = $this->plugin->getFruitStorage();
                if ($storage->hasSpace($player->getName())) {
                    $storage->addFruit($player->getName(), $entry["id"]);
                    $player->sendMessage("§eSent to /storage - inventory full!");
                } else {
                    $player->getLevel()->dropItem($player, $item);
                    $player->sendMessage("§eDropped on ground - inventory and storage full!");
                }
            }

            $player->sendMessage("§6§l[Summer Shop] §r§aPurchased §f" . $fruit->getDisplayName() . " §afor §e" . $entry["price"] . " Sunglasses!");

        } else {
            $fightPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceFight");
            if ($fightPlugin === null || !$fightPlugin->isEnabled()) {
                $player->sendMessage("§cFight system not available! Refunding...");
                $phm->add($player->getName(), $entry["price"]);
                return;
            }

            $sm2 = $fightPlugin->getSwordManager();
            $result = $sm2->forceSword($player, $entry["id"]);

            if (!$result) {
                $player->sendMessage("§cSword not found! Refunding...");
                $phm->add($player->getName(), $entry["price"]);
                return;
            }

            $fightPlugin->updateWeaponSlot($player);
            $player->sendMessage("§6§l[Summer Shop] §r§aPurchased " . $entry["name"] . " §afor §e" . $entry["price"] . " Sunglasses!");
        }
    }
}