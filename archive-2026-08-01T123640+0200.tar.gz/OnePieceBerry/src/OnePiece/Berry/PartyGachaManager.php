<?php

namespace OnePiece\Berry;

use pocketmine\Player;
use pocketmine\item\Item;

class PartyGachaManager {

    private $plugin;
    private $spinning = [];
    private $pendingConfirm = [];

    const GACHA_COST = 500;

    const FRUIT_CHANCES = [
        "bari_bari"        => 900,
        "moku_moku"        => 850,
        "inu_inu"          => 800,
        "tori_tori_falcon" => 700,
        "bara_bara"        => 350,
        "gomu_gomu"        => 280,
        "suna_suna"        => 200,
        "bomb_bomb"        => 160,
        "neko_neko"        => 130,
        "yami_yami"        => 100,
        "hie_hie"          => 80,
        "iro_iro"          => 80,
        "revive_revive"    => 80,
        "love_love"        => 80,
        "magu_magu"        => 80,
        "mera_mera"        => 80,
        "ope_ope"          => 80,
        "pika_pika"        => 80,
        "exp_2x_15"        => 80,
        "exp_2x_30"        => 80,
        "tori_tori"        => 70,
        "sound_sound"      => 70,
        "giro_giro"        => 60,
        "gear_fourth"      => 60,
        "yami_v2"          => 60,
        "shadow_shadow"    => 15,
        "zou_zou"          => 15,
        "trex_trex"        => 15,
        "mochi_mochi"      => 10,
        "goro_goro"        => 15,
        "okuchi_okuchi"    => 10,
        "gura_gura"        => 10,
        "soru_soru"        => 10,
        "dark_x_quake"     => 10,
        "uo_uo"            => 10,
    ];

    const FRUIT_RARITY = [
        "bari_bari"        => "common",
        "moku_moku"        => "common",
        "inu_inu"          => "common",
        "tori_tori_falcon" => "common",
        "bara_bara"        => "rare",
        "gomu_gomu"        => "rare",
        "suna_suna"        => "rare",
        "bomb_bomb"        => "rare",
        "neko_neko"        => "rare",
        "yami_yami"        => "rare",
        "hie_hie"          => "legendary",
        "iro_iro"          => "legendary",
        "revive_revive"    => "legendary",
        "mera_mera"        => "legendary",
        "ope_ope"          => "legendary",
        "love_love"        => "legendary",
        "pika_pika"        => "legendary",
        "magu_magu"        => "legendary",
        "tori_tori"        => "legendary",
        "sound_sound"      => "legendary",
        "giro_giro"        => "legendary",
        "gear_fourth"      => "legendary",
        "yami_v2"          => "legendary",
        "exp_2x_15"        => "legendary",
        "exp_2x_30"        => "legendary",
        "shadow_shadow"    => "mythical",
        "zou_zou"          => "mythical",
        "trex_trex"        => "mythical",
        "mochi_mochi"      => "mythical",
        "goro_goro"        => "mythical",
        "okuchi_okuchi"    => "mythical",
        "gura_gura"        => "mythical",
        "soru_soru"        => "mythical",
        "dark_x_quake"     => "mythical",
        "uo_uo"            => "mythical",
    ];

    private static $fakeNames = [
        "§aMoku Moku", "§9Gomu Gomu", "§6Ope Ope", "§dGura Gura",
        "§aInu Inu", "§9Bara Bara", "§6Pika Pika", "§dUo Uo",
        "§aBari Bari", "§9Suna Suna", "§6Mera Mera", "§dSoru Soru",
        "§aTori Tori", "§9Yami Yami", "§6Gear Fourth", "§dDark X Quake",
        "§aBomb Bomb", "§9Neko Neko", "§6Hie Hie", "§dGoro Goro",
        "§6Iro Iro", "§6Sound Sound", "§dMochi Mochi", "§dOkuchi Okuchi",
    ];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function isSpinning(Player $player) {
        return isset($this->spinning[strtolower($player->getName())]);
    }

    public function setPendingConfirm(Player $player, $value) {
        $name = strtolower($player->getName());
        if ($value) {
            $this->pendingConfirm[$name] = time();
        } else {
            unset($this->pendingConfirm[$name]);
        }
    }

    public function hasPendingConfirm(Player $player) {
        $name = strtolower($player->getName());
        if (!isset($this->pendingConfirm[$name])) return false;
        if (time() - $this->pendingConfirm[$name] > 30) {
            unset($this->pendingConfirm[$name]);
            return false;
        }
        return true;
    }

    public function startSpin(Player $player) {
        $name = strtolower($player->getName());
        if ($this->isSpinning($player)) return ["success" => false, "error" => "Already spinning!"];
        $phm = $this->plugin->getPartyHatManager();
        if (!$phm->has($player->getName(), self::GACHA_COST)) {
            return ["success" => false, "error" => "Not enough Party Hats!"];
        }
        $phm->remove($player->getName(), self::GACHA_COST);
        $this->spinning[$name] = true;
        $wonFruitId = $this->rollFruit();
        $wonRarity  = self::FRUIT_RARITY[$wonFruitId] ?? "common";
        return ["success" => true, "fruitId" => $wonFruitId, "rarity" => $wonRarity];
    }

    public function finishSpin(Player $player, $wonFruitId, $wonRarity) {
        $name = strtolower($player->getName());
        unset($this->spinning[$name]);

        if (strpos($wonFruitId, "exp_2x_") === 0) {
            $gamepassPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceGamepasses");
            if ($gamepassPlugin !== null) {
                $gamepassPlugin->getGamepassManager()->giveExpBoost($player->getName(), $wonFruitId);
                $time = $wonFruitId === "exp_2x_15" ? "15" : "30";
                $player->sendMessage("§6§l[Party Gacha] §r§eYou won a §f2x EXP Boost (" . $time . "m)§e!");
                $this->plugin->getServer()->broadcastMessage("§6§l[4th Anniversary] §r§d" . $player->getName() . " §6pulled a §b2x EXP Boost (" . $time . "m) §6from the Party Gacha!");
                return true;
            }
        }

        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin === null || !$devilPlugin->isEnabled()) return false;
        $fm = $devilPlugin->getFruitManager();
        $fruit = $fm->getFruit($wonFruitId);
        if ($fruit === null) return false;
        $item = Item::get(Item::GOLDEN_APPLE, 0, 1);
        $item->setCustomName($fruit->getRarityColor() . $fruit->getDisplayName());
        if ($player->getInventory()->canAddItem($item)) {
            $player->getInventory()->addItem($item);
        } else {
            $storage = $this->plugin->getFruitStorage();
            if ($storage->hasSpace($player->getName())) {
                $storage->addFruit($player->getName(), $wonFruitId);
            } else {
                $player->getLevel()->dropItem($player, $item);
            }
        }
        if ($wonRarity === "mythical" || $wonRarity === "legendary") {
            $this->plugin->getServer()->broadcastMessage("§6§l[4th Anniversary] §r§d" . $player->getName() . " §6pulled " . $this->getRarityColor($wonRarity) . $fruit->getDisplayName() . " §6from the Party Gacha!");
        }
        return true;
    }

    public function cancelSpin($name) {
        unset($this->spinning[strtolower($name)]);
    }

    public function rollFruit() {
        $total = 0;
        foreach (self::FRUIT_CHANCES as $w) $total += $w;
        $roll = mt_rand(1, $total);
        $sum  = 0;
        foreach (self::FRUIT_CHANCES as $fruitId => $weight) {
            $sum += $weight;
            if ($roll <= $sum) return $fruitId;
        }
        return "bari_bari";
    }

    public function getFakeNames() {
        return self::$fakeNames;
    }

    public function getFruitDisplayName($fruitId) {
        if ($fruitId === "exp_2x_15") return "2x EXP (15m)";
        if ($fruitId === "exp_2x_30") return "2x EXP (30m)";
        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin === null || !$devilPlugin->isEnabled()) return $fruitId;
        $fruit = $devilPlugin->getFruitManager()->getFruit($fruitId);
        return ($fruit === null) ? $fruitId : $fruit->getDisplayName();
    }

    public function getFruitRarityColor($fruitId) {
        if (strpos($fruitId, "exp_2x_") === 0) return "§6";
        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin === null || !$devilPlugin->isEnabled()) return "§f";
        $fruit = $devilPlugin->getFruitManager()->getFruit($fruitId);
        return ($fruit === null) ? "§f" : $fruit->getRarityColor();
    }

    public function getRarityColor($rarity) {
        switch ($rarity) {
            case "common":    return "§a";
            case "rare":      return "§9";
            case "legendary": return "§6";
            case "mythical":  return "§d";
        }
        return "§f";
    }
}