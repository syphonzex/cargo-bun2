<?php

namespace OnePiece\Berry;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;

class ShopManager {

    private $plugin;
    private $stock     = [];
    private $lastReset = 0;

    const RESET_INTERVAL = 3600;

    const FRUIT_PRICES = [
        "bari_bari"        => 5000,
        "moku_moku"        => 5000,
        "inu_inu"          => 6000,
        "tori_tori_falcon" => 7500,
        "bara_bara"        => 120000,
        "gomu_gomu"        => 250000,
        "suna_suna"        => 400000,
        "bomb_bomb"        => 450000,
        "neko_neko"        => 500000,
        "yami_yami"        => 600000,
        "hie_hie"          => 850000,
        "iro_iro"          => 1200000,
        "revive_revive"    => 1400000,
        "mera_mera"        => 1500000,
        "love_love"        => 1800000,
        "pika_pika"        => 1200000,
        "magu_magu"        => 1500000,
        "magnet_magnet"    => 1800000,
        "tori_tori"        => 2000000,
        "sound_sound"      => 2000000,
        "giro_giro"        => 2500000,
        "gear_fourth"      => 3000000,
        "yami_v2"          => 3000000,
        "shadow_shadow"    => 3500000,
        "zou_zou"          => 4000000,
        "trex_trex"        => 4000000,
        "mochi_mochi"      => 4500000,
        "goro_goro"        => 4500000,
        "gas_gas"          => 4800000,
        "gura_gura"        => 5000000,
        "gravity_gravity"  => 5500000,
        "okuchi_okuchi"    => 6000000,
        "ope_ope"          => 6500000,
        "uo_uo"            => 6000000,
        "soru_soru"        => 7000000,
        "dark_x_quake"     => 8000000,
    ];

    const FRUIT_STOCK_CHANCES = [
        "bari_bari"        => 1800,
        "moku_moku"        => 1700,
        "inu_inu"          => 1600,
        "tori_tori_falcon" => 1400,
        "bara_bara"        => 400,
        "gomu_gomu"        => 300,
        "suna_suna"        => 200,
        "bomb_bomb"        => 150,
        "neko_neko"        => 100,
        "yami_yami"        => 80,
        "hie_hie"          => 20,
        "iro_iro"          => 20,
        "revive_revive"    => 20,
        "love_love"        => 20,
        "magu_magu"        => 20,
        "mera_mera"        => 20,
        "pika_pika"        => 20,
        "magnet_magnet"    => 10,
        "tori_tori"        => 10,
        "sound_sound"      => 10,
        "giro_giro"        => 10,
        "gear_fourth"      => 10,
        "yami_v2"          => 10,
        "shadow_shadow"    => 2,
        "zou_zou"          => 2,
        "trex_trex"        => 2,
        "ope_ope"          => 1,
        "mochi_mochi"      => 1,
        "goro_goro"        => 1,
        "gas_gas"          => 1,
        "okuchi_okuchi"    => 1,
        "gura_gura"        => 1,
        "soru_soru"        => 1,
        "gravity_gravity"  => 1,
        "dark_x_quake"     => 1,
        "uo_uo"            => 1,
    ];

    const FRUIT_RARITY = [
        "bari_bari"        => "common",
        "moku_moku"        => "common",
        "inu_inu"          => "common",
        "tori_tori_falcon" => "common",
        "bara_bara"        => "rare",
        "gomu_gomu"        => "rare",
        "suna_suna"        => "rare",
        "bomb_bomb"        => "rare",
        "neko_neko"        => "rare",
        "yami_yami"        => "rare",
        "hie_hie"          => "legendary",
        "iro_iro"          => "legendary",
        "revive_revive"    => "legendary",
        "mera_mera"        => "legendary",
        "love_love"        => "legendary",
        "pika_pika"        => "legendary",
        "magu_magu"        => "legendary",
        "magnet_magnet"    => "legendary",
        "tori_tori"        => "legendary",
        "sound_sound"      => "legendary",
        "giro_giro"        => "legendary",
        "gear_fourth"      => "legendary",
        "yami_v2"          => "legendary",
        "shadow_shadow"    => "mythical",
        "zou_zou"          => "mythical",
        "trex_trex"        => "mythical",
        "ope_ope"          => "mythical",
        "mochi_mochi"      => "mythical",
        "goro_goro"        => "mythical",
        "gas_gas"          => "mythical",
        "okuchi_okuchi"    => "mythical",
        "gura_gura"        => "mythical",
        "soru_soru"        => "mythical",
        "gravity_gravity"  => "mythical",
        "uo_uo"            => "mythical",
        "dark_x_quake"     => "god",
    ];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->refreshStock();
    }

    public function checkRefresh() {
        if (time() - $this->lastReset >= self::RESET_INTERVAL) {
            $this->refreshStock();
        }
    }

    public function refreshStock() {
        $this->stock     = [];
        $this->lastReset = time();
        $paused          = $this->plugin->getPausedFruits();

        $availableChances = [];
        foreach (self::FRUIT_STOCK_CHANCES as $fruitId => $weight) {
            if (!in_array($fruitId, $paused)) {
                $availableChances[$fruitId] = $weight;
            }
        }

        if (empty($availableChances)) return;

        $count = mt_rand(2, 5);
        $used  = [];

        for ($i = 0; $i < $count; $i++) {
            $fruitId = $this->rollFruitFromPool($availableChances, $used);
            if ($fruitId === null) break;
            $used[] = $fruitId;
            $this->stock[] = [
                "fruit_id" => $fruitId,
                "rarity"   => self::FRUIT_RARITY[$fruitId] ?? "common",
                "price"    => self::FRUIT_PRICES[$fruitId] ?? 10000,
            ];
        }
    }

    private function rollFruitFromPool(array $pool, array $exclude) {
        $filtered = [];
        foreach ($pool as $fruitId => $weight) {
            if (!in_array($fruitId, $exclude)) {
                $filtered[$fruitId] = $weight;
            }
        }
        if (empty($filtered)) return null;
        $total = array_sum($filtered);
        $roll  = mt_rand(1, $total);
        $sum   = 0;
        foreach ($filtered as $fruitId => $weight) {
            $sum += $weight;
            if ($roll <= $sum) return $fruitId;
        }
        reset($filtered);
        return key($filtered);
    }

    public function getStock() {
        $this->checkRefresh();
        return $this->stock;
    }

    public function getTimeUntilReset() {
        $elapsed   = time() - $this->lastReset;
        $remaining = self::RESET_INTERVAL - $elapsed;
        return max(0, $remaining);
    }

    public function formatTime($seconds) {
        $m = intval($seconds / 60);
        $s = $seconds % 60;
        return $m . "m " . $s . "s";
    }

    public function buyFruit(Player $player, $slot) {
        $this->checkRefresh();

        if ($slot < 0 || $slot >= count($this->stock)) {
            $player->sendMessage("§cInvalid slot.");
            return false;
        }

        $entry   = $this->stock[$slot];
        $fruitId = $entry["fruit_id"];
        $price   = $entry["price"];

        $paused = $this->plugin->getPausedFruits();
        if (in_array($fruitId, $paused)) {
            $player->sendMessage("§cThis fruit is currently unavailable.");
            return false;
        }

        $bm = $this->plugin->getBerryManager();
        if (!$bm->has($player->getName(), $price)) {
            $player->sendMessage("§cNot enough berries! Need: §e" . $bm->format($price) . " §cYou have: §e" . $bm->format($bm->get($player->getName())));
            return false;
        }

        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin === null || !$devilPlugin->isEnabled()) {
            $player->sendMessage("§cDevil fruit system not available.");
            return false;
        }

        $fm    = $devilPlugin->getFruitManager();
        $fruit = $fm->getFruit($fruitId);
        if ($fruit === null) {
            $player->sendMessage("§cFruit not found.");
            return false;
        }

        $bm->remove($player->getName(), $price);

        $hadFruit    = $fm->playerHasFruit($player);
        $oldFruitName = "";
        if ($hadFruit) {
            $oldFruit = $fm->getPlayerFruit($player);
            if ($oldFruit !== null) $oldFruitName = $oldFruit->getDisplayName();
        }

        $fm->giveFruitToPlayer($player, $fruitId);

        array_splice($this->stock, $slot, 1);

        $player->sendMessage("§a§l[SHOP] §r§aPurchased §f" . $fruit->getDisplayName() . " §afor §e" . $bm->format($price));
        if ($hadFruit && !empty($oldFruitName)) {
            $player->sendMessage("§7Your previous fruit §f" . $oldFruitName . " §7was replaced.");
        }
        $player->sendMessage("§aYou now have the power of §f" . $fruit->getDisplayName() . "§a!");
        \pocketmine\Server::getInstance()->getLogger()->info("[Shop Debug] Player " . $player->getName() . " bought: " . $fruitId . " for " . $price . " Berry");
        return true;
    }
    
    public function getMaxSlots() {
        return 5;
    }

    public function addFruitToStock($fruitId, $slot = null) {
        foreach ($this->stock as $s => $data) {
            if ($data["fruit_id"] === $fruitId) {
                return "exists";
            }
        }

        $price = self::FRUIT_PRICES[$fruitId] ?? 10000;

        if ($slot !== null) {
            $slotIndex = $slot - 1;
            $replacing = isset($this->stock[$slotIndex]);
            $this->stock[$slotIndex] = [
                "fruit_id" => $fruitId,
                "rarity"   => self::FRUIT_RARITY[$fruitId] ?? "common",
                "price"    => $price,
            ];
            return $replacing ? "replaced" : true;
        }

        if (count($this->stock) >= $this->getMaxSlots()) {
            return "full";
        }

        $this->stock[] = [
            "fruit_id" => $fruitId,
            "rarity"   => self::FRUIT_RARITY[$fruitId] ?? "common",
            "price"    => $price,
        ];
        return true;
    }

    public function removeFruitFromStock($slot) {
        $slotIndex = $slot - 1;
        if (!isset($this->stock[$slotIndex])) {
            return "empty";
        }
        array_splice($this->stock, $slotIndex, 1);
        return true;
    }

    public function getRarityColor($rarity) {
        switch ($rarity) {
            case "common":    return "§a";
            case "rare":      return "§9";
            case "legendary": return "§6";
            case "mythical":  return "§d";
            case "god":  return "§c";
        }
        return "§f";
    }
}