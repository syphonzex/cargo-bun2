<?php

namespace OnePiece\Berry;

use pocketmine\Player;

class PartyShopManager {

    private $plugin;
    private $stock     = [];
    private $lastReset = 0;

    const RESET_INTERVAL = 1800;

    const SWORD_ITEMS = [
        "shusui"        => ["name" => "§9Shusui",        "price" => 100,  "rarity" => "rare",      "weight" => 30],
        "wado_ichimonji"=> ["name" => "§9Wado Ichimonji","price" => 1200, "rarity" => "rare",      "weight" => 30],
        "trident"       => ["name" => "§6Trident",       "price" => 1800, "rarity" => "legendary", "weight" => 20],
        "yoru"          => ["name" => "§dYoru",          "price" => 4000, "rarity" => "mythical",  "weight" => 10],
        "katana"          => ["name" => "§dRik's Scythe",          "price" => 1000000000000000, "rarity" => "mythical",  "weight" => 100],
    ];

    const FRUIT_PRICES = [
        "bari_bari"        => 80,
        "moku_moku"        => 80,
        "inu_inu"          => 100,
        "tori_tori_falcon" => 120,
        "bara_bara"        => 300,
        "gomu_gomu"        => 500,
        "suna_suna"        => 700,
        "bomb_bomb"        => 750,
        "neko_neko"        => 800,
        "yami_yami"        => 900,
        "exp_2x_15"        => 100,
        "exp_2x_30"        => 150,
        "hie_hie"          => 1100,
        "iro_iro"          => 1200,
        "revive_revive"    => 1300,
        "mera_mera"        => 1400,
        "love_love"        => 1500,
        "pika_pika"        => 1200,
        "magu_magu"        => 1400,
        "magnet_magnet"    => 1500,
        "tori_tori"        => 1600,
        "sound_sound"      => 1600,
        "giro_giro"        => 1800,
        "gear_fourth"      => 2000,
        "yami_v2"          => 2000,
        "shadow_shadow"    => 2200,
        "zou_zou"          => 2500,
        "trex_trex"        => 2500,
        "mochi_mochi"      => 3000,
        "ope_ope"          => 3000,
        "gura_gura"        => 3000,
        "goro_goro"        => 3500,
        "gas_gas"          => 3800,
        "okuchi_okuchi"    => 3500,
        "uo_uo"            => 3500,
        "soru_soru"        => 4000,
        "dark_x_quake"     => 5000,
    ];

    const FRUIT_STOCK_CHANCES = [
        "bari_bari"        => 900,
        "moku_moku"        => 850,
        "inu_inu"          => 800,
        "tori_tori_falcon" => 700,
        "bara_bara"        => 350,
        "gomu_gomu"        => 280,
        "suna_suna"        => 200,
        "bomb_bomb"        => 160,
        "neko_neko"        => 130,
        "yami_yami"        => 100,
        "hie_hie"          => 50,
        "iro_iro"          => 50,
        "revive_revive"    => 50,
        "love_love"        => 50,
        "magu_magu"        => 50,
        "mera_mera"        => 50,
        "pika_pika"        => 50,
        "exp_2x_15"        => 100,
        "exp_2x_30"        => 100,
        "magnet_magnet"    => 100,
        "tori_tori"        => 100,
        "sound_sound"      => 100,
        "giro_giro"        => 100,
        "gear_fourth"      => 100,
        "yami_v2"          => 100,
        "shadow_shadow"    => 20,
        "zou_zou"          => 20,
        "trex_trex"        => 20,
        "mochi_mochi"      => 20,
        "goro_goro"        => 20,
        "gas_gas"          => 20,
        "ope_ope"          => 20,
        "okuchi_okuchi"    => 20,
        "gura_gura"        => 20,
        "soru_soru"        => 20,
        "dark_x_quake"     => 5,
        "uo_uo"            => 20,
    ];

    const FRUIT_RARITY = [
        "bari_bari"        => "common",
        "moku_moku"        => "common",
        "inu_inu"          => "common",
        "tori_tori_falcon" => "common",
        "bara_bara"        => "rare",
        "gomu_gomu"        => "rare",
        "suna_suna"        => "rare",
        "bomb_bomb"        => "rare",
        "neko_neko"        => "rare",
        "yami_yami"        => "rare",
        "hie_hie"          => "legendary",
        "iro_iro"          => "legendary",
        "revive_revive"    => "legendary",
        "mera_mera"        => "legendary",
        "love_love"        => "legendary",
        "pika_pika"        => "legendary",
        "magu_magu"        => "legendary",
        "magnet_magnet"    => "legendary",
        "tori_tori"        => "legendary",
        "sound_sound"      => "legendary",
        "giro_giro"        => "legendary",
        "gear_fourth"      => "legendary",
        "yami_v2"          => "legendary",
        "exp_2x_15"        => "legendary",
        "exp_2x_30"        => "legendary",
        "shadow_shadow"    => "mythical",
        "zou_zou"          => "mythical",
        "trex_trex"        => "mythical",
        "mochi_mochi"      => "mythical",
        "goro_goro"        => "mythical",
        "gas_gas"          => "mythical",
        "okuchi_okuchi"    => "mythical",
        "ope_ope"          => "mythical",
        "gura_gura"        => "mythical",
        "soru_soru"        => "mythical",
        "dark_x_quake"     => "mythical",
        "uo_uo"            => "mythical",
    ];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->refreshStock();
    }

    public function checkRefresh() {
        if (time() - $this->lastReset >= self::RESET_INTERVAL) $this->refreshStock();
    }

    public function refreshStock() {
        $this->stock     = [];
        $this->lastReset = time();
        $fruitCount = mt_rand(3, 5);
        $used = [];
        for ($i = 0; $i < $fruitCount; $i++) {
            $fruitId = $this->rollFruitFromPool(self::FRUIT_STOCK_CHANCES, $used);
            if ($fruitId === null) break;
            $used[] = $fruitId;
            $name = null;
            if ($fruitId === "exp_2x_15") $name = "2x EXP (15m)";
            if ($fruitId === "exp_2x_30") $name = "2x EXP (30m)";
            $this->stock[] = [
                "type"    => "fruit",
                "id"      => $fruitId,
                "name"    => $name,
                "rarity"  => self::FRUIT_RARITY[$fruitId] ?? "common",
                "price"   => self::FRUIT_PRICES[$fruitId] ?? 100,
            ];
        }
        $swordPool = self::SWORD_ITEMS;
        $swordRoll = mt_rand(1, 100);
        if ($swordRoll <= 60) {
            $totalWeight = 0;
            foreach ($swordPool as $w) $totalWeight += $w["weight"];
            $roll = mt_rand(1, $totalWeight);
            $sum  = 0;
            foreach ($swordPool as $swordId => $sdata) {
                $sum += $sdata["weight"];
                if ($roll <= $sum) {
                    $this->stock[] = [
                        "type"   => "sword",
                        "id"     => $swordId,
                        "name"   => $sdata["name"],
                        "rarity" => $sdata["rarity"],
                        "price"  => $sdata["price"],
                    ];
                    break;
                }
            }
        }
    }

    private function rollFruitFromPool(array $pool, array $exclude) {
        $filtered = [];
        foreach ($pool as $fruitId => $weight) {
            if (!in_array($fruitId, $exclude)) $filtered[$fruitId] = $weight;
        }
        if (empty($filtered)) return null;
        $total = array_sum($filtered);
        $roll  = mt_rand(1, $total);
        $sum   = 0;
        foreach ($filtered as $fruitId => $weight) {
            $sum += $weight;
            if ($roll <= $sum) return $fruitId;
        }
        return null;
    }

    public function getStock() {
        $this->checkRefresh();
        return $this->stock;
    }

    public function getTimeUntilReset() {
        return max(0, self::RESET_INTERVAL - (time() - $this->lastReset));
    }

    public function formatTime($seconds) {
        return intval($seconds / 60) . "m " . ($seconds % 60) . "s";
    }

    public function getStockEntry($slot) {
        $this->checkRefresh();
        return isset($this->stock[$slot]) ? $this->stock[$slot] : null;
    }

    public function removeStockEntry($slot) {
        if (isset($this->stock[$slot])) array_splice($this->stock, $slot, 1);
    }

    public function getRarityColor($rarity) {
        switch ($rarity) {
            case "common":    return "§a";
            case "rare":      return "§9";
            case "legendary": return "§6";
            case "mythical":  return "§d";
        }
        return "§f";
    }
}