<?php

namespace OnePiece\Berry;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class Main extends PluginBase implements Listener {

    private $opWorlds = ["OP", "Sea2", "sea3"];

    private $berryManager;
    private $shopManager;
    private $gachaManager;
    private $fruitStorage;
    private $shopMenuGUI;
    private $gachaMenuGUI;

    private $partyHatManager;
    private $partyGachaManager;
    private $partyShopManager;

    private $pausedFruits = [];
    private $pauseFile;

    public function onEnable() {
        $this->getLogger()->info(TextFormat::GREEN . "One Piece Berry System loaded!");

        @mkdir($this->getDataFolder());
        @mkdir($this->getDataFolder() . "events/");

        $this->pauseFile = $this->getDataFolder() . "paused_fruits.json";
        $this->loadPausedFruits();

        $this->berryManager      = new BerryManager($this);
        $this->shopManager       = new ShopManager($this);
        $this->gachaManager      = new GachaManager($this);
        $this->fruitStorage      = new FruitStorageManager($this);
        $this->shopMenuGUI       = new ShopMenuGUI($this);
        $this->gachaMenuGUI      = new GachaMenuGUI($this);
        $this->partyHatManager   = new PartyHatManager($this);
        $this->partyGachaManager = new PartyGachaManager($this);
        $this->partyShopManager  = new PartyShopManager($this);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $map = $this->getServer()->getCommandMap();
        $map->register("onepiece", new BerryCommand($this));
        $map->register("onepiece", new ShopCommand($this));
        $map->register("onepiece", new GachaCommand($this));
        $map->register("onepiece", new StorageCommand($this));
        $map->register("onepiece", new PartyEventCommand($this));
        $map->register("onepiece", new ShopAcceptCommand($this));

        $this->getServer()->getScheduler()->scheduleRepeatingTask(new ShopRefreshTask($this), 20 * 60);

        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            $this->berryManager->load($player->getName());
            $this->partyHatManager->load($player->getName());
        }
    }

    public function onDisable() {
        if ($this->berryManager !== null)    $this->berryManager->saveAll();
        if ($this->fruitStorage !== null)    $this->fruitStorage->saveAll();
        if ($this->partyHatManager !== null) $this->partyHatManager->saveAll();
        $this->savePausedFruits();
    }

    private function loadPausedFruits() {
        if (!file_exists($this->pauseFile)) {
            $this->pausedFruits = [];
            return;
        }
        $data = json_decode(file_get_contents($this->pauseFile), true);
        $this->pausedFruits = is_array($data) ? $data : [];
    }

    private function savePausedFruits() {
        file_put_contents($this->pauseFile, json_encode($this->pausedFruits));
    }

    public function getPausedFruits()  { return $this->pausedFruits; }

    public function pauseFruit($fruitId) {
        $fruitId = strtolower($fruitId);
        if (!in_array($fruitId, $this->pausedFruits)) {
            $this->pausedFruits[] = $fruitId;
            $this->savePausedFruits();
            return true;
        }
        return false;
    }

    public function unpauseFruit($fruitId) {
        $fruitId = strtolower($fruitId);
        $key = array_search($fruitId, $this->pausedFruits);
        if ($key !== false) {
            array_splice($this->pausedFruits, $key, 1);
            $this->savePausedFruits();
            return true;
        }
        return false;
    }

    public function isFruitPaused($fruitId) {
        return in_array(strtolower($fruitId), $this->pausedFruits);
    }

    public function getShopMenuGUI()       { return $this->shopMenuGUI; }
    public function getGachaMenuGUI()      { return $this->gachaMenuGUI; }
    public function getBerryManager()      { return $this->berryManager; }
    public function getShopManager()       { return $this->shopManager; }
    public function getGachaManager()      { return $this->gachaManager; }
    public function getFruitStorage()      { return $this->fruitStorage; }
    public function getPartyHatManager()   { return $this->partyHatManager; }
    public function getPartyGachaManager() { return $this->partyGachaManager; }
    public function getPartyShopManager()  { return $this->partyShopManager; }

    public function isInOPWorld(Player $player) {
        return in_array($player->getLevel()->getName(), $this->opWorlds);
    }

    public function onPlayerJoin(PlayerJoinEvent $event) {
        $name = $event->getPlayer()->getName();
        $this->berryManager->load($name);
        $this->partyHatManager->load($name);
    }

    public function onPlayerQuit(PlayerQuitEvent $event) {
        $name = $event->getPlayer()->getName();
        $this->berryManager->save($name);
        $this->berryManager->unload($name);
        $this->gachaManager->cancelSpin($name);
        $this->partyGachaManager->cancelSpin($name);
    }
}