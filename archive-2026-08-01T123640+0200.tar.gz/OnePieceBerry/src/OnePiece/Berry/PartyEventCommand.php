<?php

namespace OnePiece\Berry;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class PartyEventCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("opevent", "4th Anniversary Event", "/opevent [gacha|shop]");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cIn-game only.");
            return true;
        }

        if (!$this->plugin->isInOPWorld($sender)) {
            $sender->sendMessage("§cYou must be in the OP world.");
            return true;
        }

        $sub = isset($args[0]) ? strtolower($args[0]) : "";

        if ($sub === "gacha") {
            return $this->handleGacha($sender);
        }

        if ($sub === "shop") {
            return $this->handleShop($sender);
        }

        $phm  = $this->plugin->getPartyHatManager();
        $hats = $phm->get($sender->getName());

        $sender->sendMessage("§6§l================================");
        $sender->sendMessage("§6§l  Summer Event!");
        $sender->sendMessage("§6§l================================");
        $sender->sendMessage("§e  Sunglasses: §f" . $hats);
        $sender->sendMessage("§7  Earn Sunglasses by killing");
        $sender->sendMessage("§7  [Summer] NPCs in the world!");
        $sender->sendMessage("§6§l--------------------------------");
        return true;
    }

    private function handleGacha(Player $sender) {
        $gm  = $this->plugin->getPartyGachaManager();
        $phm = $this->plugin->getPartyHatManager();

        if ($gm->isSpinning($sender)) {
            $sender->sendMessage("§cYou are already spinning!");
            return true;
        }

        if ($gm->hasPendingConfirm($sender)) {
            $gm->setPendingConfirm($sender, false);

            $result = $gm->startSpin($sender);
            if (!$result["success"]) {
                $sender->sendMessage("§c" . $result["error"]);
                return true;
            }

            $sender->sendMessage("§6§l[Summer Gacha] §r§eSpinning...");

            $task = new PartyGachaAnimTask($this->plugin, $sender->getName(), $result["fruitId"], $result["rarity"]);
            $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($task, 3);
            return true;
        }

        $hats = $phm->get($sender->getName());
        if ($hats < PartyGachaManager::GACHA_COST) {
            $sender->sendMessage("§cNot enough Sunglasses! Need §e" . PartyGachaManager::GACHA_COST . " §cyou have §e" . $hats);
            return true;
        }

        $gm->setPendingConfirm($sender, true);
        $sender->sendMessage("§6§l================================");
        $sender->sendMessage("§6§l  4th Anniversary Party Gacha");
        $sender->sendMessage("§6§l================================");
        $sender->sendMessage("§7  Cost: §e" . PartyGachaManager::GACHA_COST . " Party Hats");
        $sender->sendMessage("§7  Your hats: §e" . $hats);
        $sender->sendMessage("§c  WARNING: No cooldown but costs");
        $sender->sendMessage("§c  Party Hats on every roll!");
        $sender->sendMessage("§a  Boosted rates for rare fruits!");
        $sender->sendMessage("§6§l--------------------------------");
        $sender->sendMessage("§eRun §f/opevent gacha §eagain to confirm!");
        $sender->sendMessage("§7(Expires in 30 seconds)");
        $sender->sendMessage("§6§l================================");
        return true;
    }

    private function handleShop(Player $sender) {
        $sm   = $this->plugin->getPartyShopManager();
        $phm  = $this->plugin->getPartyHatManager();
        $stock = $sm->getStock();
        $hats  = $phm->get($sender->getName());

        $sender->sendMessage("§6§l================================");
        $sender->sendMessage("§6§l  Summer Shop");
        $sender->sendMessage("§6§l================================");
        $sender->sendMessage("§e  Sunglasses: §f" . $hats . "  §7| Restock in: §f" . $sm->formatTime($sm->getTimeUntilReset()));
        $sender->sendMessage("§6§l--------------------------------");

        if (empty($stock)) {
            $sender->sendMessage("§7  No items in stock right now.");
        } else {
            foreach ($stock as $i => $entry) {
                $slot    = $i + 1;
                $color   = $sm->getRarityColor($entry["rarity"]);
                $canAfford = $hats >= $entry["price"] ? "§a" : "§c";

                if ($entry["type"] === "fruit") {
                    $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
                    $displayName = $entry["id"];
                    if ($devilPlugin !== null && $devilPlugin->isEnabled()) {
                        $fruit = $devilPlugin->getFruitManager()->getFruit($entry["id"]);
                        if ($fruit !== null) $displayName = $fruit->getDisplayName();
                    }
                    $sender->sendMessage("§7  [" . $slot . "] " . $color . $displayName . " §7- " . $canAfford . $entry["price"] . " Sunglasses");
                } else {
                    $sender->sendMessage("§7  [" . $slot . "] " . $entry["name"] . " §7- " . $canAfford . $entry["price"] . " Sunglasses §7(Sword)");
                }
            }
        }

        $sender->sendMessage("§6§l--------------------------------");
        $sender->sendMessage("§eTo buy: §f/shopaccept <slot>");
        $sender->sendMessage("§6§l================================");
        return true;
    }
}