<?php

namespace OnePiece\Berry;

use pocketmine\Player;

class PartyHatManager {

    private $plugin;
    private $balances = [];
    private $savePath;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $dir = $plugin->getDataFolder() . "events/";
        @mkdir($dir, 0777, true);
        $this->savePath = $dir . "party_hats.json";
        $this->loadAll();
    }

    private function loadAll() {
        if (!file_exists($this->savePath)) return;
        $data = json_decode(file_get_contents($this->savePath), true);
        if (is_array($data)) {
            $this->balances = $data;
        }
    }

    public function saveAll() {
        file_put_contents($this->savePath, json_encode($this->balances, JSON_PRETTY_PRINT));
    }

    public function load($name) {
        $name = strtolower($name);
        if (!isset($this->balances[$name])) {
            $this->balances[$name] = 0;
        }
    }

    public function get($name) {
        $name = strtolower($name);
        return isset($this->balances[$name]) ? (int)$this->balances[$name] : 0;
    }

    public function set($name, $amount) {
        $name = strtolower($name);
        $this->balances[$name] = max(0, (int)$amount);
        $this->saveAll();
    }

    public function add($name, $amount) {
        $name = strtolower($name);
        $amount = max(0, (int)$amount);
        $this->balances[$name] = $this->get($name) + $amount;
        $this->saveAll();
    }

    public function remove($name, $amount) {
        $name = strtolower($name);
        $amount = max(0, (int)$amount);
        $current = $this->get($name);
        $this->balances[$name] = max(0, $current - $amount);
        $this->saveAll();
    }

    public function has($name, $amount) {
        return $this->get($name) >= $amount;
    }

    public function format($amount) {
        return number_format($amount);
    }
}