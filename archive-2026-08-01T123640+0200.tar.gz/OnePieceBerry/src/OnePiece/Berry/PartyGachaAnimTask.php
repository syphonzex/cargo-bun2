<?php

namespace OnePiece\Berry;

use pocketmine\scheduler\PluginTask;
use pocketmine\network\protocol\LevelEventPacket;

class PartyGachaAnimTask extends PluginTask {

    private $plugin;
    private $playerName;
    private $fruitId;
    private $rarity;
    private $ticks = 0;
    private $maxTicks = 100;

    public function __construct(Main $plugin, $playerName, $fruitId, $rarity) {
        parent::__construct($plugin);
        $this->plugin     = $plugin;
        $this->playerName = $playerName;
        $this->fruitId    = $fruitId;
        $this->rarity     = $rarity;
    }

    public function onRun($currentTick) {
        $player = $this->plugin->getServer()->getPlayerExact($this->playerName);

        if ($player === null || !$player->isOnline()) {
            $this->plugin->getPartyGachaManager()->cancelSpin($this->playerName);
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $this->ticks++;
        $gm = $this->plugin->getPartyGachaManager();
        $fakeNames = $gm->getFakeNames();

        if ($this->ticks <= 70) {
            $fake = $fakeNames[array_rand($fakeNames)];
            $player->sendTip(
                "§6§l[4th Anniversary Party Gacha]\n" .
                "§e~ Spinning ~\n" .
                $fake . "\n" .
                "§7" . str_repeat("=", 20)
            );
            $this->playTickSound($player, $this->ticks);

        } elseif ($this->ticks <= 90) {
            $color = $gm->getRarityColor($this->rarity);
            $name  = $gm->getFruitDisplayName($this->fruitId);
            $player->sendTip(
                "§6§l[4th Anniversary Party Gacha]\n" .
                "§e~ Almost there... ~\n" .
                $color . $name . "\n" .
                "§7" . str_repeat("=", 20)
            );
            $this->playSlowTickSound($player);

        } else {
            $color = $gm->getRarityColor($this->rarity);
            $name  = $gm->getFruitDisplayName($this->fruitId);
            $player->sendTip(
                "§6§l[4th Anniversary Party Gacha]\n" .
                "§a§l YOU GOT:\n" .
                $color . "§l" . $name . "\n" .
                "§7" . str_repeat("=", 20)
            );
            $this->playWinSound($player);
            $gm->finishSpin($player, $this->fruitId, $this->rarity);

            $color = $gm->getRarityColor($this->rarity);
            $player->sendMessage("§6§l=== Party Gacha Result ===");
            $player->sendMessage($color . "  " . $name);
            $player->sendMessage($color . "  [" . strtoupper($this->rarity) . "]");
            $player->sendMessage("§6§l=========================");

            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
        }
    }

    private function playTickSound($player, $tick) {
        $pk = new LevelEventPacket();
        if ($tick % 10 === 0) {
            $pk->evid = LevelEventPacket::EVENT_SOUND_CLICK;
        } else {
            $pk->evid = LevelEventPacket::EVENT_SOUND_EXP_PICKUP;
        }
        $pk->x = $player->x;
        $pk->y = $player->y;
        $pk->z = $player->z;
        $pk->data = 0;
        $player->dataPacket($pk);
    }

    private function playSlowTickSound($player) {
        $pk = new LevelEventPacket();
        $pk->evid = LevelEventPacket::EVENT_SOUND_DOOR;
        $pk->x = $player->x;
        $pk->y = $player->y;
        $pk->z = $player->z;
        $pk->data = 0;
        $player->dataPacket($pk);
    }

    private function playWinSound($player) {
        $pk = new LevelEventPacket();
        $pk->evid = LevelEventPacket::EVENT_SOUND_EXPLODE;
        $pk->x = $player->x;
        $pk->y = $player->y;
        $pk->z = $player->z;
        $pk->data = 0;
        $player->dataPacket($pk);
    }
}