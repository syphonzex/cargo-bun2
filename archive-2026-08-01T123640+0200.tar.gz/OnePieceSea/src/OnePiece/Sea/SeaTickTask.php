<?php

namespace OnePiece\Sea;

use pocketmine\scheduler\PluginTask;

class SeaTickTask extends PluginTask {

    /** @var Main */
    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct($plugin);
        $this->plugin = $plugin;
    }

    public function onRun($currentTick) {
        $this->plugin->getShipManager()->tick();
    }
}