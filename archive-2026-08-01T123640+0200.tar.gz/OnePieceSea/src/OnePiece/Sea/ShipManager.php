<?php

namespace OnePiece\Sea;

use pocketmine\Player;
use pocketmine\entity\Entity;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\FloatTag;

class ShipManager {

    private $plugin;

    private $shipTypes = [
        "raft" => [
            "name" => "Raft",
            "speed" => 0.0,
            "health" => 40,
            "description" => "Basic raft. No speed bonus."
        ],
        "caravel" => [
            "name" => "Caravel",
            "speed" => 0.3,
            "health" => 80,
            "description" => "Sturdy pirate ship. Faster sailing."
        ],
        "galleon" => [
            "name" => "Galleon",
            "speed" => 100,
            "health" => 150,
            "description" => "Mighty warship. Fastest on sea."
        ]
    ];

    private $ownedShips = [];
    private $activeBoats = [];
    private $savePath;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->savePath = $plugin->getDataFolder() . "ships.json";
        $this->loadAll();
    }

    public function loadAll() {
        if (!file_exists($this->savePath)) {
            $this->ownedShips = [];
            return;
        }
        $data = json_decode(file_get_contents($this->savePath), true);
        if (is_array($data)) {
            $this->ownedShips = $data;
        }
    }

    public function saveAll() {
        file_put_contents($this->savePath, json_encode($this->ownedShips, JSON_PRETTY_PRINT));
    }

    public function getOwnedShipType(Player $player) {
        $name = $player->getName();
        return isset($this->ownedShips[$name]) ? $this->ownedShips[$name] : "raft";
    }

    public function setOwnedShipType(Player $player, $type) {
        if (!isset($this->shipTypes[$type])) {
            return false;
        }
        $this->ownedShips[$player->getName()] = $type;
        $this->saveAll();
        return true;
    }

    public function getShipTypes() {
        return $this->shipTypes;
    }

    public function getShipTypeData($type) {
        return isset($this->shipTypes[$type]) ? $this->shipTypes[$type] : null;
    }

    private function isWaterBlock($block) {
        $id = $block->getId();
        return $id === Block::WATER || $id === Block::STILL_WATER;
    }

    private function findWaterSurface($level, $x, $z, $startY) {
        $waterIds = [Block::WATER, Block::STILL_WATER];

        $foundWater = false;
        $surfaceY = $startY;

        for ($y = $startY + 5; $y >= $startY - 10; $y--) {
            $block = $level->getBlock(new Vector3($x, $y, $z));
            $blockAbove = $level->getBlock(new Vector3($x, $y + 1, $z));

            if (in_array($block->getId(), $waterIds) && !in_array($blockAbove->getId(), $waterIds)) {
                $surfaceY = $y + 1;
                $foundWater = true;
                break;
            }
        }

        if (!$foundWater) {
            for ($y = $startY - 10; $y <= $startY + 10; $y++) {
                $block = $level->getBlock(new Vector3($x, $y, $z));
                if (in_array($block->getId(), $waterIds)) {
                    $blockAbove = $level->getBlock(new Vector3($x, $y + 1, $z));
                    if (!in_array($blockAbove->getId(), $waterIds)) {
                        $surfaceY = $y + 1;
                        $foundWater = true;
                        break;
                    }
                }
            }
        }

        if ($foundWater) {
            return $surfaceY;
        }

        return null;
    }

    private function findNearbyWater(Player $player) {
        $level = $player->getLevel();
        $pos = $player->floor();
        $yaw = $player->yaw;
        $searchRadius = 6;

        $dirX = -sin(deg2rad($yaw));
        $dirZ = cos(deg2rad($yaw));

        for ($dist = 3; $dist <= $searchRadius; $dist++) {
            $checkX = (int)floor($pos->x + $dirX * $dist);
            $checkZ = (int)floor($pos->z + $dirZ * $dist);

            $surfaceY = $this->findWaterSurface($level, $checkX, $checkZ, (int)$pos->y);

            if ($surfaceY !== null) {
                $spawnX = $checkX + 0.5;
                $spawnZ = $checkZ + 0.5;
                $spawnY = $surfaceY + 0.5;

                $blockAtSpawn = $level->getBlock(new Vector3($checkX, $surfaceY, $checkZ));
                $blockAboveSpawn = $level->getBlock(new Vector3($checkX, $surfaceY + 1, $checkZ));

                if ($blockAtSpawn->getId() === Block::AIR || $this->isWaterBlock($blockAtSpawn)) {
                    if ($blockAboveSpawn->getId() === Block::AIR) {
                        return new Vector3($spawnX, $spawnY, $spawnZ);
                    }
                }
            }
        }

        for ($x = -$searchRadius; $x <= $searchRadius; $x += 2) {
            for ($z = -$searchRadius; $z <= $searchRadius; $z += 2) {
                if (abs($x) < 2 && abs($z) < 2) continue;

                $checkX = (int)($pos->x + $x);
                $checkZ = (int)($pos->z + $z);

                $surfaceY = $this->findWaterSurface($level, $checkX, $checkZ, (int)$pos->y);

                if ($surfaceY !== null) {
                    $spawnX = $checkX + 0.5;
                    $spawnZ = $checkZ + 0.5;
                    $spawnY = $surfaceY + 0.5;

                    $blockAtSpawn = $level->getBlock(new Vector3($checkX, $surfaceY, $checkZ));
                    $blockAboveSpawn = $level->getBlock(new Vector3($checkX, $surfaceY + 1, $checkZ));

                    if ($blockAtSpawn->getId() === Block::AIR || $this->isWaterBlock($blockAtSpawn)) {
                        if ($blockAboveSpawn->getId() === Block::AIR) {
                            return new Vector3($spawnX, $spawnY, $spawnZ);
                        }
                    }
                }
            }
        }

        return null;
    }

    public function isNearWater(Player $player) {
        return $this->findNearbyWater($player) !== null;
    }

    public function spawnBoat(Player $player) {
        $name = $player->getName();

        $waterPos = $this->findNearbyWater($player);

        if ($waterPos === null) {
            $player->sendMessage(TextFormat::RED . "No water nearby! Go closer to water.");
            return false;
        }

        $this->removeBoat($player);

        $type = $this->getOwnedShipType($player);
        $typeData = $this->shipTypes[$type];

        $nbt = new CompoundTag("", [
            "Pos" => new ListTag("Pos", [
                new DoubleTag("", $waterPos->x),
                new DoubleTag("", $waterPos->y),
                new DoubleTag("", $waterPos->z)
            ]),
            "Motion" => new ListTag("Motion", [
                new DoubleTag("", 0),
                new DoubleTag("", 0),
                new DoubleTag("", 0)
            ]),
            "Rotation" => new ListTag("Rotation", [
                new FloatTag("", $player->yaw),
                new FloatTag("", 0)
            ])
        ]);

        $chunk = $player->getLevel()->getChunk($waterPos->x >> 4, $waterPos->z >> 4);

        if ($chunk === null) {
            $player->sendMessage(TextFormat::RED . "Failed to spawn boat! Chunk not loaded.");
            return false;
        }

        $boat = Entity::createEntity("Boat", $chunk, $nbt);

        if ($boat === null) {
            $player->sendMessage(TextFormat::RED . "Failed to spawn boat!");
            return false;
        }

        $boat->setMaxHealth($typeData["health"]);
        $boat->setHealth($typeData["health"]);

        $boat->spawnToAll();

        $this->activeBoats[$name] = $boat->getId();

        $player->sendMessage(TextFormat::GREEN . "" . $typeData["name"] . " spawned on the water!");
        $player->sendMessage(TextFormat::GRAY . "Right-click the boat to ride it.");
        $player->sendMessage(TextFormat::GRAY . "HP: " . $typeData["health"] . " | Speed: +" . ($typeData["speed"] * 100) . "%");

        return true;
    }

    public function removeBoat(Player $player) {
        $name = $player->getName();

        if (!isset($this->activeBoats[$name])) {
            return false;
        }

        $entityId = $this->activeBoats[$name];
        $level = $player->getLevel();

        foreach ($level->getEntities() as $entity) {
            if ($entity->getId() === $entityId) {
                $entity->close();
                break;
            }
        }

        unset($this->activeBoats[$name]);
        return true;
    }

    public function hasActiveBoat(Player $player) {
        return isset($this->activeBoats[$player->getName()]);
    }

    public function getActiveBoat(Player $player) {
        $name = $player->getName();
        if (!isset($this->activeBoats[$name])) {
            return null;
        }

        $entityId = $this->activeBoats[$name];

        foreach ($player->getLevel()->getEntities() as $entity) {
            if ($entity->getId() === $entityId) {
                return $entity;
            }
        }

        unset($this->activeBoats[$name]);
        return null;
    }

    public function tick() {
        foreach ($this->activeBoats as $name => $entityId) {
            $player = $this->plugin->getServer()->getPlayerExact($name);

            if ($player === null || !$player->isOnline()) {
                $this->removeBoatByName($name);
                continue;
            }

            if (!$this->plugin->isInOPWorld($player)) {
                $this->removeBoat($player);
                continue;
            }

            $boat = $this->getActiveBoat($player);
            if ($boat === null) {
                unset($this->activeBoats[$name]);
                continue;
            }

            if ($this->isRidingBoat($player, $boat)) {
                $type = $this->getOwnedShipType($player);
                $typeData = $this->shipTypes[$type];
                $speedBonus = $typeData["speed"];

                if ($speedBonus > 0) {
                    $this->boostBoatSpeed($player, $boat, $speedBonus);
                }

                $hp = round($boat->getHealth());
                $maxHp = $boat->getMaxHealth();
                /*$player->sendPopup(
                    TextFormat::AQUA . "@ " . $typeData["name"] .
                    " §7| §c# " . $hp . "/" . $maxHp
                );*/
            }
        }
    }

    public function removeBoatByName($name) {
        if (!isset($this->activeBoats[$name])) {
            return;
        }

        $entityId = $this->activeBoats[$name];

        foreach ($this->plugin->getServer()->getLevels() as $level) {
            foreach ($level->getEntities() as $entity) {
                if ($entity->getId() === $entityId) {
                    $entity->close();
                    break 2;
                }
            }
        }

        unset($this->activeBoats[$name]);
    }

    private function isRidingBoat(Player $player, Entity $boat) {
        $linked = $player->getLinkedEntity();
        if ($linked !== null && $linked->getId() === $boat->getId()) {
            return true;
        }

        $dist = $player->distance($boat);
        if ($dist < 1.0 && abs($player->y - $boat->y) < 1.5) {
            return true;
        }

        return false;
    }

    private function boostBoatSpeed(Player $player, Entity $boat, $speedBonus) {
        $motion = $boat->getMotion();

        if (abs($motion->x) > 0.01 || abs($motion->z) > 0.01) {
            $newMotion = new Vector3(
                $motion->x * (1 + $speedBonus),
                $motion->y,
                $motion->z * (1 + $speedBonus)
            );
            $boat->setMotion($newMotion);
        }
    }

    public function getActiveShips() {
        return $this->activeBoats;
    }
}