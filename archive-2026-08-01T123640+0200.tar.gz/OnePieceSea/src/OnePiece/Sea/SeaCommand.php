<?php

namespace OnePiece\Sea;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class SeaCommand extends Command {

    /** @var Main */
    private $plugin;

    public function __construct(Main $plugin, $name, $description, $usage) {
        parent::__construct($name, $description, $usage);
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage(TextFormat::RED . "In-game only.");
            return true;
        }

        switch ($this->getName()) {
            case "ship":
                return $this->handleShip($sender, $args);
            case "sea":
                return $this->handleSea($sender);
        }

        return true;
    }

    // ========================
    // /sea
    // ========================

    private function handleSea(Player $sender) {
        if (!$this->plugin->isInOPWorld($sender)) {
            $sender->sendMessage(TextFormat::RED . "Only in OP world!");
            return true;
        }

        $sz = $this->plugin->getSeaZone();
        $zone = $sz->getZoneAt($sender->getX(), $sender->getZ());
        $dist = round(sqrt($sender->getX() * $sender->getX() + $sender->getZ() * $sender->getZ()));

        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        $sender->sendMessage(TextFormat::GOLD . "  $ Sea Info");
        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        $sender->sendMessage($sz->getZoneColor($zone) . "Zone: " . $sz->getZoneName($zone));
        $sender->sendMessage(TextFormat::GRAY . $sz->getZoneDescription($zone));
        $sender->sendMessage(TextFormat::YELLOW . "Distance: " . $dist . " blocks");
        $sender->sendMessage(TextFormat::YELLOW . "Bounty mult: " . $sz->getBountyMultiplier($zone) . "x");
        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");

        return true;
    }

    // ========================
    // /ship
    // ========================

    private function handleShip(Player $sender, array $args) {
        if (!$this->plugin->isInOPWorld($sender)) {
            $sender->sendMessage(TextFormat::RED . "Only in OP world!");
            return true;
        }

        if (count($args) === 0) {
            return $this->shipStatus($sender);
        }

        $sub = strtolower($args[0]);

        switch ($sub) {
            case "help":
                return $this->shipHelp($sender);
            case "spawn":
                return $this->shipSpawn($sender);
            case "remove":
                return $this->shipRemove($sender);
            case "upgrade":
                return $this->shipUpgrade($sender, $args);
            case "types":
                return $this->shipTypes($sender);
            case "set":
                return $this->shipSet($sender, $args);
            default:
                return $this->shipHelp($sender);
        }
    }

    private function shipHelp(Player $sender) {
        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        $sender->sendMessage(TextFormat::GOLD . "  @ Ship Commands");
        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        $sender->sendMessage(TextFormat::YELLOW . "/ship" . TextFormat::GRAY . " - Ship status");
        $sender->sendMessage(TextFormat::YELLOW . "/ship spawn" . TextFormat::GRAY . " - Spawn your boat");
        $sender->sendMessage(TextFormat::YELLOW . "/ship remove" . TextFormat::GRAY . " - Remove your boat");
        $sender->sendMessage(TextFormat::YELLOW . "/ship upgrade <type>" . TextFormat::GRAY . " - Upgrade");
        $sender->sendMessage(TextFormat::YELLOW . "/ship types" . TextFormat::GRAY . " - View ship types");
        $sender->sendMessage(TextFormat::YELLOW . "/sea" . TextFormat::GRAY . " - Sea zone info");
        if ($sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "/ship set <player> <type>" . TextFormat::GRAY . " - Admin");
        }
        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        return true;
    }

    private function shipStatus(Player $sender) {
        $sm = $this->plugin->getShipManager();
        $type = $sm->getOwnedShipType($sender);
        $data = $sm->getShipTypeData($type);

        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        $sender->sendMessage(TextFormat::GOLD . "  @ Your Ship");
        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        $sender->sendMessage(TextFormat::YELLOW . "Type: " . TextFormat::WHITE . $data["name"]);
        $sender->sendMessage(TextFormat::YELLOW . "HP: " . TextFormat::WHITE . $data["health"]);
        $sender->sendMessage(TextFormat::YELLOW . "Speed Bonus: " . TextFormat::WHITE . "+" . ($data["speed"] * 100) . "%");
        $sender->sendMessage(TextFormat::GRAY . $data["description"]);

        if ($sm->hasActiveBoat($sender)) {
            $boat = $sm->getActiveBoat($sender);
            if ($boat !== null) {
                $sender->sendMessage(TextFormat::GREEN . "Status: ACTIVE (HP: " . round($boat->getHealth()) . "/" . $boat->getMaxHealth() . ")");
            }
        } else {
            $sender->sendMessage(TextFormat::GRAY . "Status: NOT SPAWNED");
        }

        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        return true;
    }

    private function shipSpawn(Player $sender) {
        $sm = $this->plugin->getShipManager();

        if ($sm->hasActiveBoat($sender)) {
            $sender->sendMessage(TextFormat::YELLOW . "You already have a boat! Use /ship remove first.");
            return true;
        }

        $sm->spawnBoat($sender);
        return true;
    }

    private function shipRemove(Player $sender) {
        $sm = $this->plugin->getShipManager();

        if (!$sm->hasActiveBoat($sender)) {
            $sender->sendMessage(TextFormat::RED . "No boat spawned.");
            return true;
        }

        $sm->removeBoat($sender);
        $sender->sendMessage(TextFormat::GRAY . "@ Boat removed.");
        return true;
    }

    private function shipTypes(Player $sender) {
        $sm = $this->plugin->getShipManager();
        $types = $sm->getShipTypes();

        $costs = ["raft" => "Free", "caravel" => "5 Diamonds", "galleon" => "15 Diamonds"];

        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        $sender->sendMessage(TextFormat::GOLD . "  @ Ship Types");
        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");

        foreach ($types as $id => $data) {
            $cost = isset($costs[$id]) ? $costs[$id] : "?";
            $sender->sendMessage(
                TextFormat::YELLOW . "• " . $data["name"] .
                TextFormat::GRAY . " | HP: " . $data["health"] .
                " | Speed: +" . ($data["speed"] * 100) . "%" .
                " | Cost: " . $cost
            );
        }

        $sender->sendMessage(TextFormat::GOLD . "═══════════════════════");
        return true;
    }

    private function shipUpgrade(Player $sender, array $args) {
        if (!isset($args[1])) {
            $sender->sendMessage(TextFormat::RED . "Usage: /ship upgrade <raft|caravel|galleon>");
            return true;
        }

        $type = strtolower($args[1]);
        $sm = $this->plugin->getShipManager();

        if ($sm->getShipTypeData($type) === null) {
            $sender->sendMessage(TextFormat::RED . "Invalid type! Use /ship types");
            return true;
        }

        $costs = ["raft" => 0, "caravel" => 5, "galleon" => 15];
        $cost = isset($costs[$type]) ? $costs[$type] : 0;

        if ($cost > 0) {
            $inv = $sender->getInventory();
            $found = false;

            for ($i = 0; $i < $inv->getSize(); $i++) {
                $item = $inv->getItem($i);
                if ($item->getId() === \pocketmine\item\Item::DIAMOND && $item->getCount() >= $cost) {
                    $item->setCount($item->getCount() - $cost);
                    $inv->setItem($i, $item);
                    $found = true;
                    break;
                }
            }

            if (!$found) {
                $sender->sendMessage(TextFormat::RED . "Need " . $cost . " Diamonds!");
                return true;
            }
        }

        // Remove current boat if active
        if ($sm->hasActiveBoat($sender)) {
            $sm->removeBoat($sender);
        }

        $sm->setOwnedShipType($sender, $type);
        $data = $sm->getShipTypeData($type);
        $sender->sendMessage(TextFormat::GREEN . "@ Upgraded to " . $data["name"] . "!");
        $sender->sendMessage(TextFormat::GRAY . "HP: " . $data["health"] . " | Speed: +" . ($data["speed"] * 100) . "%");

        return true;
    }

    private function shipSet(Player $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only!");
            return true;
        }

        if (count($args) < 3) {
            $sender->sendMessage(TextFormat::RED . "Usage: /ship set <player> <type>");
            return true;
        }

        $target = $this->plugin->getServer()->getPlayerExact($args[1]);
        if ($target === null) {
            $sender->sendMessage(TextFormat::RED . "Player not online.");
            return true;
        }

        $type = strtolower($args[2]);
        $sm = $this->plugin->getShipManager();

        if ($sm->getShipTypeData($type) === null) {
            $sender->sendMessage(TextFormat::RED . "Invalid type!");
            return true;
        }

        $sm->setOwnedShipType($target, $type);
        $sender->sendMessage(TextFormat::GREEN . "$ Set " . $target->getName() . "'s ship to " . $type);
        $target->sendMessage(TextFormat::GOLD . "@ Ship set to " . $type . " by admin!");

        return true;
    }
}