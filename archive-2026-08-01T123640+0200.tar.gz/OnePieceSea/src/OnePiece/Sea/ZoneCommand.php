<?php

namespace OnePiece\Sea;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\entity\Effect;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Config;

class ZoneCommand extends Command {

    private $plugin;
    private $godConfig;

    private $fallbackZone = [
        "OP"   => "Starter_Island",
        "Sea2" => "Sabaody_Archapelago",
        "sea3" => "Port_Town"
    ];

public function __construct(Main $plugin) {
    parent::__construct("zone", "Zone management and teleport", "/zone help");
    $this->plugin = $plugin;

    @mkdir($plugin->getDataFolder());
    $this->godConfig = new Config(
        $plugin->getDataFolder() . "god_players.yml",
        Config::YAML,
        ["players" => []]
    );
}

    public function execute(CommandSender $sender, $label, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage(TextFormat::RED . "In-game only.");
            return true;
        }

        if (!isset($args[0])) {
            if ($sender->isOp()) {
                return $this->showHelp($sender);
            }
            return $this->handleTeleport($sender);
        }

        $sub = strtolower($args[0]);

        switch ($sub) {
            case "help":
                return $this->showHelp($sender);
            case "op":
                return $this->handleTeleport($sender);
            case "pos1":
                return $this->handlePos1($sender);
            case "pos2":
                return $this->handlePos2($sender);
            case "create":
                return $this->handleCreate($sender, $args);
            case "remove":
            case "delete":
                return $this->handleRemove($sender, $args);
            case "list":
                return $this->handleList($sender);
            case "info":
                return $this->handleInfo($sender);
            case "tp":
                return $this->handleTpToZone($sender, $args);
            case "setspawn":
                return $this->handleSetSpawn($sender, $args);
            case "restrict":
                return $this->handleRestrict($sender, $args);
            case "sethome":
                return $this->handleSetHome($sender);
case "home":
    return $this->handleHome($sender);

case "god":
    return $this->handleGod($sender, $args);

default:
                if ($sender->isOp()) {
                    return $this->showHelp($sender);
                }
                return $this->handleTeleport($sender);
        }
    }

    private function handlePos1(Player $sender) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only.");
            return true;
        }
        $sz = $this->plugin->getSeaZone();
        $pos = $sz->setPos1($sender);
        $sender->sendMessage(TextFormat::GREEN . "Position 1 set: X=" . $pos["x"] . " Y=" . $pos["y"] . " Z=" . $pos["z"]);
        return true;
    }

    private function handlePos2(Player $sender) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only.");
            return true;
        }
        $sz = $this->plugin->getSeaZone();
        $pos = $sz->setPos2($sender);
        $sender->sendMessage(TextFormat::GREEN . "Position 2 set: X=" . $pos["x"] . " Y=" . $pos["y"] . " Z=" . $pos["z"]);

        if ($sz->hasSelection($sender)) {
            $sel = $sz->getSelection($sender);
            $p1 = $sel["pos1"];
            $p2 = $sel["pos2"];
            $sizeX = abs($p2["x"] - $p1["x"]) + 1;
            $sizeY = abs($p2["y"] - $p1["y"]) + 1;
            $sizeZ = abs($p2["z"] - $p1["z"]) + 1;
            $sender->sendMessage(TextFormat::GRAY . "Selection size: " . $sizeX . "x" . $sizeY . "x" . $sizeZ);
            $sender->sendMessage(TextFormat::GRAY . "Use /zone create <n> <description> to create.");
        }
        return true;
    }

    private function handleCreate(Player $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only.");
            return true;
        }

        $sz = $this->plugin->getSeaZone();

        if (!$sz->hasSelection($sender)) {
            $sender->sendMessage(TextFormat::RED . "Set pos1 and pos2 first!");
            return true;
        }

        if (!isset($args[1])) {
            $sender->sendMessage(TextFormat::RED . "Usage: /zone create <n> <description>");
            return true;
        }

        $zoneName = $args[1];
        $worldName = $sender->getLevel()->getFolderName();

        if ($sz->zoneExists($zoneName, $worldName)) {
            $sender->sendMessage(TextFormat::RED . "Zone '" . $zoneName . "' already exists in " . $worldName . "!");
            return true;
        }

        $description = "";
        if (isset($args[2])) {
            $description = implode(" ", array_slice($args, 2));
        }

        $sel = $sz->getSelection($sender);
        $sz->createZone($zoneName, $description, $sel["pos1"], $sel["pos2"], $worldName);

        $p1 = $sel["pos1"];
        $p2 = $sel["pos2"];

        $sender->sendMessage(TextFormat::GREEN . "Zone '" . $zoneName . "' created in " . $worldName . "!");
        $sender->sendMessage(TextFormat::GRAY . "From: X=" . $p1["x"] . " Y=" . $p1["y"] . " Z=" . $p1["z"]);
        $sender->sendMessage(TextFormat::GRAY . "To: X=" . $p2["x"] . " Y=" . $p2["y"] . " Z=" . $p2["z"]);
        if (!empty($description)) {
            $sender->sendMessage(TextFormat::GRAY . "Description: " . $description);
        }
        return true;
    }

    private function handleRemove(Player $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only.");
            return true;
        }

        if (!isset($args[1])) {
            $sender->sendMessage(TextFormat::RED . "Usage: /zone remove <n>");
            return true;
        }

        $zoneName = $args[1];
        $worldName = $sender->getLevel()->getFolderName();
        $sz = $this->plugin->getSeaZone();

        if (!$sz->zoneExists($zoneName, $worldName)) {
            $sender->sendMessage(TextFormat::RED . "Zone '" . $zoneName . "' not found in " . $worldName . "!");
            return true;
        }

        $sz->removeZone($zoneName, $worldName);
        $sender->sendMessage(TextFormat::GREEN . "Zone '" . $zoneName . "' removed from " . $worldName . ".");
        return true;
    }

    private function handleInfo(Player $sender) {
        $sz = $this->plugin->getSeaZone();
        $worldName = $sender->getLevel()->getFolderName();
        $x = $sender->getFloorX();
        $y = $sender->getFloorY();
        $z = $sender->getFloorZ();

        $zone = $sz->getZoneAt($x, $y, $z, $worldName);
        if ($zone === null) {
            $sender->sendMessage(TextFormat::YELLOW . "You are not inside any zone.");
            return true;
        }

        $restrict = isset($zone["restrict"]) ? $zone["restrict"] : 0;
        $sender->sendMessage(TextFormat::GOLD . "Zone: " . TextFormat::WHITE . $zone["name"]);
        $sender->sendMessage(TextFormat::GOLD . "World: " . TextFormat::WHITE . $worldName);
        if (!empty($zone["description"])) {
            $sender->sendMessage(TextFormat::GRAY . $zone["description"]);
        }
        if ($restrict > 0) {
            $sender->sendMessage(TextFormat::YELLOW . "Level Req: " . TextFormat::WHITE . $restrict);
        }
        return true;
    }

    private function handleList(Player $sender) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only.");
            return true;
        }

        $sz = $this->plugin->getSeaZone();
        $worldName = $sender->getLevel()->getFolderName();
        $zones = $sz->getAllZones($worldName);

        if (empty($zones)) {
            $sender->sendMessage(TextFormat::YELLOW . "No zones in " . $worldName . " yet.");
            return true;
        }

        $sender->sendMessage(TextFormat::GOLD . "=======================");
        $sender->sendMessage(TextFormat::GOLD . "  Zones in " . $worldName . " (" . count($zones) . ")");
        $sender->sendMessage(TextFormat::GOLD . "=======================");

        foreach ($zones as $id => $zone) {
            $min = $zone["min"];
            $max = $zone["max"];
            $restrict = isset($zone["restrict"]) ? $zone["restrict"] : 0;
            $hasSpawn = isset($zone["spawn"]);

            $extra = "";
            if ($restrict > 0) {
                $extra .= TextFormat::RED . " [Lv." . $restrict . "+]";
            }
            if ($hasSpawn) {
                $extra .= TextFormat::GREEN . " [Spawn Set]";
            }

            $sender->sendMessage(TextFormat::AQUA . $zone["name"] . $extra);
            $sender->sendMessage(TextFormat::GRAY . "  " . $min["x"] . "," . $min["y"] . "," . $min["z"] . " -> " . $max["x"] . "," . $max["y"] . "," . $max["z"]);
            if (!empty($zone["description"])) {
                $sender->sendMessage(TextFormat::GRAY . "  " . $zone["description"]);
            }
        }

        $sender->sendMessage(TextFormat::GOLD . "=======================");
        return true;
    }

    private function handleSetSpawn(Player $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only.");
            return true;
        }

        if (!isset($args[1])) {
            $sender->sendMessage(TextFormat::RED . "Usage: /zone setspawn <zonename>");
            return true;
        }

        $zoneName = $args[1];
        $worldName = $sender->getLevel()->getFolderName();
        $sz = $this->plugin->getSeaZone();

        if (!$sz->zoneExists($zoneName, $worldName)) {
            $sender->sendMessage(TextFormat::RED . "Zone '" . $zoneName . "' not found in " . $worldName . "!");
            return true;
        }

        $x = $sender->getFloorX();
        $y = $sender->getFloorY();
        $z = $sender->getFloorZ();

        $sz->setZoneSpawn($zoneName, $worldName, $x, $y, $z);
        $sender->sendMessage(TextFormat::GREEN . "Spawn set for '" . $zoneName . "' at X=" . $x . " Y=" . $y . " Z=" . $z);
        return true;
    }

    private function handleRestrict(Player $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only.");
            return true;
        }

        if (!isset($args[1]) || !isset($args[2])) {
            $sender->sendMessage(TextFormat::RED . "Usage: /zone restrict <zonename> <level|off>");
            return true;
        }

        $zoneName = $args[1];
        $worldName = $sender->getLevel()->getFolderName();
        $sz = $this->plugin->getSeaZone();

        if (!$sz->zoneExists($zoneName, $worldName)) {
            $sender->sendMessage(TextFormat::RED . "Zone '" . $zoneName . "' not found in " . $worldName . "!");
            return true;
        }

        $value = strtolower($args[2]);

        if ($value === "off") {
            $sz->setZoneRestrict($zoneName, $worldName, 0);
            $sender->sendMessage(TextFormat::GREEN . "Restriction removed for '" . $zoneName . "'");
        } else {
            $level = (int)$value;
            if ($level <= 0) {
                $sender->sendMessage(TextFormat::RED . "Level must be a positive number or 'off'");
                return true;
            }
            $sz->setZoneRestrict($zoneName, $worldName, $level);
            $sender->sendMessage(TextFormat::GREEN . "Zone '" . $zoneName . "' now requires level " . $level);
        }
        return true;
    }

    private function handleSetHome(Player $sender) {
        $sz = $this->plugin->getSeaZone();
        $name = $sender->getName();
        $worldName = $sender->getLevel()->getFolderName();

        $x = $sender->getFloorX();
        $y = $sender->getFloorY();
        $z = $sender->getFloorZ();

        $zoneName = $sz->getZoneNameAt($x, $y, $z, $worldName);

        if ($zoneName === null) {
            $sender->sendMessage(TextFormat::RED . "You must be inside a island to set your home!");
            return true;
        }

        $sz->setHome($name, $x, $y, $z, $zoneName, $worldName);
        $sender->sendMessage(TextFormat::GREEN . "Home set in " . $zoneName . "!");
        return true;
    }

private function handleHome(Player $sender) {
    $combatPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceCombat");
    if ($combatPlugin !== null && $combatPlugin->isEnabled()) {
        $combatTag = $combatPlugin->getCombatTag();
        if ($combatTag !== null && $combatTag->isTagged($sender)) {
            $remaining = round($combatTag->getRemainingTime($sender), 1);
            $sender->sendMessage(TextFormat::RED . "✖ You cannot use home in combat! (" . $remaining . "s remaining)");
            return true;
        }
    }
    $sz = $this->plugin->getSeaZone();
    $name = $sender->getName();

    $home = $sz->getHome($name);

    if ($home === null) {
        $sender->sendMessage(TextFormat::RED . "You don't have a home set!");
        return true;
    }

    $homeWorld = isset($home["world"]) ? $home["world"] : "OP";
    $currentWorld = $sender->getLevel()->getFolderName();

    if ($homeWorld !== $currentWorld) {
        $fallbackKey = isset($this->fallbackZone[$currentWorld]) ? $this->fallbackZone[$currentWorld] : null;

        if ($fallbackKey === null) {
            $sender->sendMessage(TextFormat::RED . "Your home is in another world and no fallback is defined!");
            return true;
        }

        $fallbackZone = $sz->getZoneByName($fallbackKey, $currentWorld);

        if ($fallbackZone === null) {
            $sender->sendMessage(TextFormat::RED . "Your home is in another sea. Fallback zone not found!");
            return true;
        }

        $level = $this->plugin->getServer()->getLevelByName($currentWorld);
        if ($level === null) {
            $sender->sendMessage(TextFormat::RED . "Could not find your current world.");
            return true;
        }

        $spawnPos = $sz->getZoneSpawn($fallbackZone);
        $safeY = $this->findSafeY($level, $spawnPos->x, $spawnPos->y, $spawnPos->z);

        $sender->teleport(new \pocketmine\math\Vector3($spawnPos->x, $safeY, $spawnPos->z));

        $sender->sendMessage(TextFormat::YELLOW . "Your home is set in " . $homeWorld . ".");
        $sender->sendMessage(TextFormat::GREEN . "Teleported to " . $fallbackZone["name"] . " instead.");
        return true;
    }

    $server = $this->plugin->getServer();

    if (!$server->isLevelLoaded($homeWorld)) {
        if (!$server->loadLevel($homeWorld)) {
            $sender->sendMessage(TextFormat::RED . "Could not load world '" . $homeWorld . "'!");
            return true;
        }
    }

    $level = $server->getLevelByName($homeWorld);
    if ($level === null) {
        $sender->sendMessage(TextFormat::RED . "World '" . $homeWorld . "' not found!");
        return true;
    }

    $safeY = $this->findSafeY($level, $home["x"], $home["y"], $home["z"]);
    $sender->teleport(new \pocketmine\math\Vector3($home["x"], $safeY, $home["z"]));
    $sender->sendMessage(TextFormat::GREEN . "Teleported to your home in " . $home["zone"]);
    return true;
}

    private function handleTeleport(Player $sender) {
        $sz = $this->plugin->getSeaZone();
        $name = $sender->getName();
        $server = $this->plugin->getServer();

        $lastWorld = $sz->getLastWorld($name);
$worldName = "OP";

if ($lastWorld === "Sea2") {
    $worldName = "Sea2";
} elseif ($lastWorld === "sea3") {
    $worldName = "sea3";
}

if ($worldName === "Sea2") {
    $server->dispatchCommand($sender, "stp sea2");
} elseif ($worldName === "sea3") {
    $server->dispatchCommand($sender, "stp sea3");
} else {
    $server->dispatchCommand($sender, "stp op");
}

        $zone = $sz->getSpawnZone($name, $worldName);

        if ($zone === null) {
            $sender->sendMessage(TextFormat::RED . "No zones have been created in " . $worldName . " yet!");
            return true;
        }

        if (!$server->isLevelLoaded($worldName)) {
            if (!$server->loadLevel($worldName)) {
                $sender->sendMessage(TextFormat::RED . "Failed to load world '" . $worldName . "'!");
                return true;
            }
        }

        $level = $server->getLevelByName($worldName);
        if ($level === null) {
            $sender->sendMessage(TextFormat::RED . "World '" . $worldName . "' not found!");
            return true;
        }

        $spawnPos = $sz->getZoneSpawn($zone);
        $safeY = $this->findSafeY($level, $spawnPos->x, $spawnPos->y, $spawnPos->z);

        $sender->teleport(new \pocketmine\math\Vector3($spawnPos->x, $safeY, $spawnPos->z));

        $sender->sendMessage(TextFormat::AQUA . "=======================");
        $sender->sendMessage(TextFormat::AQUA . "  Welcome to: " . TextFormat::WHITE . $zone["name"]);
        $sender->sendMessage(TextFormat::AQUA . "=======================");
        if (!empty($zone["description"])) {
            $sender->sendMessage(TextFormat::GRAY . $zone["description"]);
        }

        $sender->setGamemode(0);
        $sender->setAllowFlight(false);
        $sender->setGamemode(2);
        $sender->addEffect(Effect::getEffect(10)->setDuration(60)->setAmplifier(255)->setVisible(false));
        $this->applyGodStrength($sender);

        return true;
    }

    private function handleTpToZone(Player $sender, array $args) {
        if (!isset($args[1])) {
            $sender->sendMessage(TextFormat::RED . "Usage: /zone tp <n>");
            return true;
        }

        $zoneName = $args[1];
        $worldName = $sender->getLevel()->getFolderName();
        $sz = $this->plugin->getSeaZone();

        $zone = $sz->getZoneByName($zoneName, $worldName);
        if ($zone === null) {
            $sender->sendMessage(TextFormat::RED . "Zone '" . $zoneName . "' not found in " . $worldName . "!");
            return true;
        }

        $restrict = $sz->getZoneRestrict($zoneName, $worldName);
        if ($restrict > 0 && !$sender->isOp()) {
            $playerLevel = $this->getPlayerLevel($sender);
            if ($playerLevel < $restrict) {
                $sender->sendMessage(TextFormat::RED . "You need to be level " . $restrict . " to go here!");
                return true;
            }
        }

        $server = $this->plugin->getServer();

        if (!$server->isLevelLoaded($worldName)) {
            if (!$server->loadLevel($worldName)) {
                $sender->sendMessage(TextFormat::RED . "Failed to load world '" . $worldName . "'!");
                return true;
            }
        }

        $level = $server->getLevelByName($worldName);
        if ($level === null) {
            $sender->sendMessage(TextFormat::RED . "World '" . $worldName . "' not found!");
            return true;
        }

        $spawnPos = $sz->getZoneSpawn($zone);
        $safeY = $this->findSafeY($level, $spawnPos->x, $spawnPos->y, $spawnPos->z);

        $sender->teleport(new \pocketmine\math\Vector3($spawnPos->x, $safeY, $spawnPos->z));
        $sender->sendMessage(TextFormat::GREEN . "Teleported to: " . $zone["name"]);
        return true;
    }

    private function findSafeY($level, $x, $startY, $z) {
        $floorX = (int)floor($x);
        $floorZ = (int)floor($z);

        for ($y = (int)$startY; $y > 0; $y--) {
            $block      = $level->getBlock(new \pocketmine\math\Vector3($floorX, $y - 1, $floorZ));
            $blockAt    = $level->getBlock(new \pocketmine\math\Vector3($floorX, $y, $floorZ));
            $blockAbove = $level->getBlock(new \pocketmine\math\Vector3($floorX, $y + 1, $floorZ));
            if ($block->isSolid() && !$blockAt->isSolid() && !$blockAbove->isSolid()) {
                return $y;
            }
        }

        for ($y = (int)$startY; $y < 128; $y++) {
            $block      = $level->getBlock(new \pocketmine\math\Vector3($floorX, $y - 1, $floorZ));
            $blockAt    = $level->getBlock(new \pocketmine\math\Vector3($floorX, $y, $floorZ));
            $blockAbove = $level->getBlock(new \pocketmine\math\Vector3($floorX, $y + 1, $floorZ));
            if ($block->isSolid() && !$blockAt->isSolid() && !$blockAbove->isSolid()) {
                return $y;
            }
        }

        return $startY;
    }

    private function showHelp(Player $sender) {
        $sender->sendMessage(TextFormat::GOLD . "=======================");
        $sender->sendMessage(TextFormat::GOLD . "  Zone Commands");
        $sender->sendMessage(TextFormat::GOLD . "=======================");
        $sender->sendMessage(TextFormat::YELLOW . "/zone sethome" . TextFormat::GRAY . " - Set home at current location");
        $sender->sendMessage(TextFormat::YELLOW . "/zone home" . TextFormat::GRAY . " - Teleport to your home");
        if ($sender->isOp()) {
            $sender->sendMessage(TextFormat::YELLOW . "/zone pos1" . TextFormat::GRAY . " - Set position 1");
            $sender->sendMessage(TextFormat::YELLOW . "/zone pos2" . TextFormat::GRAY . " - Set position 2");
            $sender->sendMessage(TextFormat::YELLOW . "/zone create <n> <desc>" . TextFormat::GRAY . " - Create zone in current world");
            $sender->sendMessage(TextFormat::YELLOW . "/zone remove <n>" . TextFormat::GRAY . " - Remove zone in current world");
            $sender->sendMessage(TextFormat::YELLOW . "/zone list" . TextFormat::GRAY . " - List zones in current world");
            $sender->sendMessage(TextFormat::YELLOW . "/zone info" . TextFormat::GRAY . " - Current zone info");
            $sender->sendMessage(TextFormat::YELLOW . "/zone tp <n>" . TextFormat::GRAY . " - TP to zone in current world");
            $sender->sendMessage(TextFormat::YELLOW . "/zone setspawn <n>" . TextFormat::GRAY . " - Set zone spawn");
            $sender->sendMessage(TextFormat::YELLOW . "/zone restrict <n> <level|off>" . TextFormat::GRAY . " - Set level req");
            $sender->sendMessage(TextFormat::YELLOW . "/zone god add <player>" . TextFormat::GRAY . " - Give Strength I on /zone op");
            $sender->sendMessage(TextFormat::YELLOW . "/zone god remove <player>" . TextFormat::GRAY . " - Remove Strength I access");
            $sender->sendMessage(TextFormat::YELLOW . "/zone god list" . TextFormat::GRAY . " - List god players");
        }
        $sender->sendMessage(TextFormat::GOLD . "=======================");
        return true;
    }

private function handleGod(Player $sender, array $args) {
    if (!$sender->isOp()) {
        $sender->sendMessage(TextFormat::RED . "OP only.");
        return true;
    }

    if (!isset($args[1])) {
        $sender->sendMessage(TextFormat::GOLD . "=== God Strength Commands ===");
        $sender->sendMessage(TextFormat::YELLOW . "/zone god add <player>" . TextFormat::GRAY . " - Add player");
        $sender->sendMessage(TextFormat::YELLOW . "/zone god remove <player>" . TextFormat::GRAY . " - Remove player");
        $sender->sendMessage(TextFormat::YELLOW . "/zone god list" . TextFormat::GRAY . " - List players");
        return true;
    }

    $action = strtolower($args[1]);

    if ($action === "add") {
        if (!isset($args[2])) {
            $sender->sendMessage(TextFormat::RED . "Usage: /zone god add <player>");
            return true;
        }

        $playerName = $args[2];
        $players = $this->godConfig->get("players", []);
        $players[strtolower($playerName)] = $playerName;

        $this->godConfig->set("players", $players);
        $this->godConfig->save();

        $sender->sendMessage(TextFormat::GREEN . "Added " . TextFormat::YELLOW . $playerName . TextFormat::GREEN . " to god strength list.");

        $target = $this->plugin->getServer()->getPlayerExact($playerName);
        if ($target instanceof Player) {
            $this->applyGodStrength($target);
            $target->sendMessage(TextFormat::GOLD . "You now receive great Strength..");
        }

        return true;
    }

    if ($action === "remove" || $action === "delete" || $action === "del") {
        if (!isset($args[2])) {
            $sender->sendMessage(TextFormat::RED . "Usage: /zone god remove <player>");
            return true;
        }

        $playerName = $args[2];
        $players = $this->godConfig->get("players", []);
        $key = strtolower($playerName);

        if (isset($players[$key])) {
            unset($players[$key]);
            $this->godConfig->set("players", $players);
            $this->godConfig->save();
            $sender->sendMessage(TextFormat::GREEN . "Removed " . TextFormat::YELLOW . $playerName . TextFormat::GREEN . " from god strength list.");
        } else {
            $sender->sendMessage(TextFormat::YELLOW . $playerName . " is not in the god strength list.");
        }

        return true;
    }

    if ($action === "list") {
        $players = $this->godConfig->get("players", []);

        if (empty($players)) {
            $sender->sendMessage(TextFormat::YELLOW . "God strength list is empty.");
            return true;
        }

        $sender->sendMessage(TextFormat::GOLD . "God strength players:");
        foreach ($players as $name) {
            $sender->sendMessage(TextFormat::YELLOW . "- " . $name);
        }

        return true;
    }

    $sender->sendMessage(TextFormat::RED . "Usage: /zone god <add|remove|list> [player]");
    return true;
}

private function isGodPlayer(Player $player) {
    $players = $this->godConfig->get("players", []);
    return isset($players[strtolower($player->getName())]);
}

private function applyGodStrength(Player $player) {
    if (!$this->isGodPlayer($player)) {
        return;
    }

    $effect = Effect::getEffect(Effect::STRENGTH);
    if ($effect !== null) {
        $effect->setDuration(20 * 60 * 60); // 1 hour
        $effect->setAmplifier(1); // Strength I
        $effect->setVisible(false);
        $player->addEffect($effect);
    }
}

    private function getPlayerLevel(Player $player) {
        $statsPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceStats");
        if ($statsPlugin === null || !$statsPlugin->isEnabled()) return 1;
        $sm = $statsPlugin->getStatManager();
        $sp = $sm->getStatPlayer($player);
        if ($sp === null) return 1;
        return $sp->getLevel();
    }
}