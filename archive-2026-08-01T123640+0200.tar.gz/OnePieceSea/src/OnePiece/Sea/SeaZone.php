<?php

namespace OnePiece\Sea;

use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat;

class SeaZone {

    private $plugin;
    private $zones = [];
    private $playerZones = [];
    private $playerLastZones = [];
    private $selections = [];
    private $playerDataPath;

    private $worldZoneFiles = [
        "OP"   => "zones_OP.json",
        "Sea2" => "zones_Sea2.json",
        "sea3" => "zones_sea3.json"
    ];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->playerDataPath = $plugin->getDataFolder() . "players/";
        @mkdir($this->playerDataPath);
        $this->loadAllZones();
    }

    private function getZoneFile($worldName) {
        if (isset($this->worldZoneFiles[$worldName])) {
            return $this->plugin->getDataFolder() . $this->worldZoneFiles[$worldName];
        }
        return $this->plugin->getDataFolder() . "zones_" . $worldName . ".json";
    }

    private function loadAllZones() {
        $this->zones = [];
        foreach (array_keys($this->worldZoneFiles) as $worldName) {
            $this->zones[$worldName] = [];
            $file = $this->getZoneFile($worldName);
            if (!file_exists($file)) {
                continue;
            }
            $data = json_decode(file_get_contents($file), true);
            if (is_array($data)) {
                $this->zones[$worldName] = $data;
            }
        }
    }

    public function saveZones() {
        foreach ($this->worldZoneFiles as $worldName => $fileName) {
            $file = $this->plugin->getDataFolder() . $fileName;
            $data = isset($this->zones[$worldName]) ? $this->zones[$worldName] : [];
            file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
        }
    }

    public function saveWorldZones($worldName) {
        $file = $this->getZoneFile($worldName);
        $data = isset($this->zones[$worldName]) ? $this->zones[$worldName] : [];
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
    }

    private function getPlayerFile($name) {
        return $this->playerDataPath . strtolower($name) . ".json";
    }

    public function loadPlayerData($name) {
        $file = $this->getPlayerFile($name);
        if (!file_exists($file)) {
            return null;
        }
        $data = json_decode(file_get_contents($file), true);
        if (is_array($data)) {
            return $data;
        }
        return null;
    }

    public function savePlayerData($name, array $data) {
        $file = $this->getPlayerFile($name);
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
    }

    public function getLastZone($name) {
        $data = $this->loadPlayerData($name);
        if ($data !== null && isset($data["last_zone"])) {
            return $data["last_zone"];
        }
        return null;
    }

    public function setLastZone($name, $zoneName) {
        $data = $this->loadPlayerData($name);
        if ($data === null) {
            $data = [];
        }
        $data["last_zone"] = $zoneName;
        $this->savePlayerData($name, $data);
    }

    public function getLastWorld($name) {
        $data = $this->loadPlayerData($name);
        if ($data !== null && isset($data["last_world"])) {
            return $data["last_world"];
        }
        return null;
    }

    public function setLastWorld($name, $worldName) {
        $data = $this->loadPlayerData($name);
        if ($data === null) {
            $data = [];
        }
        $data["last_world"] = $worldName;
        $this->savePlayerData($name, $data);
    }

    public function getHome($name) {
        $data = $this->loadPlayerData($name);
        if ($data !== null && isset($data["home"])) {
            return $data["home"];
        }
        return null;
    }

    public function setHome($name, $x, $y, $z, $zoneName, $worldName = "OP") {
        $data = $this->loadPlayerData($name);
        if ($data === null) {
            $data = [];
        }
        $data["home"] = [
            "x"     => $x,
            "y"     => $y,
            "z"     => $z,
            "zone"  => $zoneName,
            "world" => $worldName
        ];
        $this->savePlayerData($name, $data);
    }

    public function getZonesForWorld($worldName) {
        return isset($this->zones[$worldName]) ? $this->zones[$worldName] : [];
    }

    public function getFirstZone($worldName = "OP") {
        $zones = $this->getZonesForWorld($worldName);
        if (empty($zones)) {
            return null;
        }
        $keys = array_keys($zones);
        return $zones[$keys[0]];
    }

    public function getZoneCenter($zone) {
        $min = $zone["min"];
        $max = $zone["max"];
        $x = ($min["x"] + $max["x"]) / 2;
        $y = $max["y"];
        $z = ($min["z"] + $max["z"]) / 2;
        return new Vector3($x, $y, $z);
    }

    public function getZoneSpawn($zone) {
        if (isset($zone["spawn"])) {
            return new Vector3($zone["spawn"]["x"], $zone["spawn"]["y"], $zone["spawn"]["z"]);
        }
        return $this->getZoneCenter($zone);
    }

    public function setZoneSpawn($zoneName, $worldName, $x, $y, $z) {
        if (!isset($this->zones[$worldName][$zoneName])) return false;
        $this->zones[$worldName][$zoneName]["spawn"] = [
            "x" => $x,
            "y" => $y,
            "z" => $z
        ];
        $this->saveWorldZones($worldName);
        return true;
    }

    public function setZoneRestrict($zoneName, $worldName, $level) {
        if (!isset($this->zones[$worldName][$zoneName])) return false;
        if ($level <= 0) {
            unset($this->zones[$worldName][$zoneName]["restrict"]);
        } else {
            $this->zones[$worldName][$zoneName]["restrict"] = $level;
        }
        $this->saveWorldZones($worldName);
        return true;
    }

    public function getZoneRestrict($zoneName, $worldName) {
        if (!isset($this->zones[$worldName][$zoneName])) return 0;
        if (!isset($this->zones[$worldName][$zoneName]["restrict"])) return 0;
        return (int)$this->zones[$worldName][$zoneName]["restrict"];
    }

    public function getSpawnZone($name, $worldName = "OP") {
        $lastZoneName = $this->getLastZone($name);

        if ($lastZoneName !== null && isset($this->zones[$worldName][$lastZoneName])) {
            return $this->zones[$worldName][$lastZoneName];
        }

        return $this->getFirstZone($worldName);
    }

    public function setPos1(Player $player) {
        $name = $player->getName();
        $pos = $player->floor();
        $this->selections[$name]["pos1"] = [
            "x" => $pos->x,
            "y" => $pos->y,
            "z" => $pos->z
        ];
        return $this->selections[$name]["pos1"];
    }

    public function setPos2(Player $player) {
        $name = $player->getName();
        $pos = $player->floor();
        $this->selections[$name]["pos2"] = [
            "x" => $pos->x,
            "y" => $pos->y,
            "z" => $pos->z
        ];
        return $this->selections[$name]["pos2"];
    }

    public function hasSelection(Player $player) {
        $name = $player->getName();
        return isset($this->selections[$name]["pos1"]) && isset($this->selections[$name]["pos2"]);
    }

    public function getSelection(Player $player) {
        $name = $player->getName();
        if (!$this->hasSelection($player)) {
            return null;
        }
        return $this->selections[$name];
    }

    public function createZone($zoneName, $description, $pos1, $pos2, $worldName = "OP") {
        $minX = min($pos1["x"], $pos2["x"]);
        $minY = min($pos1["y"], $pos2["y"]);
        $minZ = min($pos1["z"], $pos2["z"]);
        $maxX = max($pos1["x"], $pos2["x"]);
        $maxY = max($pos1["y"], $pos2["y"]);
        $maxZ = max($pos1["z"], $pos2["z"]);

        if (!isset($this->zones[$worldName])) {
            $this->zones[$worldName] = [];
        }

        $this->zones[$worldName][$zoneName] = [
            "name"        => $zoneName,
            "description" => $description,
            "min"         => ["x" => $minX, "y" => $minY, "z" => $minZ],
            "max"         => ["x" => $maxX, "y" => $maxY, "z" => $maxZ]
        ];

        $this->saveWorldZones($worldName);
        return true;
    }

    public function removeZone($zoneName, $worldName) {
        if (!isset($this->zones[$worldName][$zoneName])) {
            return false;
        }
        unset($this->zones[$worldName][$zoneName]);
        $this->saveWorldZones($worldName);
        return true;
    }

    public function getZoneAt($x, $y, $z, $worldName = "OP") {
        $zones = $this->getZonesForWorld($worldName);
        $best = null;
        $bestVolume = PHP_INT_MAX;
        foreach ($zones as $id => $zone) {
            $min = $zone["min"];
            $max = $zone["max"];
            if (
                $x >= $min["x"] && $x <= $max["x"] &&
                $y >= $min["y"] && $y <= $max["y"] &&
                $z >= $min["z"] && $z <= $max["z"]
            ) {
                $volume = ($max["x"] - $min["x"]) * ($max["y"] - $min["y"]) * ($max["z"] - $min["z"]);
                if ($volume < $bestVolume) {
                    $bestVolume = $volume;
                    $best = $zone;
                }
            }
        }
        return $best;
    }

    public function getZoneNameAt($x, $y, $z, $worldName = "OP") {
        $zone = $this->getZoneAt($x, $y, $z, $worldName);
        if ($zone === null) {
            return null;
        }
        return $zone["name"];
    }

    public function getAllZones($worldName = null) {
        if ($worldName !== null) {
            return isset($this->zones[$worldName]) ? $this->zones[$worldName] : [];
        }
        return $this->zones;
    }

    public function zoneExists($zoneName, $worldName) {
        return isset($this->zones[$worldName][$zoneName]);
    }

    public function getZoneByName($zoneName, $worldName) {
        return isset($this->zones[$worldName][$zoneName]) ? $this->zones[$worldName][$zoneName] : null;
    }

    public function getZoneWorldName($zoneName) {
        foreach ($this->zones as $worldName => $zones) {
            if (isset($zones[$zoneName])) {
                return $worldName;
            }
        }
        return null;
    }

    public function checkPlayerZone(Player $player) {
        $name = $player->getName();
        $x = $player->getFloorX();
        $y = $player->getFloorY();
        $z = $player->getFloorZ();
        $worldName = $player->getLevel()->getFolderName();

        $currentZone = $this->getZoneNameAt($x, $y, $z, $worldName);
        $previousZone = isset($this->playerZones[$name]) ? $this->playerZones[$name] : null;

        if ($previousZone !== $currentZone) {
            $this->playerZones[$name] = $currentZone;

            if ($currentZone !== null) {
                $zone = $this->getZoneAt($x, $y, $z, $worldName);
                $zoneKey = $this->getZoneKey($zone["name"], $worldName);
                $this->setLastZone($name, $zoneKey);
                $player->sendTip(TextFormat::WHITE . $zone["name"]);
            } elseif ($previousZone !== null) {
                $player->sendTip(TextFormat::WHITE . "Sea");
            }
        }
    }

    public function getZoneKey($zoneName, $worldName) {
        if (!isset($this->zones[$worldName])) return null;
        foreach ($this->zones[$worldName] as $key => $zone) {
            if ($zone["name"] === $zoneName) {
                return $key;
            }
        }
        return null;
    }

    public function getPlayerZone(Player $player) {
        $name = $player->getName();
        $worldName = $player->getLevel()->getFolderName();
        if (!isset($this->playerZones[$name])) {
            $this->playerZones[$name] = $this->getZoneNameAt(
                $player->getFloorX(),
                $player->getFloorY(),
                $player->getFloorZ(),
                $worldName
            );
        }
        return $this->playerZones[$name];
    }

    public function cleanup(Player $player) {
        $name = $player->getName();
        unset($this->playerZones[$name]);
        unset($this->selections[$name]);
    }
}