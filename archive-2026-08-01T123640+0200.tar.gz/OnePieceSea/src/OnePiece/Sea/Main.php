<?php

namespace OnePiece\Sea;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\entity\EntityLevelChangeEvent;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class Main extends PluginBase implements Listener {

    private $opWorlds = ["OP", "Sea2", "sea3"];

    private $shipManager;
    private $seaZone;

    public function onEnable() {
        $this->getLogger()->info(TextFormat::GREEN . "One Piece Sea System loaded!");

        @mkdir($this->getDataFolder());

        $this->shipManager = new ShipManager($this);
        $this->seaZone = new SeaZone($this);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $map = $this->getServer()->getCommandMap();
        $map->register("onepiece", new SeaCommand($this, "ship", "Ship commands", "/ship help"));
        $map->register("onepiece", new SeaCommand($this, "sea", "Sea zone info", "/sea"));
        $map->register("onepiece", new ZoneCommand($this));

        $this->getServer()->getScheduler()->scheduleRepeatingTask(new SeaTickTask($this), 10);
    }

    public function onDisable() {
        if ($this->shipManager !== null) {
            $this->shipManager->saveAll();
        }
        if ($this->seaZone !== null) {
            $this->seaZone->saveZones();
        }
    }

public function isInOPWorld(Player $player) {
    return in_array($player->getLevel()->getName(), $this->opWorlds);
}
    
    public function getOPWorlds() {
    return $this->opWorlds;
}

    public function getShipManager() {
        return $this->shipManager;
    }

    public function getSeaZone() {
        return $this->seaZone;
    }

    public function onPlayerMove(PlayerMoveEvent $event) {
        $player = $event->getPlayer();
        if (!$this->isInOPWorld($player)) {
            return;
        }
        $this->seaZone->checkPlayerZone($player);
    }

    public function onLevelChange(EntityLevelChangeEvent $event) {
        $entity = $event->getEntity();
        if (!($entity instanceof Player)) return;
        $worldName = $event->getTarget()->getName();
        if (in_array($worldName, $this->opWorlds)) {
            $this->seaZone->setLastWorld($entity->getName(), $worldName);
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $event) {
        $player = $event->getPlayer();

        if ($this->shipManager->hasActiveBoat($player)) {
            $this->shipManager->removeBoat($player);
        }

        $this->seaZone->cleanup($player);
    }
}