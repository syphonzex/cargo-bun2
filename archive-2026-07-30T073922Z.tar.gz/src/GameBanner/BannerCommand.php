<?php

namespace GameBanner;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginIdentifiableCommand;
use pocketmine\Player;

class BannerCommand extends Command implements PluginIdentifiableCommand {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("banner", "Game Banner management", "/banner help");
        $this->setPermission("gamebanner.admin");
        $this->plugin = $plugin;
        $this->setAliases(["gb"]);
    }

    public function getPlugin() { return $this->plugin; }

    public function execute(CommandSender $sender, $label, array $args) {
        if (empty($args)) {
            $this->sendHelp($sender);
            return true;
        }

        $sub = strtolower(array_shift($args));

        switch ($sub) {
            case "create":
                $this->handleCreate($sender, $args);
                break;
            case "remove":
                $this->handleRemove($sender, $args);
                break;
            case "place":
                $this->handlePlace($sender, $args);
                break;
            case "addworld":
                $this->handleAddWorld($sender, $args);
                break;
            case "list":
                $this->handleList($sender);
                break;
            case "info":
                $this->handleInfo($sender, $args);
                break;
            case "refresh":
                $this->handleRefresh($sender, $args);
                break;
            case "vote":
                $this->handleVote($sender, $args);
                break;
            case "help":
            default:
                $this->sendHelp($sender);
                break;
        }
        return true;
    }

    private function sendHelp(CommandSender $sender) {
        $sender->sendMessage("§6§l=== Game Banner ===");
        $sender->sendMessage("§e/banner create <id> <icon.png> <command> <name...>");
        $sender->sendMessage("§e/banner remove <id>");
        $sender->sendMessage("§e/banner place <id> §7- Tap a wall to place");
        $sender->sendMessage("§e/banner addworld <id> <world> §7- Add player count world");
        $sender->sendMessage("§e/banner list");
        $sender->sendMessage("§e/banner info <id>");
        $sender->sendMessage("§e/banner refresh <id|all>");
        $sender->sendMessage("§e/banner vote <id> <up|down> §7- Vote (any player)");
    }

    private function handleCreate(CommandSender $sender, array $args) {
        if (!$this->testPermission($sender)) return;
        if (count($args) < 4) {
            $sender->sendMessage("§cUsage: /banner create <id> <icon.png> <command> <display name...>");
            $sender->sendMessage("§7Example: /banner create granny granny.png granny_enter §cGranny Horror");
            return;
        }

        $id = strtolower($args[0]);
        $icon = $args[1];
        $command = $args[2];
        $displayName = implode(" ", array_slice($args, 3));

        if ($this->plugin->createBanner($id, $icon, $displayName, $command, [])) {
            $sender->sendMessage("§aBanner §e" . $id . " §acreated!");
            $sender->sendMessage("§7Icon: §f" . $icon . " §7Cmd: §f" . $command);
            $sender->sendMessage("§7Place icon in: §fplugins/GameBanner/icons/" . $icon);
            $sender->sendMessage("§7Use /banner addworld " . $id . " <world> to add player count worlds");
            $sender->sendMessage("§7Use /banner place " . $id . " to place it");
        } else {
            $sender->sendMessage("§cBanner §e" . $id . " §calready exists.");
        }
    }

    private function handleRemove(CommandSender $sender, array $args) {
        if (!$this->testPermission($sender)) return;
        if (empty($args)) {
            $sender->sendMessage("§cUsage: /banner remove <id>");
            return;
        }
        if ($this->plugin->removeBanner($args[0])) {
            $sender->sendMessage("§aBanner §e" . $args[0] . " §aremoved.");
        } else {
            $sender->sendMessage("§cBanner not found.");
        }
    }

    private function handlePlace(CommandSender $sender, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cIn-game only.");
            return;
        }
        if (!$this->testPermission($sender)) return;
        if (empty($args)) {
            $sender->sendMessage("§cUsage: /banner place <id>");
            return;
        }

        $id = strtolower($args[0]);
        $banner = $this->plugin->getBanner($id);
        if ($banner === null) {
            $sender->sendMessage("§cBanner not found.");
            return;
        }

        $iconPath = $this->plugin->getDataFolder() . "icons/" . $banner["icon"];
        if (!file_exists($iconPath)) {
            $sender->sendMessage("§cIcon file not found: §f" . $banner["icon"]);
            $sender->sendMessage("§7Place it in: §fplugins/GameBanner/icons/");
            return;
        }

        $this->plugin->placePending[strtolower($sender->getName())] = $id;
        $sender->sendMessage("§aTap a wall to place banner §e" . $id . "§a.");
        $sender->sendMessage("§7Tap on the §fside§7 of a block (not top/bottom).");
    }

    private function handleAddWorld(CommandSender $sender, array $args) {
        if (!$this->testPermission($sender)) return;
        if (count($args) < 2) {
            $sender->sendMessage("§cUsage: /banner addworld <id> <worldName>");
            return;
        }

        $id = strtolower($args[0]);
        $all = $this->plugin->getBanners();
        if (!isset($all[$id])) {
            $sender->sendMessage("§cBanner not found.");
            return;
        }

        if (!is_array($all[$id]["worlds"])) {
            $all[$id]["worlds"] = [];
        }
        if (!in_array($args[1], $all[$id]["worlds"])) {
            $all[$id]["worlds"][] = $args[1];
        }

        $this->plugin->saveBanners($all);

        $sender->sendMessage("§aWorld §e" . $args[1] . " §aadded to §e" . $id . "§a.");
    }

    private function handleList(CommandSender $sender) {
        $banners = $this->plugin->getBanners();
        if (empty($banners)) {
            $sender->sendMessage("§7No banners created.");
            return;
        }

        $sender->sendMessage("§6§l=== Banners ===");
        foreach ($banners as $id => $b) {
            $placed = !empty($b["positions"]) ? "§a[Placed]" : "§c[Not placed]";
            $vd = $this->plugin->getVoteData($id);
            $total = $vd["up"] + $vd["down"];
            $pct = $total > 0 ? (int)round(($vd["up"] / $total) * 100) : 0;
            $pc = $this->plugin->getPlayerCount(isset($b["worlds"]) ? $b["worlds"] : []);
            $sender->sendMessage("§e" . $id . " " . $placed . " §f" . $b["display_name"] . " §7| §a" . $pct . "% §7| §b" . $pc . " playing");
        }
    }

    private function handleInfo(CommandSender $sender, array $args) {
        if (empty($args)) {
            $sender->sendMessage("§cUsage: /banner info <id>");
            return;
        }

        $id = strtolower($args[0]);
        $banner = $this->plugin->getBanner($id);
        if ($banner === null) {
            $sender->sendMessage("§cBanner not found.");
            return;
        }

        $vd = $this->plugin->getVoteData($id);
        $total = $vd["up"] + $vd["down"];
        $pct = $total > 0 ? (int)round(($vd["up"] / $total) * 100) : 0;
        $pc = $this->plugin->getPlayerCount(isset($banner["worlds"]) ? $banner["worlds"] : []);

        $sender->sendMessage("§6§l=== " . $id . " ===");
        $sender->sendMessage("§7Name: §f" . $banner["display_name"]);
        $sender->sendMessage("§7Icon: §f" . $banner["icon"]);
        $sender->sendMessage("§7Command: §f" . $banner["command"]);
        $sender->sendMessage("§7Worlds: §f" . (empty($banner["worlds"]) ? "none" : implode(", ", $banner["worlds"])));
        $sender->sendMessage("§7Votes: §a" . $vd["up"] . " up §7/ §c" . $vd["down"] . " down §7(" . $pct . "%)");
        $sender->sendMessage("§7Players: §b" . $pc);
        $sender->sendMessage("§7Placed: " . (!empty($banner["positions"]) ? "§aYes" : "§cNo"));
    }

    private function handleRefresh(CommandSender $sender, array $args) {
        if (!$this->testPermission($sender)) return;
        if (empty($args)) {
            $sender->sendMessage("§cUsage: /banner refresh <id|all>");
            return;
        }

        if ($args[0] === "all") {
            foreach ($this->plugin->getBanners() as $id => $b) {
                $this->plugin->refreshBanner($id);
            }
            $sender->sendMessage("§aAll banners refreshed.");
        } else {
            $this->plugin->refreshBanner($args[0]);
            $sender->sendMessage("§aBanner §e" . $args[0] . " §arefreshed.");
        }
    }

    private function handleVote(CommandSender $sender, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cIn-game only.");
            return;
        }
        if (count($args) < 2) {
            $sender->sendMessage("§cUsage: /banner vote <id> <up|down>");
            return;
        }

        $id = strtolower($args[0]);
        $type = strtolower($args[1]);
        if ($type !== "up" && $type !== "down") {
            $sender->sendMessage("§cMust be 'up' or 'down'.");
            return;
        }

        if ($this->plugin->getBanner($id) === null) {
            $sender->sendMessage("§cBanner not found.");
            return;
        }

        $result = $this->plugin->vote($id, $sender->getName(), $type);
        if ($result === "removed") {
            $sender->sendMessage("§7Vote removed.");
        } else {
            $sender->sendMessage("§a" . ucfirst($type) . "voted!");
        }

        $this->plugin->refreshBanner($id);
    }
}