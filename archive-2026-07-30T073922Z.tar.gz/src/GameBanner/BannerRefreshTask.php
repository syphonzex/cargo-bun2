<?php

namespace GameBanner;

use pocketmine\scheduler\PluginTask;

class BannerRefreshTask extends PluginTask {

    private $plugin;
    private $lastState = [];

    public function __construct(Main $plugin) {
        parent::__construct($plugin);
        $this->plugin = $plugin;
    }

    public function onRun($currentTick) {
        $banners = $this->plugin->getBanners();
        if (empty($banners)) return;
        if (count($this->plugin->getServer()->getOnlinePlayers()) === 0) return;

        foreach ($banners as $name => $banner) {
            if (empty($banner["positions"]) || empty($banner["map_ids"])) continue;

            $playerCount = $this->plugin->getPlayerCount(isset($banner["worlds"]) ? $banner["worlds"] : []);
            $voteData = $this->plugin->getVoteData($name);

            $stateKey = $playerCount . ":" . $voteData["up"] . ":" . $voteData["down"];

            if (isset($this->lastState[$name]) && $this->lastState[$name] === $stateKey) continue;

            $this->lastState[$name] = $stateKey;
            $this->plugin->refreshBanner($name);
        }
    }
}