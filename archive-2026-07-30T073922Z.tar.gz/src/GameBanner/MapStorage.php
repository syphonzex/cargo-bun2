<?php

namespace GameBanner;

class MapStorage {

    private static $instance = null;
    private $mapCache = [];
    private $baseId = 90000;

    public static function init() {
        self::$instance = new MapStorage();
    }

    public static function get() {
        return self::$instance;
    }

    public function setMapData($mapId, $rawBytes) {
        $this->mapCache[$mapId] = $rawBytes;
    }

    public function getMapData($mapId) {
        return isset($this->mapCache[$mapId]) ? $this->mapCache[$mapId] : null;
    }

    public function clearMap($mapId) {
        unset($this->mapCache[$mapId]);
    }

    public function getMapIdsForSlot($slotIndex) {
        $ids = [];
        $start = $this->baseId + ($slotIndex * 9);
        for ($i = 0; $i < 9; $i++) {
            $ids[] = $start + $i;
        }
        return $ids;
    }
}