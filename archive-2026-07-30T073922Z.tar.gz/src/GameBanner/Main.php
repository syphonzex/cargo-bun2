<?php

namespace GameBanner;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\utils\Config;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\tile\ItemFrame as ItemFrameTile;
use pocketmine\tile\Tile;
use pocketmine\block\Block;
use pocketmine\block\ItemFrame as ItemFrameBlock;

class Main extends PluginBase implements Listener {

    private $banners;
    private $votes;
    public $placePending = [];
    private $refreshTask = null;

    private $pixelFont = [
        "A" => ["01110","10001","10001","11111","10001","10001","10001"],
        "B" => ["11110","10001","10001","11110","10001","10001","11110"],
        "C" => ["01110","10001","10000","10000","10000","10001","01110"],
        "D" => ["11110","10001","10001","10001","10001","10001","11110"],
        "E" => ["11111","10000","10000","11110","10000","10000","11111"],
        "F" => ["11111","10000","10000","11110","10000","10000","10000"],
        "G" => ["01110","10001","10000","10111","10001","10001","01110"],
        "H" => ["10001","10001","10001","11111","10001","10001","10001"],
        "I" => ["11111","00100","00100","00100","00100","00100","11111"],
        "J" => ["00111","00010","00010","00010","00010","10010","01100"],
        "K" => ["10001","10010","10100","11000","10100","10010","10001"],
        "L" => ["10000","10000","10000","10000","10000","10000","11111"],
        "M" => ["10001","11011","10101","10101","10001","10001","10001"],
        "N" => ["10001","11001","10101","10011","10001","10001","10001"],
        "O" => ["01110","10001","10001","10001","10001","10001","01110"],
        "P" => ["11110","10001","10001","11110","10000","10000","10000"],
        "Q" => ["01110","10001","10001","10001","10101","10010","01101"],
        "R" => ["11110","10001","10001","11110","10100","10010","10001"],
        "S" => ["01110","10001","10000","01110","00001","10001","01110"],
        "T" => ["11111","00100","00100","00100","00100","00100","00100"],
        "U" => ["10001","10001","10001","10001","10001","10001","01110"],
        "V" => ["10001","10001","10001","10001","01010","01010","00100"],
        "W" => ["10001","10001","10001","10101","10101","11011","10001"],
        "X" => ["10001","10001","01010","00100","01010","10001","10001"],
        "Y" => ["10001","10001","01010","00100","00100","00100","00100"],
        "Z" => ["11111","00001","00010","00100","01000","10000","11111"],
        "0" => ["01110","10001","10011","10101","11001","10001","01110"],
        "1" => ["00100","01100","00100","00100","00100","00100","01110"],
        "2" => ["01110","10001","00001","00010","00100","01000","11111"],
        "3" => ["01110","10001","00001","00110","00001","10001","01110"],
        "4" => ["00010","00110","01010","10010","11111","00010","00010"],
        "5" => ["11111","10000","11110","00001","00001","10001","01110"],
        "6" => ["01110","10001","10000","11110","10001","10001","01110"],
        "7" => ["11111","00001","00010","00100","01000","01000","01000"],
        "8" => ["01110","10001","10001","01110","10001","10001","01110"],
        "9" => ["01110","10001","10001","01111","00001","10001","01110"],
        ":" => ["00000","00100","00100","00000","00100","00100","00000"],
        "!" => ["00100","00100","00100","00100","00100","00000","00100"],
        "%" => ["11001","11010","00010","00100","01000","01011","10011"],
        " " => ["00000","00000","00000","00000","00000","00000","00000"],
        "." => ["00000","00000","00000","00000","00000","00000","00100"],
        "," => ["00000","00000","00000","00000","00000","00100","01000"],
        "-" => ["00000","00000","00000","11111","00000","00000","00000"],
        "_" => ["00000","00000","00000","00000","00000","00000","11111"],
        "+" => ["00000","00100","00100","11111","00100","00100","00000"],
        "[" => ["01110","01000","01000","01000","01000","01000","01110"],
        "]" => ["01110","00010","00010","00010","00010","00010","01110"],
        "(" => ["00110","01000","01000","01000","01000","01000","00110"],
        ")" => ["01100","00010","00010","00010","00010","00010","01100"],
        "/" => ["00001","00010","00010","00100","01000","01000","10000"],
        "?" => ["01110","10001","00001","00110","00100","00000","00100"],
        "'" => ["00100","00100","01000","00000","00000","00000","00000"],
    ];

    public function onEnable() {
        if (!extension_loaded("gd")) {
            $this->getLogger()->critical("GD extension is required!");
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        @mkdir($this->getDataFolder());
        @mkdir($this->getDataFolder() . "icons/");

        MapStorage::init();

        $this->banners = new Config($this->getDataFolder() . "banners.yml", Config::YAML, []);
        $this->votes = new Config($this->getDataFolder() . "votes.yml", Config::YAML, []);

        $this->rebuildAllMaps();

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getServer()->getCommandMap()->register("gamebanner", new BannerCommand($this));

        $this->refreshTask = new BannerRefreshTask($this);
        $this->getServer()->getScheduler()->scheduleRepeatingTask($this->refreshTask, 100);

        $this->getLogger()->info("GameBanner enabled!");
    }

    public function onDisable() {
        if ($this->refreshTask !== null) {
            $this->getServer()->getScheduler()->cancelTask($this->refreshTask->getTaskId());
            $this->refreshTask = null;
        }
    }

    private function rebuildAllMaps() {
        $all = $this->banners->getAll();

        foreach ($all as $name => $banner) {
            if (empty($banner["positions"])) continue;
            if (!isset($banner["map_ids"]) || count($banner["map_ids"]) !== 9) continue;

            $mapIds = $banner["map_ids"];

            $topTiles = $this->renderTopSection($name, $banner);
            $bottomTiles = $this->renderBottomRow($name, $banner);

            if ($topTiles === null || $bottomTiles === null) continue;

            for ($i = 0; $i < 6; $i++) {
                MapStorage::get()->setMapData($mapIds[$i], $topTiles[$i]);
            }
            for ($i = 0; $i < 3; $i++) {
                MapStorage::get()->setMapData($mapIds[6 + $i], $bottomTiles[$i]);
            }
        }
    }

    private function getNextSlot() {
        $all = $this->banners->getAll();
        $usedSlots = [];
        foreach ($all as $name => $banner) {
            if (isset($banner["slot"])) {
                $usedSlots[] = (int)$banner["slot"];
            }
        }
        if (empty($usedSlots)) return 0;
        sort($usedSlots);
        for ($i = 0; $i <= count($usedSlots); $i++) {
            if (!in_array($i, $usedSlots)) return $i;
        }
        return count($usedSlots);
    }

    public function createBanner($name, $iconFile, $displayName, $command, $worlds) {
        $all = $this->banners->getAll();
        if (isset($all[$name])) return false;
        $all[$name] = [
            "icon" => $iconFile,
            "display_name" => $displayName,
            "command" => $command,
            "worlds" => $worlds,
            "positions" => [],
            "map_ids" => [],
            "slot" => $this->getNextSlot()
        ];
        $this->banners->setAll($all);
        $this->banners->save();
        return true;
    }

    public function removeBanner($name) {
        $all = $this->banners->getAll();
        if (!isset($all[$name])) return false;
        $this->clearFrames($name);

        if (isset($all[$name]["map_ids"])) {
            foreach ($all[$name]["map_ids"] as $mapId) {
                MapStorage::get()->clearMap($mapId);
            }
        }

        unset($all[$name]);
        $this->banners->setAll($all);
        $this->banners->save();

        $votes = $this->votes->getAll();
        unset($votes[$name]);
        $this->votes->setAll($votes);
        $this->votes->save();
        return true;
    }

    public function getBanner($name) {
        $all = $this->banners->getAll();
        return isset($all[$name]) ? $all[$name] : null;
    }

    public function getBanners() {
        return $this->banners->getAll();
    }

    public function saveBanners($all) {
        $this->banners->setAll($all);
        $this->banners->save();
    }

    public function placeBanner($name, Player $player, $block, $face) {
        $banner = $this->getBanner($name);
        if ($banner === null) return false;

        $iconPath = $this->getDataFolder() . "icons/" . $banner["icon"];
        if (!file_exists($iconPath)) return false;

        $slot = isset($banner["slot"]) ? $banner["slot"] : $this->getNextSlot();
        $mapIds = MapStorage::get()->getMapIdsForSlot($slot);

        $topTiles = $this->renderTopSection($name, $banner);
        if ($topTiles === null) return false;
        $bottomTiles = $this->renderBottomRow($name, $banner);

        for ($i = 0; $i < 6; $i++) {
            MapStorage::get()->setMapData($mapIds[$i], $topTiles[$i]);
        }
        for ($i = 0; $i < 3; $i++) {
            MapStorage::get()->setMapData($mapIds[6 + $i], $bottomTiles[$i]);
        }

        $level = $player->getLevel();
        $worldName = $level->getFolderName();

        $sideBlock = $block->getSide($face);

        $faceMeta = [2 => 3, 3 => 2, 4 => 1, 5 => 0];
        $frameFace = isset($faceMeta[$face]) ? $faceMeta[$face] : 3;

        $ox = (int)$sideBlock->x;
        $oy = (int)$sideBlock->y;
        $oz = (int)$sideBlock->z;

        $positions = [];

        for ($row = 0; $row < 3; $row++) {
            for ($col = 0; $col < 3; $col++) {
                $fp = $this->getFramePos($ox, $oy, $oz, $face, $row, $col);
                $fx = (int)$fp->x;
                $fy = (int)$fp->y;
                $fz = (int)$fp->z;

                $existing = $level->getBlock(new Vector3($fx, $fy, $fz));
                if ($existing->getId() !== Block::AIR && $existing->getId() !== Block::ITEM_FRAME_BLOCK) {
                    $player->sendMessage("§cBlocked at $fx, $fy, $fz - clear the area first.");
                    return false;
                }
            }
        }

        for ($row = 0; $row < 3; $row++) {
            for ($col = 0; $col < 3; $col++) {
                $fp = $this->getFramePos($ox, $oy, $oz, $face, $row, $col);
                $fx = (int)$fp->x;
                $fy = (int)$fp->y;
                $fz = (int)$fp->z;

                $level->setBlock(new Vector3($fx, $fy, $fz), new ItemFrameBlock($frameFace), true, true);

                $nbt = new CompoundTag("", [
                    new StringTag("id", Tile::ITEM_FRAME),
                    new IntTag("x", $fx),
                    new IntTag("y", $fy),
                    new IntTag("z", $fz),
                    new ByteTag("ItemRotation", 0),
                    new FloatTag("ItemDropChance", 0.0)
                ]);

                $chunk = $level->getChunk($fx >> 4, $fz >> 4);
                if ($chunk === null) continue;

                $tile = Tile::createTile(
                    Tile::ITEM_FRAME,
                    $chunk,
                    $nbt
                );

                $tileIndex = $row * 3 + $col;
                $mapId = $mapIds[$tileIndex];

                $item = Item::get(Item::FILLED_MAP, 0, 1);
                $item->setCustomName("§r§8Banner");
                $item->setNamedTag(new CompoundTag("", [
                    new StringTag("map_uuid", (string)$mapId),
                    new ByteTag("locked_image", 1),
                    new StringTag("banner_id", $name)
                ]));

                if ($tile instanceof ItemFrameTile) {
                    $tile->setItem($item);
                    $tile->spawnToAll();
                }

                $positions[] = [
                    "x" => $fx, "y" => $fy, "z" => $fz,
                    "world" => $worldName, "face" => $frameFace,
                    "tile" => $tileIndex
                ];
            }
        }

        $all = $this->banners->getAll();
        $all[$name]["positions"] = $positions;
        $all[$name]["map_ids"] = $mapIds;
        $all[$name]["slot"] = $slot;
        $this->banners->setAll($all);
        $this->banners->save();

        $this->sendMaps($mapIds);

        return true;
    }

    private function sendMaps($mapIds, $player = null) {
        foreach ($mapIds as $mapId) {
            $rawImage = MapStorage::get()->getMapData($mapId);
            if ($rawImage === null) continue;
            $pk = new BannerMapPacket();
            $pk->colors = $rawImage;
            $pk->mapId = $mapId;
            if ($player !== null) {
                $player->dataPacket($pk);
            } else {
                foreach ($this->getServer()->getOnlinePlayers() as $p) {
                    $p->dataPacket($pk);
                }
            }
        }
    }

    private function clearFrames($name) {
        $banner = $this->getBanner($name);
        if ($banner === null || empty($banner["positions"])) return;

        foreach ($banner["positions"] as $pos) {
            $level = $this->getServer()->getLevelByName($pos["world"]);
            if ($level === null) continue;
            $level->setBlock(new Vector3($pos["x"], $pos["y"], $pos["z"]), Block::get(Block::AIR), true, true);
        }
    }

    private function getFramePos($ox, $oy, $oz, $face, $row, $col) {
        $y = $oy + (2 - $row);
        switch ($face) {
            case 2:
                return new Vector3($ox + (1 - $col), $y, $oz);
            case 3:
                return new Vector3($ox - (1 - $col), $y, $oz);
            case 4:
                return new Vector3($ox, $y, $oz - (1 - $col));
            case 5:
                return new Vector3($ox, $y, $oz + (1 - $col));
        }
        return new Vector3($ox + $col, $y, $oz);
    }

    private function drawScaledText($canvas, $text, $x, $y, $scale, $r, $g, $b) {
        $color = imagecolorallocate($canvas, $r, $g, $b);
        $shadow = imagecolorallocate($canvas, (int)($r * 0.25), (int)($g * 0.25), (int)($b * 0.25));
        $text = strtoupper($text);
        $curX = $x;

        for ($i = 0; $i < strlen($text); $i++) {
            $ch = $text[$i];
            if (!isset($this->pixelFont[$ch])) {
                $curX += 4 * $scale;
                continue;
            }
            $glyph = $this->pixelFont[$ch];
            $glyphW = strlen($glyph[0]);
            for ($gy = 0; $gy < 7; $gy++) {
                $row = $glyph[$gy];
                for ($gx = 0; $gx < $glyphW; $gx++) {
                    if ($row[$gx] === "1") {
                        $px = $curX + $gx * $scale;
                        $py = $y + $gy * $scale;
                        imagefilledrectangle($canvas, $px + $scale, $py + $scale, $px + $scale + $scale - 1, $py + $scale + $scale - 1, $shadow);
                        imagefilledrectangle($canvas, $px, $py, $px + $scale - 1, $py + $scale - 1, $color);
                    }
                }
            }
            $curX += ($glyphW + 1) * $scale;
        }

        return $curX - $x;
    }

    private function measureText($text, $scale) {
        $text = strtoupper($text);
        $width = 0;
        for ($i = 0; $i < strlen($text); $i++) {
            $ch = $text[$i];
            if (!isset($this->pixelFont[$ch])) {
                $width += 4 * $scale;
                continue;
            }
            $glyphW = strlen($this->pixelFont[$ch][0]);
            $width += ($glyphW + 1) * $scale;
        }
        if ($width > 0) $width -= $scale;
        return $width;
    }

    private function drawThumbsUp($canvas, $cx, $cy, $size, $r, $g, $b) {
        $color = imagecolorallocate($canvas, $r, $g, $b);
        $dark = imagecolorallocate($canvas, (int)($r * 0.6), (int)($g * 0.6), (int)($b * 0.6));
        $s = $size;

        imagefilledrectangle($canvas, $cx - $s * 2, $cy - $s, $cx - $s, $cy + $s * 3, $color);
        imagefilledrectangle($canvas, $cx - $s, $cy, $cx + $s * 3, $cy + $s * 3, $color);
        imagefilledrectangle($canvas, $cx, $cy - $s * 3, $cx + $s, $cy, $color);
        imagefilledrectangle($canvas, $cx - $s, $cy + $s * 3, $cx + $s * 3, $cy + $s * 3 + $s, $dark);
    }

    private function drawThumbsDown($canvas, $cx, $cy, $size, $r, $g, $b) {
        $color = imagecolorallocate($canvas, $r, $g, $b);
        $dark = imagecolorallocate($canvas, (int)($r * 0.6), (int)($g * 0.6), (int)($b * 0.6));
        $s = $size;

        imagefilledrectangle($canvas, $cx + $s, $cy - $s * 3, $cx + $s * 3, $cy + $s, $color);
        imagefilledrectangle($canvas, $cx - $s * 3, $cy - $s * 3, $cx + $s, $cy, $color);
        imagefilledrectangle($canvas, $cx, $cy, $cx + $s, $cy + $s * 3, $color);
        imagefilledrectangle($canvas, $cx - $s * 3, $cy - $s * 3 - $s, $cx + $s, $cy - $s * 3, $dark);
    }

    private function extractTileRaw($canvas, $col, $row) {
        $raw = "";
        $startX = $col * 128;
        $startY = $row * 128;
        for ($py = 0; $py < 128; $py++) {
            for ($px = 0; $px < 128; $px++) {
                $rgba = imagecolorat($canvas, $startX + $px, $startY + $py);
                $r = ($rgba >> 16) & 0xFF;
                $g = ($rgba >> 8) & 0xFF;
                $b = $rgba & 0xFF;
                $raw .= chr($r) . chr($g) . chr($b) . chr(255);
            }
        }
        return $raw;
    }

    private function renderTopSection($name, $banner) {
        $iconPath = $this->getDataFolder() . "icons/" . $banner["icon"];
        $info = @getimagesize($iconPath);
        if ($info === false) return null;

        $mime = $info["mime"];
        if ($mime === "image/png") {
            $img = @imagecreatefrompng($iconPath);
        } elseif ($mime === "image/jpeg") {
            $img = @imagecreatefromjpeg($iconPath);
        } elseif ($mime === "image/gif") {
            $img = @imagecreatefromgif($iconPath);
        } else {
            $img = @imagecreatefrompng($iconPath);
        }
        if ($img === false) return null;
        imagesavealpha($img, true);

        $canvas = imagecreatetruecolor(384, 256);
        imagesavealpha($canvas, true);
        $bgColor = imagecolorallocate($canvas, 25, 25, 30);
        imagefill($canvas, 0, 0, $bgColor);

        $borderColor = imagecolorallocate($canvas, 60, 60, 70);
        imageline($canvas, 0, 0, 383, 0, $borderColor);
        imageline($canvas, 0, 1, 383, 1, $borderColor);
        imageline($canvas, 0, 0, 0, 255, $borderColor);
        imageline($canvas, 1, 0, 1, 255, $borderColor);
        imageline($canvas, 383, 0, 383, 255, $borderColor);
        imageline($canvas, 382, 0, 382, 255, $borderColor);

        $iconW = imagesx($img);
        $iconH = imagesy($img);
        $imgAreaH = 250;
        $ratio = min(360 / $iconW, $imgAreaH / $iconH);
        $newW = (int)($iconW * $ratio);
        $newH = (int)($iconH * $ratio);
        $offsetX = (int)((384 - $newW) / 2);
        $offsetY = 10 + (int)(($imgAreaH - $newH) / 2);
        imagecopyresampled($canvas, $img, $offsetX, $offsetY, 0, 0, $newW, $newH, $iconW, $iconH);
        imagedestroy($img);

        $tiles = [];
        for ($r = 0; $r < 2; $r++) {
            for ($c = 0; $c < 3; $c++) {
                $tiles[] = $this->extractTileRaw($canvas, $c, $r);
            }
        }

        imagedestroy($canvas);
        return $tiles;
    }

    private function renderBottomRow($name, $banner) {
        $canvas = imagecreatetruecolor(384, 128);
        imagesavealpha($canvas, true);
        $bgColor = imagecolorallocate($canvas, 25, 25, 30);
        imagefill($canvas, 0, 0, $bgColor);

        $borderColor = imagecolorallocate($canvas, 60, 60, 70);
        $dividerColor = imagecolorallocate($canvas, 80, 80, 90);

        imagefilledrectangle($canvas, 4, 4, 379, 6, $dividerColor);

        $displayName = isset($banner["display_name"]) ? $banner["display_name"] : $name;
        $titleScale = 3;
        $titleW = $this->measureText($displayName, $titleScale);
        while ($titleW > 370 && $titleScale > 2) {
            $titleScale--;
            $titleW = $this->measureText($displayName, $titleScale);
        }
        $titleX = (int)((384 - $titleW) / 2);
        $this->drawScaledText($canvas, $displayName, $titleX, 14, $titleScale, 255, 255, 255);

        $bottomY = 50;
        imagefilledrectangle($canvas, 4, $bottomY - 4, 379, $bottomY - 3, $dividerColor);

        $voteData = $this->getVoteData($name);
        $playerCount = $this->getPlayerCount(isset($banner["worlds"]) ? $banner["worlds"] : []);
        $upCount = $voteData["up"];
        $downCount = $voteData["down"];
        $totalVotes = $upCount + $downCount;
        $pct = $totalVotes > 0 ? (int)round(($upCount / $totalVotes) * 100) : 0;

        $panelH = 128 - $bottomY;
        $thirdW = (int)(384 / 3);

        $upBg = imagecolorallocate($canvas, 30, 50, 30);
        imagefilledrectangle($canvas, 2, $bottomY, $thirdW - 1, 125, $upBg);
        $this->drawThumbsUp($canvas, 30, $bottomY + (int)($panelH / 2) - 6, 4, 80, 220, 80);
        $this->drawScaledText($canvas, (string)$upCount, 66, $bottomY + (int)($panelH / 2) - 10, 3, 100, 255, 100);
        $pctText = $pct . "%";
        $pctW = $this->measureText($pctText, 2);
        $pctX = (int)(($thirdW - $pctW) / 2);
        $this->drawScaledText($canvas, $pctText, $pctX, 125 - 18, 2, 100, 255, 100);

        $midBg = imagecolorallocate($canvas, 30, 30, 45);
        imagefilledrectangle($canvas, $thirdW, $bottomY, $thirdW * 2 - 1, 125, $midBg);
        $playerIcon = imagecolorallocate($canvas, 100, 180, 255);
        $headCx = $thirdW + (int)($thirdW / 2);
        $headCy = $bottomY + 12;
        imagefilledrectangle($canvas, $headCx - 6, $headCy - 6, $headCx + 6, $headCy + 6, $playerIcon);
        imagefilledrectangle($canvas, $headCx - 10, $headCy + 8, $headCx + 10, $headCy + 22, $playerIcon);
        $pcText = (string)$playerCount;
        $pcW = $this->measureText($pcText, 3);
        $pcX = $thirdW + (int)(($thirdW - $pcW) / 2);
        $this->drawScaledText($canvas, $pcText, $pcX, $bottomY + 42, 3, 100, 180, 255);

        $downBg = imagecolorallocate($canvas, 50, 30, 30);
        imagefilledrectangle($canvas, $thirdW * 2, $bottomY, 381, 125, $downBg);
        $downAreaCx = $thirdW * 2 + (int)($thirdW / 2);
        $this->drawThumbsDown($canvas, $downAreaCx - 20, $bottomY + (int)($panelH / 2) - 6, 4, 220, 80, 80);
        $this->drawScaledText($canvas, (string)$downCount, $downAreaCx + 10, $bottomY + (int)($panelH / 2) - 10, 3, 255, 100, 100);

        $sepColor = imagecolorallocate($canvas, 70, 70, 80);
        imagefilledrectangle($canvas, $thirdW - 1, $bottomY, $thirdW, 126, $sepColor);
        imagefilledrectangle($canvas, $thirdW * 2 - 1, $bottomY, $thirdW * 2, 126, $sepColor);

        imageline($canvas, 0, 0, 0, 127, $borderColor);
        imageline($canvas, 1, 0, 1, 127, $borderColor);
        imageline($canvas, 383, 0, 383, 127, $borderColor);
        imageline($canvas, 382, 0, 382, 127, $borderColor);
        imageline($canvas, 0, 126, 383, 126, $borderColor);
        imageline($canvas, 0, 127, 383, 127, $borderColor);

        $tiles = [];
        for ($c = 0; $c < 3; $c++) {
            $tiles[] = $this->extractTileRaw($canvas, $c, 0);
        }

        imagedestroy($canvas);
        return $tiles;
    }

    public function refreshBanner($name) {
        $banner = $this->getBanner($name);
        if ($banner === null || empty($banner["positions"])) return;
        if (!isset($banner["map_ids"]) || count($banner["map_ids"]) !== 9) return;

        $mapIds = $banner["map_ids"];
        $bottomTiles = $this->renderBottomRow($name, $banner);

        for ($i = 0; $i < 3; $i++) {
            $mapId = $mapIds[6 + $i];
            MapStorage::get()->setMapData($mapId, $bottomTiles[$i]);

            $pk = new BannerMapPacket();
            $pk->colors = $bottomTiles[$i];
            $pk->mapId = $mapId;
            foreach ($this->getServer()->getOnlinePlayers() as $p) {
                $p->dataPacket($pk);
            }
        }
    }

    public function getPlayerCount($worlds) {
        $count = 0;
        if (!is_array($worlds)) return 0;
        foreach ($worlds as $worldName) {
            $level = $this->getServer()->getLevelByName($worldName);
            if ($level !== null) {
                $count += count($level->getPlayers());
            }
        }
        return $count;
    }

    public function getVoteData($bannerName) {
        $all = $this->votes->getAll();
        $up = 0;
        $down = 0;
        if (isset($all[$bannerName])) {
            foreach ($all[$bannerName] as $player => $vote) {
                if ($vote === "up") $up++;
                elseif ($vote === "down") $down++;
            }
        }
        return ["up" => $up, "down" => $down];
    }

    public function vote($bannerName, $playerName, $type) {
        $all = $this->votes->getAll();
        if (!isset($all[$bannerName])) $all[$bannerName] = [];
        $key = strtolower($playerName);
        $current = isset($all[$bannerName][$key]) ? $all[$bannerName][$key] : null;
        if ($current === $type) {
            unset($all[$bannerName][$key]);
            $this->votes->setAll($all);
            $this->votes->save();
            return "removed";
        }
        $all[$bannerName][$key] = $type;
        $this->votes->setAll($all);
        $this->votes->save();
        return "voted";
    }

    public function onReceive(DataPacketReceiveEvent $event) {
        $packet = $event->getPacket();
        if ($packet->pid() !== BannerMapRequestPacket::NETWORK_ID) return;

        $mapId = 0;

        if ($packet instanceof BannerMapRequestPacket) {
            $mapId = $packet->mapId;
        } else {
            try {
                $packet->setBuffer($packet->buffer, 1);
                $mapId = $packet->getLong();
            } catch (\Exception $e) {
                return;
            }
        }

        if ($mapId < 90000) return;

        $rawImage = MapStorage::get()->getMapData($mapId);
        if ($rawImage === null) return;

        $pk = new BannerMapPacket();
        $pk->colors = $rawImage;
        $pk->mapId = $mapId;
        $event->getPlayer()->dataPacket($pk);
    }

    public function onInteract(PlayerInteractEvent $event) {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $action = $event->getAction();
        $pname = strtolower($player->getName());

        if (isset($this->placePending[$pname])) {
            if ($action !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;

            $bannerId = $this->placePending[$pname];
            unset($this->placePending[$pname]);
            $event->setCancelled(true);

            $face = $event->getFace();
            if ($face < 2) {
                $player->sendMessage("§cTap a wall side, not top or bottom.");
                $this->placePending[$pname] = $bannerId;
                return;
            }

            $player->sendMessage("§ePlacing banner...");
            if ($this->placeBanner($bannerId, $player, $block, $face)) {
                $player->sendMessage("§aBanner §e" . $bannerId . " §aplaced!");
            } else {
                $player->sendMessage("§cFailed to place banner. Check the area is clear.");
            }
            return;
        }

        if ($action !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;
        if ($block->getId() !== Block::ITEM_FRAME_BLOCK) return;

        $bx = (int)$block->x;
        $by = (int)$block->y;
        $bz = (int)$block->z;
        $worldName = $player->getLevel()->getFolderName();

        foreach ($this->getBanners() as $bname => $banner) {
            if (empty($banner["positions"])) continue;
            foreach ($banner["positions"] as $posIdx => $pos) {
                if ($pos["world"] === $worldName && (int)$pos["x"] === $bx && (int)$pos["y"] === $by && (int)$pos["z"] === $bz) {
                    $event->setCancelled(true);

                    $tileIndex = isset($pos["tile"]) ? (int)$pos["tile"] : $posIdx;
                    $tileRow = (int)($tileIndex / 3);
                    $tileCol = $tileIndex % 3;

                    if ($tileRow === 2 && $tileCol === 0) {
                        $result = $this->vote($bname, $player->getName(), "up");
                        if ($result === "removed") {
                            $player->sendMessage("§7Upvote removed.");
                        } else {
                            $player->sendMessage("§a> Upvoted!");
                        }
                        $this->refreshBanner($bname);
                        return;
                    }

                    if ($tileRow === 2 && $tileCol === 2) {
                        $result = $this->vote($bname, $player->getName(), "down");
                        if ($result === "removed") {
                            $player->sendMessage("§7Downvote removed.");
                        } else {
                            $player->sendMessage("§c> Downvoted!");
                        }
                        $this->refreshBanner($bname);
                        return;
                    }

                    $cmd = $banner["command"];
                    if (strlen($cmd) > 0) {
                        $this->getServer()->dispatchCommand($player, $cmd);
                    }
                    return;
                }
            }
        }
    }

    public function onJoin(PlayerJoinEvent $event) {
        $player = $event->getPlayer();
        foreach ($this->getBanners() as $name => $banner) {
            if (!isset($banner["map_ids"]) || empty($banner["map_ids"])) continue;
            $this->sendMaps($banner["map_ids"], $player);
        }
    }
}