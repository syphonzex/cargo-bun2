<?php

namespace NoteBlockPlayer;

use pocketmine\entity\Entity;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
use pocketmine\Player;

class Boombox {

    /** @var string */
    private $worldName;
    /** @var Vector3 */
    private $position;
    /** @var SongPlayer|null */
    private $songPlayer = null;
    /** @var string */
    private $currentSong = "";
    /** @var bool */
    private $loop = false;
    /** @var bool */
    private $shuffle = false;
    /** @var array */
    private $whitelistedSongs = [];
    /** @var Entity|null */
    private $hologram = null;

    public function __construct(string $worldName, Vector3 $position) {
        $this->worldName = $worldName;
        $this->position = $position;
    }

    public function getWorldName(): string {
        return $this->worldName;
    }

    public function getPosition(): Vector3 {
        return $this->position;
    }

    public function playSong(Song $song, Main $plugin) {
        if ($this->songPlayer !== null) {
            $this->songPlayer = null;
        }

        $this->songPlayer = new SongPlayer($song, true);
        $this->currentSong = $song->getName();

        // Add all players currently in the world
        $level = $plugin->getServer()->getLevelByName($this->worldName);
        if ($level !== null) {
            foreach ($level->getPlayers() as $player) {
                $this->songPlayer->addPlayer($player);
            }
        }

        $plugin->ensureTaskRunning();
        $this->updateHologram($plugin);
    }

    public function stop() {
        $this->songPlayer = null;
        $this->currentSong = "";
    }

    public function onTick(Main $plugin) {
        if ($this->songPlayer === null) return;

        $this->songPlayer->onTick();

        if ($this->songPlayer->isFinished()) {
            if ($this->loop) {
                // Restart current song
                $song = $plugin->getSong($this->currentSong);
                if ($song !== null) {
                    $this->playSong($song, $plugin);
                }
            } else {
                $this->stop();
            }
        }
    }

    public function addPlayer(Player $player) {
        if ($this->songPlayer !== null) {
            $this->songPlayer->addPlayer($player);
        }
    }

    public function removePlayer(Player $player) {
        if ($this->songPlayer !== null) {
            $this->songPlayer->removePlayer($player);
        }
    }

    public function hasPlayer(Player $player): bool {
        return $this->songPlayer !== null && $this->songPlayer->hasPlayer($player);
    }

    public function setLoop(bool $loop) {
        $this->loop = $loop;
    }

    public function setShuffle(bool $shuffle) {
        $this->shuffle = $shuffle;
    }

    public function addWhitelistedSong(string $songKey) {
        $this->whitelistedSongs[strtolower($songKey)] = true;
    }

    public function isSongWhitelisted(string $songKey): bool {
        return isset($this->whitelistedSongs[strtolower($songKey)]);
    }

    public function getCurrentSong(): string {
        return $this->currentSong;
    }

    public function updateHologram(Main $plugin) {
        $level = $plugin->getServer()->getLevelByName($this->worldName);
        if ($level === null) return;

        if ($this->hologram !== null) {
            $this->hologram->close();
        }

        $text = "§b§lBoomBox v2.0\n§7Currently Playing: §e" . ($this->currentSong ?: "None");

        $this->hologram = $plugin->createHologram(
            $level,
            $this->position->add(0, 1.5, 0),
            $text
        );
    }

    public function removeHologram() {
        if ($this->hologram !== null) {
            $this->hologram->close();
            $this->hologram = null;
        }
    }
}