<?php

namespace NoteBlockPlayer;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;

class Main extends PluginBase implements Listener {

    private $songs = [];
    private $activePlayers = [];
    private $boomboxes = [];
    private $playerModes = [];
    private $taskId = null;
    private $whitelistedSongs = [];

    public function onEnable() {
        @mkdir($this->getDataFolder() . "songs");
        Entity::registerEntity(BoomboxHologramEntity::class, true);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->loadSongs();
    }

    public function onDisable() {
        $this->stopAllPlayback();
    }

    private function loadSongs() {
        $parser = new NBSParser();
        $dir = $this->getDataFolder() . "songs/";
        foreach (scandir($dir) as $file) {
            if (strtolower(pathinfo($file, PATHINFO_EXTENSION)) !== "nbs") continue;
            $song = $parser->parse($dir . $file);
            if ($song !== null) {
                $key = strtolower(pathinfo($file, PATHINFO_FILENAME));
                $this->songs[$key] = $song;
            }
        }
    }

    public function getSong($key) {
        $key = strtolower($key);
        return isset($this->songs[$key]) ? $this->songs[$key] : null;
    }

    public function createBoombox(Level $level, Vector3 $pos) {
        $boombox = new Boombox($level->getName(), $pos);
        $key = $level->getName() . ":" . $pos->x . ":" . $pos->y . ":" . $pos->z;
        $this->boomboxes[$key] = $boombox;
        return $boombox;
    }

    public function createHologram(Level $level, Vector3 $pos, $text) {
        $nbt = Entity::createBaseNBT($pos);
        $hologram = Entity::createEntity("BoomboxHologramEntity", $level, $nbt);
        if ($hologram instanceof BoomboxHologramEntity) {
            $hologram->setDisplayText($text);
            $hologram->spawnToAll();
            return $hologram;
        }
        return null;
    }

    public function setPlayerMode(Player $player, $mode) {
        $this->playerModes[$player->getName()] = $mode;
    }

    public function getPlayerMode(Player $player) {
        return isset($this->playerModes[$player->getName()]) ? $this->playerModes[$player->getName()] : "global";
    }

    public function whitelistSong($songKey) {
        $this->whitelistedSongs[strtolower($songKey)] = true;
    }

    public function isSongWhitelisted($songKey) {
        return isset($this->whitelistedSongs[strtolower($songKey)]);
    }

    public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
        if ($command->getName() === "music") {
            return $this->handleMusicCommand($sender, $args);
        }
        if ($command->getName() === "boombox") {
            if (!$sender->hasPermission("noteblockplayer.boombox")) return true;
            return $this->handleBoomboxCommand($sender, $args);
        }
        return false;
    }

    private function handleMusicCommand(CommandSender $sender, array $args) {
        if (!($sender instanceof Player)) return true;

        if (count($args) === 0) {
            $sender->sendMessage(TextFormat::YELLOW . "/music play <song> | stop | mode <global|personal>");
            return true;
        }

        $sub = strtolower($args[0]);

        if ($sub === "play" && isset($args[1])) {
            $songKey = strtolower($args[1]);
            if (!isset($this->songs[$songKey]) || !$this->isSongWhitelisted($songKey)) {
                $sender->sendMessage(TextFormat::RED . "Song not found or not allowed.");
                return true;
            }
            $this->stopPlayerPlayback($sender);
            $sp = new SongPlayer($this->songs[$songKey]);
            $sp->addPlayer($sender);
            $this->activePlayers[$sender->getName()] = $sp;
            $this->ensureTaskRunning();
        } elseif ($sub === "stop") {
            $this->stopPlayerPlayback($sender);
        } elseif ($sub === "mode" && isset($args[1])) {
            $this->setPlayerMode($sender, strtolower($args[1]));
        }
        return true;
    }

    private function handleBoomboxCommand(CommandSender $sender, array $args) {
        if (count($args) === 0) {
            $sender->sendMessage(TextFormat::YELLOW . "/boombox spawn|play|stop|loop|shuffle|whitelist");
            return true;
        }

        $sub = strtolower($args[0]);

        if ($sub === "spawn" && $sender instanceof Player) {
            $boombox = $this->createBoombox($sender->getLevel(), $sender->getPosition()->floor());
            $boombox->updateHologram($this);
        } elseif ($sub === "play" && isset($args[1]) && $sender instanceof Player) {
            $boombox = $this->getNearestBoombox($sender);
            $song = $this->getSong($args[1]);
            if ($boombox && $song) {
                $boombox->playSong($song, $this);
            }
        } elseif ($sub === "whitelist" && isset($args[1])) {
            $this->whitelistSong($args[1]);
        }
        return true;
    }

    private function getNearestBoombox(Player $player) {
        foreach ($this->boomboxes as $boombox) {
            if ($boombox->getWorldName() === $player->getLevel()->getName() &&
                $boombox->getPosition()->distance($player) <= 10) {
                return $boombox;
            }
        }
        return null;
    }

    public function onPlayerQuit(PlayerQuitEvent $event) {
        unset($this->activePlayers[$event->getPlayer()->getName()]);
    }

    public function tickPlayers() {
        foreach ($this->activePlayers as $name => $sp) {
            $sp->onTick();
            if ($sp->isFinished()) unset($this->activePlayers[$name]);
        }
        foreach ($this->boomboxes as $boombox) {
            $boombox->onTick($this);
        }
    }

    public function ensureTaskRunning() {
        if ($this->taskId === null) {
            $task = new SongTask($this);
            $handler = $this->getServer()->getScheduler()->scheduleRepeatingTask($task, 1);
            $this->taskId = $handler->getTaskId();
        }
    }

    private function stopPlayerPlayback(Player $player) {
        unset($this->activePlayers[$player->getName()]);
    }

    private function stopAllPlayback() {
        $this->activePlayers = [];
    }
}
