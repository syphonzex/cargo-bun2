<?php

namespace NoteBlockPlayer;

use pocketmine\entity\Human;
use pocketmine\entity\Entity;
use pocketmine\network\protocol\AddPlayerPacket;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\item\Item;
use pocketmine\Player;

class BoomboxHologramEntity extends Human {

    private $displayText = "";

    public function onUpdate($currentTick) {
        if ($this->closed) return false;
        return parent::onUpdate($currentTick);
    }

    public function setDisplayText($text) {
        $this->displayText = $text;
        $this->setDataProperty(Entity::DATA_NAMETAG, Entity::DATA_TYPE_STRING, $text);
    }

    public function getDisplayText() {
        return $this->displayText;
    }

    public function attack($damage, EntityDamageEvent $source) {
        $source->setCancelled(true);
    }

    public function spawnTo(Player $player) {
        if (!isset($this->hasSpawned[$player->getLoaderId()])) {
            $this->hasSpawned[$player->getLoaderId()] = $player;

            $pk = new AddPlayerPacket();
            $pk->uuid = $this->getUniqueId();
            $pk->username = "";
            $pk->eid = $this->getId();
            $pk->x = $this->x;
            $pk->y = $this->y;
            $pk->z = $this->z;
            $pk->yaw = $this->yaw;
            $pk->pitch = $this->pitch;
            $pk->item = Item::get(Item::AIR);
            $pk->metadata = [
                Entity::DATA_FLAGS => [Entity::DATA_TYPE_BYTE, 1 << Entity::DATA_FLAG_INVISIBLE],
                Entity::DATA_NAMETAG => [Entity::DATA_TYPE_STRING, $this->displayText],
                Entity::DATA_SHOW_NAMETAG => [Entity::DATA_TYPE_BYTE, 1],
                Entity::DATA_NO_AI => [Entity::DATA_TYPE_BYTE, 1],
                Entity::DATA_LEAD_HOLDER => [Entity::DATA_TYPE_LONG, -1],
                Entity::DATA_LEAD => [Entity::DATA_TYPE_BYTE, 0],
            ];

            $player->dataPacket($pk);
        }
    }

    public function getName() {
        return "BoomboxHologram";
    }
}