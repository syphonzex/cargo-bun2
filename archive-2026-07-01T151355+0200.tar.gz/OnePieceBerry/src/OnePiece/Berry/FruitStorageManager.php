<?php

namespace OnePiece\Berry;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\Item;

class FruitStorageManager {

    private $plugin;
    private $storage = [];
    private $savePath;

    const MAX_SLOTS = 8;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->savePath = $plugin->getDataFolder() . "fruit_storage.json";
        $this->loadAll();
    }

    private function loadAll() {
        if (!file_exists($this->savePath)) return;
        $data = json_decode(file_get_contents($this->savePath), true);
        if (is_array($data)) {
            $this->storage = $data;
        }
    }

    public function saveAll() {
        file_put_contents($this->savePath, json_encode($this->storage, JSON_PRETTY_PRINT));
    }

    public function getStorage($name) {
        $name = strtolower($name);
        return isset($this->storage[$name]) ? $this->storage[$name] : [];
    }

    public function getEffectiveMaxSlots($name) {
        $miscPlugin = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin("OnePieceMISC");
        if ($miscPlugin !== null && $miscPlugin->isEnabled()) {
            $loader = \OnePiece\WantedPoster\Loader::get();
            if ($loader !== null) {
                $gm = $loader->getGamepassManager();
                if ($gm !== null && $gm->hasStoragePlus($name)) {
                    return self::MAX_SLOTS + 1;
                }
            }
        }
        return self::MAX_SLOTS;
    }

    public function hasSpace($name) {
        $fruits = $this->getStorage($name);
        return count($fruits) < $this->getEffectiveMaxSlots($name);
    }

    public function addFruit($name, $fruitId) {
        $name = strtolower($name);
        if (!$this->hasSpace($name)) return false;
        if (!isset($this->storage[$name])) $this->storage[$name] = [];
        $this->storage[$name][] = $fruitId;
        $this->saveAll();
        return true;
    }

    public function removeFruit($name, $slot) {
        $name = strtolower($name);
        if (!isset($this->storage[$name])) return null;
        if ($slot < 0 || $slot >= count($this->storage[$name])) return null;
        $fruitId = $this->storage[$name][$slot];
        array_splice($this->storage[$name], $slot, 1);
        $this->saveAll();
        return $fruitId;
    }

    public function storeFruit(Player $player) {
        $name = strtolower($player->getName());
        $item = $player->getInventory()->getItemInHand();

        if ($item->getId() !== Item::GOLDEN_APPLE) {
            $player->sendMessage("§cYou must hold a Devil Fruit to store it!");
            return false;
        }

        $customName = $item->getCustomName();
        if (empty($customName)) {
            $player->sendMessage("§cThis is not a valid Devil Fruit!");
            return false;
        }

        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin === null || !$devilPlugin->isEnabled()) {
            $player->sendMessage("§cDevil fruit system not available.");
            return false;
        }

        $fm = $devilPlugin->getFruitManager();
        $fruitId = $this->getFruitIdFromName($fm, $customName);

        if ($fruitId === null) {
            $player->sendMessage("§cThis is not a valid Devil Fruit!");
            return false;
        }

        if (!$this->hasSpace($name)) {
            $player->sendMessage("§cYour storage is full! Max " . $this->getEffectiveMaxSlots(strtolower($player->getName())) . " fruits.");
            return false;
        }

        $this->addFruit($name, $fruitId);

        $item->setCount($item->getCount() - 1);
        $player->getInventory()->setItemInHand($item);

        $fruit = $fm->getFruit($fruitId);
        $displayName = $fruit !== null ? $fruit->getDisplayName() : $fruitId;

        $player->sendMessage("§a§l[STORAGE] §r§aStored §f" . $displayName . " §ain your storage.");
         \pocketmine\Server::getInstance()->getLogger()->info("[Storage Debug] Player " . $player->getName() . " deposited: " . $displayName);
        return true;
    }

    private function getFruitIdFromName($fm, $customName) {
        $cleanName = preg_replace('/§./', '', $customName);
        $cleanName = trim($cleanName);

        foreach ($fm->getAllFruits() as $id => $fruit) {
            $fruitDisplayName = preg_replace('/§./', '', $fruit->getDisplayName());
            $fruitDisplayName = trim($fruitDisplayName);
            if (strcasecmp($cleanName, $fruitDisplayName) === 0) {
                return $id;
            }
        }
        return null;
    }

public function withdrawFruit($ownerName, $slot, Player $receiver) {
    $name = strtolower(is_string($ownerName) ? $ownerName : $ownerName->getName());
    $fruits = $this->getStorage($name);

    if ($slot < 0 || $slot >= count($fruits)) {
        $receiver->sendMessage("§cInvalid slot.");
        return false;
    }

    $fruitId = $fruits[$slot];

    $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
    if ($devilPlugin === null || !$devilPlugin->isEnabled()) {
        $receiver->sendMessage("§cDevil fruit system not available.");
        return false;
    }

    $fm = $devilPlugin->getFruitManager();
    $fruit = $fm->getFruit($fruitId);
    if ($fruit === null) {
        $receiver->sendMessage("§cFruit not found.");
        return false;
    }

    $item = Item::get(Item::GOLDEN_APPLE, 0, 1);
    $item->setCustomName($fruit->getRarityColor() . $fruit->getDisplayName());

    if (!$receiver->getInventory()->canAddItem($item)) {
        $receiver->sendMessage("§cInventory full!");
        return false;
    }

    $this->removeFruit($name, $slot);
    $receiver->getInventory()->addItem($item);
    $receiver->sendMessage("§a§l[STORAGE] §r§aWithdrew §f" . $fruit->getDisplayName() . " §afrom §f" . $name . "'s §astorage.");
    \pocketmine\Server::getInstance()->getLogger()->info("[Storage Debug] " . $receiver->getName() . " withdrew " . $fruitId . " from " . $name . "'s storage.");
    return true;
}

    public function getCount($name) {
        return count($this->getStorage(strtolower($name)));
    }
}