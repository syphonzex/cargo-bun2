<?php

namespace OnePiece\Berry;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class BerryCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("berry", "Berry currency commands", "/berry help", ["berries", "bal"]);
        $this->setPermission("onepiece.berry");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!isset($args[0])) {
            if ($sender instanceof Player) {
                $bm = $this->plugin->getBerryManager();
                $bal = $bm->get($sender->getName());
                $sender->sendMessage("§6§l[BERRY] §r§eYour balance: §f" . $bm->format($bal));
                return true;
            }
            $sender->sendMessage("§cUsage: /berry help");
            return true;
        }

        $sub = strtolower($args[0]);
        $bm = $this->plugin->getBerryManager();

        switch ($sub) {
            case "help":
                $sender->sendMessage("§6§l═══ Berry Commands ═══");
                $sender->sendMessage("§e/berry §7- Check your balance");
                $sender->sendMessage("§e/berry top §7- Richest players");
                if ($sender->hasPermission("onepiece.berry.admin")) {
                    $sender->sendMessage("§c/berry give <player> <amount> §7- Admin give");
                    $sender->sendMessage("§c/berry take <player> <amount> §7- Admin take");
                    $sender->sendMessage("§c/berry set <player> <amount> §7- Admin set");
                    $sender->sendMessage("§c/berry check <player> §7- Check player balance");
                }
                return true;

            case "top":
            case "rich":
                $top = $bm->getTop(10);
                $sender->sendMessage("§6§l═══ Richest Pirates ═══");
                $rank = 1;
                foreach ($top as $name => $bal) {
                    $color = $rank <= 3 ? "§e" : "§7";
                    $sender->sendMessage($color . "#" . $rank . " §f" . $name . " §7- §e" . $bm->format($bal));
                    $rank++;
                }
                if (empty($top)) {
                    $sender->sendMessage("§7No data yet.");
                }
                return true;

            case "give":
                if (!$sender->hasPermission("onepiece.berry.admin")) {
                    $sender->sendMessage("§cNo permission.");
                    return true;
                }
                if (!isset($args[1]) || !isset($args[2])) {
                    $sender->sendMessage("§cUsage: /berry give <player> <amount>");
                    return true;
                }
                $targetName = $args[1];
                $amount = (int)$args[2];
                if ($amount <= 0) {
                    $sender->sendMessage("§cAmount must be positive.");
                    return true;
                }
                $bm->load($targetName);
                $newBal = $bm->add($targetName, $amount);
                $sender->sendMessage("§a§l[BERRY] §r§aGave §f" . $bm->format($amount) . " §ato §f" . $targetName . " §7(Total: " . $bm->format($newBal) . ")");
                $target = $this->plugin->getServer()->getPlayer($targetName);
                if ($target !== null) {
                    $target->sendMessage("§a§l[BERRY] §r§aReceived §f" . $bm->format($amount) . " §afrom admin!");
                }
                return true;

            case "take":
            case "remove":
                if (!$sender->hasPermission("onepiece.berry.admin")) {
                    $sender->sendMessage("§cNo permission.");
                    return true;
                }
                if (!isset($args[1]) || !isset($args[2])) {
                    $sender->sendMessage("§cUsage: /berry take <player> <amount>");
                    return true;
                }
                $targetName = $args[1];
                $amount = (int)$args[2];
                if ($amount <= 0) {
                    $sender->sendMessage("§cAmount must be positive.");
                    return true;
                }
                $bm->load($targetName);
                $result = $bm->remove($targetName, $amount);
                if ($result) {
                    $sender->sendMessage("§a§l[BERRY] §r§aRemoved §f" . $bm->format($amount) . " §afrom §f" . $targetName);
                } else {
                    $sender->sendMessage("§cPlayer doesn't have enough berries.");
                }
                return true;

            case "set":
                if (!$sender->hasPermission("onepiece.berry.admin")) {
                    $sender->sendMessage("§cNo permission.");
                    return true;
                }
                if (!isset($args[1]) || !isset($args[2])) {
                    $sender->sendMessage("§cUsage: /berry set <player> <amount>");
                    return true;
                }
                $targetName = $args[1];
                $amount = (int)$args[2];
                if ($amount < 0) {
                    $sender->sendMessage("§cAmount can't be negative.");
                    return true;
                }
                $bm->load($targetName);
                $bm->set($targetName, $amount);
                $sender->sendMessage("§a§l[BERRY] §r§aSet §f" . $targetName . " §abalance to §f" . $bm->format($amount));
                return true;

            case "check":
            case "bal":
                if (!isset($args[1])) {
                    if ($sender instanceof Player) {
                        $bal = $bm->get($sender->getName());
                        $sender->sendMessage("§6§l[BERRY] §r§eYour balance: §f" . $bm->format($bal));
                        return true;
                    }
                    $sender->sendMessage("§cUsage: /berry check <player>");
                    return true;
                }
                if (!$sender->hasPermission("onepiece.berry.admin")) {
                    $sender->sendMessage("§cNo permission.");
                    return true;
                }
                $targetName = $args[1];
                $bm->load($targetName);
                $bal = $bm->get($targetName);
                $sender->sendMessage("§6§l[BERRY] §r§e" . $targetName . "'s balance: §f" . $bm->format($bal));
                return true;
        }

        $sender->sendMessage("§cUnknown sub-command. Use /berry help");
        return true;
    }
}