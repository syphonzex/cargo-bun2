<?php

namespace OnePiece\Berry;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class GachaCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("opgacha", "Devil Fruit Gacha", "/opgacha", ["gacha"]);
        $this->setPermission("onepiece.gacha");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        $sub = isset($args[0]) ? strtolower($args[0]) : "";

        if ($sub === "set") {
            if (!$sender->hasPermission("onepiece.admin")) {
                $sender->sendMessage("§cNo permission.");
                return true;
            }
            if (!isset($args[1]) || !isset($args[2])) {
                $sender->sendMessage("§cUsage: /opgacha set <player> <fruit-id>");
                $sender->sendMessage("§7Example: /opgacha set Steve uo_uo");
                return true;
            }
            $targetName = $args[1];
            $fruitId    = strtolower($args[2]);

            $allFruits = array_keys(GachaManager::FRUIT_CHANCES);
            if (!in_array($fruitId, $allFruits)) {
                $sender->sendMessage("§cUnknown fruit: §f" . $fruitId);
                $sender->sendMessage("§7Valid IDs: §f" . implode("§7, §f", $allFruits));
                return true;
            }

            if ($this->plugin->isFruitPaused($fruitId)) {
                $sender->sendMessage("§cThis fruit is currently paused.");
                return true;
            }

            $display = $this->getFruitDisplay($fruitId);
            $this->plugin->getGachaManager()->setGuaranteedFruit($targetName, $fruitId);
            $sender->sendMessage("§a[GACHA] §fNext spin for §e" . $targetName . " §fis guaranteed: " . $display);

            $target = $this->plugin->getServer()->getPlayerExact($targetName);
            if ($target !== null && $target->isOnline()) {
                //$target->sendMessage("§d[GACHA] §fYour next gacha spin has a guaranteed fruit waiting!");
            }
            return true;
        }

        if ($sub === "unset") {
            if (!$sender->hasPermission("onepiece.admin")) {
                $sender->sendMessage("§cNo permission.");
                return true;
            }
            if (!isset($args[1])) {
                $sender->sendMessage("§cUsage: /opgacha unset <player>");
                return true;
            }
            $targetName = $args[1];
            $gm = $this->plugin->getGachaManager();

            if (!$gm->hasGuaranteedFruit($targetName)) {
                $sender->sendMessage("§c[GACHA] §f" . $targetName . " has no guaranteed fruit set.");
                return true;
            }

            $gm->unsetGuaranteedFruit($targetName);
            $sender->sendMessage("§a[GACHA] §fGuaranteed fruit for §e" . $targetName . " §fhas been cleared.");
            return true;
        }

        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cIn-game only.");
            return true;
        }

        if (!$this->plugin->isInOPWorld($sender)) {
            $sender->sendMessage("§cYou must be in the OP world.");
            return true;
        }

        $this->plugin->getGachaMenuGUI()->openGachaMenu($sender);
        return true;
    }

    private function getFruitDisplay($fruitId) {
        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin !== null && $devilPlugin->isEnabled()) {
            $fruit = $devilPlugin->getFruitManager()->getFruit($fruitId);
            if ($fruit !== null) return $fruit->getRarityColor() . $fruit->getDisplayName();
        }
        return $fruitId;
    }
}