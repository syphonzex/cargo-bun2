<?php

namespace OnePiece\Berry;

use pocketmine\scheduler\PluginTask;

class ShopRefreshTask extends PluginTask {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct($plugin);
        $this->plugin = $plugin;
    }

    public function onRun($currentTick) {
        $this->plugin->getShopManager()->checkRefresh();
    }
}