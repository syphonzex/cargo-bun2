<?php

namespace OnePiece\Berry;

use pocketmine\Player;
use pocketmine\item\Item;
use pocketmine\level\Position;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\network\protocol\UpdateBlockPacket;
use pocketmine\network\protocol\BlockEntityDataPacket;
use pocketmine\network\protocol\ContainerOpenPacket;
use pocketmine\network\protocol\ContainerClosePacket;
use pocketmine\network\protocol\BlockEventPacket;
use pocketmine\inventory\BaseInventory;
use pocketmine\inventory\FakeBlockMenu;
use pocketmine\inventory\InventoryType;
use pocketmine\event\Listener;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\inventory\InventoryCloseEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class ShopMenuGUI implements Listener {

    private $plugin;
    private static $windows = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->plugin->getServer()->getPluginManager()->registerEvents($this, $plugin);
    }

    public function getPlugin() {
        return $this->plugin;
    }

    public static function getWindow(Player $player) {
        return isset(self::$windows[strtolower($player->getName())]) ? self::$windows[strtolower($player->getName())] : null;
    }

    public static function setWindow(Player $player, $data) {
        self::$windows[strtolower($player->getName())] = $data;
    }

    public static function removeWindow(Player $player) {
        unset(self::$windows[strtolower($player->getName())]);
    }

    public function openShopMenu(Player $player) {
        if (!$player->isOnline()) return;

        $inventory = new ShopWindowInventory($player, "Devil Fruit Shop");
        $this->setupShopMenu($player, $inventory);

        self::setWindow($player, [
            "type" => "shop",
            "inventory" => $inventory
        ]);

        $player->addWindow($inventory);
    }

    public function openConfirmMenu(Player $player, $stockSlot) {
        if (!$player->isOnline()) return;

        $shop = $this->plugin->getShopManager();
        $stock = $shop->getStock();

        if ($stockSlot < 0 || $stockSlot >= count($stock)) return;

        $entry = $stock[$stockSlot];
        $fruitId = $entry["fruit_id"];
        $rarity = $entry["rarity"];
        $price = $entry["price"];

        $displayName = $fruitId;
        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin !== null && $devilPlugin->isEnabled()) {
            $fruit = $devilPlugin->getFruitManager()->getFruit($fruitId);
            if ($fruit !== null) {
                $displayName = $fruit->getDisplayName();
            }
        }

        $rarityColor = $shop->getRarityColor($rarity);
        $chestTitle = $rarityColor . ucfirst($rarity) . ": " . $displayName;
        $inventory = new ShopWindowInventory($player, $chestTitle);
        $this->setupConfirmMenu($player, $inventory, $entry, $displayName);

        self::setWindow($player, [
            "type" => "confirm",
            "slot" => $stockSlot,
            "fruit_id" => $fruitId,
            "display_name" => $displayName,
            "rarity" => $rarity,
            "price" => $price,
            "inventory" => $inventory
        ]);

        $player->addWindow($inventory);
    }

    // FIX 1: Removed ?Player nullable hint (PHP 5.x/7.0 incompatible)
    // FIX 2: Inventory now created with $viewer so chest spawns at viewer's position
    public function openStorageMenu(Player $viewer, Player $target = null) {
        if (!$viewer->isOnline()) return;

        $owner = $target !== null ? $target : $viewer;
        $isOperatorViewing = $viewer->isOp() && $viewer->getName() !== $owner->getName();

        // FIX 2: Use $viewer here, not $owner — chest must spawn at viewer's location
        $inventory = new ShopWindowInventory($viewer, "Fruit Storage");

        $this->setupStorageMenu($owner, $inventory, $viewer);

        self::setWindow($viewer, [
            "type" => "storage",
            "inventory" => $inventory,
            "owner" => $owner->getName(),
            "isOperatorViewing" => $isOperatorViewing
        ]);

        $viewer->addWindow($inventory);
    }

    public function openStorageConfirmMenu(Player $player, $storageSlot, $ownerName = "") {
        if (!$player->isOnline()) return;

        // FIX 5: Accept ownerName so operator context is preserved
        if ($ownerName === "") $ownerName = $player->getName();

        $fs = $this->plugin->getFruitStorage();
        $fruits = $fs->getStorage($ownerName);

        if ($storageSlot < 0 || $storageSlot >= count($fruits)) return;

        $fruitId = $fruits[$storageSlot];
        $displayName = $fruitId;
        $rarityColor = "§f";

        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin !== null && $devilPlugin->isEnabled()) {
            $fruit = $devilPlugin->getFruitManager()->getFruit($fruitId);
            if ($fruit !== null) {
                $displayName = $fruit->getDisplayName();
                $rarityColor = $fruit->getRarityColor();
            }
        }

        $chestTitle = $rarityColor . $displayName;
        $inventory = new ShopWindowInventory($player, $chestTitle);
        $this->setupStorageConfirmMenu($player, $inventory, $fruitId, $displayName, $rarityColor, $storageSlot);

        self::setWindow($player, [
            "type" => "storage_confirm",
            "slot" => $storageSlot,
            "fruit_id" => $fruitId,
            "display_name" => $displayName,
            "owner" => $ownerName, // FIX 5: persist owner through to confirm menu
            "inventory" => $inventory
        ]);

        $player->addWindow($inventory);
    }

    private function setupShopMenu(Player $player, ShopWindowInventory $inventory) {
        $shop = $this->plugin->getShopManager();
        $bm = $this->plugin->getBerryManager();
        $stock = $shop->getStock();
        $remaining = $shop->getTimeUntilReset();
        $pane = Item::get(102, 0, 1);
        $pane->setCustomName(" ");

        for ($i = 0; $i < 27; $i++) {
            $inventory->setItem($i, clone $pane);
        }

        $infoItem = Item::get(Item::CLOCK, 0, 1);
        $infoItem->setCustomName("§eResets in: §f" . $shop->formatTime($remaining));
        $inventory->setItem(2, $infoItem);

        $berryItem = Item::get(Item::GOLD_INGOT, 0, 1);
        $berryItem->setCustomName("§6Berries: §e" . $bm->format($bm->get($player->getName())));
        $inventory->setItem(6, $berryItem);

        $currentFruit = "None";
        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin !== null && $devilPlugin->isEnabled()) {
            $fm = $devilPlugin->getFruitManager();
            if ($fm->playerHasFruit($player)) {
                $fruit = $fm->getPlayerFruit($player);
                if ($fruit !== null) {
                    $currentFruit = $fruit->getDisplayName();
                }
            }
        }

        $fruitInfoItem = Item::get(Item::APPLE, 0, 1);
        $fruitInfoItem->setCustomName("§7Current Fruit: §f" . $currentFruit);
        $inventory->setItem(4, $fruitInfoItem);

        if (empty($stock)) {
            $emptyItem = Item::get(Item::IRON_BARS, 0, 1);
            $emptyItem->setCustomName("§7No fruits in stock - Wait for reset!");
            $inventory->setItem(13, $emptyItem);
        } else {
            $startSlot = 10;
            foreach ($stock as $i => $entry) {
                $displayName = $entry["fruit_id"];
                if ($devilPlugin !== null && $devilPlugin->isEnabled()) {
                    $fruit = $devilPlugin->getFruitManager()->getFruit($entry["fruit_id"]);
                    if ($fruit !== null) $displayName = $fruit->getDisplayName();
                }

                $rarityColor = $shop->getRarityColor($entry["rarity"]);
                $priceFormatted = $bm->format($entry["price"]);

                $item = $this->getRarityItem($entry["rarity"]);
                $item->setCustomName($rarityColor . $displayName . " §7- §e" . $priceFormatted . " " . $rarityColor . "[" . strtoupper($entry["rarity"]) . "]");

                $inventory->setItem($startSlot + $i, $item);
            }
        }

        $warnItem = Item::get(Item::PAPER, 0, 1);
        $warnItem->setCustomName("§cBuying replaces your current fruit!");
        $inventory->setItem(22, $warnItem);
    }

    private function setupConfirmMenu(Player $player, ShopWindowInventory $inventory, $entry, $displayName) {
        $shop = $this->plugin->getShopManager();
        $bm = $this->plugin->getBerryManager();
        $rarityColor = $shop->getRarityColor($entry["rarity"]);
        $priceFormatted = $bm->format($entry["price"]);
        $balance = $bm->format($bm->get($player->getName()));
        $hasEnough = $bm->has($player->getName(), $entry["price"]);

        $pane = Item::get(102, 0, 1);
        $pane->setCustomName(" ");

        for ($i = 0; $i < 27; $i++) {
            $inventory->setItem($i, clone $pane);
        }

        $fruitItem = $this->getRarityItem($entry["rarity"]);
        $fruitItem->setCustomName($rarityColor . $displayName . " " . $rarityColor . "[" . strtoupper($entry["rarity"]) . "]");
        $inventory->setItem(4, $fruitItem);

        $priceItem = Item::get(Item::GOLD_INGOT, 0, 1);
        $priceItem->setCustomName("§7Price: §e" . $priceFormatted . " §7You have: §e" . $balance);
        $inventory->setItem(13, $priceItem);

        if ($hasEnough) {
            $confirmItem = Item::get(Item::DYE, 10, 1);
            $confirmItem->setCustomName("§a[CONFIRM] Buy " . $displayName . " for §e" . $priceFormatted);
            $inventory->setItem(11, $confirmItem);
        } else {
            $cantBuyItem = Item::get(Item::DYE, 8, 1);
            $cantBuyItem->setCustomName("§cNot enough berries!");
            $inventory->setItem(11, $cantBuyItem);
        }

        $cancelItem = Item::get(Item::DYE, 1, 1);
        $cancelItem->setCustomName("§c[CANCEL] Go Back");
        $inventory->setItem(15, $cancelItem);
    }

    // FIX 1: Removed ?Player nullable hint (PHP 5.x/7.0 incompatible)
    private function setupStorageMenu(Player $owner, ShopWindowInventory $inventory, Player $viewer = null) {
        $fs = $this->plugin->getFruitStorage();
        $fruits = $fs->getStorage($owner->getName());
        $count = count($fruits);
        $max = FruitStorageManager::MAX_SLOTS;

        $pane = Item::get(102, 0, 1);
        $pane->setCustomName(" ");

        for ($i = 0; $i < 27; $i++) {
            $inventory->setItem($i, clone $pane);
        }

        $infoItem = Item::get(Item::CHEST, 0, 1);
        $header = "§6Fruit Storage §7(" . $count . "/" . $max . ")";
        if ($viewer !== null && $viewer->getName() !== $owner->getName()) {
            $header .= " §f[Viewing: " . $owner->getName() . "]";
        }
        $infoItem->setCustomName($header);
        $inventory->setItem(4, $infoItem);

        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");

        for ($i = 0; $i < $max; $i++) {
            $slot = 10 + $i;
            if ($i < $count) {
                $fruitId = $fruits[$i];
                $displayName = $fruitId;
                $rarityColor = "§f";

                if ($devilPlugin !== null && $devilPlugin->isEnabled()) {
                    $fruit = $devilPlugin->getFruitManager()->getFruit($fruitId);
                    if ($fruit !== null) {
                        $displayName = $fruit->getDisplayName();
                        $rarityColor = $fruit->getRarityColor();
                    }
                }

                $item = Item::get(Item::GOLDEN_APPLE, 0, 1);
                $item->setCustomName($rarityColor . $displayName . " §7[Click to Withdraw]");
                $inventory->setItem($slot, $item);
            } else {
                $item = Item::get(Item::IRON_BARS, 0, 1);
                $item->setCustomName("§8[Empty Slot]");
                $inventory->setItem($slot, $item);
            }
        }

        $helpItem = Item::get(Item::PAPER, 0, 1);
        if ($viewer !== null && $viewer->isOp() && $viewer->getName() !== $owner->getName()) {
            $helpItem->setCustomName("§eClick Golden Apple in your inv to store for §f" . $owner->getName());
        } else {
            $helpItem->setCustomName("§eClick a Devil Fruit in your inventory to store");
        }
        $inventory->setItem(22, $helpItem);

        $closeItem = Item::get(0, 14, 1);
        $closeItem->setCustomName("§cClose Menu");
        $inventory->setItem(26, $closeItem);
    }

    private function getStorageOwner(Player $viewer) {
        $window = self::getWindow($viewer);
        if ($window && isset($window["owner"])) {
            return $window["owner"];
        }
        return $viewer->getName();
    }

    // FIX 2 (note): handleStorageClick was dead code — clicks route through onTransaction -> handleClick.
    // Keeping this method removed to avoid confusion. All storage click logic is in handleClick below.

    private function setupStorageConfirmMenu(Player $player, ShopWindowInventory $inventory, $fruitId, $displayName, $rarityColor, $storageSlot) {
        $pane = Item::get(102, 0, 1);
        $pane->setCustomName(" ");

        for ($i = 0; $i < 27; $i++) {
            $inventory->setItem($i, clone $pane);
        }

        $fruitItem = Item::get(Item::GOLDEN_APPLE, 0, 1);
        $fruitItem->setCustomName($rarityColor . $displayName);
        $inventory->setItem(4, $fruitItem);

        $withdrawItem = Item::get(Item::DYE, 10, 1);
        $withdrawItem->setCustomName("§a[WITHDRAW] Take " . $displayName);
        $inventory->setItem(11, $withdrawItem);

        $cancelItem = Item::get(Item::DYE, 1, 1);
        $cancelItem->setCustomName("§c[CANCEL] Go Back");
        $inventory->setItem(15, $cancelItem);
    }

    private function getRarityItem($rarity) {
        switch ($rarity) {
            case "common":
                return Item::get(Item::DYE, 10, 1);
            case "rare":
                return Item::get(Item::DYE, 4, 1);
            case "legendary":
                return Item::get(Item::DYE, 14, 1);
            case "mythical":
                return Item::get(Item::DYE, 5, 1);
            case "god":
                return Item::get(Item::DYE, 1, 1);
        }
        return Item::get(Item::DYE, 8, 1);
    }

    public function onTransaction(InventoryTransactionEvent $event) {
        $transaction = $event->getTransaction();
        $player = $transaction->getPlayer();

        if (!($player instanceof Player)) return;

        $window = self::getWindow($player);
        if ($window === null) return;

        $inventory = $window["inventory"];
        if (!($inventory instanceof ShopWindowInventory)) return;

        $clickedSlot = -1;
        $clickedItem = null;
        $isPlayerInventory = false;

        foreach ($transaction->getTransactions() as $trans) {
            $inv = $trans->getInventory();
            $targetItem = $trans->getTargetItem();

            if ($inv instanceof ShopWindowInventory) {
                $clickedSlot = $trans->getSlot();
                $clickedItem = $targetItem;
                $isPlayerInventory = false;
                break;
            }

            if ($inv === $player->getInventory()) {
                if ($window["type"] === "storage") {
                    $sourceItem = $inv->getItem($trans->getSlot());
                    if ($sourceItem->getId() === Item::GOLDEN_APPLE && $sourceItem->getCustomName() !== "") {
                        $clickedSlot = $trans->getSlot();
                        $clickedItem = $sourceItem;
                        $isPlayerInventory = true;
                        break;
                    }
                }
            }
        }

        $event->setCancelled(true);

        $player->getFloatingInventory()->clearAll();
        $player->getInventory()->sendContents($player);
        $inventory->sendContents($player);

        if ($clickedSlot >= 0) {
            if ($isPlayerInventory) {
                $this->handlePlayerInventoryClick($player, $clickedSlot, $clickedItem);
            } else {
                $this->handleClick($player, $clickedSlot, $clickedItem);
            }
        }
    }

    private function handlePlayerInventoryClick(Player $player, $slot, Item $item = null) {
        $window = self::getWindow($player);
        if ($window === null) return;

        $type = $window["type"];

        if ($type === "storage") {
            if ($item === null) return;
            if ($item->getId() !== Item::GOLDEN_APPLE) return;
            if ($item->getCustomName() === "") return;

            // FIX 3: Use owner from window, not always the viewer's name
            $ownerName = isset($window["owner"]) ? $window["owner"] : $player->getName();

            $fs = $this->plugin->getFruitStorage();

            if (!$fs->hasSpace($ownerName)) {
                $player->sendMessage("§cStorage is full! Max " . FruitStorageManager::MAX_SLOTS . " fruits.");
                return;
            }

            $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
            if ($devilPlugin === null || !$devilPlugin->isEnabled()) {
                $player->sendMessage("§cDevil fruit system not available.");
                return;
            }

            $fm = $devilPlugin->getFruitManager();
            $fruitId = $this->getFruitIdFromItem($fm, $item);

            if ($fruitId === null) {
                $player->sendMessage("§cThis is not a valid Devil Fruit!");
                return;
            }

            $fs->addFruit($ownerName, $fruitId);

            $newItem = clone $item;
            $newItem->setCount($item->getCount() - 1);
            $player->getInventory()->setItem($slot, $newItem);

            $fruit = $fm->getFruit($fruitId);
            $displayName = $fruit !== null ? $fruit->getDisplayName() : $fruitId;

            $player->sendMessage("§a§l[STORAGE] §r§aStored §f" . $displayName . " §ain §f" . $ownerName . "'s §astorage.");

            $gui = $this;
            $ownerPlayer = $this->plugin->getServer()->getPlayer($ownerName);
            $player->removeWindow($window["inventory"]);
            $this->scheduleTask(function() use ($gui, $player, $ownerPlayer) {
                if ($player->isOnline()) {
                    $gui->openStorageMenu($player, $ownerPlayer);
                }
            }, 5);
        }
    }

    private function getFruitIdFromItem($fm, Item $item) {
        $customName = $item->getCustomName();
        $cleanName = preg_replace('/§./', '', $customName);
        $cleanName = trim($cleanName);

        foreach ($fm->getAllFruits() as $id => $fruit) {
            $fruitDisplayName = preg_replace('/§./', '', $fruit->getDisplayName());
            $fruitDisplayName = trim($fruitDisplayName);
            if (strcasecmp($cleanName, $fruitDisplayName) === 0) {
                return $id;
            }
        }
        return null;
    }

    private function handleClick(Player $player, $slot, Item $item = null) {
        $window = self::getWindow($player);
        if ($window === null) return;

        $type = $window["type"];
        $gui = $this;

        if ($type === "shop") {
            if ($slot === 26) {
                $player->removeWindow($window["inventory"]);
                return;
            }

            $shop = $this->plugin->getShopManager();
            $stock = $shop->getStock();
            $stockSlot = $slot - 10;

            if ($stockSlot >= 0 && $stockSlot < count($stock)) {
                $player->removeWindow($window["inventory"]);
                $this->scheduleTask(function() use ($gui, $player, $stockSlot) {
                    if ($player->isOnline()) {
                        $gui->openConfirmMenu($player, $stockSlot);
                    }
                }, 5);
            }

        } elseif ($type === "confirm") {
            $stockSlot = $window["slot"];

            if ($slot === 11) {
                $bm = $this->plugin->getBerryManager();
                if (!$bm->has($player->getName(), $window["price"])) {
                    $player->sendMessage("§cNot enough berries!");
                    return;
                }

                $shop = $this->plugin->getShopManager();
                $player->removeWindow($window["inventory"]);
                $shop->buyFruit($player, $stockSlot);
                return;
            }

            if ($slot === 15) {
                $player->removeWindow($window["inventory"]);
                $this->scheduleTask(function() use ($gui, $player) {
                    if ($player->isOnline()) {
                        $gui->openShopMenu($player);
                    }
                }, 5);
                return;
            }

        } elseif ($type === "storage") {
            if ($slot === 26) {
                $player->removeWindow($window["inventory"]);
                return;
            }

            // FIX 3: Use owner from window instead of always $player->getName()
            $ownerName = isset($window["owner"]) ? $window["owner"] : $player->getName();
            $ownerPlayer = $this->plugin->getServer()->getPlayer($ownerName);

            $fs = $this->plugin->getFruitStorage();
            $fruits = $fs->getStorage($ownerName);
            $storageSlot = $slot - 10;

            if ($storageSlot >= 0 && $storageSlot < count($fruits)) {
                if (!$player->getInventory()->canAddItem(Item::get(Item::GOLDEN_APPLE, 0, 1))) {
                    $player->sendMessage("§cInventory full!");
                    return;
                }

                $player->removeWindow($window["inventory"]);
                // FIX 5: Pass $ownerName through to openStorageConfirmMenu
                $this->scheduleTask(function() use ($gui, $player, $storageSlot, $ownerName) {
                    if ($player->isOnline()) {
                        $gui->openStorageConfirmMenu($player, $storageSlot, $ownerName);
                    }
                }, 5);
            }

        } elseif ($type === "storage_confirm") {
            $storageSlot = $window["slot"];
            // FIX 4 & 5: Use persisted owner, not always $player
            $ownerName = isset($window["owner"]) ? $window["owner"] : $player->getName();

            if ($slot === 11) {
                $fs = $this->plugin->getFruitStorage();
                $player->removeWindow($window["inventory"]);
                self::removeWindow($player);
                // FIX 4: Withdraw from correct owner's storage
                $this->scheduleTask(function() use ($player, $fs, $storageSlot, $ownerName) {
                    if ($player->isOnline()) {
                        $ownerPlayer = $this->plugin->getServer()->getPlayer($ownerName);
                        $fs->withdrawFruit($ownerPlayer !== null ? $ownerPlayer : $player, $storageSlot, $player);
                    }
                }, 5);
                return;
            }

            if ($slot === 15) {
                $ownerPlayer = $this->plugin->getServer()->getPlayer($ownerName);
                $player->removeWindow($window["inventory"]);
                $this->scheduleTask(function() use ($gui, $player, $ownerPlayer) {
                    if ($player->isOnline()) {
                        $gui->openStorageMenu($player, $ownerPlayer);
                    }
                }, 5);
                return;
            }
        }
    }

    private function scheduleTask(callable $callable, int $delay) {
        Server::getInstance()->getScheduler()->scheduleDelayedTask(new class($callable) extends Task {
            private $callable;

            public function __construct(callable $callable) {
                $this->callable = $callable;
            }

            public function onRun($currentTick) {
                $callable = $this->callable;
                $callable();
            }
        }, $delay);
    }

    public function onClose(InventoryCloseEvent $event) {
        $player = $event->getPlayer();
        $inventory = $event->getInventory();

        if ($inventory instanceof ShopWindowInventory) {
            self::removeWindow($player);
        }
    }

    public function onQuit(PlayerQuitEvent $event) {
        self::removeWindow($event->getPlayer());
    }
}

class ShopWindowInventory extends BaseInventory {

    public $customName;
    public $pos;

    public function __construct(Player $player, $name = "Devil Fruit Shop") {
        $this->customName = $name;
        $this->pos = Position::fromObject($player->add(0, 2), $player->level);
        $this->holder = new FakeBlockMenu($this, $this->pos);
        parent::__construct($this->holder, InventoryType::get(InventoryType::CHEST));
    }

    public function sendChestState(Player $player, $open = true) {
        $pk = new BlockEventPacket();
        $pk->x = (int)$this->pos->x;
        $pk->y = (int)$this->pos->y;
        $pk->z = (int)$this->pos->z;
        $pk->case1 = 1;
        $pk->case2 = $open ? 1 : 0;
        $player->dataPacket($pk);
    }

    public function onOpen(Player $who) {
        if (!$who->isOnline()) return;

        $pk = new UpdateBlockPacket();
        $pk->x = $this->pos->x;
        $pk->y = $this->pos->y;
        $pk->z = $this->pos->z;
        $pk->blockId = 54;
        $pk->blockData = 0;
        $pk->flags = UpdateBlockPacket::FLAG_ALL;
        $who->dataPacket($pk);

        $compound = new CompoundTag();
        $compound->id = new StringTag("id", "Chest");
        $compound->CustomName = new StringTag("CustomName", $this->customName);
        $compound->x = new IntTag("x", (int)$this->pos->x);
        $compound->y = new IntTag("y", (int)$this->pos->y);
        $compound->z = new IntTag("z", (int)$this->pos->z);

        $nbt = new NBT(NBT::LITTLE_ENDIAN);
        $nbt->setData($compound);

        $pk = new BlockEntityDataPacket();
        $pk->x = $this->pos->x;
        $pk->y = $this->pos->y;
        $pk->z = $this->pos->z;
        $pk->namedtag = $nbt->write();
        $who->dataPacket($pk);

        parent::onOpen($who);

        $inventory = $this;

        Server::getInstance()->getScheduler()->scheduleDelayedTask(new class($who, $inventory) extends Task {
            private $player;
            private $inventory;

            public function __construct(Player $player, $inventory) {
                $this->player = $player;
                $this->inventory = $inventory;
            }

            public function onRun($currentTick) {
                if (!$this->player->isOnline()) return;

                $this->inventory->sendChestState($this->player, true);

                $pk = new ContainerOpenPacket();
                $pk->windowid = $this->player->getWindowId($this->inventory);
                $pk->type = $this->inventory->getType()->getNetworkType();
                $pk->slots = $this->inventory->getSize();
                $pk->x = $this->inventory->pos->x;
                $pk->y = $this->inventory->pos->y;
                $pk->z = $this->inventory->pos->z;

                $this->player->dataPacket($pk);
                $this->inventory->sendContents($this->player);
            }
        }, 2);
    }

    public function onClose(Player $who) {
        if (!$who->isOnline()) return;

        $this->sendChestState($who, false);

        $pk = new UpdateBlockPacket();
        $pk->x = $this->pos->x;
        $pk->y = $this->pos->y;
        $pk->z = $this->pos->z;
        $pk->blockId = $who->getLevel()->getBlockIdAt($this->pos->x, $this->pos->y, $this->pos->z);
        $pk->blockData = $who->getLevel()->getBlockDataAt($this->pos->x, $this->pos->y, $this->pos->z);
        $pk->flags = UpdateBlockPacket::FLAG_ALL;
        $who->dataPacket($pk);

        parent::onClose($who);
    }
}