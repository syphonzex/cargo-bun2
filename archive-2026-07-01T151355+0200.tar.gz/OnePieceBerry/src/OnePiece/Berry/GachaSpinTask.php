<?php

namespace OnePiece\Berry;

use pocketmine\scheduler\PluginTask;

class GachaSpinTask extends PluginTask {

    private $plugin;
    private $gachaGUI;
    private $playerName;

    public function __construct(Main $plugin, GachaMenuGUI $gachaGUI, $playerName) {
        parent::__construct($plugin);
        $this->plugin = $plugin;
        $this->gachaGUI = $gachaGUI;
        $this->playerName = $playerName;
    }

    public function onRun($currentTick) {
        $player = $this->plugin->getServer()->getPlayerExact($this->playerName);

        if ($player === null || !$player->isOnline()) {
            $this->plugin->getGachaManager()->cancelSpin($this->playerName);
            GachaMenuGUI::removeSpinData($player);
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $spinData = GachaMenuGUI::getSpinData($player);
        if ($spinData === null) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $window = GachaMenuGUI::getWindow($player);
        if ($window === null || $window["type"] !== "spin") {
            $this->plugin->getGachaManager()->cancelSpin($this->playerName);
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $tick = $spinData["tick"] + 1;
        $maxTicks = $spinData["maxTicks"];

        GachaMenuGUI::setSpinData($player, [
            "fruitId" => $spinData["fruitId"],
            "rarity" => $spinData["rarity"],
            "tick" => $tick,
            "maxTicks" => $maxTicks
        ]);

        $inventory = $window["inventory"];

        if ($tick >= $maxTicks) {
            $this->gachaGUI->updateSpinSlots($player, $inventory);
            $this->gachaGUI->finishSpin($player);
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $this->gachaGUI->updateSpinSlots($player, $inventory);

        if ($tick >= $maxTicks - 5) {
            $this->gachaGUI->playSlowTickSound($player);
        } else {
            $this->gachaGUI->playTickSound($player);
        }
    }
}