<?php

namespace OnePiece\Berry;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\Item;
use pocketmine\level\Position;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\network\protocol\UpdateBlockPacket;
use pocketmine\network\protocol\BlockEntityDataPacket;
use pocketmine\network\protocol\ContainerOpenPacket;
use pocketmine\network\protocol\BlockEventPacket;
use pocketmine\network\protocol\LevelEventPacket;
use pocketmine\inventory\BaseInventory;
use pocketmine\inventory\FakeBlockMenu;
use pocketmine\inventory\InventoryType;
use pocketmine\event\Listener;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\inventory\InventoryCloseEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\scheduler\PluginTask;

class GachaMenuGUI implements Listener {

    private $plugin;
    private static $windows = [];
    private static $spinData = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->plugin->getServer()->getPluginManager()->registerEvents($this, $plugin);
    }

    public function getPlugin() {
        return $this->plugin;
    }

    public static function getWindow(Player $player) {
        return self::$windows[strtolower($player->getName())] ?? null;
    }

    public static function setWindow(Player $player, $data) {
        self::$windows[strtolower($player->getName())] = $data;
    }

    public static function removeWindow(Player $player) {
        unset(self::$windows[strtolower($player->getName())]);
        unset(self::$spinData[strtolower($player->getName())]);
    }

    public static function getSpinData(Player $player) {
        return self::$spinData[strtolower($player->getName())] ?? null;
    }

    public static function setSpinData(Player $player, $data) {
        self::$spinData[strtolower($player->getName())] = $data;
    }

    public static function removeSpinData(Player $player) {
        unset(self::$spinData[strtolower($player->getName())]);
    }

    public function openGachaMenu(Player $player) {
        if (!$player->isOnline()) return;

        $inventory = new GachaWindowInventory($player, "Devil Fruit Gacha");
        $this->setupMainMenu($player, $inventory);

        self::setWindow($player, [
            "type" => "main",
            "inventory" => $inventory
        ]);

        $player->addWindow($inventory);
    }

    public function openSpinMenu(Player $player, $wonFruitId, $wonRarity) {
        if (!$player->isOnline()) return;

        $inventory = new GachaWindowInventory($player, "Spinning...");

        self::setWindow($player, [
            "type" => "spin",
            "inventory" => $inventory
        ]);

        self::setSpinData($player, [
            "fruitId" => $wonFruitId,
            "rarity" => $wonRarity,
            "tick" => 0,
            "maxTicks" => 30
        ]);

        $this->setupSpinMenu($player, $inventory);

        $player->addWindow($inventory);

        $task = new GachaSpinTask($this->plugin, $this, $player->getName());
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($task, 3);
    }

    private function setupMainMenu(Player $player, GachaWindowInventory $inventory) {
        $gacha = $this->plugin->getGachaManager();
        $bm = $this->plugin->getBerryManager();

        $pane = Item::get(102, 0, 1);
        $pane->setCustomName(" ");

        for ($i = 0; $i < 27; $i++) {
            $inventory->setItem($i, clone $pane);
        }

$cost = $this->plugin->getGachaManager()->getGachaCost($player);

$info = Item::get(Item::BOOK, 0, 1);
$info->setCustomName("§6§lDevil Fruit Gacha§r\n§r§7Spin for a random Devil Fruit!\n§7Cost: §e" . $bm->format($cost));
$inventory->setItem(4, $info);

        $berryItem = Item::get(Item::GOLD_INGOT, 0, 1);
        $berryItem->setCustomName("§6Your Berries: §e" . $bm->format($bm->get($player->getName())));
        $inventory->setItem(10, $berryItem);

        $commonItem = Item::get(Item::DYE, 10, 1);
        $commonItem->setCustomName("§aCommon §7- 54%");
        $inventory->setItem(19, $commonItem);

        $rareItem = Item::get(Item::DYE, 4, 1);
        $rareItem->setCustomName("§9Rare §7- 40%");
        $inventory->setItem(20, $rareItem);

        $legendaryItem = Item::get(Item::DYE, 14, 1);
        $legendaryItem->setCustomName("§6Legendary §7- 5%");
        $inventory->setItem(21, $legendaryItem);

        $mythicalItem = Item::get(Item::DYE, 5, 1);
        $mythicalItem->setCustomName("§dMythical §7- 1%");
        $inventory->setItem(22, $mythicalItem);

        if ($gacha->isSpinning($player)) {
            $spinItem = Item::get(Item::CLOCK, 0, 1);
            $spinItem->setCustomName("§eSpinning...");
            $inventory->setItem(13, $spinItem);
        } elseif ($gacha->hasCooldown($player)) {
            $remaining = $gacha->getRemainingCooldown($player);
            $cooldownItem = Item::get(Item::CLOCK, 0, 1);
            $cooldownItem->setCustomName("§cCooldown: §e" . $gacha->formatCooldown($remaining));
            $inventory->setItem(13, $cooldownItem);
        } else {
$canAfford = $bm->has($player->getName(), $cost);
if ($canAfford) {
    $spinItem = Item::get(Item::GOLDEN_APPLE, 0, 1);
    $spinItem->setCustomName("§a§lSPIN!§r\n§r§7Click to spin the gacha!\n§7Cost: §e" . $bm->format($cost));
} else {
    $spinItem = Item::get(Item::GOLDEN_APPLE, 0, 1);
    $spinItem->setCustomName("§c§lNOT ENOUGH BERRIES§r\n§r§7Need: §e" . $bm->format($cost));
}
            $inventory->setItem(13, $spinItem);
        }
    }

    public function setupSpinMenu(Player $player, GachaWindowInventory $inventory) {
        $pane = Item::get(102, 0, 1);
        $pane->setCustomName(" ");

        for ($i = 0; $i < 27; $i++) {
            $inventory->setItem($i, clone $pane);
        }

        $arrow1 = Item::get(Item::ARROW, 0, 1);
        $arrow1->setCustomName("§e§l>>>§r");
        $inventory->setItem(3, $arrow1);

        $arrow2 = Item::get(Item::ARROW, 0, 1);
        $arrow2->setCustomName("§e§l<<<§r");
        $inventory->setItem(5, $arrow2);

        $spinningItem = Item::get(Item::CLOCK, 0, 1);
        $spinningItem->setCustomName("§e§lSpinning...§r");
        $inventory->setItem(4, $spinningItem);

        $gacha = $this->plugin->getGachaManager();

        for ($i = 10; $i <= 16; $i++) {
            $randomId = $gacha->getRandomFruitId();
            $color = $gacha->getFruitRarityColor($randomId);
            $name = $gacha->getFruitDisplayName($randomId);

            $fruitItem = Item::get(Item::GOLDEN_APPLE, 0, 1);
            $fruitItem->setCustomName($color . $name);
            $inventory->setItem($i, $fruitItem);
        }
    }

public function updateSpinSlots(Player $player, GachaWindowInventory $inventory, $currentFruitId = null) {
    $gacha = $this->plugin->getGachaManager();
    $spinData = self::getSpinData($player);

    if ($spinData === null) return;

    $tick = $spinData["tick"];
    $maxTicks = $spinData["maxTicks"];
    $wonFruitId = $spinData["fruitId"];

    if ($tick >= $maxTicks - 5) {
        $color = $gacha->getFruitRarityColor($wonFruitId);
        $name = $gacha->getFruitDisplayName($wonFruitId);

        for ($i = 10; $i <= 16; $i++) {
            if ($i === 13) {
                $fruitItem = Item::get(Item::GOLDEN_APPLE, 0, 1);
                $fruitItem->setCustomName($color . "§l" . $name);
                $inventory->setItem($i, $fruitItem);
            } else {
                $pane = Item::get(102, 0, 1);
                $pane->setCustomName(" ");
                $inventory->setItem($i, $pane);
            }
        }

        $indicator = Item::get(Item::GLOWSTONE_DUST, 0, 1);
        $indicator->setCustomName("§6§lYou got:§r");
        $inventory->setItem(4, $indicator);
        return;
    }

    for ($i = 10; $i <= 16; $i++) {
        $randomId = $gacha->getRandomFruitId();
        $color = $gacha->getFruitRarityColor($randomId);
        $name = $gacha->getFruitDisplayName($randomId);

        $fruitItem = Item::get(Item::GOLDEN_APPLE, 0, 1);
        $fruitItem->setCustomName($color . $name);
        $inventory->setItem($i, $fruitItem);
    }

    $centerFruit = ($tick >= $maxTicks - 10) ? $wonFruitId : $gacha->getRandomFruitId();
    $color = $gacha->getFruitRarityColor($centerFruit);
    $name = $gacha->getFruitDisplayName($centerFruit);

    $centerItem = Item::get(Item::GOLDEN_APPLE, 0, 1);
    $centerItem->setCustomName($color . "§l" . $name);
    $inventory->setItem(13, $centerItem);

    $inventory->sendContents($player);
}

    public function finishSpin(Player $player) {
        $spinData = self::getSpinData($player);
        if ($spinData === null) return;

        $wonFruitId = $spinData["fruitId"];
        $wonRarity = $spinData["rarity"];

        $gacha = $this->plugin->getGachaManager();
        $gacha->finishSpin($player, $wonFruitId, $wonRarity);

        self::removeSpinData($player);

        $this->playWinSound($player, $wonRarity);

        $window = self::getWindow($player);
        if ($window !== null) {
            $inventory = $window["inventory"];

            $color = $gacha->getRarityColor($wonRarity);
            $name = $gacha->getFruitDisplayName($wonFruitId);

            $resultItem = Item::get(Item::GOLDEN_APPLE, 0, 1);
            $resultItem->setCustomName($color . "§l" . $name . "\n§r" . $color . "[" . strtoupper($wonRarity) . "]");
            $inventory->setItem(13, $resultItem);

            $collectItem = Item::get(Item::DYE, 10, 1);
            $collectItem->setCustomName("§a§lCOLLECTED!§r\n§r§7Fruit added to inventory");
            $inventory->setItem(22, $collectItem);

            $inventory->sendContents($player);
        }

        $player->sendMessage("§6§l===============");
        $player->sendMessage("§6§l  GACHA RESULT!");
        $player->sendMessage("§6§l===============");
        $player->sendMessage($color . "  " . $name);
        $player->sendMessage($color . "  [" . strtoupper($wonRarity) . "]");
        $player->sendMessage("§6§l===============");
    }

    public function playTickSound(Player $player) {
        $pk = new LevelEventPacket();
        $pk->evid = LevelEventPacket::EVENT_SOUND_CLICK;
        $pk->x = $player->x;
        $pk->y = $player->y;
        $pk->z = $player->z;
        $pk->data = 0;
        $player->dataPacket($pk);
    }

    public function playSlowTickSound(Player $player) {
        $pk = new LevelEventPacket();
        $pk->evid = LevelEventPacket::EVENT_SOUND_DOOR;
        $pk->x = $player->x;
        $pk->y = $player->y;
        $pk->z = $player->z;
        $pk->data = 0;
        $player->dataPacket($pk);
    }

    public function playWinSound(Player $player, $rarity) {
        $pk = new LevelEventPacket();

        if ($rarity === "mythical" || $rarity === "legendary") {
            $pk->evid = LevelEventPacket::EVENT_SOUND_EXPLODE;
        } else {
            $pk->evid = LevelEventPacket::EVENT_SOUND_EXP_PICKUP;
        }

        $pk->x = $player->x;
        $pk->y = $player->y;
        $pk->z = $player->z;
        $pk->data = 0;
        $player->dataPacket($pk);
    }

    public function onTransaction(InventoryTransactionEvent $event) {
        $transaction = $event->getTransaction();
        $player = $transaction->getPlayer();

        if (!($player instanceof Player)) return;

        $window = self::getWindow($player);
        if ($window === null) return;

        $inventory = $window["inventory"];
        if (!($inventory instanceof GachaWindowInventory)) return;

        $clickedSlot = -1;
        $clickedItem = null;

        foreach ($transaction->getTransactions() as $trans) {
            $inv = $trans->getInventory();
            if ($inv instanceof GachaWindowInventory) {
                $clickedSlot = $trans->getSlot();
                $clickedItem = $inv->getItem($clickedSlot);
                break;
            }
        }

        if ($clickedSlot < 0) return;

        $event->setCancelled(true);

        $player->getFloatingInventory()->clearAll();
        $player->getInventory()->sendContents($player);
        $inventory->sendContents($player);

        if ($window["type"] === "spin") {
            return;
        }

        $this->handleClick($player, $clickedSlot, $clickedItem);
    }

    private function handleClick(Player $player, $slot, Item $item = null) {
        $window = self::getWindow($player);
        if ($window === null) return;

        $name = $item !== null ? $item->getCustomName() : "";

        if ($slot === 26) {
            $player->removeWindow($window["inventory"]);
            return;
        }

        if ($slot === 13) {
            $gacha = $this->plugin->getGachaManager();

            if ($gacha->isSpinning($player) || $gacha->hasCooldown($player)) {
                return;
            }

            $result = $gacha->startSpin($player);

            if (!$result["success"]) {
                $player->sendMessage("§c" . $result["error"]);
                return;
            }

            $player->removeWindow($window["inventory"]);

            $gui = $this;
            $wonFruitId = $result["fruitId"];
            $wonRarity = $result["rarity"];

            $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
                new class($this->plugin, $gui, $player->getName(), $wonFruitId, $wonRarity) extends PluginTask {
                    private $gui;
                    private $playerName;
                    private $fruitId;
                    private $rarity;

                    public function __construct($plugin, $gui, $playerName, $fruitId, $rarity) {
                        parent::__construct($plugin);
                        $this->gui = $gui;
                        $this->playerName = $playerName;
                        $this->fruitId = $fruitId;
                        $this->rarity = $rarity;
                    }

                    public function onRun($currentTick) {
                        $player = $this->getOwner()->getServer()->getPlayerExact($this->playerName);
                        if ($player !== null && $player->isOnline()) {
                            $this->gui->openSpinMenu($player, $this->fruitId, $this->rarity);
                        }
                    }
                }, 5
            );
        }
    }

    public function onClose(InventoryCloseEvent $event) {
        $player = $event->getPlayer();
        $inventory = $event->getInventory();

        if ($inventory instanceof GachaWindowInventory) {
            $spinData = self::getSpinData($player);
            if ($spinData !== null) {
                return;
            }
            self::removeWindow($player);
        }
    }

    public function onQuit(PlayerQuitEvent $event) {
        $player = $event->getPlayer();
        $gacha = $this->plugin->getGachaManager();
        $gacha->cancelSpin($player->getName());
        self::removeWindow($player);
    }
}

class GachaWindowInventory extends BaseInventory {

    public $customName;
    public $pos;

    public function __construct(Player $player, $name = "Gacha") {
        $this->customName = $name;
        $this->pos = Position::fromObject($player->add(0, 2), $player->level);
        $this->holder = new FakeBlockMenu($this, $this->pos);
        parent::__construct($this->holder, InventoryType::get(InventoryType::CHEST));
    }

    public function sendChestState(Player $player, $open = true) {
        $pk = new BlockEventPacket();
        $pk->x = (int)$this->pos->x;
        $pk->y = (int)$this->pos->y;
        $pk->z = (int)$this->pos->z;
        $pk->case1 = 1;
        $pk->case2 = $open ? 1 : 0;
        $player->dataPacket($pk);
    }

    public function onOpen(Player $who) {
        if (!$who->isOnline()) return;

        $pk = new UpdateBlockPacket();
        $pk->x = $this->pos->x;
        $pk->y = $this->pos->y;
        $pk->z = $this->pos->z;
        $pk->blockId = 54;
        $pk->blockData = 0;
        $pk->flags = UpdateBlockPacket::FLAG_ALL;
        $who->dataPacket($pk);

        $compound = new CompoundTag();
        $compound->id = new StringTag("id", "Chest");
        $compound->CustomName = new StringTag("CustomName", $this->customName);
        $compound->x = new IntTag("x", (int)$this->pos->x);
        $compound->y = new IntTag("y", (int)$this->pos->y);
        $compound->z = new IntTag("z", (int)$this->pos->z);

        $nbt = new NBT(NBT::LITTLE_ENDIAN);
        $nbt->setData($compound);

        $pk = new BlockEntityDataPacket();
        $pk->x = $this->pos->x;
        $pk->y = $this->pos->y;
        $pk->z = $this->pos->z;
        $pk->namedtag = $nbt->write();
        $who->dataPacket($pk);

        parent::onOpen($who);

        $inventory = $this;

        Server::getInstance()->getScheduler()->scheduleDelayedTask(new class($who, $inventory) extends PluginTask {
            private $player;
            private $inventory;

            public function __construct(Player $player, $inventory) {
                parent::__construct(Server::getInstance()->getPluginManager()->getPlugin("OnePieceBerry"));
                $this->player = $player;
                $this->inventory = $inventory;
            }

            public function onRun($currentTick) {
                if (!$this->player->isOnline()) return;

                $this->inventory->sendChestState($this->player, true);

                $pk = new ContainerOpenPacket();
                $pk->windowid = $this->player->getWindowId($this->inventory);
                $pk->type = $this->inventory->getType()->getNetworkType();
                $pk->slots = $this->inventory->getSize();
                $pk->x = $this->inventory->pos->x;
                $pk->y = $this->inventory->pos->y;
                $pk->z = $this->inventory->pos->z;

                $this->player->dataPacket($pk);
                $this->inventory->sendContents($this->player);
            }
        }, 2);
    }

    public function onClose(Player $who) {
        if (!$who->isOnline()) return;

        $this->sendChestState($who, false);

        $pk = new UpdateBlockPacket();
        $pk->x = $this->pos->x;
        $pk->y = $this->pos->y;
        $pk->z = $this->pos->z;
        $pk->blockId = $who->getLevel()->getBlockIdAt($this->pos->x, $this->pos->y, $this->pos->z);
        $pk->blockData = $who->getLevel()->getBlockDataAt($this->pos->x, $this->pos->y, $this->pos->z);
        $pk->flags = UpdateBlockPacket::FLAG_ALL;
        $who->dataPacket($pk);

        parent::onClose($who);
    }
}