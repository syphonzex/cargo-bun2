<?php
namespace OnePiece\Berry;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\scheduler\PluginTask;

class StorageCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("storage", "Devil Fruit Storage", "/storage [player]", ["fruitstorage"]);
        $this->setPermission("onepiece.storage");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cThis command can only be used in-game.");
            return true;
        }

        /*if (!$sender->hasPermission("onepiece.storage")) {
            $sender->sendMessage("§cYou don't have permission to use this command.");
            return true;
        }*/

        if (isset($args[0])) {
            if (!$sender->hasPermission("onepiece.storage.others")) {
               // $sender->sendMessage("§cYou don't have permission to view other players' storage.");
                return true;
            }

            $target = $this->plugin->getServer()->getPlayerExact($args[0]);

            if ($target instanceof Player) {
                // ✅ 2-SECOND DELAY FOR OTHER PLAYER
                $sender->sendMessage("§aLoading storage data..");
                $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
                    new StorageLoadTask($this->plugin, $sender, $target), 
                    40 // 2 seconds (20 ticks = 1 second)
                );
            } else {
                $sender->sendMessage("§cPlayer §f" . $args[0] . " §cis not online.");
            }

            return true;
        }

        // ✅ 2-SECOND DELAY FOR OWN STORAGE
        $sender->sendMessage("§aLoading storage data..");
        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
            new StorageLoadTask($this->plugin, $sender, $sender), 
            40 // 2 seconds
        );
        
        return true;
    }
}

// ✅ NEW TASK CLASS FOR DELAYED STORAGE OPENING
class StorageLoadTask extends PluginTask {
    
    private $viewer;
    private $target;
    
    public function __construct(Main $plugin, Player $viewer, Player $target) {
        parent::__construct($plugin);
        $this->viewer = $viewer;
        $this->target = $target;
    }
    
    public function onRun($tick) {
        if ($this->viewer->isOnline() && $this->target->isOnline()) {
            $this->getOwner()->getShopMenuGUI()->openStorageMenu($this->viewer, $this->target);
        } else {
            $this->viewer->sendMessage("§cStorage loading cancelled - player disconnected.");
        }
    }
}