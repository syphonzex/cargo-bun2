<?php

namespace OnePiece\Berry;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\Item;

class GachaManager {

    private $plugin;
    private $cooldowns = [];
    private $spinning  = [];

    const GACHA_COST = 50000;
    const COOLDOWN   = 1800;

    const FRUIT_CHANCES = [
        "bari_bari"        => 1800,
        "moku_moku"        => 1700,
        "inu_inu"          => 1600,
        "tori_tori_falcon" => 1400,
        "bara_bara"        => 400,
        "gomu_gomu"        => 300,
        "suna_suna"        => 200,
        "bomb_bomb"        => 150,
        "neko_neko"        => 100,
        "yami_yami"        => 80,
        "hie_hie"          => 30,
        "iro_iro"          => 30,
        "revive_revive"    => 30,
        "love_love"        => 30,
        "magu_magu"        => 30,
        "mera_mera"        => 30,
        "pika_pika"        => 30,
        "tori_tori"        => 25,
        "sound_sound"      => 25,
        "giro_giro"        => 20,
        "gear_fourth"      => 20,
        "yami_v2"          => 20,
        "shadow_shadow"    => 2,
        "zou_zou"          => 2,
        "trex_trex"        => 2,
        "ope_ope"          => 1,
        "mochi_mochi"      => 1,
        "goro_goro"        => 1,
        "okuchi_okuchi"    => 1,
        "gura_gura"        => 1,
        "soru_soru"        => 1,
        "gravity_gravity"  => 1,
        "dark_x_quake"     => 1,
        "uo_uo"            => 1,
    ];

    const FRUIT_RARITY = [
        "bari_bari"        => "common",
        "moku_moku"        => "common",
        "inu_inu"          => "common",
        "tori_tori_falcon" => "common",
        "bara_bara"        => "rare",
        "gomu_gomu"        => "rare",
        "suna_suna"        => "rare",
        "bomb_bomb"        => "rare",
        "neko_neko"        => "rare",
        "yami_yami"        => "rare",
        "hie_hie"          => "legendary",
        "iro_iro"          => "legendary",
        "revive_revive"    => "legendary",
        "mera_mera"        => "legendary",
        "love_love"        => "legendary",
        "pika_pika"        => "legendary",
        "magu_magu"        => "legendary",
        "tori_tori"        => "legendary",
        "sound_sound"      => "legendary",
        "giro_giro"        => "legendary",
        "gear_fourth"      => "legendary",
        "yami_v2"          => "legendary",
        "shadow_shadow"    => "mythical",
        "zou_zou"          => "mythical",
        "trex_trex"        => "mythical",
        "ope_ope"          => "mythical",
        "mochi_mochi"      => "mythical",
        "goro_goro"        => "mythical",
        "okuchi_okuchi"    => "mythical",
        "gura_gura"        => "mythical",
        "soru_soru"        => "mythical",
        "gravity_gravity"  => "mythical",
        "uo_uo"            => "mythical",
        "dark_x_quake"     => "god",
    ];

    private $guaranteed = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function getPlugin() {
        return $this->plugin;
    }

    public function hasCooldown(Player $player) {
        $name = strtolower($player->getName());
        if (!isset($this->cooldowns[$name])) return false;
        return time() < $this->cooldowns[$name];
    }

    public function getRemainingCooldown(Player $player) {
        $name = strtolower($player->getName());
        if (!isset($this->cooldowns[$name])) return 0;
        return max(0, $this->cooldowns[$name] - time());
    }

    public function formatCooldown($seconds) {
        $m = intval($seconds / 60);
        $s = $seconds % 60;
        return $m . "m " . $s . "s";
    }

    public function isSpinning(Player $player) {
        return isset($this->spinning[strtolower($player->getName())]);
    }

    public function setSpinning(Player $player, $value) {
        $name = strtolower($player->getName());
        if ($value) {
            $this->spinning[$name] = true;
        } else {
            unset($this->spinning[$name]);
        }
    }

public function getGachaCost(Player $player) {
    $statsPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceStats");
    if ($statsPlugin === null || !$statsPlugin->isEnabled()) return self::GACHA_COST;
    $sm = $statsPlugin->getStatManager();
    if ($sm === null) return self::GACHA_COST;
    $sp = $sm->getStatPlayer($player);
    if ($sp === null) return self::GACHA_COST;
    $level = $sp->getLevel();
    if ($level >= 500) return 500000;
    if ($level >= 300) return 350000;
    if ($level >= 200) return 200000;
    if ($level >= 100) return 100000;
    return self::GACHA_COST;
}

public function startSpin(Player $player) {
    $name = strtolower($player->getName());

    if ($this->isSpinning($player)) {
        return ["success" => false, "error" => "Already spinning!"];
    }

    if ($this->hasCooldown($player)) {
        $remaining = $this->getRemainingCooldown($player);
        return ["success" => false, "error" => "Cooldown: " . $this->formatCooldown($remaining)];
    }

    $cost = $this->getGachaCost($player);
    $bm = $this->plugin->getBerryManager();
    if (!$bm->has($player->getName(), $cost)) {
        return ["success" => false, "error" => "Not enough berries!"];
    }

    $bm->remove($player->getName(), $cost);
    $this->spinning[$name] = true;

    $wonFruitId = $this->rollFruitForPlayer($player);
    $wonRarity  = self::FRUIT_RARITY[$wonFruitId] ?? "common";

    return [
        "success" => true,
        "fruitId" => $wonFruitId,
        "rarity"  => $wonRarity
    ];
}

    public function finishSpin(Player $player, $wonFruitId, $wonRarity) {
        $name = strtolower($player->getName());
        unset($this->spinning[$name]);
        $this->cooldowns[$name] = time() + self::COOLDOWN;

        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin === null || !$devilPlugin->isEnabled()) {
            $player->sendMessage("§cDevil fruit system not available! Refunding...");
            $this->plugin->getBerryManager()->add($player->getName(), self::GACHA_COST);
            return false;
        }

        $fm    = $devilPlugin->getFruitManager();
        $fruit = $fm->getFruit($wonFruitId);
        if ($fruit === null) {
            $player->sendMessage("§cFruit error! Refunding...");
            $this->plugin->getBerryManager()->add($player->getName(), self::GACHA_COST);
            return false;
        }

        $item = Item::get(Item::GOLDEN_APPLE, 0, 1);
        $item->setCustomName($fruit->getRarityColor() . $fruit->getDisplayName());

        if ($player->getInventory()->canAddItem($item)) {
            $player->getInventory()->addItem($item);
        } else {
            $storage = $this->plugin->getFruitStorage();
            if ($storage->hasSpace($player->getName())) {
                $storage->addFruit($player->getName(), $wonFruitId);
                $player->sendMessage("§eSent to /storage - inventory full!");
            } else {
                $player->getLevel()->dropItem($player, $item);
                $player->sendMessage("§eDropped on ground - inventory & storage full!");
            }
        }

        if ($wonRarity === "god" || $wonRarity === "mythical" || $wonRarity === "legendary") {
            $rarityColor = $this->getRarityColor($wonRarity);
            $this->plugin->getServer()->broadcastMessage(
                "§d§l" . $player->getName() . " §r§dpulled " . $rarityColor . $fruit->getDisplayName() . " §dfrom Gacha!"
            );
        }
        \pocketmine\Server::getInstance()->getLogger()->info("[Gacha Debug] Player " . $player->getName() . " rolled: " . $wonFruitId . " (Rarity: " . $wonRarity . ")");
        return true;
    }

    public function cancelSpin($name) {
        unset($this->spinning[strtolower($name)]);
    }

    public function setGuaranteedFruit($playerName, $fruitId) {
        $this->guaranteed[strtolower($playerName)] = $fruitId;
    }

    public function hasGuaranteedFruit($playerName) {
        return isset($this->guaranteed[strtolower($playerName)]);
    }

    public function getGuaranteedFruit($playerName) {
        return $this->guaranteed[strtolower($playerName)] ?? null;
    }

    public function unsetGuaranteedFruit($playerName) {
        unset($this->guaranteed[strtolower($playerName)]);
    }

    public function rollFruitForPlayer(Player $player) {
        $name = strtolower($player->getName());
        if (isset($this->guaranteed[$name])) {
            $fruitId = $this->guaranteed[$name];
            unset($this->guaranteed[$name]);
            return $fruitId;
        }
        return $this->rollFruit();
    }

    public function rollFruit() {
        $paused  = $this->plugin->getPausedFruits();
        $chances = [];
        foreach (self::FRUIT_CHANCES as $fruitId => $weight) {
            if (!in_array($fruitId, $paused)) {
                $chances[$fruitId] = $weight;
            }
        }
        if (empty($chances)) {
            $chances = self::FRUIT_CHANCES;
        }
        $total = 0;
        foreach ($chances as $w) $total += $w;
        $roll = mt_rand(1, $total);
        $sum  = 0;
        foreach ($chances as $fruitId => $weight) {
            $sum += $weight;
            if ($roll <= $sum) return $fruitId;
        }
        reset($chances);
        return key($chances);
    }

    public function getRandomFruitId() {
        return $this->rollFruit();
    }

    public function getFruitDisplayName($fruitId) {
        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin === null || !$devilPlugin->isEnabled()) return $fruitId;
        $fm    = $devilPlugin->getFruitManager();
        $fruit = $fm->getFruit($fruitId);
        if ($fruit === null) return $fruitId;
        return $fruit->getDisplayName();
    }

    public function getFruitRarityColor($fruitId) {
        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin === null || !$devilPlugin->isEnabled()) return "§f";
        $fm    = $devilPlugin->getFruitManager();
        $fruit = $fm->getFruit($fruitId);
        if ($fruit === null) return "§f";
        return $fruit->getRarityColor();
    }

    public function getRarityColor($rarity) {
        switch ($rarity) {
            case "common":    return "§a";
            case "rare":      return "§9";
            case "legendary": return "§6";
            case "mythical":  return "§d";
            case "god":  return "§c";
        }
        return "§f";
    }

    public function getRarityFromFruitId($fruitId) {
        return self::FRUIT_RARITY[$fruitId] ?? "common";
    }

    public function getChancePercent($fruitId) {
        $paused  = $this->plugin->getPausedFruits();
        $chances = [];
        foreach (self::FRUIT_CHANCES as $id => $weight) {
            if (!in_array($id, $paused)) {
                $chances[$id] = $weight;
            }
        }
        if (empty($chances)) $chances = self::FRUIT_CHANCES;
        $total = array_sum($chances);
        $w     = $chances[$fruitId] ?? 0;
        if ($total === 0) return 0.0;
        return round(($w / $total) * 100, 3);
    }
}