<?php

namespace OnePiece\Berry;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class ShopCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("opshop", "Devil Fruit Shop", "/opshop [buy <slot>|pause <fruit>|unpause <fruit>|paused|refresh|add <fruit> [slot]|remove <slot>]", ["dfshop"]);
        $this->setPermission("onepiece.shop");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        $sub = isset($args[0]) ? strtolower($args[0]) : "";

        if ($sub === "pause" || $sub === "unpause" || $sub === "paused") {
            if (!$sender->hasPermission("onepiece.admin")) {
                $sender->sendMessage("§cNo permission.");
                return true;
            }
            return $this->handlePause($sender, $sub, $args);
        }

        if ($sub === "refresh") {
            if (!$sender->hasPermission("onepiece.admin")) {
                $sender->sendMessage("§cNo permission.");
                return true;
            }
            return $this->handleRefresh($sender);
        }

        if ($sub === "add") {
            if (!$sender->hasPermission("onepiece.admin")) {
                $sender->sendMessage("§cNo permission.");
                return true;
            }
            return $this->handleAdd($sender, $args);
        }

        if ($sub === "remove") {
            if (!$sender->hasPermission("onepiece.admin")) {
                $sender->sendMessage("§cNo permission.");
                return true;
            }
            return $this->handleRemove($sender, $args);
        }

        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cIn-game only.");
            return true;
        }

        if (!$this->plugin->isInOPWorld($sender)) {
            $sender->sendMessage("§cYou must be in the OP world.");
            return true;
        }

        if ($sub === "buy") {
            if (!isset($args[1])) {
                $sender->sendMessage("§cUsage: /opshop buy <slot>");
                return true;
            }
            $slot = (int)$args[1] - 1;
            $this->plugin->getShopMenuGUI()->openConfirmMenu($sender, $slot);
            return true;
        }

        $this->plugin->getShopMenuGUI()->openShopMenu($sender);
        return true;
    }

    private function handleRefresh(CommandSender $sender) {
        $this->plugin->getShopManager()->refreshStock();
        $sender->sendMessage("§a[OPSHOP] §fShop stock has been refreshed.");
       // $this->plugin->getServer()->broadcastMessage("§6[OPSHOP] §eThe Devil Fruit Shop has been restocked!");
        return true;
    }

    private function handleAdd(CommandSender $sender, array $args) {
        if (!isset($args[1])) {
            $sender->sendMessage("§cUsage: /opshop add <fruit-id> [slot]");
            $sender->sendMessage("§7Example: /opshop add uo_uo");
            $sender->sendMessage("§7Example: /opshop add uo_uo 3");
            return true;
        }

        $fruitId = strtolower($args[1]);
        $slot = isset($args[2]) ? (int)$args[2] : null;

        $allFruits = array_keys(ShopManager::FRUIT_PRICES);
        if (!in_array($fruitId, $allFruits)) {
            $sender->sendMessage("§cUnknown fruit: §f" . $fruitId);
            $sender->sendMessage("§7Valid IDs: §f" . implode("§7, §f", $allFruits));
            return true;
        }

        if ($this->plugin->isFruitPaused($fruitId)) {
            $sender->sendMessage("§cThis fruit is currently paused. Unpause it first.");
            return true;
        }

        $shopManager = $this->plugin->getShopManager();
        $maxSlots = $shopManager->getMaxSlots();

        if ($slot !== null) {
            if ($slot < 1 || $slot > $maxSlots) {
                $sender->sendMessage("§cInvalid slot. Must be between 1 and " . $maxSlots . ".");
                return true;
            }
        }

        $display = $this->getFruitDisplay($fruitId);

        $result = $shopManager->addFruitToStock($fruitId, $slot);

        if ($result === true) {
            $sender->sendMessage("§a[OPSHOP] §f" . $display . " §7(" . $fruitId . ") §ahas been added to the shop.");
           // $this->plugin->getServer()->broadcastMessage("§6[OPSHOP] §f" . $display . " §ehas been added to the shop!");
        } elseif ($result === "replaced") {
            $sender->sendMessage("§a[OPSHOP] §f" . $display . " §7(" . $fruitId . ") §ahas replaced slot " . $slot . ".");
           // $this->plugin->getServer()->broadcastMessage("§6[OPSHOP] §f" . $display . " §ehas been added to the shop!");
        } elseif ($result === "full") {
            $sender->sendMessage("§c[OPSHOP] Shop is full! Specify a slot to replace.");
            $sender->sendMessage("§7Usage: /opshop add <fruit-id> <slot>");
        } elseif ($result === "exists") {
            $sender->sendMessage("§c[OPSHOP] " . $display . " is already in the shop.");
        } else {
            $sender->sendMessage("§c[OPSHOP] Failed to add fruit.");
        }

        return true;
    }

    private function handleRemove(CommandSender $sender, array $args) {
        if (!isset($args[1])) {
            $sender->sendMessage("§cUsage: /opshop remove <slot>");
            $sender->sendMessage("§7Example: /opshop remove 3");
            return true;
        }

        $slot = (int)$args[1];
        $shopManager = $this->plugin->getShopManager();
        $maxSlots = $shopManager->getMaxSlots();

        if ($slot < 1 || $slot > $maxSlots) {
            $sender->sendMessage("§cInvalid slot. Must be between 1 and " . $maxSlots . ".");
            return true;
        }

        $result = $shopManager->removeFruitFromStock($slot);

        if ($result === true) {
            $sender->sendMessage("§a[OPSHOP] §fSlot " . $slot . " has been cleared.");
        } elseif ($result === "empty") {
            $sender->sendMessage("§c[OPSHOP] Slot " . $slot . " is already empty.");
        } else {
            $sender->sendMessage("§c[OPSHOP] Failed to remove fruit.");
        }

        return true;
    }

    private function handlePause(CommandSender $sender, $sub, array $args) {
        if ($sub === "paused") {
            $paused = $this->plugin->getPausedFruits();
            if (empty($paused)) {
                $sender->sendMessage("§a[OPSHOP] §fNo fruits are currently paused.");
            } else {
                $sender->sendMessage("§6[OPSHOP] §ePaused fruits §7(" . count($paused) . ")§e:");
                foreach ($paused as $fruitId) {
                    $display = $this->getFruitDisplay($fruitId);
                    $sender->sendMessage("  §c- §f" . $display . " §7(" . $fruitId . ")");
                }
            }
            return true;
        }

        if (!isset($args[1])) {
            $sender->sendMessage("§cUsage: /opshop " . $sub . " <fruit-id>");
            $sender->sendMessage("§7Example: /opshop pause uo_uo");
            return true;
        }

        $fruitId = strtolower($args[1]);

        $allFruits = array_keys(ShopManager::FRUIT_PRICES);
        if (!in_array($fruitId, $allFruits)) {
            $sender->sendMessage("§cUnknown fruit: §f" . $fruitId);
            $sender->sendMessage("§7Valid IDs: §f" . implode("§7, §f", $allFruits));
            return true;
        }

        $display = $this->getFruitDisplay($fruitId);

        if ($sub === "pause") {
            if ($this->plugin->pauseFruit($fruitId)) {
                $sender->sendMessage("§6[OPSHOP] §e" . $display . " §7(" . $fruitId . ") §eis now §cpAUSED §e— unavailable in gacha and shop.");
                //$this->plugin->getServer()->broadcastMessage("§6[OPSHOP] §e" . $display . " §ehas been removed from the shop and gacha.");
                $this->plugin->getShopManager()->refreshStock();

                $tradesPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceTrades");
                if ($tradesPlugin !== null && $tradesPlugin->isEnabled()) {
                    $fm = $tradesPlugin->getFactoryManager();
                    foreach ($fm->getAllActiveKeys() as $key) {
                        $active = $fm->getActiveData($key);
                        if ($active !== null && isset($active["fruit_id"]) && $active["fruit_id"] === $fruitId) {
                            $fm->resolveFactory($key);
                            $sender->sendMessage("§6[OPSHOP] §eActive factory running §f" . $display . " §ehas been force-resolved.");
                        }
                    }
                }
            } else {
                $sender->sendMessage("§c" . $display . " is already paused.");
            }
        } else {
            if ($this->plugin->unpauseFruit($fruitId)) {
                $sender->sendMessage("§a[OPSHOP] §f" . $display . " §7(" . $fruitId . ") §ais now §aUNPAUSED §a— available again.");
               // $this->plugin->getServer()->broadcastMessage("§a[OPSHOP] §f" . $display . " §ahas returned to the shop and gacha pool.");
                $this->plugin->getShopManager()->refreshStock();
            } else {
                $sender->sendMessage("§c" . $display . " is not paused.");
            }
        }

        return true;
    }

    private function getFruitDisplay($fruitId) {
        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin !== null && $devilPlugin->isEnabled()) {
            $fruit = $devilPlugin->getFruitManager()->getFruit($fruitId);
            if ($fruit !== null) return $fruit->getRarityColor() . $fruit->getDisplayName();
        }
        return $fruitId;
    }
}