<?php

namespace OnePiece\Berry;

use pocketmine\Player;

class BerryManager {

    private $plugin;
    private $balances = [];
    private $savePath;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->savePath = $plugin->getDataFolder() . "berries.json";
        $this->loadAll();
    }

    private function loadAll() {
        if (!file_exists($this->savePath)) return;
        $data = json_decode(file_get_contents($this->savePath), true);
        if (is_array($data)) {
            $this->balances = $data;
        }
    }

    public function saveAll() {
        file_put_contents($this->savePath, json_encode($this->balances, JSON_PRETTY_PRINT));
    }

    public function load($name) {
        $name = strtolower($name);
        if (!isset($this->balances[$name])) {
            $this->balances[$name] = 0;
        }
    }

    public function save($name) {
        $this->saveAll();
    }

    public function unload($name) {
    }

    public function get($name) {
        $name = strtolower($name);
        return isset($this->balances[$name]) ? $this->balances[$name] : 0;
    }

    public function set($name, $amount) {
        $name = strtolower($name);
        $amount = max(0, (int)$amount);
        $this->balances[$name] = $amount;
        $this->saveAll();
    }

    public function add($name, $amount) {
        $name = strtolower($name);
        $amount = max(0, (int)$amount);
        $current = $this->get($name);
        $this->balances[$name] = $current + $amount;
        $this->saveAll();
        return $this->balances[$name];
    }

    public function remove($name, $amount) {
        $name = strtolower($name);
        $amount = max(0, (int)$amount);
        $current = $this->get($name);
        if ($current < $amount) return false;
        $this->balances[$name] = $current - $amount;
        $this->saveAll();
        return true;
    }

    public function has($name, $amount) {
        return $this->get(strtolower($name)) >= $amount;
    }

    public function transfer($from, $to, $amount) {
        $from = strtolower($from);
        $to = strtolower($to);
        $amount = max(0, (int)$amount);
        if (!$this->has($from, $amount)) return false;
        $this->balances[$from] -= $amount;
        if (!isset($this->balances[$to])) $this->balances[$to] = 0;
        $this->balances[$to] += $amount;
        $this->saveAll();
        return true;
    }

    public function format($amount) {
        if ($amount >= 1000000000) {
            return "B$" . round($amount / 1000000000, 2) . "B";
        }
        if ($amount >= 1000000) {
            return "B$" . round($amount / 1000000, 2) . "M";
        }
        if ($amount >= 1000) {
            return "B$" . round($amount / 1000, 1) . "K";
        }
        return "B$" . $amount;
    }

    public function getTop($limit = 10) {
        $sorted = $this->balances;
        arsort($sorted);
        return array_slice($sorted, 0, $limit, true);
    }

    public function getAll() {
        return $this->balances;
    }
}