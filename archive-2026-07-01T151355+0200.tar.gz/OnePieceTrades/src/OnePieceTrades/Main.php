<?php

namespace OnePieceTrades;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\inventory\InventoryCloseEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\entity\Entity;
use pocketmine\scheduler\Task;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\network\protocol\RemoveEntityPacket;
use pocketmine\network\protocol\SetEntityLinkPacket;
use pocketmine\network\protocol\Info as ProtocolInfo;
use OnePieceTrades\Factory\FactoryManager;
use OnePieceTrades\Factory\FactoryEntity;
use OnePieceTrades\Factory\FactoryListener;
use OnePieceTrades\Factory\FactoryCommand;

class Main extends PluginBase implements Listener {

    private $tradeManager;
    private $factoryManager;
    private $pendingSet = [];
    private $seated = [];
    private $seatEntities = [];
    private $tradeSessions = [];
    private $tradeConfirm = [];
    private $tradeItems = [];
    public $suppressReopen = [];
    private $occupiedStations = [];
    private $entityCount = 100000;
    private $prefix = "§e[Trade] §r";

    public function onEnable() {
        @mkdir($this->getDataFolder());
        $this->tradeManager   = new TradeManager($this);
        $this->factoryManager = new FactoryManager($this);
        Entity::registerEntity(FactoryEntity::class, true);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getServer()->getPluginManager()->registerEvents(new TradeGUIListener($this), $this);
        new FactoryListener($this);
        $this->getServer()->getCommandMap()->register("onepiece", new FactoryCommand($this));
        $this->factoryManager->startSchedulers();
        $this->getLogger()->info("OnePieceTrades enabled");
    }

    public function onDisable() {
        foreach ($this->seated as $name => $data) {
            $player = $this->getServer()->getPlayerExact($name);
            if ($player !== null && $player->isOnline()) {
                $this->unseatPlayer($player);
            }
        }
        $this->tradeManager->saveAll();
    }

    public function getTradeManager() {
        return $this->tradeManager;
    }

    public function getFactoryManager() {
        return $this->factoryManager;
    }

    public function getPrefix() {
        return $this->prefix;
    }

    public function tradeDebug($msg) {
        $this->getLogger()->info("[TRADE-DEBUG] " . $msg);
    }

    public function isSuppressReopen(Player $player) {
        return isset($this->suppressReopen[strtolower($player->getName())]);
    }

    private function setSuppressReopen(Player $player) {
        $name = strtolower($player->getName());
        $this->suppressReopen[$name] = true;
        $plugin = $this;
        $this->scheduleTask(function() use ($plugin, $name) {
            unset($plugin->suppressReopen[$name]);
        }, 10);
    }

    public function getSeated() {
        return $this->seated;
    }

    public function getTradeSessions() {
        return $this->tradeSessions;
    }

    public function getTradeConfirm() {
        return $this->tradeConfirm;
    }

    public function getTradeItems() {
        return $this->tradeItems;
    }

    public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
        if ($command->getName() !== "optrade") return false;
        if (!($sender instanceof Player)) {
            $sender->sendMessage($this->prefix . "Use this in-game.");
            return true;
        }

        if (count($args) === 0) {
            $sender->sendMessage($this->prefix . "§f/optrade create <name>");
            $sender->sendMessage($this->prefix . "§f/optrade set <1|2>");
            $sender->sendMessage($this->prefix . "§f/optrade edit <oldname> <newname>");
            $sender->sendMessage($this->prefix . "§f/optrade delete <name>");
            $sender->sendMessage($this->prefix . "§f/optrade list");
            return true;
        }

        $sub = strtolower($args[0]);

        switch ($sub) {
            case "create":
                if (!isset($args[1])) {
                    $sender->sendMessage($this->prefix . "§cUsage: /optrade create <name>");
                    return true;
                }
                $name = implode(" ", array_slice($args, 1));
                if ($this->tradeManager->stationExists($name)) {
                    $sender->sendMessage($this->prefix . "§cA station with that name already exists.");
                    return true;
                }
                $this->tradeManager->createStation($name, $sender->getName());
                $sender->sendMessage($this->prefix . "§aStation §e" . $name . " §acreated. Use /optrade set 1 and /optrade set 2 to set seats.");
                break;

            case "set":
                if (!isset($args[1])) {
                    $sender->sendMessage($this->prefix . "§cUsage: /optrade set <1|2>");
                    return true;
                }
                $seatNum = $args[1];
                if ($seatNum !== "1" && $seatNum !== "2") {
                    $sender->sendMessage($this->prefix . "§cSeat must be 1 or 2.");
                    return true;
                }
                $station = $this->tradeManager->getLastCreatedBy($sender->getName());
                if ($station === null) {
                    $sender->sendMessage($this->prefix . "§cCreate a station first.");
                    return true;
                }
                $this->pendingSet[strtolower($sender->getName())] = [
                    "station" => $station,
                    "seat" => (int)$seatNum
                ];
                $sender->sendMessage($this->prefix . "§aTap a stairs block to set seat " . $seatNum . " for station §e" . $station . "§a.");
                break;

            case "edit":
                if (!isset($args[1]) || !isset($args[2])) {
                    $sender->sendMessage($this->prefix . "§cUsage: /optrade edit <oldname> <newname>");
                    return true;
                }
                $oldName = $args[1];
                $newName = implode(" ", array_slice($args, 2));
                if (!$this->tradeManager->stationExists($oldName)) {
                    $sender->sendMessage($this->prefix . "§cStation not found.");
                    return true;
                }
                if ($this->tradeManager->stationExists($newName)) {
                    $sender->sendMessage($this->prefix . "§cA station with that name already exists.");
                    return true;
                }
                $this->tradeManager->renameStation($oldName, $newName);
                $sender->sendMessage($this->prefix . "§aRenamed §e" . $oldName . " §ato §e" . $newName . "§a.");
                break;

            case "delete":
                if (!isset($args[1])) {
                    $sender->sendMessage($this->prefix . "§cUsage: /optrade delete <name>");
                    return true;
                }
                $name = implode(" ", array_slice($args, 1));
                if (!$this->tradeManager->stationExists($name)) {
                    $sender->sendMessage($this->prefix . "§cStation not found.");
                    return true;
                }
                $this->tradeManager->deleteStation($name);
                $sender->sendMessage($this->prefix . "§aStation §e" . $name . " §adeleted.");
                break;

            case "list":
                $stations = $this->tradeManager->getAllStations();
                if (empty($stations)) {
                    $sender->sendMessage($this->prefix . "§cNo trade stations.");
                    return true;
                }
                $sender->sendMessage($this->prefix . "§6Trade Stations:");
                foreach ($stations as $sName => $data) {
                    $s1 = isset($data["seat1"]) ? "§aSet" : "§cNot Set";
                    $s2 = isset($data["seat2"]) ? "§aSet" : "§cNot Set";
                    $sender->sendMessage("§e- " . $data["name"] . " §7| Seat1: " . $s1 . " §7| Seat2: " . $s2);
                }
                break;

            default:
                $sender->sendMessage($this->prefix . "§cUnknown subcommand.");
        }

        return true;
    }

    public function onInteract(PlayerInteractEvent $event) {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $name = strtolower($player->getName());

        if (isset($this->pendingSet[$name])) {
            $event->setCancelled(true);
            if ($this->isStairsBlock($block->getId())) {
                $pending = $this->pendingSet[$name];
                $pos = [
                    "x" => $block->getFloorX(),
                    "y" => $block->getFloorY(),
                    "z" => $block->getFloorZ(),
                    "level" => $block->getLevel()->getFolderName()
                ];
                $this->tradeManager->setSeat($pending["station"], $pending["seat"], $pos);
                $player->sendMessage($this->prefix . "§aSeat " . $pending["seat"] . " set for station §e" . $pending["station"] . "§a.");
                unset($this->pendingSet[$name]);
            } else {
                $player->sendMessage($this->prefix . "§cThat is not a stairs block.");
            }
            return;
        }

        if ($this->isStairsBlock($block->getId())) {
            $station = $this->tradeManager->getStationBySeat($block->getFloorX(), $block->getFloorY(), $block->getFloorZ(), $block->getLevel()->getFolderName());
            if ($station !== null) {
                $event->setCancelled(true);
                if (isset($this->seated[$name])) {
                    return;
                }
                $seatNum = $station["seat"];
                $stationName = $station["name"];
                $currentOccupant = $this->getSeatOccupant($stationName, $seatNum);
                if ($currentOccupant !== null) {
                    $player->sendMessage($this->prefix . "§cThis seat is already occupied.");
                    return;
                }
                if (isset($this->occupiedStations[$stationName])) {
                    $player->sendMessage($this->prefix . "§cThis trade station is currently in use.");
                    return;
                }
                $this->seatPlayer($player, $stationName, $seatNum, $block);
            }
        }
    }

    public function isStairsBlock($id) {
        $stairs = [53, 67, 108, 109, 114, 128, 134, 135, 136, 156, 163, 164, 180];
        return in_array($id, $stairs);
    }

    public function seatPlayer(Player $player, $stationName, $seatNum, Block $block) {
        $this->tradeDebug($player->getName() . " SAT at station '" . $stationName . "' seat " . $seatNum);
        $name = strtolower($player->getName());

        $this->entityCount++;
        $eid = $this->entityCount;

        $seatX = $block->getFloorX() + 0.5;
        $seatY = $block->getFloorY() + 0.3;
        $seatZ = $block->getFloorZ() + 0.5;

        $pk = new AddEntityPacket();
        $pk->eid = $eid;
        $pk->type = 84;
        $pk->x = $seatX;
        $pk->y = $seatY;
        $pk->z = $seatZ;
        $pk->speedX = 0;
        $pk->speedY = 0;
        $pk->speedZ = 0;
        $pk->yaw = $player->yaw;
        $pk->pitch = $player->pitch;
        $pk->metadata = [
            0 => [0, 1 << 5],
            2 => [Entity::DATA_TYPE_STRING, ""],
            Entity::DATA_SHOW_NAMETAG => [0, 1],
            15 => [0, 1]
        ];

        $players = Server::getInstance()->getOnlinePlayers();
        Server::broadcastPacket($players, $pk);

        $ppk = new SetEntityLinkPacket();
        $ppk->from = $eid;
        $ppk->to = 0;
        $ppk->type = 2;
        $player->dataPacket($ppk);

        $pkc = new SetEntityLinkPacket();
        $pkc->from = $eid;
        $pkc->to = $player->getId();
        $pkc->type = 2;
        Server::broadcastPacket($players, $pkc);

        $this->seatEntities[$name] = $eid;

        $this->seated[$name] = [
            "station"  => $stationName,
            "seat"     => $seatNum,
            "sit_time" => microtime(true),
            "pos"      => [
                "x" => $player->getX(),
                "y" => $player->getY(),
                "z" => $player->getZ()
            ],
            "level" => $player->getLevel()->getFolderName()
        ];

        $player->sendMessage($this->prefix . "§aYou sat down at §e" . $stationName . " §aSeat " . $seatNum . ".");
        $player->sendMessage($this->prefix . "§7Jump to stand up.");

        $otherSeatNum = $seatNum === 1 ? 2 : 1;
        $otherPlayer = $this->getSeatOccupant($stationName, $otherSeatNum);
        if ($otherPlayer !== null) {
            $other = $this->getServer()->getPlayerExact($otherPlayer);
            if ($other !== null && $other->isOnline()) {
                $this->startTrade($player, $other, $stationName);
            }
        }
    }

    public function unseatPlayer(Player $player) {
        $this->tradeDebug($player->getName() . " UNSEAT");
        $name = strtolower($player->getName());
        if (!isset($this->seated[$name])) return;

        $this->setSuppressReopen($player);

        $data = $this->seated[$name];

        if (isset($this->seatEntities[$name])) {
            $eid = $this->seatEntities[$name];

            $ppk = new SetEntityLinkPacket();
            $ppk->from = $eid;
            $ppk->to = 0;
            $ppk->type = 0;
            $player->dataPacket($ppk);

            $pkc = new SetEntityLinkPacket();
            $pkc->from = $eid;
            $pkc->to = $player->getId();
            $pkc->type = 0;
            $players = Server::getInstance()->getOnlinePlayers();
            Server::broadcastPacket($players, $pkc);

            $rpk = new RemoveEntityPacket();
            $rpk->eid = $eid;
            Server::broadcastPacket($players, $rpk);

            unset($this->seatEntities[$name]);
        }

        $level = $this->getServer()->getLevelByName($data["level"]);
        if ($level !== null) {
            $player->teleport(new Vector3($data["pos"]["x"], $data["pos"]["y"] + 1, $data["pos"]["z"]));
        }

        $stationName = $data["station"];
        unset($this->seated[$name]);

        $player->sendMessage($this->prefix . "§eYou stood up.");

        $this->cancelTradeByPlayer($player);
    }

    public function onPacketReceive(DataPacketReceiveEvent $event) {
        $pk = $event->getPacket();
        if ($pk::NETWORK_ID === ProtocolInfo::INTERACT_PACKET) {
            $player = $event->getPlayer();
            $name = strtolower($player->getName());
            if (isset($this->seated[$name])) {
                if ($pk->action === 3) {
                    $this->unseatPlayer($player);
                }
            }
        }
    }

    /**
     * @EventHandler
     */
    public function onPlayerMove(PlayerMoveEvent $event) {
        $player = $event->getPlayer();
        $name   = strtolower($player->getName());
        if (!isset($this->seated[$name])) return;

        if ((microtime(true) - $this->seated[$name]["sit_time"]) < 1.5) return;

        $from = $event->getFrom();
        $to   = $event->getTo();

        $dx = $to->x - $from->x;
        $dz = $to->z - $from->z;

        if (($dx * $dx + $dz * $dz) > 0.0025) {
            $this->unseatPlayer($player);
        }
    }

    public function getSeatOccupant($stationName, $seatNum) {
        foreach ($this->seated as $pName => $data) {
            if ($data["station"] === $stationName && $data["seat"] === $seatNum) {
                return $pName;
            }
        }
        return null;
    }

    public function startTrade(Player $p1, Player $p2, $stationName) {
        $this->tradeDebug("SESSION START: " . $p1->getName() . " <-> " . $p2->getName() . " at '" . $stationName . "'");
        $n1 = strtolower($p1->getName());
        $n2 = strtolower($p2->getName());

        $sessionId = $stationName . "_" . time();

        $this->tradeSessions[$n1] = [
            "session" => $sessionId,
            "partner" => $n2,
            "station" => $stationName
        ];
        $this->tradeSessions[$n2] = [
            "session" => $sessionId,
            "partner" => $n1,
            "station" => $stationName
        ];

        $this->tradeConfirm[$n1] = false;
        $this->tradeConfirm[$n2] = false;

        $this->tradeItems[$n1] = [];
        $this->tradeItems[$n2] = [];

        $this->occupiedStations[$stationName] = true;

        $p1->sendMessage($this->prefix . "§aTrade started with §e" . $p2->getName() . "§a!");
        $p2->sendMessage($this->prefix . "§aTrade started with §e" . $p1->getName() . "§a!");

        $this->unseatPlayerSilent($p1);
        $this->unseatPlayerSilent($p2);

        $plugin = $this;
        $this->scheduleTask(function() use ($plugin, $p1, $p2) {
            if ($p1->isOnline() && $p2->isOnline()) {
                $plugin->openTradeMenu($p1);
                $plugin->openTradeMenu($p2);
            }
        }, 15);
    }

    public function unseatPlayerSilent(Player $player) {
        $name = strtolower($player->getName());
        if (!isset($this->seated[$name])) return;

        $this->setSuppressReopen($player);

        $data = $this->seated[$name];

        if (isset($this->seatEntities[$name])) {
            $eid = $this->seatEntities[$name];

            $ppk = new SetEntityLinkPacket();
            $ppk->from = $eid;
            $ppk->to = 0;
            $ppk->type = 0;
            $player->dataPacket($ppk);

            $pkc = new SetEntityLinkPacket();
            $pkc->from = $eid;
            $pkc->to = $player->getId();
            $pkc->type = 0;
            $players = Server::getInstance()->getOnlinePlayers();
            Server::broadcastPacket($players, $pkc);

            $rpk = new RemoveEntityPacket();
            $rpk->eid = $eid;
            Server::broadcastPacket($players, $rpk);

            unset($this->seatEntities[$name]);
        }

        $level = $this->getServer()->getLevelByName($data["level"]);
        if ($level !== null) {
            $player->teleport(new Vector3($data["pos"]["x"], $data["pos"]["y"] + 1, $data["pos"]["z"]));
        }

        unset($this->seated[$name]);
    }

    public function openTradeMenu(Player $player) {
        $name = strtolower($player->getName());
        if (!isset($this->tradeSessions[$name])) return;

        $session = $this->tradeSessions[$name];
        $partnerName = $session["partner"];
        $partner = $this->getServer()->getPlayerExact($partnerName);
        if ($partner === null) return;

        $title = "§8Trade: §e" . $player->getName() . " §7vs §e" . $partner->getName();
        $inventory = new TradeInventory($player, $title);
        $this->setupTradeMenu($player, $inventory);

        TradeGUIListener::setWindow($player, [
            "type" => "trade",
            "inventory" => $inventory
        ]);

        $player->addWindow($inventory);
    }

    public function openStoragePickerMenu(Player $player, $targetSlotIndex) {
        $name = strtolower($player->getName());
        if (!isset($this->tradeSessions[$name])) return;

        $title = "§6Pick a fruit to offer (Slot " . ($targetSlotIndex + 1) . ")";
        $inventory = new TradeInventory($player, $title);
        $this->setupStoragePickerMenu($player, $inventory);

        TradeGUIListener::setWindow($player, [
            "type" => "storage_picker",
            "inventory" => $inventory,
            "target_slot" => $targetSlotIndex
        ]);

        $player->addWindow($inventory);
    }

    public function setupStoragePickerMenu(Player $player, TradeInventory $inventory) {
        $pane = Item::get(102, 0, 1);
        $pane->setCustomName(" ");
        for ($i = 0; $i < 27; $i++) {
            $inventory->setItem($i, clone $pane);
        }

        $infoItem = Item::get(Item::PAPER, 0, 1);
        $infoItem->setCustomName("§eClick a fruit from your storage to offer.\n§7Use /storage to deposit fruits first.");
        $inventory->setItem(4, $infoItem);

        $devilPlugin = $this->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        $berryPlugin = $this->getServer()->getPluginManager()->getPlugin("OnePieceBerry");

        $slot = 9;
        $hasAny = false;

        if ($berryPlugin !== null && $berryPlugin->isEnabled()) {
            $fs = $berryPlugin->getFruitStorage();
            $storedFruits = $fs->getStorage($player->getName());

            foreach ($storedFruits as $i => $fruitId) {
                $display = $fruitId;
                $color   = "§f";
                if ($devilPlugin !== null) {
                    $fruit = $devilPlugin->getFruitManager()->getFruit($fruitId);
                    if ($fruit !== null) {
                        $display = $fruit->getDisplayName();
                        $color   = $fruit->getRarityColor();
                    }
                }
                $fruitItem = Item::get(Item::GOLDEN_APPLE, 0, 1);
                $fruitItem->setCustomName($color . $display . "\n§7[Storage Slot " . ($i + 1) . "]");
                $inventory->setItem($slot, $fruitItem);
                $slot++;
                $hasAny = true;
                if ($slot >= 26) break;
            }
        }

        if (!$hasAny) {
            $noneItem = Item::get(Item::IRON_BARS, 0, 1);
            $noneItem->setCustomName("§cNo fruits in storage! Use /storage to deposit fruits.");
            $inventory->setItem(13, $noneItem);
        }

        $backItem = Item::get(Item::DYE, 1, 1);
        $backItem->setCustomName("§c[BACK] Return to trade");
        $inventory->setItem(26, $backItem);
    }

    public function setupTradeMenu(Player $player, TradeInventory $inventory) {
        $name = strtolower($player->getName());
        $session = $this->tradeSessions[$name] ?? null;
        if ($session === null) return;

        $partnerName = $session["partner"];
        $myConfirm = $this->tradeConfirm[$name] ?? false;
        $partnerConfirm = $this->tradeConfirm[$partnerName] ?? false;

        $pane = Item::get(102, 0, 1);
        $pane->setCustomName(" ");

        $separator = Item::get(Item::IRON_BARS, 0, 1);
        $separator->setCustomName("§7|");

        for ($i = 0; $i < 27; $i++) {
            $inventory->setItem($i, clone $pane);
        }

        $inventory->setItem(4, clone $separator);
        $inventory->setItem(13, clone $separator);
        $inventory->setItem(22, clone $separator);

        $myLabel = Item::get(Item::SKULL, 3, 1);
        $myLabel->setCustomName("§a" . $player->getName() . "'s Offer");
        $inventory->setItem(0, $myLabel);

        $partner = $this->getServer()->getPlayerExact($partnerName);
        $theirName = $partner !== null ? $partner->getName() : $partnerName;
        $theirLabel = Item::get(Item::SKULL, 3, 1);
        $theirLabel->setCustomName("§c" . $theirName . "'s Offer");
        $inventory->setItem(8, $theirLabel);

        $myItems = $this->tradeItems[$name] ?? [];
        $mySlots = [1, 2];
        foreach ($mySlots as $idx => $slot) {
            if (isset($myItems[$idx])) {
                $inventory->setItem($slot, clone $myItems[$idx]);
            } else {
                $empty = Item::get(Item::DYE, 8, 1);
                $empty->setCustomName("§7[Slot " . ($idx + 1) . "] §eClick to select a fruit");
                $inventory->setItem($slot, $empty);
            }
        }

        $storageItem = Item::get(Item::CHEST, 0, 1);
        $storageItem->setCustomName("§b[STORAGE] Open storage picker\n§7(or click an empty fruit slot directly)");
        $inventory->setItem(3, $storageItem);

        $partnerItems = $this->tradeItems[$partnerName] ?? [];
        $theirSlots = [5, 6];
        foreach ($theirSlots as $idx => $slot) {
            if (isset($partnerItems[$idx])) {
                $inventory->setItem($slot, clone $partnerItems[$idx]);
            } else {
                $empty = Item::get(Item::IRON_BARS, 0, 1);
                $empty->setCustomName("§7[Empty]");
                $inventory->setItem($slot, $empty);
            }
        }

        if ($myConfirm) {
            $confirmItem = Item::get(Item::DYE, 10, 1);
            $confirmItem->setCustomName("§aYou CONFIRMED");
        } else {
            $confirmItem = Item::get(Item::DYE, 8, 1);
            $confirmItem->setCustomName("§eClick to CONFIRM trade");
        }
        $inventory->setItem(12, $confirmItem);

        if ($partnerConfirm) {
            $partnerStatus = Item::get(Item::DYE, 10, 1);
            $partnerStatus->setCustomName("§a" . $theirName . " CONFIRMED");
        } else {
            $partnerStatus = Item::get(Item::DYE, 8, 1);
            $partnerStatus->setCustomName("§7Waiting for " . $theirName . "...");
        }
        $inventory->setItem(14, $partnerStatus);

        $cancelItem = Item::get(Item::BED, 14, 1);
        $cancelItem->setCustomName("§cCancel Trade");
        $inventory->setItem(26, $cancelItem);
    }

    public function refreshPartnerMenu(Player $player) {
        $name = strtolower($player->getName());
        if (!isset($this->tradeSessions[$name])) return;

        $partnerName = $this->tradeSessions[$name]["partner"];
        $partner = $this->getServer()->getPlayerExact($partnerName);
        if ($partner === null || !$partner->isOnline()) return;

        $window = TradeGUIListener::getWindow($partner);
        if ($window === null || !isset($window["inventory"])) return;
        if ($window["type"] !== "trade") return;

        $this->setupTradeMenu($partner, $window["inventory"]);
        $window["inventory"]->sendContents($partner);
    }

    public function refreshOwnMenu(Player $player) {
        $window = TradeGUIListener::getWindow($player);
        if ($window === null || !isset($window["inventory"])) return;

        $this->setupTradeMenu($player, $window["inventory"]);
        $window["inventory"]->sendContents($player);
    }

    public function handleTradeConfirm(Player $player) {
        $this->tradeDebug($player->getName() . " CONFIRMED trade");
        $name = strtolower($player->getName());
        if (!isset($this->tradeSessions[$name])) return;

        $this->tradeConfirm[$name] = true;
        $partnerName = $this->tradeSessions[$name]["partner"];

        $player->sendMessage($this->prefix . "§aYou confirmed the trade.");

        $partner = $this->getServer()->getPlayerExact($partnerName);
        if ($partner !== null && $partner->isOnline()) {
            $partner->sendMessage($this->prefix . "§e" . $player->getName() . " §aconfirmed the trade.");
        }

        $this->refreshOwnMenu($player);
        $this->refreshPartnerMenu($player);

        if (($this->tradeConfirm[$partnerName] ?? false) === true) {
            $this->executeTrade($player, $partner);
        }
    }

    public function executeTrade(Player $p1, Player $p2) {
        $this->tradeDebug("=== TRADE EXECUTING ===");
        $this->tradeDebug("Player A: " . $p1->getName());
        $this->tradeDebug("Player B: " . $p2->getName());
        $n1 = strtolower($p1->getName());
        $n2 = strtolower($p2->getName());
        $dbgItems1 = isset($this->tradeItems[$n1]) ? $this->tradeItems[$n1] : [];
        $dbgItems2 = isset($this->tradeItems[$n2]) ? $this->tradeItems[$n2] : [];
        foreach ($dbgItems1 as $si => $di) {
            if ($di->getId() !== Item::AIR) {
                $df = $di->getNamedTagEntry("trade_fruit_id");
                $ds = $di->getNamedTagEntry("trade_source");
                $this->tradeDebug("  " . $p1->getName() . " offers slot " . $si . ": " . ($df !== null ? $df->getValue() : "item:" . $di->getId()) . " from " . ($ds !== null ? $ds->getValue() : "unknown"));
            }
        }
        foreach ($dbgItems2 as $si => $di) {
            if ($di->getId() !== Item::AIR) {
                $df = $di->getNamedTagEntry("trade_fruit_id");
                $ds = $di->getNamedTagEntry("trade_source");
                $this->tradeDebug("  " . $p2->getName() . " offers slot " . $si . ": " . ($df !== null ? $df->getValue() : "item:" . $di->getId()) . " from " . ($ds !== null ? $ds->getValue() : "unknown"));
            }
        }
        $n1 = strtolower($p1->getName());
        $n2 = strtolower($p2->getName());

        $items1 = $this->tradeItems[$n1] ?? [];
        $items2 = $this->tradeItems[$n2] ?? [];

        if (empty($items1) && empty($items2)) {
            $p1->sendMessage($this->prefix . "§cTrade cancelled. No fruits offered.");
            $p2->sendMessage($this->prefix . "§cTrade cancelled. No fruits offered.");
            $this->cleanupTrade($p1, $p2);
            return;
        }

        $this->deliverFruitsToPlayer($p2, $items1);
        $this->deliverFruitsToPlayer($p1, $items2);

        $p1->sendMessage($this->prefix . "§aTrade completed successfully!");
        $p2->sendMessage($this->prefix . "§aTrade completed successfully!");

        $this->cleanupTrade($p1, $p2);
    }

    private function deliverFruitsToPlayer(Player $recipient, array $items) {
        $this->tradeDebug("Delivering " . count($items) . " items to " . $recipient->getName());
        $berryPlugin = $this->getServer()->getPluginManager()->getPlugin("OnePieceBerry");
        $devilPlugin = $this->getServer()->getPluginManager()->getPlugin("OnePieceDevil");

        foreach ($items as $item) {
            if ($item->getId() === Item::AIR) continue;

            $fruitTag = $item->getNamedTagEntry("trade_fruit_id");
            $fruitId = $fruitTag !== null ? $fruitTag->getValue() : null;

            if ($fruitId === null) {
                $recipient->getInventory()->addItem(clone $item);
                continue;
            }

            if ($berryPlugin !== null && $berryPlugin->isEnabled()) {
                $fs = $berryPlugin->getFruitStorage();
                if ($fs->hasSpace($recipient->getName())) {
                    $fs->addFruit($recipient->getName(), $fruitId);
                    $display = $fruitId;
                    if ($devilPlugin !== null) {
                        $fruit = $devilPlugin->getFruitManager()->getFruit($fruitId);
                        if ($fruit !== null) $display = $fruit->getDisplayName();
                    }
                    $recipient->sendMessage($this->prefix . "§aReceived §f" . $display . " §a→ added to your storage.");
                    $this->tradeDebug("  -> " . $recipient->getName() . " received '" . $fruitId . "' -> STORAGE");
                    continue;
                }
            }

            if ($devilPlugin !== null && $devilPlugin->isEnabled()) {
                $fm = $devilPlugin->getFruitManager();
                if (!$fm->playerHasFruit($recipient)) {
                    $fm->giveFruitToPlayer($recipient, $fruitId);
                    $display = $fruitId;
                    $fruit = $fm->getFruit($fruitId);
                    if ($fruit !== null) $display = $fruit->getDisplayName();
                    $recipient->sendMessage($this->prefix . "§aReceived §f" . $display . " §a→ equipped.");
                    $this->tradeDebug("  -> " . $recipient->getName() . " received '" . $fruitId . "' -> EQUIPPED");
                    continue;
                }
            }

            $fruitItem = Item::get(Item::GOLDEN_APPLE, 0, 1);
            $fruitId2 = $fruitId;
            $color = "§f";
            if ($devilPlugin !== null) {
                $fruit = $devilPlugin->getFruitManager()->getFruit($fruitId2);
                if ($fruit !== null) {
                    $fruitItem->setCustomName($fruit->getRarityColor() . $fruit->getDisplayName());
                    $color = $fruit->getRarityColor();
                } else {
                    $fruitItem->setCustomName("§f" . $fruitId2);
                }
            } else {
                $fruitItem->setCustomName("§f" . $fruitId2);
            }
            $recipient->getInventory()->addItem($fruitItem);
            $recipient->sendMessage($this->prefix . "§aReceived fruit → added to inventory (storage full).");
            $this->tradeDebug("  -> " . $recipient->getName() . " received '" . $fruitId2 . "' -> INVENTORY (storage full)");
        }
    }

    private function returnFruitsToPlayer(Player $player, array $items) {
        $this->tradeDebug("Returning " . count($items) . " items to " . $player->getName());
        $berryPlugin = $this->getServer()->getPluginManager()->getPlugin("OnePieceBerry");
        $devilPlugin = $this->getServer()->getPluginManager()->getPlugin("OnePieceDevil");

        foreach ($items as $item) {
            if ($item->getId() === Item::AIR) continue;

            $sourceTag = $item->getNamedTagEntry("trade_source");
            $fruitTag = $item->getNamedTagEntry("trade_fruit_id");
            $source = $sourceTag !== null ? $sourceTag->getValue() : null;
            $fruitId = $fruitTag !== null ? $fruitTag->getValue() : null;

            if ($source === "equipped" && $fruitId !== null && $devilPlugin !== null) {
                $devilPlugin->getFruitManager()->giveFruitToPlayer($player, $fruitId);
                continue;
            }

            if ($source !== null && strpos($source, "storage:") === 0 && $fruitId !== null && $berryPlugin !== null) {
                $berryPlugin->getFruitStorage()->addFruit($player->getName(), $fruitId);
                continue;
            }

            $player->getInventory()->addItem(clone $item);
        }
    }

    public function cleanupTrade(Player $p1, Player $p2) {
        $this->tradeDebug("CLEANUP: " . $p1->getName() . " <-> " . $p2->getName());
        $n1 = strtolower($p1->getName());
        $n2 = strtolower($p2->getName());

        $this->setSuppressReopen($p1);
        $this->setSuppressReopen($p2);

        $stationName = isset($this->tradeSessions[$n1]) ? $this->tradeSessions[$n1]["station"] : null;
        if ($stationName !== null) {
            unset($this->occupiedStations[$stationName]);
        }

        $w1 = TradeGUIListener::getWindow($p1);
        $w2 = TradeGUIListener::getWindow($p2);

        if ($w1 !== null && isset($w1["inventory"])) {
            $p1->removeWindow($w1["inventory"]);
        }
        if ($w2 !== null && isset($w2["inventory"])) {
            $p2->removeWindow($w2["inventory"]);
        }

        TradeGUIListener::removeWindow($p1);
        TradeGUIListener::removeWindow($p2);

        unset($this->tradeSessions[$n1]);
        unset($this->tradeSessions[$n2]);
        unset($this->tradeConfirm[$n1]);
        unset($this->tradeConfirm[$n2]);
        unset($this->tradeItems[$n1]);
        unset($this->tradeItems[$n2]);

        $plugin = $this;
        $this->scheduleTask(function() use ($plugin, $p1, $p2) {
            if ($p1->isOnline() && isset($plugin->getSeated()[strtolower($p1->getName())])) {
                $plugin->unseatPlayer($p1);
            }
            if ($p2->isOnline() && isset($plugin->getSeated()[strtolower($p2->getName())])) {
                $plugin->unseatPlayer($p2);
            }
        }, 10);
    }

    public function cancelTradeByPlayer(Player $player) {
        $name = strtolower($player->getName());
        if (!isset($this->tradeSessions[$name])) return;
        $this->tradeDebug($player->getName() . " CANCELLED trade (partner: " . $this->tradeSessions[$name]["partner"] . ")");

        $this->setSuppressReopen($player);
        $partnerName = $this->tradeSessions[$name]["partner"];
        $stationName = $this->tradeSessions[$name]["station"] ?? null;
        if ($stationName !== null) {
            unset($this->occupiedStations[$stationName]);
        }
        $partner = $this->getServer()->getPlayerExact($partnerName);

        $myItems = $this->tradeItems[$name] ?? [];
        $this->returnFruitsToPlayer($player, $myItems);

        if ($partner !== null && $partner->isOnline()) {
            $this->setSuppressReopen($partner);
            $partnerItems = $this->tradeItems[$partnerName] ?? [];
            $this->returnFruitsToPlayer($partner, $partnerItems);

            $w2 = TradeGUIListener::getWindow($partner);
            if ($w2 !== null && isset($w2["inventory"])) {
                $partner->removeWindow($w2["inventory"]);
            }
            TradeGUIListener::removeWindow($partner);

            $partner->sendMessage($this->prefix . "§c" . $player->getName() . " cancelled the trade.");

            $pn = strtolower($partner->getName());
            unset($this->tradeSessions[$pn]);
            unset($this->tradeConfirm[$pn]);
            unset($this->tradeItems[$pn]);

            if (isset($this->seated[$pn])) {
                $this->unseatPlayer($partner);
            }
        }

        $w1 = TradeGUIListener::getWindow($player);
        if ($w1 !== null && isset($w1["inventory"])) {
            $player->removeWindow($w1["inventory"]);
        }
        TradeGUIListener::removeWindow($player);

        unset($this->tradeSessions[$name]);
        unset($this->tradeConfirm[$name]);
        unset($this->tradeItems[$name]);

        $player->sendMessage($this->prefix . "§cTrade cancelled. Items returned.");
    }

    public function onPlayerQuit(PlayerQuitEvent $event) {
        $player = $event->getPlayer();
        $name = strtolower($player->getName());

        if (isset($this->tradeSessions[$name])) {
            $this->tradeDebug($player->getName() . " DISCONNECTED during trade (partner: " . $this->tradeSessions[$name]["partner"] . ")");
            $this->cancelTradeByPlayer($player);
        }

        if (isset($this->seated[$name])) {
            if (isset($this->seatEntities[$name])) {
                $eid = $this->seatEntities[$name];
                $rpk = new RemoveEntityPacket();
                $rpk->eid = $eid;
                Server::broadcastPacket(Server::getInstance()->getOnlinePlayers(), $rpk);
                unset($this->seatEntities[$name]);
            }
            unset($this->seated[$name]);
        }

        unset($this->pendingSet[$name]);
    }

    public function onDamage(EntityDamageEvent $event) {
        $entity = $event->getEntity();
        if ($entity instanceof Player) {
            $name = strtolower($entity->getName());
            if (isset($this->seated[$name]) || isset($this->tradeSessions[$name])) {
                $event->setCancelled(true);
            }
        }
        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof Player) {
                $dName = strtolower($damager->getName());
                if (isset($this->seated[$dName]) || isset($this->tradeSessions[$dName])) {
                    $event->setCancelled(true);
                }
            }
        }
    }

    public function onBlockBreak(BlockBreakEvent $event) {
        $block = $event->getBlock();
        $station = $this->tradeManager->getStationBySeat(
            $block->getFloorX(), $block->getFloorY(), $block->getFloorZ(),
            $block->getLevel()->getFolderName()
        );
        if ($station !== null) {
            $event->setCancelled(true);
            $event->getPlayer()->sendMessage($this->prefix . "§cThis block is a trade seat. Remove the station first.");
        }
    }

    public function isTradeableItem(Item $item) {
        if ($item->getId() === Item::AIR) return false;
        return true;
    }

    public function scheduleTask(callable $callable, int $delay) {
        Server::getInstance()->getScheduler()->scheduleDelayedTask(new class($callable) extends Task {
            private $callable;
            public function __construct(callable $callable) {
                $this->callable = $callable;
            }
            public function onRun($currentTick) {
                $callable = $this->callable;
                $callable();
            }
        }, $delay);
    }
}