<?php

namespace OnePieceRaid\Awaken;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\utils\Config;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\LargeExplodeParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\particle\InstantEnchantParticle;
use pocketmine\level\particle\EnchantParticle;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ShortTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\entity\Entity;
use OnePiece\NPC\NPCEntity;
use OnePieceRaid\Main;
use OnePieceRaid\Awaken\AwakenRoundTask;
use OnePieceRaid\Awaken\AwakenCleanupTask;
use OnePieceRaid\Awaken\AwakenStartCountdownTask;
use OnePieceRaid\Awaken\AwakenBossAbilityTask;

class AwakenManager {

    private $plugin;
    private $config;
    private $playerData;
    private $raids       = [];
    private $instances   = [];
    private $joinZones   = [];
    private $awakenSpawn = null;

    const ROUNDS          = 5;
    const NPC_LEVEL_MIN   = 350;
    const NPC_LEVEL_MAX   = 400;
    const BOSS_LEVEL      = 500;
    const BOSS_HP         = 10000;
    const SPAWN_RADIUS    = 6;
    const MAX_PLAYERS     = 4;
    const MIN_LEVEL       = 400;
    const MIN_MASTERY     = 50;
    const JOIN_RADIUS     = 4.0;
    const LOBBY_COUNTDOWN = 30;
    const ROUND_PAUSE     = 5;
    const RAID_TIME_LIMIT = 600;

    const FRUIT_MAP = [
        "pika_pika"  => "light",
        "hie_hie"    => "ice",
        "magu_magu"  => "magma",
        "yami_yami"  => "dark",
        "suna_suna"  => "sand",
        "gomu_gomu"  => "rubber",
        "mera_mera"  => "flame",
        "mochi_mochi"=> "dough",
        "goro_goro"  => "lightning",
    ];
    private static $THEME_BLOCKS = [
    "ice"       => [[79, 0], [174, 0], [80, 0]],
    "magma"     => [[87, 0], [88, 0], [13, 0]],
    "light"     => [[89, 0], [41, 0], [24, 0]],
    "dark"      => [[49, 0], [173, 0], [35, 15]],
    "sand"      => [[12, 0], [24, 0], [159, 0]],
    "rubber"    => [[165, 0], [35, 5], [35, 13]],
    "flame"     => [[87, 0], [88, 0], [35, 14]],
    "dough"     => [[35, 0], [155, 0], [80, 0]],
    "lightning" => [[57, 0], [35, 3], [20, 0]],
];

public function __construct(Main $plugin) {
    $this->plugin = $plugin;
    $this->config = new Config($plugin->getDataFolder() . "awaken_raids.yml", Config::YAML);
    $this->playerData = new Config($plugin->getDataFolder() . "awaken_data.yml", Config::YAML);
    
    $all = $this->config->getAll();
    $this->awakenSpawn = isset($all["awaken_spawn"]) ? $all["awaken_spawn"] : null;
    $this->joinZones = isset($all["join_zones"]) ? $all["join_zones"] : [];
    
    unset($all["awaken_spawn"], $all["join_zones"]);
    $this->raids = $all;
}

public function isPlayerInAwakenWorld(Player $player) {
    $worldName = $player->getLevel()->getFolderName();
    foreach ($this->instances as $inst) {
        if ($inst["world"] === $worldName) return true;
    }
    return false;
}

public function setRegion($key, $corner, $x, $y, $z, $world) {
    $key = strtolower($key);
    if (!isset($this->raids[$key])) return false;
    $field = "region_pos" . (int)$corner;
    $this->raids[$key][$field] = ["x" => (float)$x, "y" => (float)$y, "z" => (float)$z, "world" => $world];
    $this->saveConfig();
    return true;
}

public function getRegion($key) {
    $key = strtolower($key);
    $raid = $this->raids[$key] ?? null;
    if ($raid === null) return null;
    $p1 = $raid["region_pos1"] ?? null;
    $p2 = $raid["region_pos2"] ?? null;
    if ($p1 === null || $p2 === null) return null;
    return ["pos1" => $p1, "pos2" => $p2];
}

public function applyThemeBlocks($instanceKey) {
    $inst = $this->instances[$instanceKey] ?? null;
    if ($inst === null) return;
    $raidKey = strtolower($inst["raid_key"]);
    $theme = self::$THEME_BLOCKS[$raidKey] ?? null;
    if ($theme === null) return;
    $region = $this->getRegion($raidKey);
    if ($region === null) return;
    $server = Server::getInstance();
    $worldName = $inst["world"];
    if (!$server->isLevelLoaded($worldName)) return;
    $level = $server->getLevelByName($worldName);
    if ($level === null) return;
    $p1 = $region["pos1"];
    $p2 = $region["pos2"];
    $minX = (int)floor(min($p1["x"], $p2["x"]));
    $maxX = (int)floor(max($p1["x"], $p2["x"]));
    $minY = (int)floor(min($p1["y"], $p2["y"]));
    $maxY = (int)floor(max($p1["y"], $p2["y"]));
    $minZ = (int)floor(min($p1["z"], $p2["z"]));
    $maxZ = (int)floor(max($p1["z"], $p2["z"]));
    $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(
        new AwakenThemeTask($this->plugin, $level, $minX, $maxX, $minY, $maxY, $minZ, $maxZ, $theme),
        1
    );
}

public function startSchedulers() {
    $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(
        new AwakenJoinZoneTask($this->plugin), 10
    );
}

public function getBossEntity($instanceKey) {
    $inst = $this->instances[$instanceKey] ?? null;
    if ($inst === null) return null;

    $server = Server::getInstance();
    $level  = $server->getLevelByName($inst["world"]);
    if ($level === null) return null;

    $ids = $inst["entity_ids"] ?? [];

    foreach ($ids as $eid) {
        $entity = $level->getEntity($eid);
        if (!($entity instanceof NPCEntity)) continue;
        if ($entity->closed || !$entity->isAlive()) continue;
        if (isset($entity->npcId) && substr($entity->npcId, -5) === "_boss") {
            return $entity;
        }
    }

    return null;
}

public function saveConfig() {
    $all = $this->raids;
    $all["awaken_spawn"] = $this->awakenSpawn;
    $all["join_zones"] = $this->joinZones;
    $this->config->setAll($all);
    $this->config->save();
}

    public function savePlayerData() {
        $this->playerData->save();
    }

    public function getRaidKeyForFruit($fruitId) {
        return self::FRUIT_MAP[strtolower($fruitId)] ?? null;
    }

    public function getAwakenFruitClass($raidKey) {
        $map = [
            "light"     => "\\OnePieceRaid\\Awaken\\fruits\\AwakenLight",
            "ice"       => "\\OnePieceRaid\\Awaken\\fruits\\AwakenIce",
            "magma"     => "\\OnePieceRaid\\Awaken\\fruits\\AwakenMagma",
            "dark"      => "\\OnePieceRaid\\Awaken\\fruits\\AwakenDark",
            "sand"      => "\\OnePieceRaid\\Awaken\\fruits\\AwakenSand",
            "rubber"    => "\\OnePieceRaid\\Awaken\\fruits\\AwakenRubber",
            "flame"     => "\\OnePieceRaid\\Awaken\\fruits\\AwakenFlame",
            "dough"     => "\\OnePieceRaid\\Awaken\\fruits\\AwakenDough",
            "lightning" => "\\OnePieceRaid\\Awaken\\fruits\\AwakenLightning",
        ];
        return $map[strtolower($raidKey)] ?? null;
    }

    public function raidExists($key) { return isset($this->raids[strtolower($key)]); }
    public function getRaid($key)    { return $this->raids[strtolower($key)] ?? null; }
    public function getAllRaids()    { return $this->raids; }

    public function createRaid($key) {
        $key = strtolower($key);
        if (isset($this->raids[$key])) return false;
        $this->raids[$key] = [
            "world"        => null,
            "round_spawns" => [],
            "boss_spawn"   => null,
            "join_zone"    => null,
            "price_ability1" => 500000,
            "price_ability2" => 1000000,
            "price_item"   => true,
        ];
        $this->saveConfig();
        return true;
    }

    public function setWorld($key, $world) {
        $key = strtolower($key);
        if (!isset($this->raids[$key])) return false;
        $this->raids[$key]["world"] = $world;
        $this->saveConfig();
        return true;
    }

    public function setRoundSpawn($key, $round, $x, $y, $z, $world) {
        $key = strtolower($key);
        if (!isset($this->raids[$key])) return false;
        $this->raids[$key]["round_spawns"][$round] = [
            "x" => (float)$x, "y" => (float)$y, "z" => (float)$z, "world" => $world
        ];
        $this->saveConfig();
        return true;
    }

    public function setBossSpawn($key, $x, $y, $z, $world) {
        $key = strtolower($key);
        if (!isset($this->raids[$key])) return false;
        $this->raids[$key]["boss_spawn"] = [
            "x" => (float)$x, "y" => (float)$y, "z" => (float)$z, "world" => $world
        ];
        $this->saveConfig();
        return true;
    }

public function setJoinZone($number, $x, $y, $z, $world) {
    $this->joinZones[(int)$number] = ["x" => (float)$x, "y" => (float)$y, "z" => (float)$z, "world" => $world];
    $this->saveConfig();
    return true;
}

public function removeJoinZone($number) {
    $n = (int)$number;
    if (!isset($this->joinZones[$n])) return false;
    unset($this->joinZones[$n]);
    $this->saveConfig();
    return true;
}

public function getAllJoinZones() { return $this->joinZones; }

    public function setAwakenSpawn($x, $y, $z, $world) {
        $this->awakenSpawn = ["x" => (float)$x, "y" => (float)$y, "z" => (float)$z, "world" => $world];
        $this->saveConfig();
    }

    public function setPrice($key, $ability, $price) {
        $key = strtolower($key);
        if (!isset($this->raids[$key])) return false;
        $field = "price_" . strtolower($ability);
        $this->raids[$key][$field] = (int)$price;
        $this->saveConfig();
        return true;
    }

public function getPlayerFruitId(Player $player) {
    $devilPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
    if ($devilPlugin === null) return null;
    $fm = $devilPlugin->getFruitManager();
    $fruit = $fm->getPlayerFruit($player);
    if ($fruit === null) return null;
    if (is_object($fruit)) {
        return $fruit->getId();
    }
    return (string)$fruit;
}

    public function getPlayerLevel(Player $player) {
        $statsPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceStats");
        if ($statsPlugin === null) return 0;
        $sp = $statsPlugin->getStatManager()->getStatPlayer($player);
        return $sp !== null ? $sp->getLevel() : 0;
    }

    public function getPlayerMastery(Player $player) {
        $devilPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin === null) return 0;
        $mm = $devilPlugin->getMasteryManager();
        if ($mm === null) return 0;
        return $mm->getLevel($player->getName());
    }

    public function getPlayerBerry(Player $player) {
        $berryPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceBerry");
        if ($berryPlugin === null) return 0;
        return $berryPlugin->getBerryManager()->get($player->getName());
    }

    public function deductBerry(Player $player, $amount) {
        $berryPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceBerry");
        if ($berryPlugin === null) return false;
        $bm = $berryPlugin->getBerryManager();
        if (!$bm->has($player->getName(), $amount)) return false;
        return $bm->remove($player->getName(), $amount);
    }

    public function playerHasDevilFruitItem(Player $player) {
        $inv = $player->getInventory();
        for ($i = 0; $i < $inv->getSize(); $i++) {
            $item = $inv->getItem($i);
            if ($item->getId() === \pocketmine\item\Item::GOLDEN_APPLE && $item->getCount() > 0) {
                return true;
            }
        }
        return false;
    }

    public function removeDevilFruitItem(Player $player) {
        $inv = $player->getInventory();
        for ($i = 0; $i < $inv->getSize(); $i++) {
            $item = $inv->getItem($i);
            if ($item->getId() === \pocketmine\item\Item::GOLDEN_APPLE && $item->getCount() > 0) {
                $inv->setItem($i, \pocketmine\item\Item::get(\pocketmine\item\Item::AIR));
                return true;
            }
        }
        return false;
    }

    public function getPlayerData($playerName) {
        return $this->playerData->get($playerName, []);
    }

    public function getRaidsCompleted($playerName, $raidKey) {
        $raidKey = strtolower($raidKey);
        $data = $this->playerData->get($playerName, []);
        return (int)($data[$raidKey]["raids_done"] ?? 0);
    }

    public function recordRaidCompletion($playerName, $raidKey) {
        $raidKey = strtolower($raidKey);
        $data = $this->playerData->get($playerName, []);
        if (!isset($data[$raidKey])) {
            $data[$raidKey] = ["raids_done" => 0, "ability1" => false, "ability2" => false];
        }
        $data[$raidKey]["raids_done"]++;
        $this->playerData->set($playerName, $data);
        $this->savePlayerData();
    }

    public function hasAbilityAwakened($playerName, $raidKey, $ability) {
        $raidKey = strtolower($raidKey);
        $data = $this->playerData->get($playerName, []);
        return (bool)($data[$raidKey][$ability] ?? false);
    }

    public function setAbilityAwakened($playerName, $raidKey, $ability) {
        $raidKey = strtolower($raidKey);
        $data = $this->playerData->get($playerName, []);
        if (!isset($data[$raidKey])) {
            $data[$raidKey] = ["raids_done" => 0, "ability1" => false, "ability2" => false];
        }
        $data[$raidKey][$ability] = true;
        $this->playerData->set($playerName, $data);
        $this->savePlayerData();
    }

    public function getNextAbilityToAwaken($playerName, $raidKey) {
        if (!$this->hasAbilityAwakened($playerName, $raidKey, "ability1")) return "ability1";
        if (!$this->hasAbilityAwakened($playerName, $raidKey, "ability2")) return "ability2";
        return null;
    }

    public function getNeededRaids($playerName, $raidKey) {
        $next = $this->getNextAbilityToAwaken($playerName, $raidKey);
        if ($next === "ability1") {
            return max(0, 1 - $this->getRaidsCompleted($playerName, $raidKey));
        }
        if ($next === "ability2") {
            return max(0, 2 - $this->getRaidsCompleted($playerName, $raidKey));
        }
        return 0;
    }

    public function isPlayerInInstance($playerName) {
        foreach ($this->instances as $instanceKey => $inst) {
            if (in_array($playerName, $inst["players"])) return true;
        }
        return false;
    }

    public function getInstanceByPlayer($playerName) {
        foreach ($this->instances as $instanceKey => $inst) {
            if (in_array($playerName, $inst["players"])) return $instanceKey;
        }
        return null;
    }

    public function getInstanceData($instanceKey) {
        return $this->instances[$instanceKey] ?? null;
    }

    public function isJoinOpen($raidKey) {
        foreach ($this->instances as $instanceKey => $inst) {
            if ($inst["raid_key"] === strtolower($raidKey) && $inst["phase"] === "lobby") return $instanceKey;
        }
        return null;
    }

public function buyTicket(Player $player, $raidKey, $payWithFruit = false) {
    $raidKey = strtolower($raidKey);
    $pName = $player->getName();

    if (!$this->raidExists($raidKey)) {
        $player->sendMessage("§c[AWAKEN] This raid does not exist.");
        return false;
    }

    $raid = $this->getRaid($raidKey);
    if ($raid["world"] === null) {
        $player->sendMessage("§c[AWAKEN] This raid world has not been configured yet.");
        return false;
    }

    $level = $this->getPlayerLevel($player);
    if ($level < self::MIN_LEVEL) {
        $player->sendMessage("§c[AWAKEN] You must be Level " . self::MIN_LEVEL . " to enter. (You are " . $level . ".)");
        return false;
    }

    if ($this->isPlayerInInstance($pName)) {
        $player->sendMessage("§c[AWAKEN] You are already in an active raid instance.");
        return false;
    }

    if ($payWithFruit) {
        if (!$this->playerHasDevilFruitItem($player)) {
            $player->sendMessage("§c[AWAKEN] You do not have a devil fruit in your inventory.");
            return false;
        }
        $this->removeDevilFruitItem($player);
        $player->sendMessage("§a[AWAKEN] Devil fruit used as raid ticket.");
    } else {
        $price = 500000;
        if (!$this->deductBerry($player, $price)) {
            $player->sendMessage("§c[AWAKEN] You need 500,000 Berry. (Or use /awaken buy " . $raidKey . " fruit)");
            return false;
        }
        $player->sendMessage("§a[AWAKEN] 500,000 Berry paid for raid ticket.");
    }

    $chipName = $this->getChipName($raidKey);

    $existingChipKey = $this->getPlayerHeldChipRaidKey($player);

    if ($existingChipKey !== null) {
        if (strtolower($existingChipKey) === strtolower($raidKey)) {
            $player->sendMessage("§c[AWAKEN] You already have a §e" . $chipName . "'s Chip§c.");
            return false;
        }

        $inv = $player->getInventory();
        for ($i = 0; $i < $inv->getSize(); $i++) {
            $item = $inv->getItem($i);
            if ($item->getId() === \pocketmine\item\Item::PAPER && $item->hasCustomName()) {
                $existingName = $item->getCustomName();
                $existingChipName = $this->getChipName($existingChipKey);
                if (strpos($existingName, $existingChipName . "'s Chip") !== false) {
                    $inv->setItem($i, \pocketmine\item\Item::get(\pocketmine\item\Item::AIR));
                    break;
                }
            }
        }

        $player->sendMessage("§e[AWAKEN] Your §f" . $this->getChipName($existingChipKey) . " Chip §ewas replaced with a §f" . $chipName . " Chip§e.");
    }

    $item = \pocketmine\item\Item::get(\pocketmine\item\Item::PAPER, 0, 1);
    $item->setCustomName("§r§e" . $chipName . "'s Chip");
    $player->getInventory()->addItem($item);
    $player->sendMessage("§a[AWAKEN] You received a §e" . $chipName . " Chip§a. Enter the raid zone to begin.");

    return true;
}

    private function createInstance($raidKey, $ownerName) {
        $raid = $this->getRaid($raidKey);
        if ($raid === null || $raid["world"] === null) return null;

        $templateWorld = $raid["world"];
        $number        = $this->getNextInstanceNumber($raidKey);
        $instanceWorld = $templateWorld . "_awaken_" . $number;

        if (!$this->copyWorld($templateWorld, $instanceWorld)) return null;

        $server = Server::getInstance();
        if (!$server->isLevelLoaded($instanceWorld)) {
            if (!$server->loadLevel($instanceWorld)) return null;
        }

        $instanceKey = $raidKey . "_" . $number;

        $this->instances[$instanceKey] = [
            "raid_key"       => $raidKey,
            "world"          => $instanceWorld,
            "players"        => [$ownerName],
            "owner"          => $ownerName,
            "zone_number"    => null,
            "phase"          => "lobby",
            "countdown"      => self::LOBBY_COUNTDOWN,
            "current_round"  => 0,
            "entity_ids"     => [],
            "alive_count"    => 0,
            "boss_alive"     => false,
            "completions"    => [],
            "number"         => $number,
        ];

        return $instanceKey;
    }

    private function getNextInstanceNumber($raidKey) {
        $server     = Server::getInstance();
        $raid       = $this->getRaid($raidKey);
        $template   = $raid["world"];
        $worldsPath = $server->getDataPath() . "worlds/";
        $i = 1;
        while (is_dir($worldsPath . $template . "_awaken_" . $i)) {
            $i++;
        }
        return $i;
    }

    private function copyWorld($from, $to) {
        $server    = Server::getInstance();
        $worldsPath = $server->getDataPath() . "worlds/";
        $src       = $worldsPath . $from;
        $dst       = $worldsPath . $to;

        if (!is_dir($src)) return false;
        if (is_dir($dst)) return true;

        return $this->recursiveCopy($src, $dst);
    }

    private function recursiveCopy($src, $dst) {
        if (!@mkdir($dst, 0777, true) && !is_dir($dst)) return false;
        $dir = opendir($src);
        if (!$dir) return false;
        while (($file = readdir($dir)) !== false) {
            if ($file === "." || $file === "..") continue;
            $srcFile = $src . "/" . $file;
            $dstFile = $dst . "/" . $file;
            if (is_dir($srcFile)) {
                if (!$this->recursiveCopy($srcFile, $dstFile)) { closedir($dir); return false; }
            } else {
                if (!copy($srcFile, $dstFile)) { closedir($dir); return false; }
            }
        }
        closedir($dir);
        return true;
    }

    public function deleteInstanceWorld($instanceKey) {
        $inst = $this->instances[$instanceKey] ?? null;
        if ($inst === null) return;

        $worldName = $inst["world"];
        $server    = Server::getInstance();

        if ($server->isLevelLoaded($worldName)) {
            $level = $server->getLevelByName($worldName);
            if ($level !== null) {
                foreach ($level->getPlayers() as $p) {
                    $this->teleportToSafety($p);
                }
                $server->unloadLevel($level, true);
            }
        }

        $worldsPath = $server->getDataPath() . "worlds/" . $worldName;
        if (is_dir($worldsPath)) {
            $this->recursiveDelete($worldsPath);
        }

        unset($this->instances[$instanceKey]);
    }

    private function recursiveDelete($dir) {
        if (!is_dir($dir)) return;
        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item === "." || $item === "..") continue;
            $path = $dir . "/" . $item;
            if (is_dir($path)) {
                $this->recursiveDelete($path);
            } else {
                @unlink($path);
            }
        }
        @rmdir($dir);
    }

    private function teleportToJoinZone(Player $player, $raidKey) {
        $raid = $this->getRaid($raidKey);
        if ($raid === null || $raid["join_zone"] === null) return;
        $jz     = $raid["join_zone"];
        $server = Server::getInstance();
        if (!$server->isLevelLoaded($jz["world"])) $server->loadLevel($jz["world"]);
        $level  = $server->getLevelByName($jz["world"]);
        if ($level === null) return;
        $player->teleport(new Vector3($jz["x"], $jz["y"], $jz["z"]), 0, 0);
        $level->addParticle(new PortalParticle(new Vector3($jz["x"], $jz["y"] + 1, $jz["z"])));
    }

    public function teleportPlayersToInstance($instanceKey) {
        $inst = $this->instances[$instanceKey] ?? null;
        if ($inst === null) return;

        $server    = Server::getInstance();
        $worldName = $inst["world"];

        if (!$server->isLevelLoaded($worldName)) {
            if (!$server->loadLevel($worldName)) return;
        }

        $level = $server->getLevelByName($worldName);
        if ($level === null) return;

        $raidKey = $inst["raid_key"];
        $raid    = $this->getRaid($raidKey);

        $entryPos = null;

        if ($raid !== null && !empty($raid["round_spawns"])) {
            $rs = $raid["round_spawns"][1] ?? reset($raid["round_spawns"]);
            if ($rs !== null) {
                $entryPos = new Position((float)$rs["x"], (float)$rs["y"] + 2, (float)$rs["z"], $level);
            }
        }

        if ($entryPos === null) {
            $sp = $level->getSpawnLocation();
            $entryPos = new Position($sp->x, $sp->y, $sp->z, $level);
        }
$this->applyThemeBlocks($instanceKey);

        $combatPlugin = $server->getPluginManager()->getPlugin("OnePieceCombat");

        foreach ($inst["players"] as $pName) {
            $p = $server->getPlayerExact($pName);
            if ($p !== null && $p->isOnline()) {
                $p->teleport($entryPos);
                $p->sendTip("§c§lAWAKEN RAID\n§fPrepare yourself!");

                if ($combatPlugin !== null && $combatPlugin->isEnabled()) {
                    $toggle = $combatPlugin->getCombatToggle();
                    if ($toggle->isEnabled($pName)) {
                        $toggle->addDeathProtection($pName);
                    }
                }
            }
        }
    }

    public function startRound($instanceKey) {
        if (!isset($this->instances[$instanceKey])) return;

        $this->instances[$instanceKey]["phase"]       = "fighting";
        $this->instances[$instanceKey]["current_round"]++;
        $this->instances[$instanceKey]["entity_ids"]  = [];
        $this->instances[$instanceKey]["alive_count"] = 0;

        if ($this->instances[$instanceKey]["current_round"] === 1) {
            $this->removeChipFromPlayers($instanceKey);
        }

        $round   = $this->instances[$instanceKey]["current_round"];
        $raidKey = $this->instances[$instanceKey]["raid_key"];
        $raid    = $this->getRaid($raidKey);
        $isBoss  = ($round > self::ROUNDS);

        $spawnData = $isBoss
            ? ($raid["boss_spawn"] ?? null)
            : ($raid["round_spawns"][$round] ?? ($raid["round_spawns"][1] ?? null));

        if ($spawnData === null) {
            $this->resolveInstance($instanceKey, true);
            return;
        }

        $this->broadcastToInstance($instanceKey, "§c§l[AWAKEN RAID] §r§fRound §c" . min($round, self::ROUNDS) . "§f/§c" . self::ROUNDS . " §fbegins!");

        $server = Server::getInstance();
        $level = $server->getLevelByName($this->instances[$instanceKey]["world"]);
        if ($level !== null && $spawnData !== null) {
            $roundPos = new \pocketmine\level\Position((float)$spawnData["x"], (float)$spawnData["y"] + 2, (float)$spawnData["z"], $level);
            foreach ($this->instances[$instanceKey]["players"] as $pName) {
                $p = $server->getPlayerExact($pName);
                if ($p !== null && $p->isOnline()) {
                    $p->teleport($roundPos);
                }
            }
        }

if ($isBoss) {
    $this->spawnBoss($instanceKey, $spawnData);
} else {
    $npcCount = 4 + $round;
    $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(
        new AwakenSpawnTask($this->plugin, $instanceKey, $spawnData, $round, $npcCount),
        20
    );
}
    }

public function spawnSingleRoundNpc($instanceKey, $spawnData, $round, $index, $npcCount) {
    if (!isset($this->instances[$instanceKey])) return;

    $level = Server::getInstance()->getLevelByName($this->instances[$instanceKey]["world"]);
    if ($level === null) return;

    $angle  = (2 * M_PI / max(1, $npcCount)) * $index + (mt_rand(-30, 30) * M_PI / 180);
    $radius = mt_rand(15, 35) / 10.0;

    $sx = $spawnData["x"] + cos($angle) * $radius;
    $sz = $spawnData["z"] + sin($angle) * $radius;
    $cx = (int)floor($sx) >> 4;
    $cz = (int)floor($sz) >> 4;
    $level->loadChunk($cx, $cz, true);
    $scanFrom = min(127, (int)$spawnData["y"] + 10);
    $groundY  = null;
    for ($checkY = $scanFrom; $checkY > 1; $checkY--) {
        $bid = $level->getBlockIdAt((int)floor($sx), $checkY, (int)floor($sz));
        if ($bid !== 0 && $bid !== 8 && $bid !== 9) {
            $groundY = $checkY + 1;
            break;
        }
    }
    if ($groundY === null || $groundY < 2) {
        $sx = $spawnData["x"];
        $sz = $spawnData["z"];
        $groundY = (int)$spawnData["y"] + 1;
    }
    $sy = (float)$groundY;

    $npcLevel = mt_rand(self::NPC_LEVEL_MIN, self::NPC_LEVEL_MAX);
    $npcStats = $this->getNpcStats($npcLevel, false);

    $this->doSpawnNpc($instanceKey, $level, $sx, $sy, $sz, $npcLevel, $npcStats, false, $round, $index);
}

    private function spawnBoss($instanceKey, $spawnData) {
        if (!isset($this->instances[$instanceKey])) return;
        $level = Server::getInstance()->getLevelByName($this->instances[$instanceKey]["world"]);
        if ($level === null) return;

        $npcStats = ["hp" => self::BOSS_HP, "damage" => 18.0, "speed" => 0.85];
        $this->doSpawnNpc($instanceKey, $level, $spawnData["x"], $spawnData["y"], $spawnData["z"],
            self::BOSS_LEVEL, $npcStats, true, 0, 0);

        $this->broadcastToInstance($instanceKey, "§4§l[AWAKEN RAID] §r§cTHE BOSS HAS APPEARED!");

        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(
            new AwakenBossAbilityTask($this->plugin, $instanceKey),
            200
        );
    }

    public function doSpawnNpc($instanceKey, $level, $x, $y, $z, $npcLevel, $npcStats, $isBoss, $round, $index) {
        $npcId   = "awaken_" . $instanceKey . "_r" . $round . "_" . $index . ($isBoss ? "_boss" : "");
        $display = $isBoss
            ? "§4§lAWAKEN BOSS §r§7[Lv." . $npcLevel . "]"
            : "§c§lPirate §r§7[Lv." . $npcLevel . "]";

        $skinBytes = str_repeat("\xFF", 64 * 64 * 4);
        $skinName  = "Standard_Steve";
        $npcPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceNPC");

        if ($npcPlugin !== null) {
            $nm = $npcPlugin->getNPCManager();
            if ($isBoss) {
                $raidKey     = $this->instances[$instanceKey]["raid_key"];
                $skinPath    = $npcPlugin->getDataFolder() . "skins/" . strtolower($raidKey) . ".png";
                $loaded      = file_exists($skinPath) ? $nm->loadSkinBytes(strtolower($raidKey) . ".png") : false;
                if ($loaded)  { $skinBytes = $loaded; $skinName = strtolower($raidKey); }
            } else {
                $skinPath = $npcPlugin->getDataFolder() . "skins/";
                $skinFiles = [];
                $excluded = ["aokiji.png","bigmom.png","hancock.png","katakuri.png","enel.png","law.png","whitebeard.png","diamond.png","swan.png","jones.png","mr5.png","moria.png","kaido.png","jack.png","blackbeard.png","rik.png","seaking.png", "ice.png", "light.png", "dark.png", "lightning.png", "rubber.png", "sand.png", "flame.png", "magma.png"];
                if (is_dir($skinPath)) {
                    foreach (scandir($skinPath) as $f) {
                        if (substr($f, -4) === ".png" && !in_array(strtolower($f), $excluded)) $skinFiles[] = $f;
                    }
                }
                if (!empty($skinFiles)) {
                    $pick   = $skinFiles[array_rand($skinFiles)];
                    $loaded = $nm->loadSkinBytes($pick);
                    if ($loaded) {
                        $skinBytes = $loaded;
                        $skinName  = pathinfo($pick, PATHINFO_FILENAME);
                    }
                }
            }
        }

        $ix = (int)floor($x);
        $iz = (int)floor($z);

        $chunk = $level->getChunk($ix >> 4, $iz >> 4, true);
        if ($chunk === null) return;

        $nbt = new CompoundTag("", [
            new ListTag("Pos", [
                new DoubleTag("", (float)$x + 0.5),
                new DoubleTag("", (float)$y),
                new DoubleTag("", (float)$z + 0.5),
            ]),
            new ListTag("Motion", [
                new DoubleTag("", 0.0), new DoubleTag("", 0.0), new DoubleTag("", 0.0),
            ]),
            new ListTag("Rotation", [
                new FloatTag("", (float)mt_rand(0, 359)), new FloatTag("", 0.0),
            ]),
            new ListTag("Inventory", []),
            new ShortTag("Health", (int)$npcStats["hp"]),
            new ShortTag("MaxHealth", (int)$npcStats["hp"]),
            new ByteTag("Movement", 1),
            new ByteTag("WallCheck", 1),
            new StringTag("NPCId", $npcId),
            new StringTag("NPCDisplayName", $display),
            new CompoundTag("Skin", [
                new StringTag("Name", $skinName),
                new StringTag("Data", $skinBytes),
            ]),
        ]);

        $entity = null;
        try {
            $entity = Entity::createEntity("OP", $chunk, $nbt);
        } catch (\Exception $e) {}

        if (!($entity instanceof NPCEntity)) {
            try {
                $entity = new NPCEntity($chunk, $nbt);
            } catch (\Exception $e) { return; }
        }

        $entity->npcId                = $npcId;
        $entity->npcLevel             = $npcLevel;
        $entity->npcCategory          = $isBoss ? "boss" : "commander";
        $entity->npcDamage            = $npcStats["damage"];
        $entity->npcSpeed             = $npcStats["speed"];
        $entity->npcMeleeRange        = $isBoss ? 3.0 : 1.8;
        $entity->npcAttackCooldown    = $isBoss ? 12 : 20;
        $entity->bossAbilitiesEnabled = $isBoss;
        $entity->npcFruitId           = "";
        $entity->npcFightingStyle     = "";
        $entity->npcWeaponId          = "";
        $entity->martialAbilities     = [];
        $entity->martialCooldowns     = [];
        $entity->npcHakiArmament      = true;
        $entity->npcHakiObservation   = $isBoss;
        $entity->npcHakiConqueror     = $isBoss;

        try {
            if ($entity->getAttributeMap() !== null) {
                $entity->setMaxHealth((int)$npcStats["hp"]);
                $entity->setHealth((int)$npcStats["hp"]);
            }
        } catch (\Exception $e) {}

        if (method_exists($entity, "setSkin"))               $entity->setSkin($skinBytes, $skinName);
        if (method_exists($entity, "setNameTagVisible"))     $entity->setNameTagVisible(true);
        if (method_exists($entity, "setNameTagAlwaysVisible")) $entity->setNameTagAlwaysVisible(true);

        $entity->spawnToAll();
        if (method_exists($entity, "updateNametagHealth")) $entity->updateNametagHealth();

        $this->instances[$instanceKey]["entity_ids"][] = $entity->getId();
        $this->instances[$instanceKey]["alive_count"]++;
        if ($isBoss) $this->instances[$instanceKey]["boss_alive"] = true;
    }

    private function getNpcStats($level, $isBoss) {
        $npcPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceNPC");
        if ($npcPlugin !== null) {
            $cat   = $isBoss ? "boss" : "commander";
            $stats = $npcPlugin->getNPCManager()->getStats($level, $cat);
            if ($isBoss) {
                $stats["hp"]     = self::BOSS_HP;
                $stats["damage"] = 18.0;
            }
            return $stats;
        }
        if ($isBoss) {
            return ["hp" => self::BOSS_HP, "damage" => 18.0, "speed" => 0.85];
        }
        return [
            "hp"     => 800 + ($level * 40),
            "damage" => 4.0 + ($level * 0.05),
            "speed"  => min(1.8, 0.85 + ($level * 0.003)),
        ];
    }

    public function isAwakenNpc($npcId) {
        return strpos($npcId, "awaken_") === 0;
    }

    public function getInstanceKeyFromNpcId($npcId) {
        if (!$this->isAwakenNpc($npcId)) return null;
        $stripped = substr($npcId, strlen("awaken_"));
        $rPos     = strpos($stripped, "_r");
        if ($rPos === false) return null;
        return substr($stripped, 0, $rPos);
    }

    public function onNpcDeath($instanceKey) {
        if (!isset($this->instances[$instanceKey])) return;

        $this->instances[$instanceKey]["alive_count"] = max(0, $this->instances[$instanceKey]["alive_count"] - 1);

        if ($this->instances[$instanceKey]["alive_count"] <= 0) {
            if ($this->instances[$instanceKey]["boss_alive"]) {
                $this->instances[$instanceKey]["boss_alive"] = false;
                $this->resolveInstance($instanceKey, true);
            } else {
                $round = $this->instances[$instanceKey]["current_round"];
                if ($round >= self::ROUNDS) {
                    $this->instances[$instanceKey]["phase"] = "boss_intro";
                    $this->broadcastToInstance($instanceKey, "§4§l[AWAKEN RAID] §r§eAll rounds cleared! The Boss approaches...");
                    $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
                        new AwakenRoundTask($this->plugin, $instanceKey, true),
                        self::ROUND_PAUSE * 20
                    );
                } else {
                    $this->instances[$instanceKey]["phase"] = "between_rounds";
                    $this->broadcastToInstance($instanceKey, "§a§l[AWAKEN RAID] §r§fRound §a" . $round . "§f cleared! Next round in §a" . self::ROUND_PAUSE . "§f seconds...");
                    $this->broadcastToInstanceTip($instanceKey, "§aROUND " . $round . " CLEARED\n§fNext round in " . self::ROUND_PAUSE . "s");
                    $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
                        new AwakenRoundTask($this->plugin, $instanceKey, false),
                        self::ROUND_PAUSE * 20
                    );
                }
            }
        } else {
            $this->broadcastToInstancePopup($instanceKey, "§c[AWAKEN] §fEnemies remaining: §c" . $this->instances[$instanceKey]["alive_count"]);
        }
    }

    public function resolveInstance($instanceKey, $success) {
        $inst = $this->instances[$instanceKey] ?? null;
        if ($inst === null) return;

        $raidKey = $inst["raid_key"];
        $players = $inst["players"];

        $this->despawnAllEntities($instanceKey);

        $combatPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceCombat");

        foreach ($players as $pName) {
            if ($combatPlugin !== null && $combatPlugin->isEnabled()) {
                $combatPlugin->getCombatToggle()->removeDeathProtection($pName);
            }
        }

        if ($success) {
            $this->broadcastToInstance($instanceKey, "§a§l[AWAKEN RAID] §r§aRaid complete! The power of awakening is yours!");
            $this->broadcastToInstanceTip($instanceKey, "§aVICTORY\n§fAwakening achieved!");

foreach ($players as $pName) {
    $participant = Server::getInstance()->getPlayerExact($pName);
    if ($participant !== null && $participant->isOnline()) {
        $playerFruitId = $this->getPlayerFruitId($participant);
        $expectedFruitId = null;
        foreach (self::FRUIT_MAP as $fId => $rKey) {
            if (strtolower($rKey) === strtolower($raidKey)) { $expectedFruitId = $fId; break; }
        }
        if ($playerFruitId !== null && $expectedFruitId !== null && strtolower($playerFruitId) === strtolower($expectedFruitId)) {
            $this->recordRaidCompletion($pName, $raidKey);
        } else {
          //  $this->broadcastToInstance($instanceKey, "§e[AWAKEN] §f" . $pName . " §7did not receive raid credit (wrong or no fruit equipped).");
        }
    }
}
            $fruit       = null;
            $raidKeyLower = strtolower($raidKey);
            foreach (self::FRUIT_MAP as $fId => $rKey) {
                if ($rKey === $raidKeyLower) { $fruit = $fId; break; }
            }

            $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
                new \OnePieceRaid\Awaken\AwakenTeleportTask($this->plugin, $instanceKey, $fruit),
                5 * 20
            );
        } else {
            $this->broadcastToInstance($instanceKey, "§c§l[AWAKEN RAID] §r§cRaid failed! Better luck next time.");
            $this->broadcastToInstanceTip($instanceKey, "§cDEFEAT\n§fThe darkness consumed you...");

            $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
                new \OnePieceRaid\Awaken\AwakenTeleportTask($this->plugin, $instanceKey, null),
                3 * 20
            );
        }
    }

    public function despawnAllEntities($instanceKey) {
        if (!isset($this->instances[$instanceKey])) return;
        $ids = $this->instances[$instanceKey]["entity_ids"] ?? [];
        foreach (Server::getInstance()->getLevels() as $level) {
            foreach ($ids as $eid) {
                $entity = $level->getEntity($eid);
                if ($entity !== null && !$entity->closed) {
                    $entity->despawnFromAll();
                    $entity->close();
                }
            }
        }
        $this->instances[$instanceKey]["entity_ids"]  = [];
        $this->instances[$instanceKey]["alive_count"] = 0;
    }

public function teleportToSafety(Player $player) {
    if (!$player->isOnline()) return;
    $server = Server::getInstance();
    $server->dispatchCommand($player, "stp sea3");
    $server->dispatchCommand($player, "zone tp Sea_Castle");

    $invPlugin = $server->getPluginManager()->getPlugin("OnePieceInventory");
    if ($invPlugin !== null && $invPlugin->isEnabled()) {
        $server->getScheduler()->scheduleDelayedTask(
            new class($player) extends \pocketmine\scheduler\Task {
                private $player;

                public function __construct(Player $player) {
                    $this->player = $player;
                }

                public function onRun($currentTick) {
                    if (!$this->player->isOnline()) return;
                    $item = \pocketmine\item\Item::get(\pocketmine\item\Item::DIAMOND, 0, 1);
                    $item->setCustomName("§r§bNavigator\n§8[§fTap to open menu§8]");
                    $this->player->getInventory()->setItem(5, $item);
                }
            }, 20
        );
    }
}

    public function teleportToAwakenSpawn(Player $player) {
        if ($this->awakenSpawn === null) return false;
        $server = Server::getInstance();
        if (!$server->isLevelLoaded($this->awakenSpawn["world"])) {
            $server->loadLevel($this->awakenSpawn["world"]);
        }
        $level = $server->getLevelByName($this->awakenSpawn["world"]);
        if ($level === null) return false;
        $player->teleport(new Position(
            $this->awakenSpawn["x"],
            $this->awakenSpawn["y"],
            $this->awakenSpawn["z"],
            $level
        ));
        return true;
    }

public function getChipName($raidKey) {
    $raidKey = strtolower($raidKey);
    $server = \pocketmine\Server::getInstance();
    $devilPlugin = $server->getPluginManager()->getPlugin("OnePieceDevil");
    if ($devilPlugin !== null) {
        $fm = $devilPlugin->getFruitManager();
        foreach (self::FRUIT_MAP as $fruitId => $rKey) {
            if (strtolower($rKey) === $raidKey) {
                $fruit = $fm->getFruit($fruitId);
                if ($fruit !== null) {
                    return \pocketmine\utils\TextFormat::clean($fruit->getDisplayName());
                }
                return ucwords(str_replace("_", " ", $fruitId));
            }
        }
    }
    foreach (self::FRUIT_MAP as $fruitId => $rKey) {
        if (strtolower($rKey) === $raidKey) return ucwords(str_replace("_", " ", $fruitId));
    }
    return ucfirst($raidKey);
}

public function getPlayerHeldChipRaidKey(Player $player) {
    $inv = $player->getInventory();
    for ($i = 0; $i < $inv->getSize(); $i++) {
        $item = $inv->getItem($i);
        if ($item->getId() === \pocketmine\item\Item::PAPER && $item->hasCustomName()) {
            $name = $item->getCustomName();
            foreach ($this->raids as $key => $data) {
                $chipName = $this->getChipName($key);
                if (strpos($name, $chipName . "'s Chip") !== false) return $key;
            }
        }
    }
    return null;
}

public function isInJoinArea(Player $player, Vector3 $center) {
    $pos = $player->getPosition();
    return abs($pos->x - $center->x) <= 1 && abs($pos->z - $center->z) <= 1 && abs($pos->y - $center->y) <= 2;
}

public function scanJoinZones() {
    $server = Server::getInstance();

    foreach ($this->joinZones as $number => $jz) {
        if (!$server->isLevelLoaded($jz["world"])) continue;
        $level = $server->getLevelByName($jz["world"]);
        if ($level === null) continue;

        $center = new Vector3($jz["x"], $jz["y"], $jz["z"]);

        $zoneInstanceKey = null;
        $zoneRaidKey = null;
        foreach ($this->instances as $iKey => $inst) {
            if ($inst["phase"] === "lobby" && $inst["zone_number"] === (int)$number) {
                $zoneInstanceKey = $iKey;
                $zoneRaidKey = $inst["raid_key"];
                break;
            }
        }

foreach ($level->getPlayers() as $p) {
    if (!$this->isInJoinArea($p, $center)) continue;
    if ($this->isPlayerInInstance($p->getName())) continue;

    $chipKey = $this->getPlayerHeldChipRaidKey($p);

    if ($zoneInstanceKey !== null) {
        if ($chipKey !== null && strtolower($chipKey) !== strtolower($zoneRaidKey)) continue;
        if (count($this->instances[$zoneInstanceKey]["players"]) >= self::MAX_PLAYERS) continue;
        if (in_array($p->getName(), $this->instances[$zoneInstanceKey]["players"])) continue;

        $this->instances[$zoneInstanceKey]["players"][] = $p->getName();
        $p->sendMessage("§a[AWAKEN] You joined the raid lobby! Starts in §f" . $this->instances[$zoneInstanceKey]["countdown"] . "§a seconds.");
        $this->broadcastToInstance($zoneInstanceKey, "§a[AWAKEN] §f" . $p->getName() . " §ajoined the lobby! (" . count($this->instances[$zoneInstanceKey]["players"]) . "/" . self::MAX_PLAYERS . ")");
    } else {
        if ($chipKey === null) continue;

        $instanceKey = $this->createInstance($chipKey, $p->getName());
        if ($instanceKey === null) continue;

        $this->instances[$instanceKey]["phase"]       = "lobby";
        $this->instances[$instanceKey]["countdown"]   = self::LOBBY_COUNTDOWN;
        $this->instances[$instanceKey]["owner"]       = $p->getName();
        $this->instances[$instanceKey]["zone_number"] = (int)$number;

        $zoneInstanceKey = $instanceKey;
        $zoneRaidKey     = $chipKey;

        $p->sendMessage("§a[AWAKEN] Lobby created! Raid starts in §f" . self::LOBBY_COUNTDOWN . "§a seconds.");
        $p->sendMessage("§7Others can join by entering this zone with a §e" . $this->getChipName($chipKey) . " Chip §7or no chip.");

        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(
            new AwakenStartCountdownTask($this->plugin, $instanceKey), 20
        );
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(
            new AwakenCleanupTask($this->plugin, $instanceKey), 200
        );
    }
}
    }
}

public function checkJoinZoneProximity($instanceKey) {
    if (!isset($this->instances[$instanceKey])) return;
    if ($this->instances[$instanceKey]["phase"] !== "lobby") return;

    $raidKey = $this->instances[$instanceKey]["raid_key"];
    $raid = $this->getRaid($raidKey);
    if ($raid === null || $raid["join_zone"] === null) return;
    if (count($this->instances[$instanceKey]["players"]) >= self::MAX_PLAYERS) return;

    $jz = $raid["join_zone"];
    $server = Server::getInstance();
    $level = $server->getLevelByName($jz["world"]);
    if ($level === null) return;

    $center = new Vector3($jz["x"], $jz["y"], $jz["z"]);

    foreach ($level->getPlayers() as $p) {
        $pName = $p->getName();
        if (in_array($pName, $this->instances[$instanceKey]["players"])) continue;
        if ($this->isPlayerInInstance($pName)) continue;
        if (count($this->instances[$instanceKey]["players"]) >= self::MAX_PLAYERS) break;
        if (!$this->isInJoinArea($p, $center)) continue;

        $chipKey = $this->getPlayerHeldChipRaidKey($p);
        if ($chipKey === null || strtolower($chipKey) !== strtolower($raidKey)) continue;

        $this->instances[$instanceKey]["players"][] = $pName;
        $p->sendMessage("§a[AWAKEN] You joined the raid lobby! Starts in §f" . $this->instances[$instanceKey]["countdown"] . "§a seconds.");
        $this->broadcastToInstance($instanceKey, "§a[AWAKEN] §f" . $pName . " §ajoined the lobby! (" . count($this->instances[$instanceKey]["players"]) . "/" . self::MAX_PLAYERS . ")");
    }
}

public function tickCountdown($instanceKey) {
    if (!isset($this->instances[$instanceKey])) return false;
    if ($this->instances[$instanceKey]["phase"] !== "lobby") return false;

    $inst       = &$this->instances[$instanceKey];
    $zoneNumber = $inst["zone_number"];
    $ownerName  = $inst["owner"];
    $server     = Server::getInstance();

    if ($zoneNumber !== null && isset($this->joinZones[$zoneNumber])) {
        $jz     = $this->joinZones[$zoneNumber];
        $center = new Vector3($jz["x"], $jz["y"], $jz["z"]);
        $level  = $server->getLevelByName($jz["world"]);

        if ($level !== null) {
            $owner       = $server->getPlayerExact($ownerName);
            $ownerInZone = ($owner !== null && $owner->isOnline() && $this->isInJoinArea($owner, $center));

            if (!$ownerInZone) {
                $this->broadcastToInstance($instanceKey, "§c[AWAKEN] The lobby owner left the zone. Lobby disbanded.");
                $this->despawnAllEntities($instanceKey);
                $this->deleteInstanceWorld($instanceKey);
                return true;
            }

            $remainingPlayers = [];

            foreach ($inst["players"] as $pName) {
                $p = $server->getPlayerExact($pName);
                if ($p !== null && $p->isOnline() && $this->isInJoinArea($p, $center)) {
                    $remainingPlayers[] = $pName;
                } else {
                    $offline = $server->getPlayerExact($pName);
                    if ($offline !== null && $offline->isOnline()) {
                        $offline->sendMessage("§c[AWAKEN] You left the join zone and were removed from the lobby.");
                    }
                }
            }

            $inst["players"] = $remainingPlayers;
        }
    }

    $inst["countdown"]--;
    $countdown = $inst["countdown"];

    if ($countdown % 10 === 0 || $countdown <= 5) {
        $this->broadcastToInstance($instanceKey, "§e[AWAKEN RAID] §fRaid starts in §e" . $countdown . "§f seconds!");
        $this->broadcastToInstanceTip($instanceKey, "§eRAID STARTING\n§fIn " . $countdown . " seconds");
    }

    if ($countdown <= 0) {
        $inst["phase"] = "starting";
        $this->teleportPlayersToInstance($instanceKey);

        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
            new AwakenRoundTask($this->plugin, $instanceKey, false), 8 * 20
        );

        $inst["raid_start_time"] = time();
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(
            new AwakenRaidTimerTask($this->plugin, $instanceKey), 20
        );

        return true;
    }

    return false;
}

public function getOnlinePlayerCountInInstance($instanceKey) {
    $inst = $this->instances[$instanceKey] ?? null;
    if ($inst === null) return 0;
    $count = 0;
    $server = Server::getInstance();
    foreach ($inst["players"] as $pName) {
        $p = $server->getPlayerExact($pName);
        if ($p !== null && $p->isOnline()) $count++;
    }
    return $count;
}

    public function isInstanceEmpty($instanceKey) {
        $inst = $this->instances[$instanceKey] ?? null;
        if ($inst === null) return true;

        $server = Server::getInstance();
        foreach ($inst["players"] as $pName) {
            $p = $server->getPlayerExact($pName);
            if ($p !== null && $p->isOnline()) return false;
        }
        return true;
    }

    public function removePlayerFromInstance($playerName) {
        foreach ($this->instances as $instanceKey => $inst) {
            $pos = array_search($playerName, $inst["players"]);
            if ($pos !== false) {
                unset($this->instances[$instanceKey]["players"][$pos]);
                $this->instances[$instanceKey]["players"] = array_values($this->instances[$instanceKey]["players"]);
                break;
            }
        }
    }

    public function isInAwakenWorld(Player $player) {
        $worldName = $player->getLevel()->getFolderName();
        foreach ($this->instances as $inst) {
            if ($inst["world"] === $worldName) return true;
        }
        return false;
    }

    public function getInstanceKeyByWorld($worldName) {
        foreach ($this->instances as $key => $inst) {
            if ($inst["world"] === $worldName) return $key;
        }
        return null;
    }

public function broadcastToInstance($instanceKey, $msg) {
    $inst = $this->instances[$instanceKey] ?? null;
    if ($inst === null) return;
    $server = Server::getInstance();
    foreach ($inst["players"] as $pName) {
        $p = $server->getPlayerExact($pName);
        if ($p !== null && $p->isOnline()) $p->sendMessage($msg);
    }
}

public function broadcastToInstanceTip($instanceKey, $msg) {
    $inst = $this->instances[$instanceKey] ?? null;
    if ($inst === null) return;
    $server = Server::getInstance();
    foreach ($inst["players"] as $pName) {
        $p = $server->getPlayerExact($pName);
        if ($p !== null && $p->isOnline()) $p->sendTip($msg);
    }
}

public function broadcastToInstancePopup($instanceKey, $msg) {
    $inst = $this->instances[$instanceKey] ?? null;
    if ($inst === null) return;
    $server = Server::getInstance();
    foreach ($inst["players"] as $pName) {
        $p = $server->getPlayerExact($pName);
        if ($p !== null && $p->isOnline()) $p->sendPopup($msg);
    }
}

public function removeChipFromPlayers($instanceKey) {
    $inst = $this->instances[$instanceKey] ?? null;
    if ($inst === null) return;
    $server = Server::getInstance();
    foreach ($inst["players"] as $pName) {
        $p = $server->getPlayerExact($pName);
        if ($p === null || !$p->isOnline()) continue;
        $inv = $p->getInventory();
        for ($i = 0; $i < $inv->getSize(); $i++) {
            $item = $inv->getItem($i);
            if ($item->getId() === \pocketmine\item\Item::PAPER && $item->hasCustomName()) {
                $name = $item->getCustomName();
                foreach ($this->raids as $key => $data) {
                    $chipName = $this->getChipName($key);
                    if (strpos($name, $chipName . "'s Chip") !== false) {
                        $inv->setItem($i, \pocketmine\item\Item::get(\pocketmine\item\Item::AIR));
                        break;
                    }
                }
            }
            if ($item->getId() === \pocketmine\item\Item::DIAMOND) {
                $inv->setItem($i, \pocketmine\item\Item::get(\pocketmine\item\Item::AIR));
            }
        }
    }
}

public function getAbilityMode($playerName, $raidKey, $ability) {
    $data = $this->playerData->get($playerName, []);
    return $data[$raidKey][$ability . "_mode"] ?? "awakened";
}

public function setAbilityMode($playerName, $raidKey, $ability, $mode) {
    $data = $this->playerData->get($playerName, []);
    if (!isset($data[$raidKey])) {
        $data[$raidKey] = ["raids_done" => 0, "ability1" => false, "ability2" => false];
    }
    $data[$raidKey][$ability . "_mode"] = $mode;
    $this->playerData->set($playerName, $data);
    $this->playerData->save();
}

    public function getAllInstances() { return $this->instances; }

    public function formatBerry($amount) {
        return number_format($amount) . " Berry";
    }
}