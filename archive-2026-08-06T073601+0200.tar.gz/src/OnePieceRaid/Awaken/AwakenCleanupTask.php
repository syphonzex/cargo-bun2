<?php

namespace OnePieceRaid\Awaken;

use pocketmine\scheduler\Task;
use OnePieceRaid\Main;

class AwakenCleanupTask extends Task {

    private $plugin;
    private $instanceKey;

    public function __construct(Main $plugin, $instanceKey) {
        $this->plugin      = $plugin;
        $this->instanceKey = $instanceKey;
    }

    public function onRun($currentTick) {
        $am   = $this->plugin->getAwakenManager();
        $inst = $am->getInstanceData($this->instanceKey);

        if ($inst === null) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        if ($am->isInstanceEmpty($this->instanceKey)) {
            $am->despawnAllEntities($this->instanceKey);
            $am->deleteInstanceWorld($this->instanceKey);
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
        }
    }
}
