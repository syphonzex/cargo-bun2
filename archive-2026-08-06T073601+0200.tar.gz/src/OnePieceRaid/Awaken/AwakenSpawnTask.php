<?php
namespace OnePieceRaid\Awaken;

use pocketmine\scheduler\Task;
use OnePieceRaid\Main;

class AwakenSpawnTask extends Task {

    private $plugin;
    private $instanceKey;
    private $spawnData;
    private $round;
    private $npcCount;
    private $spawnedIndex;

    public function __construct(Main $plugin, $instanceKey, array $spawnData, $round, $npcCount) {
        $this->plugin       = $plugin;
        $this->instanceKey  = $instanceKey;
        $this->spawnData    = $spawnData;
        $this->round        = $round;
        $this->npcCount     = $npcCount;
        $this->spawnedIndex = 0;
    }

    public function onRun($currentTick) {
        $am = $this->plugin->getAwakenManager();

        if (!isset($am->getAllInstances()[$this->instanceKey])) {
            $this->getHandler()->cancel();
            return;
        }

        if ($this->spawnedIndex >= $this->npcCount) {
            $this->getHandler()->cancel();
            return;
        }

        $am->spawnSingleRoundNpc($this->instanceKey, $this->spawnData, $this->round, $this->spawnedIndex, $this->npcCount);
        $this->spawnedIndex++;
    }
}