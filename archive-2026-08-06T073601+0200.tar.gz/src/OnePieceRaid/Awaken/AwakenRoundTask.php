<?php

namespace OnePieceRaid\Awaken;

use pocketmine\scheduler\Task;
use OnePieceRaid\Main;

class AwakenRoundTask extends Task {

    private $plugin;
    private $instanceKey;
    private $isBoss;

    public function __construct(Main $plugin, $instanceKey, $isBoss = false) {
        $this->plugin      = $plugin;
        $this->instanceKey = $instanceKey;
        $this->isBoss      = $isBoss;
    }

    public function onRun($currentTick) {
        $am   = $this->plugin->getAwakenManager();
        $inst = $am->getInstanceData($this->instanceKey);

        if ($inst === null) return;

        if ($this->isBoss) {
            $am->startRound($this->instanceKey);
        } else {
            $am->startRound($this->instanceKey);
        }
    }
}
