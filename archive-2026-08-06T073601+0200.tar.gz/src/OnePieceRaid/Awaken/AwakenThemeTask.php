<?php
namespace OnePieceRaid\Awaken;

use pocketmine\scheduler\Task;
use pocketmine\level\Level;
use pocketmine\block\Block;
use pocketmine\Server;
use OnePieceRaid\Main;

class AwakenThemeTask extends Task {

    const CHUNKS_PER_TICK = 2;

    private $plugin;
    private $level;
    private $levelName;
    private $minX;
    private $maxX;
    private $minY;
    private $maxY;
    private $minZ;
    private $maxZ;
    private $theme;
    private $currentX;
    private $currentZ;
    private $done;

    public function __construct(Main $plugin, Level $level, $minX, $maxX, $minY, $maxY, $minZ, $maxZ, array $theme) {
        $this->plugin    = $plugin;
        $this->level     = $level;
        $this->levelName = $level->getFolderName();
        $this->minX      = $minX;
        $this->maxX      = $maxX;
        $this->minY      = $minY;
        $this->maxY      = $maxY;
        $this->minZ      = $minZ;
        $this->maxZ      = $maxZ;
        $this->theme     = $theme;
        $this->currentX  = $minX;
        $this->currentZ  = $minZ;
        $this->done      = false;
    }

    public function onRun($currentTick) {
        if ($this->done) {
            $this->getHandler()->cancel();
            return;
        }

        // A Level object reference stays non-null even after the world is unloaded.
        // We must verify the world is still actually loaded by name.
        $server = Server::getInstance();
        if ($this->level === null || !$server->isLevelLoaded($this->levelName)) {
            $this->done = true;
            $this->getHandler()->cancel();
            return;
        }

        // Re-fetch the live level reference each tick in case it was reloaded.
        $this->level = $server->getLevelByName($this->levelName);
        if ($this->level === null) {
            $this->done = true;
            $this->getHandler()->cancel();
            return;
        }

        $chunksProcessed = 0;

        while ($this->currentX <= $this->maxX) {
            while ($this->currentZ <= $this->maxZ) {
                $this->processColumn($this->currentX, $this->currentZ);
                $this->currentZ++;

                if (($this->currentZ - $this->minZ) % 16 === 0) {
                    $chunksProcessed++;
                    if ($chunksProcessed >= self::CHUNKS_PER_TICK) return;
                }
            }
            $this->currentZ = $this->minZ;
            $this->currentX++;
        }

        $this->done = true;
        $this->getHandler()->cancel();
    }

    private function processColumn($x, $z) {
        $themeCount = count($this->theme);
        if ($themeCount === 0) return;

        for ($y = $this->maxY; $y >= $this->minY; $y--) {
            $blockId = $this->level->getBlockIdAt($x, $y, $z);

            if ($blockId === Block::GRASS) {
                $pick = $this->randomThemePick($themeCount);
                $this->level->setBlockIdAt($x, $y, $z, $pick[0]);
                $this->level->setBlockDataAt($x, $y, $z, $pick[1]);
                $this->fillBelow($x, $y - 1, $z);
                return;
            }

            if (
                $blockId === Block::AIR ||
                $blockId === Block::LEAVES ||
                $blockId === Block::LEAVES2
            ) {
                continue;
            }

            return;
        }
    }

    private function fillBelow($x, $y, $z) {
        $depth      = 0;
        $themeCount = count($this->theme);
        while ($y >= $this->minY && $depth < 3) {
            $blockId = $this->level->getBlockIdAt($x, $y, $z);
            if ($blockId !== Block::DIRT && $blockId !== Block::GRASS) break;
            $pick = $this->randomThemePick($themeCount);
            $this->level->setBlockIdAt($x, $y, $z, $pick[0]);
            $this->level->setBlockDataAt($x, $y, $z, $pick[1]);
            $y--;
            $depth++;
        }
    }

    private function randomThemePick($themeCount) {
        $roll = mt_rand(0, 99);
        if ($themeCount === 1) return $this->theme[0];
        if ($themeCount === 2) {
            return $this->theme[$roll < 60 ? 0 : 1];
        }
        if ($roll < 50) return $this->theme[0];
        if ($roll < 80) return $this->theme[1];
        return $this->theme[2];
    }
}