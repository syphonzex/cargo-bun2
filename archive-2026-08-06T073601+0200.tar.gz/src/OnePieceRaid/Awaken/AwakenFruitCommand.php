<?php

namespace OnePieceRaid\Awaken;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\Server;
use OnePieceRaid\Main;

class AwakenFruitCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct(
            "awakenfruit",
            "Claim or check your awakened devil fruit abilities",
            "/awakenfruit",
            []
        );
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cIn-game only.");
            return true;
        }

        $am      = $this->plugin->getAwakenManager();
        $pName   = $sender->getName();
        $fruitId = $am->getPlayerFruitId($sender);

        if ($fruitId === null) {
            $sender->sendMessage("§c[AWAKEN] You do not have a devil fruit equipped.");
            return true;
        }

        $raidKey = $am->getRaidKeyForFruit($fruitId);
        if ($raidKey === null) {
            $sender->sendMessage("§c[AWAKEN] Your fruit does not have an awakening path yet.");
            return true;
        }

        $raid = $am->getRaid($raidKey);
        if ($raid === null) {
            $sender->sendMessage("§c[AWAKEN] Dough? The immense power seems enough. But if you insist I'll add awakening for it..");
            return true;
        }

        $nextAbility = $am->getNextAbilityToAwaken($pName, $raidKey);

        if ($nextAbility === null) {
            $sender->sendMessage("§b§l[AWAKEN] §r§aYou have fully awakened your fruit!");
            $sender->sendMessage("§7Both abilities are awakened. You are at maximum power.");
            return true;
        }

        $raidsNeeded = $am->getNeededRaids($pName, $raidKey);
        if ($raidsNeeded > 0) {
            $done  = $am->getRaidsCompleted($pName, $raidKey);
            $total = ($nextAbility === "ability1") ? 1 : 2;
            $sender->sendMessage("§c§l[AWAKEN] §r§cYou have not completed enough raids.");
            $sender->sendMessage("§7Progress: §f" . $done . "/" . $total . " §7raid completions for §f" . $nextAbility . "§7.");
            return true;
        }

        $priceKey = "price_" . $nextAbility;
        $price    = (int)($raid[$priceKey] ?? ($nextAbility === "ability1" ? 500000 : 1000000));
        $berry    = $am->getPlayerBerry($sender);

        $fruityClass = $am->getAwakenFruitClass($raidKey);

        $abilityName = "Unknown";
        if ($fruityClass !== null && class_exists($fruityClass)) {
            $obj = new $fruityClass();
            $abilityName = ($nextAbility === "ability1") ? $obj->getAbility1Name() : $obj->getAbility2Name();
        }

        if (empty($args) || strtolower($args[0]) !== "confirm") {
            $sender->sendMessage("§b§l[AWAKEN] §r§fNext ability to awaken: §b" . $abilityName);
            $sender->sendMessage("§7Unlock cost: §e" . number_format($price) . " Berry");
            $sender->sendMessage("§7Your Berry: §f" . number_format($berry));
            if ($berry >= $price) {
                $sender->sendMessage("§aType §f/awakenfruit confirm §ato purchase and unlock §b" . $abilityName . "§a.");
            } else {
                $sender->sendMessage("§cYou need §f" . number_format($price - $berry) . " §cmore Berry.");
            }
            return true;
        }

        if ($berry < $price) {
            $sender->sendMessage("§c[AWAKEN] Insufficient Berry. Need §f" . number_format($price) . "§c, have §f" . number_format($berry) . "§c.");
            return true;
        }

        if (!$am->deductBerry($sender, $price)) {
            $sender->sendMessage("§c[AWAKEN] Payment failed. Try again.");
            return true;
        }

        $am->setAbilityAwakened($pName, $raidKey, $nextAbility);

        if ($fruityClass !== null && class_exists($fruityClass)) {
            $obj = new $fruityClass();
            if ($nextAbility === "ability1") {
                $obj->onAwaken1($sender);
            } else {
                $obj->onAwaken2($sender);
            }
        }

        $sender->sendMessage("§b§l[AWAKEN] §r§aAbility unlocked: §b" . $abilityName . "§a!");
        $sender->sendMessage("§7Your §f" . $nextAbility . "§7 slot now uses the awakened version.");
        $sender->sendMessage("§7Use §f/fruit equip " . $nextAbility . "_base §7to switch back to the original.");
        $sender->sendTip("§b§lAWAKENED\n§f" . $abilityName);

        Server::getInstance()->dispatchCommand($sender, "stp sea3");
        Server::getInstance()->dispatchCommand($sender, "zone tp Sea_Castle");

        return true;
    }
}
