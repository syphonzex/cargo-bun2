<?php

namespace OnePieceRaid\Awaken\fruits;

use pocketmine\Player;

abstract class AwakenBaseFruit {

    abstract public function getFruitId();
    abstract public function getAbility1Name();
    abstract public function getAbility2Name();
    abstract public function getAbility1Cooldown();
    abstract public function getAbility2Cooldown();
    abstract public function useAbility1(Player $player);
    abstract public function useAbility2(Player $player);

    public function onAwaken1(Player $player) {}
    public function onAwaken2(Player $player) {}
}
