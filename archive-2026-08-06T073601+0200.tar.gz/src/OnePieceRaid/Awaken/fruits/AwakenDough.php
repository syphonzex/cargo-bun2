<?php

namespace OnePieceRaid\Awaken\fruits;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\entity\Effect;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\Task;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\ExplodeParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\particle\LargeExplodeParticle;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\FizzSound;
use pocketmine\level\sound\ExplodeSound;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;
use OnePiece\Devil\BlockEffects;

class AwakenDough extends AwakenBaseFruit {

    public function getFruitId()          { return "mochi_mochi"; }
    public function getAbility1Name()     { return "Unstoppable Mochi"; }
    public function getAbility2Name()     { return "Muggy Mile Rebirth"; }
    public function getAbility1Cooldown() { return 14.0; }
    public function getAbility2Cooldown() { return 28.0; }

    public function onAwaken1(Player $player) {
        $player->sendMessage("§d[AWAKEN] §fUnstoppable Mochi awakened!");
        $player->sendMessage("§7Elastic dough tendrils bind and crush all surrounding enemies.");
    }

    public function onAwaken2(Player $player) {
        $player->sendMessage("§d[AWAKEN] §fMuggy Mile Rebirth awakened!");
        $player->sendMessage("§7Transform into a colossal mochi form and slam the earth.");
    }

    public function useAbility1(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;

        $damage = 7.0;
        $level  = $player->getLevel();
        $cx = $player->x; $cy = $player->y; $cz = $player->z;

        $tendrils = [];
        foreach ($level->getEntities() as $e) {
            if ($e === $player || !$e->isAlive()) continue;
            if (!($e instanceof NPCEntity) && !($e instanceof FactoryEntity)) continue;
            if ($e->distance(new Vector3($cx, $cy, $cz)) > 11) continue;

            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($level, $eid, 101, 0, $e->x, $e->y + 0.5, $e->z);
            $tendrils[] = ["eid" => $eid, "entity" => $e, "tick" => 0];
        }

        if (empty($tendrils)) {
            $player->sendTip("§d§lUNSTOPPABLE MOCHI - No targets.");
            return;
        }

        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(
            new class($plugin, $player, $damage, $tendrils, $level) extends Task {
                private $plugin, $player, $damage, $tendrils, $level, $tick = 0;
                public function __construct($pl, $p, $d, $t, $lv) {
                    $this->plugin = $pl; $this->player = $p; $this->damage = $d;
                    $this->tendrils = $t; $this->level = $lv;
                }
                public function onRun($t) {
                    $this->tick++;
                    if ($this->tick > 60) { $this->cleanup(); return; }

                    foreach ($this->tendrils as &$td) {
                        $e = $td["entity"];
                        if (!$e->isAlive()) { BlockEffects::sendRemove($td["eid"]); continue; }

                        BlockEffects::sendMove($this->level, $td["eid"],
                            $e->x, $e->y + 0.5 + sin($this->tick * 0.2) * 0.3, $e->z,
                            $this->tick * 15
                        );

                        $e->setMotion(new Vector3(0, 0, 0));

                        for ($i = 0; $i < 4; $i++) {
                            $this->level->addParticle(new DustParticle(
                                new Vector3($e->x + mt_rand(-5,5)/10.0, $e->y + mt_rand(0,20)/10.0, $e->z + mt_rand(-5,5)/10.0),
                                220, 160, 200
                            ));
                        }

                        if ($this->tick % 10 === 0) {
                            $ev = new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->damage);
                            $e->attack($this->damage, $ev);
                        }
                    }

                    if ($this->tick % 6 === 0) {
                        $this->level->addSound(new FizzSound(new Vector3($this->player->x, $this->player->y, $this->player->z)));
                    }
                }
                private function cleanup() {
                    foreach ($this->tendrils as $td) BlockEffects::sendRemove($td["eid"]);
                    $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
                }
            },
            1
        );

        $player->sendTip("§d§lUNSTOPPABLE MOCHI");
        $level->addSound(new AnvilUseSound($player));
    }

    public function useAbility2(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;

        $damage = 15.0;
        $level  = $player->getLevel();
        $cx = $player->x; $cy = $player->y; $cz = $player->z;

        $player->setMotion(new Vector3(0, 2.5, 0));

        $formEids = [];
        for ($h = 0; $h < 4; $h++) {
            for ($a = 0; $a < 8; $a++) {
                $eid   = BlockEffects::newEid();
                $angle = (2 * M_PI / 8) * $a;
                $r     = 2.0 - $h * 0.3;
                BlockEffects::sendSpawn($level, $eid, 101, 0,
                    $cx + cos($angle) * $r, $cy + $h, $cz + sin($angle) * $r
                );
                $formEids[] = ["eid" => $eid, "angle" => (float)$angle, "h" => $h];
            }
        }

        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(
            new class($plugin, $player, $damage, $formEids, $level) extends Task {
                private $plugin, $player, $damage, $formEids, $level, $tick = 0, $slammed = false;
                public function __construct($pl, $p, $d, $fe, $lv) {
                    $this->plugin = $pl; $this->player = $p; $this->damage = $d;
                    $this->formEids = $fe; $this->level = $lv;
                }
                public function onRun($t) {
                    $this->tick++;
                    if ($this->tick > 70) { $this->cleanup(); return; }

                    $cx = $this->player->x; $cy = $this->player->y; $cz = $this->player->z;

                    foreach ($this->formEids as &$seg) {
                        $seg["angle"] += 0.12;
                        $r = (2.0 - $seg["h"] * 0.3) + sin($this->tick * 0.15) * 0.5;
                        BlockEffects::sendMove($this->level, $seg["eid"],
                            $cx + cos($seg["angle"]) * $r,
                            $cy + $seg["h"],
                            $cz + sin($seg["angle"]) * $r,
                            (int)($seg["angle"] * 100)
                        );
                        if ($this->tick % 3 === 0) {
                            $this->level->addParticle(new DustParticle(
                                new Vector3($cx + cos($seg["angle"]) * $r, $cy + $seg["h"], $cz + sin($seg["angle"]) * $r),
                                220, 160, 200
                            ));
                        }
                    }

                    if (!$this->slammed && $this->player->isOnGround() && $this->tick > 15) {
                        $this->slammed = true;
                        $pos = new Vector3($cx, $cy, $cz);

                        foreach ($this->level->getEntities() as $e) {
                            if ($e === $this->player || !$e->isAlive()) continue;
                            if (!($e instanceof NPCEntity) && !($e instanceof FactoryEntity)) continue;
                            $dist = $e->distance($pos);
                            if ($dist > 12) continue;
                            $scaled = $this->damage * (1 - ($dist / 12) * 0.5);
                            $ev = new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_ENTITY_EXPLOSION, $scaled);
                            $e->attack($scaled, $ev);
                            $dx = $e->x - $cx; $dz = $e->z - $cz;
                            $len = sqrt($dx*$dx + $dz*$dz);
                            if ($len > 0) {
                                $e->setMotion(new Vector3(($dx/$len)*1.5, 0.9, ($dz/$len)*1.5));
                            }
                        }

                        $this->level->addParticle(new HugeExplodeParticle($pos));
                        $this->level->addParticle(new LargeExplodeParticle($pos));
                        $this->level->addSound(new ExplodeSound($pos));
                        $this->player->sendTip("§d§lMUGGY MILE REBIRTH - Impact!");
                    }
                }
                private function cleanup() {
                    foreach ($this->formEids as $seg) BlockEffects::sendRemove($seg["eid"]);
                    $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
                }
            },
            1
        );

        $player->sendTip("§d§lMUGGY MILE REBIRTH");
        $level->addSound(new ExplodeSound($player));
    }
}
