<?php

namespace OnePieceRaid\Awaken\fruits;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\Task;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\particle\LargeExplodeParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\WaterDripParticle;
use pocketmine\level\particle\TerrainParticle;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\FizzSound;
use pocketmine\block\Block;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;
use OnePiece\Devil\BlockEffects;

class AwakenIce extends AwakenBaseFruit {

    public function getFruitId()          { return "hie_hie"; }
    public function getAbility1Name()     { return "Glacial Entombment"; }
    public function getAbility2Name()     { return "Absolute Zero Domain"; }
    public function getAbility1Cooldown() { return 18.0; }
    public function getAbility2Cooldown() { return 26.0; }

    public function onAwaken1(Player $p) { $p->sendMessage("§b§l[AWAKEN] §r§fGlacial Entombment: Impaled by the frost."); }
    public function onAwaken2(Player $p) { $p->sendMessage("§b§l[AWAKEN] §r§fAbsolute Zero Domain: Eternity in a vortex."); }

    public function useAbility1(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;
        $level = $player->getLevel();
        $victims = [];
        $eids = [];
        foreach ($level->getEntities() as $e) {
            if ($e === $player || !$e->isAlive()) continue;
            if ($e instanceof Player) {
                if (!$plugin->canTargetPlayer($player->getName(), $e)) continue;
            } elseif (!$e instanceof NPCEntity && !$e instanceof FactoryEntity) continue;
            if ($e->distance($player) > 16) continue;

            $pillarEids = [];
            for ($h = 0; $h < 5; $h++) {
                $eid = BlockEffects::newEid();
                BlockEffects::sendSpawn($level, $eid, 79, 0, $e->x, $e->y - 5 + $h, $e->z);
                $pillarEids[] = $eid;
                $eids[] = $eid;
            }
            $victims[] = ["entity" => $e, "eids" => $pillarEids, "baseY" => $e->y, "x" => $e->x, "z" => $e->z];
            $e->attack(6.67, new EntityDamageByEntityEvent($player, $e, EntityDamageEvent::CAUSE_MAGIC, 8.0));
            $level->addParticle(new LargeExplodeParticle($e->getPosition()));
        }
        if (!empty($victims)) {
            $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new AwakenRisingGlacierTask($plugin, $player, $victims, $eids, $level), 1);
        }
        $player->sendTip("§b§lGLACIAL ENTOMBMENT");
        $level->addSound(new AnvilUseSound($player));
    }

    public function useAbility2(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;
        $level = $player->getLevel();
        $eids = [];
        for ($i = 0; $i < 24; $i++) {
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($level, $eid, 174, 0, $player->x, $player->y, $player->z);
            $eids[] = $eid;
        }
        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new AwakenIceVortexTask($plugin, $player, 1.67, $eids, $level), 1);
        $player->sendTip("§b§lABSOLUTE ZERO");
        $level->addSound(new FizzSound($player));
    }
}

class AwakenRisingGlacierTask extends Task {
    private $plugin, $player, $victims, $allEids, $level, $tick = 0;

    public function __construct($pl, $p, $v, $e, $l) {
        $this->plugin   = $pl;
        $this->player   = $p;
        $this->victims  = $v;
        $this->allEids  = $e;
        $this->level    = $l;
    }

    public function onRun($t) {
        $this->tick++;
        if ($this->tick > 50) {
            $this->cleanup();
            return;
        }

        $heightLimit = 4.5;
        $riseSpeed   = 0.45;

        foreach ($this->victims as $data) {
            $e = $data["entity"];

            // isAlive() alone is not enough — a just-killed entity can pass isAlive()
            // for one or more extra ticks while its attribute map is already nulled out.
            // Always check closed first to avoid getAttribute() on null.
            if ($e->closed || !$e->isAlive()) continue;

            $currentRise = min($heightLimit, $this->tick * $riseSpeed);

            foreach ($data["eids"] as $hIndex => $eid) {
                BlockEffects::sendMove($this->level, $eid, $data["x"], ($data["baseY"] - 4.5) + $hIndex + $currentRise, $data["z"]);
            }

            $e->setMotion(new Vector3(0, 0, 0));
            $e->teleport(new Vector3($data["x"], $data["baseY"] + $currentRise, $data["z"]));

            if ($this->tick % 4 === 0) {
                $this->level->addParticle(new DustParticle($e->getPosition(), 180, 230, 255));
                $this->level->addParticle(new TerrainParticle($e->getPosition(), Block::get(79)));
            }
        }
    }

    private function cleanup() {
        foreach ($this->victims as $data) {
            $e = $data["entity"];
            // Same guard here — entity may be closed by the time cleanup fires.
            if (!$e->closed && $e->isAlive()) {
                $e->attack(11.0, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, 11.0));
                $this->level->addParticle(new HugeExplodeParticle($e->getPosition()));
                $e->setMotion(new Vector3(0, -0.3, 0));
            }
        }
        foreach ($this->allEids as $eid) BlockEffects::sendRemove($eid);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenIceVortexTask extends Task {
    private $plugin, $player, $damage, $eids, $level, $tick = 0, $victims = [];

    public function __construct($pl, $p, $dmg, $e, $l) {
        $this->plugin  = $pl;
        $this->player  = $p;
        $this->damage  = $dmg;
        $this->eids    = $e;
        $this->level   = $l;
    }

    public function onRun($t) {
        $this->tick++;

        // Guard: if the casting player is gone/dead, clean up immediately.
        if ($this->tick > 70 || $this->player->closed || !$this->player->isAlive()) {
            $this->cleanup();
            return;
        }

        $px = $this->player->x;
        $py = $this->player->y;
        $pz = $this->player->z;

        foreach ($this->eids as $i => $eid) {
            $layer  = (int)($i / 8);
            $angle  = ($this->tick * (0.22 + ($layer * 0.08))) + ($i * (M_PI / 4));
            $radius = 4 + $layer;
            $tx = $px + cos($angle) * $radius;
            $tz = $pz + sin($angle) * $radius;
            $ty = $py + $layer + (sin($this->tick * 0.25) * 0.3);
            BlockEffects::sendMove($this->level, $eid, $tx, $ty, $tz);
        }

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || $e->closed || !$e->isAlive()) continue;
            if ($e instanceof Player) {
                if (!$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
            } elseif (!$e instanceof NPCEntity && !$e instanceof FactoryEntity) continue;
            if ($e->distance($this->player) > 9) continue;

            if (!isset($this->victims[$e->getId()])) $this->victims[$e->getId()] = $e->getPosition();

            $e->setMotion(new Vector3(0, 0, 0));
            $e->teleport($this->victims[$e->getId()]);

            if ($this->tick % 10 === 0) {
                $e->attack($this->damage, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->damage));
                $this->level->addParticle(new CriticalParticle($e->getPosition()->add(0, 1, 0)));
            }
            if ($this->tick % 5 === 0) $this->level->addParticle(new WaterDripParticle($e->getPosition()->add(0, 1.5, 0)));
        }
    }

    private function cleanup() {
        foreach ($this->eids as $eid) BlockEffects::sendRemove($eid);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}