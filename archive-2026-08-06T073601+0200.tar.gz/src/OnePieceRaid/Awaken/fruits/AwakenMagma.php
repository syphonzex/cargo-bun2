<?php

namespace OnePieceRaid\Awaken\fruits;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\Task;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\LargeExplodeParticle;
use pocketmine\level\particle\ExplodeParticle;
use pocketmine\level\particle\TerrainParticle;
use pocketmine\level\particle\LavaDripParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\WhiteSmokeParticle;
use pocketmine\level\particle\RedstoneParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\sound\ExplodeSound;
use pocketmine\level\sound\BlazeShootSound;
use pocketmine\level\sound\FizzSound;
use pocketmine\block\Block;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;
use OnePiece\Devil\BlockEffects;

class AwakenMagma extends AwakenBaseFruit {

    public function getFruitId()          { return "magu_magu"; }
    public function getAbility1Name()     { return "Meikyo: Crimson Claw"; }
    public function getAbility2Name()     { return "Great Eruption: Guren"; }
    public function getAbility1Cooldown() { return 12.0; }
    public function getAbility2Cooldown() { return 28.0; }

    public function onAwaken1(Player $p) { $p->sendMessage("§6§l[AWAKEN] §fMeikyo: Crimson Claw awakened!"); }
    public function onAwaken2(Player $p) { $p->sendMessage("§6§l[AWAKEN] §fGreat Eruption: Guren awakened!"); }

    public function useAbility1(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;
        $level = $player->getLevel();
        $eids = [];
        for($i=0; $i<10; $i++){
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($level, $eid, ($i < 4 ? 49 : 159), ($i < 4 ? 0 : 14), $player->x, $player->y, $player->z);
            $eids[] = $eid;
        }
        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new MagmaClawTask($plugin, $player, 8.5, $eids, $level), 1);
        $player->sendTip("§6§lSTEERABLE CRIMSON CLAW");
    }

    public function useAbility2(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;
        $level = $player->getLevel();
        $cx = $player->x; $cy = $player->y; $cz = $player->z;
        $coreEid = BlockEffects::newEid();
        BlockEffects::sendSpawn($level, $coreEid, 49, 0, $cx, $cy + 30, $cz);
        $shell = [];
        for ($i = 0; $i < 14; $i++) {
            $eid = BlockEffects::newEid();
            $angle = (2 * M_PI / 14) * $i;
            BlockEffects::sendSpawn($level, $eid, ($i % 2 == 0 ? 87 : 159), ($i % 2 == 0 ? 0 : 14), $cx, $cy + 30, $cz);
            $shell[] = ["eid" => $eid, "a" => (float)$angle];
        }
        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new MagmaGurenTask($plugin, $player, 10.0, $coreEid, $shell, $level, $cx, $cy, $cz), 1);
        $player->sendTip("§6§lINUGAMI GUREN");
    }
}

class MagmaClawTask extends Task {
    private $plugin, $player, $dmg, $eids, $level, $tick = 0, $targets = [];
    private $offsets = [
        [2.0, 0.0, 0.5], [2.0, 0.0, -0.5], [2.2, 0.5, 0.0], [2.2, -0.5, 0.0],
        [1.0, 0.0, 0.8], [1.0, 0.0, -0.8], [1.5, 0.5, 0.5], [1.5, 0.5, -0.5],
        [0.5, 0.0, 0.0], [1.2, -0.5, 0.0]
    ];

    public function __construct($p, $pl, $d, $e, $l) {
        $this->plugin = $p; $this->player = $pl; $this->dmg = $d; $this->eids = $e; $this->level = $l;
    }

    public function onRun($t) {
        $this->tick++;
        if ($this->tick > 25 || !$this->player->isAlive()) { $this->cleanup(); return; }
        
        $currentDir = $this->player->getDirectionVector();
        $this->player->setMotion($currentDir->multiply(1.4));
        
        $px = $this->player->x; $py = $this->player->y; $pz = $this->player->z;
        $yaw = ($this->player->yaw + 90) * M_PI / 180;

        foreach($this->eids as $k => $id) {
            $lx = $this->offsets[$k][0]; $ly = $this->offsets[$k][1]; $lz = $this->offsets[$k][2];
            $rx = $lx * cos($yaw) - $lz * sin($yaw);
            $rz = $lx * sin($yaw) + $lz * cos($yaw);
            BlockEffects::sendMove($this->level, $id, $px + $rx, $py + 1 + $ly, $pz + $rz, 0);
            if($this->tick % 3 === 0) $this->level->addParticle(new FlameParticle(new Vector3($px + $rx, $py + 1 + $ly, $pz + $rz)));
        }

        $this->level->addParticle(new SmokeParticle(new Vector3($px, $py + 0.5, $pz)));
        
        foreach($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e->distance($this->player) <= 5.2) {
                if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
                $e->setMotion(new Vector3(0, 0, 0));
                $tx = 2.6 * cos($yaw); $tz = 2.6 * sin($yaw);
                $e->teleport(new Vector3($px + $tx, $py, $pz + $tz));
                $this->targets[$e->getId()] = $e;
            }
        }

        if($this->tick === 25) {
            $this->level->addSound(new ExplodeSound($this->player));
            $this->level->addParticle(new LargeExplodeParticle($this->player));
            foreach($this->targets as $e) {
                if($e->isAlive()) {
                    $e->attack($this->dmg, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->dmg));
                    $e->setMotion(new Vector3($currentDir->x * 1.8, 0.7, $currentDir->z * 1.8));
                }
            }
        }
    }

    private function cleanup() {
        foreach($this->eids as $id) BlockEffects::sendRemove($id);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class MagmaGurenTask extends Task {
    private $plugin, $player, $dmg, $core, $shell, $level, $tick = 0, $done = false;
    private $cx, $cy, $cz, $my;
    public function __construct($p, $pl, $d, $c, $s, $l, $cx, $cy, $cz) {
        $this->plugin = $p; $this->player = $pl; $this->dmg = $d; $this->core = $c;
        $this->shell = $s; $this->level = $l; $this->cx = $cx; $this->cy = $cy; $this->cz = $cz; $this->my = $cy + 30.0;
    }
    public function onRun($t) {
        $this->tick++;
        if ($this->tick > 70 || $this->done || !$this->player->isAlive()) { $this->cleanup(); return; }
        $this->my -= 1.4;
        BlockEffects::sendMove($this->level, $this->core, $this->cx, $this->my, $this->cz, 0);
        foreach ($this->shell as &$s) {
            $a = $s["a"] + $this->tick * 0.5;
            BlockEffects::sendMove($this->level, $s["eid"], $this->cx + cos($a)*3, $this->my + sin($this->tick*0.5), $this->cz + sin($a)*3, 0);
            if ($this->tick % 2 == 0) {
                $pos = new Vector3($this->cx + cos($a)*3, $this->my, $this->cz + sin($a)*3);
                $this->level->addParticle(new CriticalParticle($pos));
                $this->level->addParticle(new RedstoneParticle($pos));
            }
        }
        if ($this->my <= $this->cy + 0.5) {
            $this->done = true;
            $pos = new Vector3($this->cx, $this->cy, $this->cz);
            $this->level->addSound(new ExplodeSound($pos));
            $this->level->addParticle(new LargeExplodeParticle($pos));
            foreach ($this->level->getEntities() as $e) {
                if ($e === $this->player || !$e->isAlive()) continue;
                if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
                if ($e->distance($pos) <= 9.0) {
                    if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
                    $e->attack($this->dmg, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->dmg));
                    $e->setMotion(new Vector3(($e->x-$this->cx)*0.5, 1.2, ($e->z-$this->cz)*0.5));
                }
            }
            $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(new MagmaPuddleTask($this->plugin, $this->player, $pos, $this->level), 1);
        }
    }
    private function cleanup() {
        BlockEffects::sendRemove($this->core);
        foreach ($this->shell as $s) BlockEffects::sendRemove($s["eid"]);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class MagmaPuddleTask extends Task {
    private $plugin, $player, $pos, $level, $tick = 0, $eids = [];
    public function __construct($p, $pl, $pos, $l) {
        $this->plugin = $p; $this->player = $pl; $this->pos = $pos; $this->level = $l;
        for($i=0; $i<6; $i++){
            $eid = BlockEffects::newEid();
            $a = (2 * M_PI / 6) * $i;
            BlockEffects::sendSpawn($l, $eid, 159, 14, $pos->x + cos($a)*2.5, $pos->y, $pos->z + sin($a)*2.5);
            $this->eids[] = $eid;
        }
    }
    public function onRun($t) {
        $this->tick++;
        if ($this->tick > 100) {
            foreach($this->eids as $id) BlockEffects::sendRemove($id);
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }
        if ($this->tick % 10 == 0) {
            $this->level->addSound(new FizzSound($this->pos));
            foreach ($this->level->getEntities() as $e) {
                if ($e === $this->player || !$e->isAlive()) continue;
                if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
                if ($e->distance($this->pos) <= 5.5) {
                    if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
                    $e->attack(1.2, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, 1.2));
                }
            }
        }
        $randX = mt_rand(-30, 30) / 10; $randZ = mt_rand(-30, 30) / 10;
        $pPos = new Vector3($this->pos->x + $randX, $this->pos->y + 0.5, $this->pos->z + $randZ);
        $this->level->addParticle($this->tick < 70 ? new FlameParticle($pPos) : new WhiteSmokeParticle($pPos));
    }
}