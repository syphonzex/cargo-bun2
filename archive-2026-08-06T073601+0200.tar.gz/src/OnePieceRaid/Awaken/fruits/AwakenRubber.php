<?php

namespace OnePieceRaid\Awaken\fruits;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\entity\Effect;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\Task;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\particle\LargeExplodeParticle;
use pocketmine\level\particle\ExplodeParticle;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\BlazeShootSound;
use pocketmine\level\sound\ExplodeSound;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;
use OnePiece\Devil\BlockEffects;

class AwakenRubber extends AwakenBaseFruit {

    public function getFruitId()          { return "gomu_gomu"; }
    public function getAbility1Name()     { return "Red Hawk"; }
    public function getAbility2Name()     { return "Jet Gatling"; }
    public function getAbility1Cooldown() { return 6.0; }
    public function getAbility2Cooldown() { return 18.0; }

    public function onAwaken1(Player $player) {
        $player->sendMessage("§c[AWAKEN] §fRed Hawk awakened!");
        $player->sendMessage("§7A blazing fist coated in Haki and fire tears through the enemy.");
    }

    public function onAwaken2(Player $player) {
        $player->sendMessage("§c[AWAKEN] §fJet Gatling awakened!");
        $player->sendMessage("§7Thousands of compressed rubber fists release in a storm of devastation.");
    }

    public function useAbility1(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;

        $damage = 9.0;

        $this->spawnRedHawkWindup($player, $plugin);

        $plugin->getServer()->getScheduler()->scheduleDelayedTask(
            new class($player, $damage, $plugin) extends Task {
                private $player, $damage, $plugin;
                public function __construct($p, $d, $pl) {
                    $this->player = $p; $this->damage = $d; $this->plugin = $pl;
                }
                public function onRun($t) {
                    if (!$this->player->isOnline()) return;
                    $dir = $this->player->getDirectionVector();
                    $this->player->setMotion(new Vector3($dir->x * 1.8, 0.35, $dir->z * 1.8));

                    $plugin2  = $this->plugin;
                    $player2  = $this->player;
                    $damage2  = $this->damage;

                    $plugin2->getServer()->getScheduler()->scheduleDelayedTask(
                        new class($player2, $damage2, $plugin2) extends Task {
                            private $player, $damage, $plugin;
                            public function __construct($p, $d, $pl) {
                                $this->player = $p; $this->damage = $d; $this->plugin = $pl;
                            }
                            public function onRun($t) {
                                if (!$this->player->isOnline()) return;
                                $level  = $this->player->getLevel();
                                $center = new Vector3($this->player->x, $this->player->y, $this->player->z);

                                foreach ($level->getEntities() as $e) {
                                    if ($e === $this->player || !$e->isAlive()) continue;
                                    if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
                                    if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
                                    if ($e->distance($center) > 4.5) continue;
                                    $ev = new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->damage);
                                    $e->attack($this->damage, $ev);
                                    $dir = $this->player->getDirectionVector();
                                    $e->setMotion(new Vector3($dir->x * 2.2, 0.6, $dir->z * 2.2));
                                }

                                for ($i = 0; $i < 20; $i++) {
                                    $level->addParticle(new FlameParticle(new Vector3(
                                        $this->player->x + mt_rand(-20, 20) / 10.0,
                                        $this->player->y + mt_rand(0, 20) / 10.0,
                                        $this->player->z + mt_rand(-20, 20) / 10.0
                                    )));
                                    if ($i % 2 === 0) {
                                        $level->addParticle(new CriticalParticle(new Vector3(
                                            $this->player->x + mt_rand(-15, 15) / 10.0,
                                            $this->player->y + 1,
                                            $this->player->z + mt_rand(-15, 15) / 10.0
                                        )));
                                    }
                                }

                                $this->spawnImpactRing($this->player, $this->plugin);
                                $level->addParticle(new HugeExplodeParticle($center));
                                $level->addSound(new ExplodeSound($center));
                                $this->player->sendTip("§c§lRED HAWK - LANDED!");
                            }

                            private function spawnImpactRing(Player $player, $plugin) {
                                $level = $player->getLevel();
                                $eids  = [];
                                for ($i = 0; $i < 12; $i++) {
                                    $angle = (2 * M_PI / 12) * $i;
                                    $eid   = BlockEffects::newEid();
                                    BlockEffects::sendSpawn($level, $eid, 87, 0,
                                        $player->x + cos($angle) * 3,
                                        $player->y,
                                        $player->z + sin($angle) * 3
                                    );
                                    $eids[] = $eid;
                                }
                                $plugin->getServer()->getScheduler()->scheduleDelayedTask(
                                    new class($plugin, $eids) extends Task {
                                        private $plugin, $eids;
                                        public function __construct($pl, $e) { $this->plugin = $pl; $this->eids = $e; }
                                        public function onRun($t) { foreach ($this->eids as $eid) BlockEffects::sendRemove($eid); }
                                    },
                                    25
                                );
                            }
                        },
                        8
                    );
                }
            },
            12
        );

        $player->sendTip("§c§lRED HAWK - Winding up...");
    }

    public function useAbility2(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;

        $damage = 1.57;

        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(
            new AwakenJetGatlingTask($plugin, $player, $damage),
            1
        );

        $player->sendTip("§c§lJET GATLING");
        $player->getLevel()->addSound(new BlazeShootSound($player));
    }

    private function spawnRedHawkWindup(Player $player, $plugin) {
        $level = $player->getLevel();
        $eids  = [];

        for ($i = 0; $i < 8; $i++) {
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($level, $eid, 87, 0,
                $player->x + mt_rand(-10, 10) / 10.0,
                $player->y + mt_rand(5, 15) / 10.0,
                $player->z + mt_rand(-10, 10) / 10.0
            );
            $eids[] = $eid;
        }

        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(
            new class($plugin, $player, $eids, $level) extends Task {
                private $plugin, $player, $eids, $level, $tick = 0;
                public function __construct($pl, $p, $e, $lv) {
                    $this->plugin = $pl; $this->player = $p; $this->eids = $e; $this->level = $lv;
                }
                public function onRun($t) {
                    $this->tick++;
                    if ($this->tick > 12) {
                        foreach ($this->eids as $eid) BlockEffects::sendRemove($eid);
                        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
                        return;
                    }
                    foreach ($this->eids as $i => $eid) {
                        $a = (2 * M_PI / count($this->eids)) * $i + ($this->tick * 0.3);
                        $r = 1.5 + sin($this->tick * 0.5) * 0.5;
                        BlockEffects::sendMove($this->level, $eid,
                            $this->player->x + cos($a) * $r,
                            $this->player->y + 1 + ($this->tick * 0.05),
                            $this->player->z + sin($a) * $r,
                            $this->tick * 25
                        );
                        $this->level->addParticle(new FlameParticle(new Vector3(
                            $this->player->x + cos($a) * $r,
                            $this->player->y + 1,
                            $this->player->z + sin($a) * $r
                        )));
                    }
                }
            },
            1
        );
    }
}

class AwakenJetGatlingTask extends Task {

    private $plugin, $player, $level, $damage;
    private $tick = 0, $totalTicks = 70;
    private $shellEids = [], $hitLog = [];

    public function __construct($plugin, Player $player, $damage) {
        $this->plugin  = $plugin;
        $this->player  = $player;
        $this->level   = $player->getLevel();
        $this->damage  = $damage;

        for ($i = 0; $i < 10; $i++) {
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($this->level, $eid, 1, 0,
                $player->x, $player->y + 1, $player->z
            );
            $this->shellEids[] = ["eid" => $eid, "angle" => (2 * M_PI / 10) * $i];
        }

        $player->addEffect(
            Effect::getEffect(Effect::SPEED)->setAmplifier(2)->setDuration(80)->setVisible(false)
        );
    }

    public function onRun($currentTick) {
        if ($this->player === null || !$this->player->isOnline()) {
            $this->cleanup();
            return;
        }

        $this->tick++;
        if ($this->tick > $this->totalTicks) {
            $this->cleanup();
            return;
        }

        $cx = $this->player->x;
        $cy = $this->player->y;
        $cz = $this->player->z;

        foreach ($this->shellEids as &$seg) {
            $seg["angle"] += 0.45;
            $r = 2.0;
            BlockEffects::sendMove($this->level, $seg["eid"],
                $cx + cos($seg["angle"]) * $r,
                $cy + 1.0 + sin($seg["angle"] * 2) * 0.4,
                $cz + sin($seg["angle"]) * $r,
                (int)($seg["angle"] * 100)
            );
        }

        if ($this->tick % 3 === 0) {
            $dir    = $this->player->getDirectionVector();
            $shotX  = $cx + $dir->x * 2;
            $shotY  = $cy + 1;
            $shotZ  = $cz + $dir->z * 2;
            $shotEid = BlockEffects::newEid();
            BlockEffects::sendSpawn($this->level, $shotEid, 1, 0, $shotX, $shotY, $shotZ);

            $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(
                new class($this->plugin, $this->player, $this->damage, $shotEid, $dir, $this->level, $this->hitLog) extends Task {
                    private $plugin, $player, $damage, $eid, $dir, $level, $hitLog;
                    private $sx, $sy, $sz, $stk = 0;
                    public function __construct($pl, $p, $d, $eid, $dir, $lv, &$hl) {
                        $this->plugin = $pl; $this->player = $p; $this->damage = $d;
                        $this->eid = $eid; $this->dir = $dir; $this->level = $lv; $this->hitLog = &$hl;
                        $this->sx = $p->x + $dir->x * 2; $this->sy = $p->y + 1; $this->sz = $p->z + $dir->z * 2;
                    }
                    public function onRun($t) {
                        $this->stk++;
                        if ($this->stk > 15) { $this->end(); return; }
                        $this->sx += $this->dir->x * 2.0;
                        $this->sy += $this->dir->y * 0.5;
                        $this->sz += $this->dir->z * 2.0;
                        BlockEffects::sendMove($this->level, $this->eid, $this->sx, $this->sy, $this->sz, $this->stk * 20);
                        $this->level->addParticle(new CriticalParticle(new Vector3($this->sx, $this->sy, $this->sz)));
                        $this->level->addParticle(new FlameParticle(new Vector3($this->sx, $this->sy, $this->sz)));
                        $pos = new Vector3($this->sx, $this->sy, $this->sz);
                        foreach ($this->level->getEntities() as $e) {
                            if ($e === $this->player || !$e->isAlive()) continue;
                            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
                            if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
                            $key = $this->eid . "_" . $e->getId();
                            if (isset($this->hitLog[$key])) continue;
                            if ($e->distance($pos) <= 2.0) {
                                $ev = new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->damage);
                                $e->attack($this->damage, $ev);
                                $this->hitLog[$key] = true;
                                $this->end(); return;
                            }
                        }
                        $b = $this->level->getBlock($pos);
                        if ($b->getId() !== 0 && $b->getId() !== 8 && $b->getId() !== 9) { $this->end(); return; }
                    }
                    private function end() {
                        BlockEffects::sendRemove($this->eid);
                        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
                    }
                },
                1
            );
        }

        for ($i = 0; $i < 4; $i++) {
            $this->level->addParticle(new CriticalParticle(new Vector3(
                $cx + mt_rand(-20, 20) / 10.0, $cy + 1, $cz + mt_rand(-20, 20) / 10.0
            )));
        }

        if ($this->tick === $this->totalTicks) {
            $this->player->sendTip("§c§lJET GATLING - Done!");
        }
    }

    private function cleanup() {
        foreach ($this->shellEids as $seg) BlockEffects::sendRemove($seg["eid"]);
        if ($this->player !== null && $this->player->isOnline()) {
            $this->player->removeEffect(Effect::SPEED);
        }
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}
