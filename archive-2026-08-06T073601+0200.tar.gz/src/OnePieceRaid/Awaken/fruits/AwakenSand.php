<?php

namespace OnePieceRaid\Awaken\fruits;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\Task;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\LargeExplodeParticle;
use pocketmine\level\particle\ExplodeParticle;
use pocketmine\level\particle\TerrainParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\WhiteSmokeParticle;
use pocketmine\level\particle\SpellParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\sound\EndermanTeleportSound;
use pocketmine\level\sound\AnvilFallSound;
use pocketmine\level\sound\FizzSound;
use pocketmine\block\Block;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;
use OnePiece\Devil\BlockEffects;

class AwakenSand extends AwakenBaseFruit {

    public function getFruitId()          { return "suna_suna"; }
    public function getAbility1Name()     { return "Sabaku Taiso"; }
    public function getAbility2Name()     { return "Kami no Sabaki"; }
    public function getAbility1Cooldown() { return 15.0; }
    public function getAbility2Cooldown() { return 28.0; }

    public function onAwaken1(Player $p) { $p->sendMessage("§e§l[AWAKENED] §6Sabaku Taiso!"); }
    public function onAwaken2(Player $p) { $p->sendMessage("§e§l[AWAKENED] §6Kami no Sabaki!"); }

    public function useAbility1(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;
        $level = $player->getLevel();
        $cx = $player->x; $cy = $player->y; $cz = $player->z;
        $walls = [];
        for ($layer = 0; $layer < 3; $layer++) {
            $radius = 7 - ($layer * 1.5);
            $count  = 12 - ($layer * 2);
            for ($a = 0; $a < $count; $a++) {
                $angle = (2 * M_PI / $count) * $a;
                $eid = BlockEffects::newEid();
                BlockEffects::sendSpawn($level, $eid, 35, $layer === 0 ? 1 : 12, $cx + cos($angle) * $radius, $cy + ($layer * 0.5), $cz + sin($angle) * $radius);
                $walls[] = ["eid" => $eid, "angle" => $angle, "layer" => $layer, "rad" => $radius];
            }
        }
        $ground = [];
        for ($i = 0; $i < 8; $i++) {
            $angle = (2 * M_PI / 8) * $i;
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($level, $eid, 12, 0, $cx + cos($angle) * 3, $cy - 0.5, $cz + sin($angle) * 3);
            $ground[] = ["eid" => $eid, "angle" => $angle];
        }
        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new SabakuTaisoTask($plugin, $player, 1.6, $walls, $ground, $level, $cx, $cy, $cz), 1);
        $level->addSound(new FizzSound($player));
    }

    public function useAbility2(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;
        $level = $player->getLevel();
        $cx = $player->x; $cy = $player->y; $cz = $player->z;
        $pillars = [];
        for ($p = 0; $p < 6; $p++) {
            $angle = (2 * M_PI / 6) * $p;
            $px = $cx + cos($angle) * 6.0; $pz = $cz + sin($angle) * 6.0;
            $segs = [];
            for ($s = 0; $s < 5; $s++) {
                $eid = BlockEffects::newEid();
                BlockEffects::sendSpawn($level, $eid, 12, 0, $px, $cy - 1, $pz);
                $segs[] = ["eid" => $eid, "x" => $px, "y" => $cy + $s, "z" => $pz, "cy" => $cy - 1, "rem" => false];
            }
            $pillars[] = ["segs" => $segs, "px" => $px, "pz" => $pz, "risen" => false, "hit1" => false];
        }
        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new DesertJudgementTask($plugin, $player, 4.0, $pillars, $level, $cx, $cy, $cz), 1);
        $level->addSound(new AnvilFallSound($player));
    }
}

class SabakuTaisoTask extends Task {
    private $plugin, $player, $dmg, $walls, $ground, $level, $cx, $cy, $cz, $tick = 0;
    public function __construct($pl, $p, $d, $w, $g, $l, $x, $y, $z) {
        $this->plugin = $pl; $this->player = $p; $this->dmg = $d;
        $this->walls = $w; $this->ground = $g; $this->level = $l;
        $this->cx = $x; $this->cy = $y; $this->cz = $z;
    }
    public function onRun($t) {
        $this->tick++;
        if ($this->tick > 60 || !$this->player->isAlive()) { $this->cleanup(); return; }
        $comp = max(0.3, 1 - ($this->tick / 80));
        foreach ($this->walls as $w) {
            $rot = ($this->tick * (0.15 + $w["layer"] * 0.05)) + $w["angle"];
            $rad = $w["rad"] * $comp;
            $wx = $this->cx + cos($rot) * $rad; $wz = $this->cz + sin($rot) * $rad; $wy = $this->cy + ($w["layer"] * 0.5);
            BlockEffects::sendMove($this->level, $w["eid"], $wx, $wy, $wz, $this->tick * 10);
            if($this->tick % 2 === 0) $this->level->addParticle(new DustParticle(new Vector3($wx, $wy, $wz), 210, 180, 100));
        }
        foreach ($this->ground as $g) {
            $rot = ($this->tick * 0.25) + $g["angle"];
            $gx = $this->cx + cos($rot) * (3 * $comp); $gz = $this->cz + sin($rot) * (3 * $comp);
            BlockEffects::sendMove($this->level, $g["eid"], $gx, $this->cy - 0.5, $gz, $this->tick * 15);
            $this->level->addParticle(new SmokeParticle(new Vector3($gx, $this->cy, $gz)));
        }
        if($this->tick % 5 === 0) $this->level->addParticle(new LargeExplodeParticle(new Vector3($this->cx + mt_rand(-5,5), $this->cy, $this->cz + mt_rand(-5,5))));
        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive()) continue;
            if (!($e instanceof Player) && !($e instanceof NPCEntity) && !($e instanceof FactoryEntity)) continue;
            if ($e->distance(new Vector3($this->cx, $this->cy, $this->cz)) > 8) continue;
            if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
            $e->setMotion(new Vector3(0, 0, 0));
            $this->level->addParticle(new DustParticle(new Vector3($e->x, $e->y + 1, $e->z), 210, 180, 100));
            if ($this->tick % 10 === 0) $e->attack($this->dmg, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->dmg));
        }
    }
    private function cleanup() {
        foreach ($this->walls as $w) BlockEffects::sendRemove($w["eid"]);
        foreach ($this->ground as $g) BlockEffects::sendRemove($g["eid"]);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class DesertJudgementTask extends Task {
    private $plugin, $player, $dmg, $pillars, $level, $cx, $cy, $cz, $tick = 0, $stun = [];
    public function __construct($pl, $p, $d, $pi, $l, $x, $y, $z) {
        $this->plugin = $pl; $this->player = $p; $this->dmg = $d;
        $this->pillars = $pi; $this->level = $l;
        $this->cx = $x; $this->cy = $y; $this->cz = $z;
    }
    public function onRun($t) {
        $this->tick++;
        if ($this->tick > 90 || !$this->player->isAlive()) { $this->cleanup(); return; }
        $phase = $this->tick <= 15 ? "rise" : ($this->tick <= 35 ? "hold" : "collapse");
        foreach ($this->pillars as &$p) {
            if ($phase === "rise") {
                foreach ($p["segs"] as &$s) {
                    $s["cy"] = min($s["y"], $s["cy"] + 0.7);
                    BlockEffects::sendMove($this->level, $s["eid"], $s["x"], $s["cy"], $s["z"], $this->tick * 15);
                    $this->level->addParticle(new TerrainParticle(new Vector3($s["x"], $s["cy"], $s["z"]), Block::get(12, 0)));
                }
                if ($this->tick === 15) $this->hit($p);
            }
            if ($phase === "collapse") {
                $prog = ($this->tick - 35) / 15.0;
                foreach ($p["segs"] as &$s) {
                    if ($s["rem"]) continue;
                    if ($this->tick >= 51) { BlockEffects::sendRemove($s["eid"]); $s["rem"] = true; continue; }
                    $nx = $s["x"] + ($this->cx - $s["x"]) * min(1.0, $prog * 0.2);
                    $nz = $s["z"] + ($this->cz - $s["z"]) * min(1.0, $prog * 0.2);
                    BlockEffects::sendMove($this->level, $s["eid"], $nx, $s["y"], $nz, $this->tick * 20);
                    $this->level->addParticle(new WhiteSmokeParticle(new Vector3($nx, $s["y"], $nz)));
                    $this->level->addParticle(new DustParticle(new Vector3($nx, $s["y"], $nz), 210, 180, 100));
                }
                if (!$p["hit1"]) { $this->hit($p); $p["hit1"] = true; }
            }
        }
        if ($this->tick === 51) $this->vfx();
        foreach ($this->stun as $eid => $d) {
            $e = $d["e"];
            if (!$e->isAlive() || $this->tick > $d["u"]) { unset($this->stun[$eid]); continue; }
            $e->setMotion(new Vector3(0,0,0)); $e->teleport(new Vector3($d["x"], $d["y"], $d["z"]));
            if($this->tick % 5 === 0) {
                $this->level->addParticle(new SpellParticle(new Vector3($e->x, $e->y + 1, $e->z)));
                $this->level->addParticle(new CriticalParticle(new Vector3($e->x, $e->y + 1, $e->z)));
            }
        }
    }
    private function hit(&$p) {
        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive()) continue;
            if (!($e instanceof Player) && !($e instanceof NPCEntity) && !($e instanceof FactoryEntity)) continue;
            if ($e->distance(new Vector3($this->cx, $this->cy, $this->cz)) > 6.5) continue;
            if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
            $e->attack($this->dmg, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->dmg));
            $this->stun[$e->getId()] = ["e" => $e, "u" => $this->tick + 35, "x" => $e->x, "y" => $e->y, "z" => $e->z];
            $this->level->addParticle(new LargeExplodeParticle($e->getPosition()));
        }
    }
    private function vfx() {
        for ($i = 0; $i < 40; $i++) {
            $v = new Vector3($this->cx + mt_rand(-30,30)/10, $this->cy + mt_rand(0,20)/10, $this->cz + mt_rand(-30,30)/10);
            $this->level->addParticle(new ExplodeParticle($v));
            $this->level->addParticle(new TerrainParticle($v, Block::get(12, 0)));
        }
        $this->level->addSound(new EndermanTeleportSound(new Vector3($this->cx, $this->cy, $this->cz)));
    }
    private function cleanup() {
        foreach ($this->pillars as $p) {
            foreach ($p["segs"] as $s) { if (!$s["rem"]) BlockEffects::sendRemove($s["eid"]); }
        }
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}