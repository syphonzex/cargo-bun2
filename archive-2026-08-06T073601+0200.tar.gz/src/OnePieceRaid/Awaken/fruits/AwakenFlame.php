<?php

namespace OnePieceRaid\Awaken\fruits;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\Task;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\particle\LargeExplodeParticle;
use pocketmine\level\particle\ExplodeParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\LavaDripParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\TerrainParticle;
use pocketmine\level\sound\BlazeShootSound;
use pocketmine\level\sound\ExplodeSound;
use pocketmine\level\sound\FizzSound;
use pocketmine\block\Block;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;
use OnePiece\Devil\BlockEffects;

class AwakenFlame extends AwakenBaseFruit {

    public function getFruitId()          { return "mera_mera"; }
    public function getAbility1Name()     { return "Fire Dragon Judgement"; }
    public function getAbility2Name()     { return "Dai Enkai: Flame Emperor"; }
    public function getAbility1Cooldown() { return 14.0; }
    public function getAbility2Cooldown() { return 27.0; }

    public function onAwaken1(Player $p) { $p->sendMessage("§c§l[AWAKEN] §fFire Dragon Judgement unlocked!"); }
    public function onAwaken2(Player $p) { $p->sendMessage("§c§l[AWAKEN] §fDai Enkai: Flame Emperor unlocked!"); }

    public function useAbility1(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;
        $level = $player->getLevel();
        $segs = [];
        for ($i = 0; $i < 12; $i++) {
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($level, $eid, ($i == 0 ? 87 : 35), ($i == 0 ? 0 : 14), $player->x, $player->y + 1, $player->z);
            $segs[] = ["eid" => $eid, "hit" => []];
        }
        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new FireDragonTask($plugin, $player, 10.0, $segs, $level), 1);
        $player->sendTip("§c§lFIRE DRAGON");
        $level->addSound(new ExplodeSound($player));
    }

    public function useAbility2(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;
        $level = $player->getLevel();
        $eids = [];
        for ($i = 0; $i < 24; $i++) {
            $eid = BlockEffects::newEid();
            $meta = ($i < 8) ? 14 : (($i < 16) ? 1 : 4);
            BlockEffects::sendSpawn($level, $eid, 35, $meta, $player->x, $player->y + 4.5, $player->z);
            $eids[] = $eid;
        }
        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new FlameEmperorTask($plugin, $player, 9.0, $eids, $level), 1);
        $player->sendTip("§6§lDAI ENKAI... §cENTEI!");
        $level->addSound(new FizzSound($player));
    }
}

class FireDragonTask extends Task {
    private $plugin, $player, $dmg, $segs, $level, $tick = 0, $bx, $by, $bz, $dragged = [], $target = null, $initialDir;
    public function __construct($pl, $p, $d, $s, $l) {
        $this->plugin = $pl; $this->player = $p; $this->dmg = $d; $this->segs = $s; $this->level = $l;
        $this->bx = $p->x; $this->by = $p->y + 1; $this->bz = $p->z;
        $this->initialDir = $p->getDirectionVector();
        $this->target = $this->findLockTarget();
    }
    private function findLockTarget() {
        $best = null; $minDot = 0.85;
        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
            $toEntity = $e->getPosition()->subtract($this->player->getPosition());
            if ($toEntity->length() < 18) {
                $dot = $this->initialDir->dot($toEntity->normalize());
                if ($dot > $minDot) { $minDot = $dot; $best = $e; }
            }
        }
        return $best;
    }
    public function onRun($t) {
        $this->tick++;
        if ($this->tick > 55 || !$this->player->isAlive()) { $this->cleanup(); return; }
        $headPos = new Vector3($this->bx, $this->by, $this->bz);
        $moveDir = $this->initialDir;
        if ($this->target !== null && $this->target->isAlive()) {
            $moveDir = $this->target->getPosition()->add(0, 1, 0)->subtract($headPos)->normalize();
        }
        $this->bx += $moveDir->x * 1.8; $this->by += $moveDir->y * 1.8; $this->bz += $moveDir->z * 1.8;
        $currentHead = new Vector3($this->bx, $this->by, $this->bz);
        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive() || isset($this->dragged[$e->getId()])) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
            if ($e->distance($currentHead) <= 3.0) {
                $this->dragged[$e->getId()] = $e;
                $e->attack($this->dmg, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->dmg));
            }
        }
        foreach ($this->segs as $i => &$s) {
            $lag = $i * 1.2;
            $sx = $this->bx - $moveDir->x * $lag; $sz = $this->bz - $moveDir->z * $lag;
            $sy = ($this->by - $moveDir->y * $lag) + sin(($this->tick - $i) * 0.4) * 0.5;
            BlockEffects::sendMove($this->level, $s["eid"], $sx, $sy, $sz, 0);
            if ($this->tick % 2 == 0) $this->level->addParticle(new FlameParticle(new Vector3($sx, $sy, $sz)));
            if ($i == 0) $this->level->addParticle(new HugeExplodeParticle(new Vector3($sx, $sy, $sz)));
        }
        foreach ($this->dragged as $id => $e) {
            if ($e->isAlive()) {
                $e->setMotion(new Vector3(0, 0, 0));
                $e->teleport($currentHead);
            } else unset($this->dragged[$id]);
        }
    }
    private function cleanup() {
        $pos = new Vector3($this->bx, $this->by, $this->bz);
        $this->level->addSound(new ExplodeSound($pos));
        foreach ($this->dragged as $e) { if ($e->isAlive()) $e->setMotion(new Vector3(mt_rand(-1,1), 0.8, mt_rand(-1,1))); }
        foreach ($this->segs as $s) BlockEffects::sendRemove($s["eid"]);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class FlameEmperorTask extends Task {
    private $plugin, $player, $dmg, $eids, $level, $tick = 0, $bx, $by, $bz, $launched = false, $target = null, $vDir;
    public function __construct($pl, $p, $d, $e, $l) {
        $this->plugin = $pl; $this->player = $p; $this->dmg = $d; $this->eids = $e; $this->level = $l;
    }
    private function findLockTarget($dir) {
        $best = null; $minDot = 0.85;
        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
            $toEntity = $e->getPosition()->subtract($this->player->getPosition());
            if ($toEntity->length() < 15) {
                $dot = $dir->dot($toEntity->normalize());
                if ($dot > $minDot) { $minDot = $dot; $best = $e; }
            }
        }
        return $best;
    }
    public function onRun($t) {
        $this->tick++;
        if (!$this->player->isAlive()) { $this->cleanup(); return; }
        if (!$this->launched) {
            $this->bx = $this->player->x; $this->by = $this->player->y + 4.5; $this->bz = $this->player->z;
            if ($this->tick >= 20) {
                $this->launched = true;
                $this->vDir = $this->player->getDirectionVector();
                $this->target = $this->findLockTarget($this->vDir);
                $this->level->addSound(new BlazeShootSound($this->player));
            }
            $this->level->addParticle(new LavaDripParticle(new Vector3($this->bx + mt_rand(-1,1), $this->by, $this->bz + mt_rand(-1,1))));
        } else {
            $center = new Vector3($this->bx, $this->by, $this->bz);
            $moveDir = $this->vDir;
            if ($this->target !== null && $this->target->isAlive()) {
                $moveDir = $this->target->getPosition()->add(0, 1, 0)->subtract($center)->normalize();
            }
            $this->bx += $moveDir->x * 1.5; $this->by += $moveDir->y * 1.5; $this->bz += $moveDir->z * 1.5;
            $newCenter = new Vector3($this->bx, $this->by, $this->bz);
            foreach ($this->level->getEntities() as $e) {
                if ($e === $this->player || !$e->isAlive()) continue;
                if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
                if ($e->distance($newCenter) <= 3.0) {
                    if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
                    $this->explode($newCenter); $this->cleanup(); return;
                }
            }
            if ($this->tick > 95) { $this->explode($newCenter); $this->cleanup(); }
        }
        $rot = $this->tick * 0.3;
        foreach ($this->eids as $i => $eid) {
            $ang = ($i % 8) * (M_PI / 4) + $rot;
            if ($i < 8) { $tx = $this->bx + cos($ang) * 2.5; $ty = $this->by; $tz = $this->bz + sin($ang) * 2.5; }
            elseif ($i < 16) { $tx = $this->bx; $ty = $this->by + cos($ang) * 2.5; $tz = $this->bz + sin($ang) * 2.5; }
            else { $tx = $this->bx + cos($ang) * 2.0; $ty = $this->by + sin($ang) * 2.0; $tz = $this->bz + cos($ang) * 2.0; }
            BlockEffects::sendMove($this->level, $eid, $tx, $ty, $tz, 0);
            if ($this->tick % 2 == 0) $this->level->addParticle(new FlameParticle(new Vector3($tx, $ty, $tz)));
        }
    }
    private function explode($pos) {
        $this->level->addSound(new ExplodeSound($pos));
        $this->level->addParticle(new HugeExplodeParticle($pos));
        for ($i = 0; $i < 20; $i++) {
            $v = $pos->add(mt_rand(-5, 5), mt_rand(-2, 4), mt_rand(-5, 5));
            $this->level->addParticle(new LargeExplodeParticle($v));
            $this->level->addParticle(new TerrainParticle($v, Block::get(87)));
        }
        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e->distance($pos) <= 9.0) {
                $e->attack($this->dmg, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->dmg));
                $e->setMotion(new Vector3(($e->x - $pos->x) * 0.6, 1.2, ($e->z - $pos->z) * 0.6));
            }
        }
    }
    private function cleanup() {
        foreach ($this->eids as $eid) BlockEffects::sendRemove($eid);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}