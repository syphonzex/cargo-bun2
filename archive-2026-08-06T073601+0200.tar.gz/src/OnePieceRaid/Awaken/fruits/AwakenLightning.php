<?php

namespace OnePieceRaid\Awaken\fruits;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\entity\Effect;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\Task;
use pocketmine\level\particle\InstantEnchantParticle;
use pocketmine\level\particle\ExplodeParticle;
use pocketmine\level\particle\WhiteSmokeParticle;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\particle\EnchantmentTableParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\sound\ExplodeSound;
use pocketmine\level\sound\GhastSound;
use pocketmine\level\sound\FizzSound;
use pocketmine\network\protocol\AddEntityPacket;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;
use OnePiece\Devil\BlockEffects;
use OnePiece\Devil\BaseFruit;

class AwakenLightning extends AwakenBaseFruit {

    private static $lightningEid = 900000;
    private static $passiveTasks = [];

    public function getFruitId() { return "goro_goro"; }
    public function getAbility1Name() { return "§b§lRaging Dragon"; }
    public function getAbility2Name() { return "§3§lCrushing Judgement"; }
    public function getAbility1Cooldown() { return 15.0; }
    public function getAbility2Cooldown() { return 30.0; }

    public function onAwaken1(Player $p) { $p->sendMessage("§b§l[AWAKEN] §fRaging Dragon unlocked!"); }
    public function onAwaken2(Player $p) { $p->sendMessage("§3§l[AWAKEN] §fCrushing Judgement unlocked!"); }

    public function onEquip(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;
        $this->onUnequip($player);
        $task = new AwakenLightningPassiveTask($plugin, $player);
        $plugin->getServer()->getScheduler()->scheduleRepeatingTask($task, 1);
        self::$passiveTasks[$player->getName()] = $task;
    }

    public function onUnequip(Player $player) {
        if (isset(self::$passiveTasks[$player->getName()])) {
            self::$passiveTasks[$player->getName()]->stop();
            unset(self::$passiveTasks[$player->getName()]);
        }
    }

public function useAbility1(Player $player) {
    $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
    if ($plugin === null) return;
    $name = $player->getName();
    if (!isset(self::$passiveTasks[$name]) || !self::$passiveTasks[$name]->active) $this->onEquip($player);
    $task = self::$passiveTasks[$name];

    $damage = 9.27;
    if ($task->consumeOrb()) {
        $damage *= 1.2;
    }

    $level = $player->getLevel();
    $dir = $player->getDirectionVector();
    $origin = new Vector3($player->x, $player->y + 1.2, $player->z);
    $target = null; $best = 999; $range = 45;

    foreach ($level->getEntities() as $e) {
        if ($e->getId() === $player->getId() || !$e->isAlive()) continue;
        if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
        if ($e instanceof Player && !$plugin->canTargetPlayer($player->getName(), $e)) continue;
        $vx = $e->x - $origin->x; $vy = ($e->y + 1) - $origin->y; $vz = $e->z - $origin->z;
        $proj = $vx * $dir->x + $vy * $dir->y + $vz * $dir->z;
        if ($proj < 1 || $proj > $range) continue;
        $distSq = $vx * $vx + $vy * $vy + $vz * $vz;
        $perpSq = $distSq - ($proj * $proj);
        if ($perpSq <= 9 && $proj < $best) { $best = $proj; $target = new Vector3($e->x, $e->y, $e->z); }
    }
    if ($target === null) {
        for ($i = 1; $i <= $range; $i++) {
            $check = $player->add($dir->x * $i, $dir->y * $i, $dir->z * $i);
            if ($level->getBlock($check)->getId() !== 0) { $target = $check; break; }
        }
    }
    if ($target === null) $target = $player->add($dir->x * $range, $dir->y * $range, $dir->z * $range);

    $impactPos = new Vector3($target->x, $level->getHighestBlockAt(floor($target->x), floor($target->z)), $target->z);
    $cloudPos = new Vector3($player->x, $player->y + 18, $player->z);
    $segs = []; $blockPool = [ [35, 3], [57, 0], [79, 0], [20, 0], [57, 0], [20, 0], [35, 3], [79, 0] ];
    for ($i = 0; $i < 8; $i++) {
        $eid = BlockEffects::newEid(); $b = $blockPool[$i % count($blockPool)];
        BlockEffects::sendSpawn($level, $eid, $b[0], $b[1], $cloudPos->x, $cloudPos->y, $cloudPos->z);
        $segs[] = $eid;
    }
    $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new AzureDragonTask($plugin, $player, $damage, $segs, $cloudPos, $impactPos, $level), 1);
    $player->sendTip("§b§lRAGING DRAGON!");
}

public function useAbility2(Player $player) {
    $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
    if ($plugin === null) return;
    $name = $player->getName();
    if (!isset(self::$passiveTasks[$name]) || !self::$passiveTasks[$name]->active) $this->onEquip($player);
    $task = self::$passiveTasks[$name];

    $damage = 2.84;
    if ($task->consumeOrb()) {
        $damage *= 1.2;
    }

    $level = $player->getLevel();
    $dir = $player->getDirectionVector();
    $origin = new Vector3($player->x, $player->y + 1.2, $player->z);
    $target = null; $best = 999;

    foreach ($level->getEntities() as $e) {
        if ($e->getId() === $player->getId() || !$e->isAlive()) continue;
        if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
        if ($e instanceof Player && !$plugin->canTargetPlayer($player->getName(), $e)) continue;
        $vx = $e->x - $origin->x; $vy = ($e->y + 1) - $origin->y; $vz = $e->z - $origin->z;
        $proj = $vx * $dir->x + $vy * $dir->y + $vz * $dir->z;
        if ($proj < 1 || $proj > 35) continue;
        $distSq = $vx * $vx + $vy * $vy + $vz * $vz;
        $perpSq = $distSq - ($proj * $proj);
        if ($perpSq <= 7 && $proj < $best) { $best = $proj; $target = new Vector3($e->x, $e->y, $e->z); }
    }
    if ($target === null) {
        for ($i = 1; $i <= 35; $i++) {
            $check = $player->add($dir->x * $i, $dir->y * $i, $dir->z * $i);
            if ($level->getBlock($check)->getId() !== 0) { $target = $check; break; }
        }
    }
    if ($target === null) $target = $player->add($dir->x * 30, $dir->y * 30, $dir->z * 30);

    $impactPos = new Vector3($target->x, $level->getHighestBlockAt(floor($target->x), floor($target->z)), $target->z);
    $cloudY = $impactPos->y + 24;
    $eids = [];
    for ($i = 0; $i < 36; $i++) {
        $eid = BlockEffects::newEid();
        if ($i % 3 === 0)     { $id = 35; $data = 3; }
        elseif ($i % 3 === 1) { $id = 57; $data = 0; }
        else                  { $id = 79; $data = 0; }
        BlockEffects::sendSpawn($level, $eid, $id, $data, $impactPos->x, $cloudY, $impactPos->z);
        $eids[] = $eid;
    }
    $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new CrushingJudgementTask($plugin, $player, $damage, $impactPos, $level, $eids, $cloudY), 1);
    $player->sendTip("§3§lCRUSHING JUDGEMENT!");
}

    public static function getNextLightningEid() {
        self::$lightningEid++; if (self::$lightningEid > 999999) self::$lightningEid = 900000; return self::$lightningEid;
    }
}

class AwakenLightningPassiveTask extends Task {
    public $plugin, $player, $level, $active = true, $world;
    private $orbs = []; private $orbSpawnTimer = 0; private $maxOrbs = 3;
    private $lastPlayerPos; private $resyncTimer = 0;
    private $tetherLagX, $tetherLagY, $tetherLagZ;

    public function __construct($plugin, Player $player) {
        $this->plugin = $plugin; $this->player = $player; $this->level = $player->getLevel();
        $this->world = $this->level->getName(); $this->lastPlayerPos = $player->getPosition();
        $this->tetherLagX = $player->x;
        $this->tetherLagY = $player->y + 1.3;
        $this->tetherLagZ = $player->z;
    }

    public function onRun($currentTick) {
        if (!$this->active || !$this->player->isOnline() || $this->player->getLevel()->getName() !== $this->world) { $this->stop(); return; }
        $currentPos = $this->player->getPosition();
        if ($this->lastPlayerPos->distance($currentPos) > 30) $this->resyncOrbs();
        $this->lastPlayerPos = $currentPos;
        $this->resyncTimer++;
        if ($this->resyncTimer >= 200) { $this->resyncTimer = 0; $this->resyncOrbs(); }
        $this->orbSpawnTimer++;
        if (count($this->orbs) < $this->maxOrbs && $this->orbSpawnTimer > mt_rand(400, 600)) {
            $this->orbSpawnTimer = 0; $eid = BlockEffects::newEid();
            $px = $this->player->x + mt_rand(-15, 15) / 10; $py = $this->player->y + 1.2 + mt_rand(0, 8) / 10; $pz = $this->player->z + mt_rand(-15, 15) / 10;
            BlockEffects::sendSpawn($this->level, $eid, 20, 0, $px, $py, $pz);
            $this->orbs[$eid] = [
                'px' => $px, 'py' => $py, 'pz' => $pz, 'vx' => 0.0, 'vy' => 0.0, 'vz' => 0.0,
                'state' => 'idle', 'shake_timer' => 0
            ];
        }

        $this->tetherLagX += ($this->player->x - $this->tetherLagX) * 0.08;
        $this->tetherLagY += (($this->player->y + 1.3) - $this->tetherLagY) * 0.08;
        $this->tetherLagZ += ($this->player->z - $this->tetherLagZ) * 0.08;

        $tetherX = $this->tetherLagX; $tetherY = $this->tetherLagY; $tetherZ = $this->tetherLagZ;
        $minDistance = 1.0; $maxDistance = 2.0; $chaseDistance = 4.0;
        $orbRepulseR = 0.9; $playerRepulseR = 1.0; $playerRepulseForce = 0.06;
        $floorY = $this->player->y + 0.5; $ceilingY = $this->player->y + 2.3;

        foreach ($this->orbs as $eid => &$orb) {
            if ($orb['state'] === 'idle') {
                if (mt_rand(1, 450) === 1) { $orb['state'] = 'shaking'; $orb['shake_timer'] = 0; }
                else {
                    $dx = $tetherX - $orb['px']; $dy = $tetherY - $orb['py']; $dz = $tetherZ - $orb['pz'];
                    $dist = sqrt($dx * $dx + $dy * $dy + $dz * $dz);

                    if ($dist >= $chaseDistance) {
                        $chaseForce = ($dist - $maxDistance) * 0.12;
                        if ($dist > 0) {
                            $orb['vx'] += ($dx / $dist) * $chaseForce;
                            $orb['vy'] += ($dy / $dist) * $chaseForce;
                            $orb['vz'] += ($dz / $dist) * $chaseForce;
                        }
                        $orb['vx'] *= 0.85; $orb['vy'] *= 0.85; $orb['vz'] *= 0.85;
                        $speed = sqrt($orb['vx'] ** 2 + $orb['vy'] ** 2 + $orb['vz'] ** 2);
                        $maxSpeed = 0.7;
                        if ($speed > $maxSpeed) { $scale = $maxSpeed / $speed; $orb['vx'] *= $scale; $orb['vy'] *= $scale; $orb['vz'] *= $scale; }
                    } else {
                        if ($dist < $minDistance && $dist > 0) {
                            $pushForce = ($minDistance - $dist) * 0.05;
                            $orb['vx'] -= ($dx / $dist) * $pushForce;
                            $orb['vy'] -= ($dy / $dist) * $pushForce;
                            $orb['vz'] -= ($dz / $dist) * $pushForce;
                        } elseif ($dist > $maxDistance) {
                            $pullForce = ($dist - $maxDistance) * 0.02;
                            $orb['vx'] += ($dx / $dist) * $pullForce;
                            $orb['vy'] += ($dy / $dist) * $pullForce;
                            $orb['vz'] += ($dz / $dist) * $pullForce;
                        }

                        $orb['vx'] += mt_rand(-20, 20) / 1000;
                        $orb['vy'] += mt_rand(-15, 15) / 1000;
                        $orb['vz'] += mt_rand(-20, 20) / 1000;

                        foreach ($this->orbs as $otherEid => $other) {
                            if ($eid === $otherEid) continue;
                            $rx = $orb['px'] - $other['px']; $ry = $orb['py'] - $other['py']; $rz = $orb['pz'] - $other['pz'];
                            $rdist = sqrt($rx * $rx + $ry * $ry + $rz * $rz);
                            if ($rdist < $orbRepulseR && $rdist > 0) {
                                $push = ($orbRepulseR - $rdist) * 0.04;
                                $orb['vx'] += ($rx / $rdist) * $push;
                                $orb['vy'] += ($ry / $rdist) * $push;
                                $orb['vz'] += ($rz / $rdist) * $push;
                            }
                        }

                        $pdx = $orb['px'] - $this->player->x; $pdy = $orb['py'] - ($this->player->y + 1.3); $pdz = $orb['pz'] - $this->player->z;
                        $pdist = sqrt($pdx * $pdx + $pdy * $pdy + $pdz * $pdz);
                        if ($pdist < $playerRepulseR && $pdist > 0) {
                            $push = ($playerRepulseR - $pdist) * $playerRepulseForce;
                            $orb['vx'] += ($pdx / $pdist) * $push;
                            $orb['vy'] += ($pdy / $pdist) * $push;
                            $orb['vz'] += ($pdz / $pdist) * $push;
                        }

                        $orb['vx'] *= 0.92; $orb['vy'] *= 0.92; $orb['vz'] *= 0.92;

                        $speed = sqrt($orb['vx'] ** 2 + $orb['vy'] ** 2 + $orb['vz'] ** 2);
                        $maxSpeed = 0.15;
                        if ($speed > $maxSpeed) { $scale = $maxSpeed / $speed; $orb['vx'] *= $scale; $orb['vy'] *= $scale; $orb['vz'] *= $scale; }
                    }

                    $orb['px'] += $orb['vx']; $orb['py'] += $orb['vy']; $orb['pz'] += $orb['vz'];

                    if ($orb['py'] < $floorY) { $orb['py'] = $floorY; $orb['vy'] = abs($orb['vy']) * 0.2; }
                    if ($orb['py'] > $ceilingY) { $orb['py'] = $ceilingY; $orb['vy'] = -abs($orb['vy']) * 0.2; }

                    BlockEffects::sendMove($this->level, $eid, $orb['px'], $orb['py'], $orb['pz'], 0);
                }
            } elseif ($orb['state'] === 'shaking') {
                $orb['shake_timer']++;
                if ($orb['shake_timer'] < 25) { BlockEffects::sendMove($this->level, $eid, $orb['px'] + mt_rand(-1, 1) / 10, $orb['py'] + mt_rand(-1, 1) / 10, $orb['pz'] + mt_rand(-1, 1) / 10, 0); }
                else {
                    $orb['state'] = 'idle'; $orb['shake_timer'] = 0;
                    $this->level->addSound(new ExplodeSound(new Vector3($orb['px'], $orb['py'], $orb['pz'])));
                    for ($i = 0; $i < 6; $i++) $this->level->addParticle(new ExplodeParticle(new Vector3($orb['px'], $orb['py'], $orb['pz'])));
                }
            }
            $orbVec = new Vector3($orb['px'], $orb['py'], $orb['pz']);
            if ($currentTick % 2 === 0) $this->level->addParticle(new PortalParticle($orbVec));
            if ($currentTick % 3 === 0) $this->level->addParticle(new InstantEnchantParticle($orbVec));
        }
        $orbCount = count($this->orbs);
        if ($orbCount > 0) {
            $effect = Effect::getEffect(Effect::SPEED); $effect->setAmplifier($orbCount - 1); $effect->setDuration(20); $effect->setVisible(false);
            $this->player->addEffect($effect);
        } else {
            if ($this->player->hasEffect(Effect::SPEED)) $this->player->removeEffect(Effect::SPEED);
        }
    }

    private function resyncOrbs() {
        $newOrbs = [];
        foreach ($this->orbs as $oldEid => $orbData) {
            BlockEffects::sendRemove($oldEid); $newEid = BlockEffects::newEid();
            BlockEffects::sendSpawn($this->level, $newEid, 20, 0, $orbData['px'], $orbData['py'], $orbData['pz']);
            $newOrbs[$newEid] = $orbData;
        }
        $this->orbs = $newOrbs;
    }

    public function consumeOrb() {
        if (empty($this->orbs)) return false;
        end($this->orbs);
        $eid = key($this->orbs);
        if ($eid === null) return false;
        $orb = $this->orbs[$eid];
        $pos = new Vector3($orb['px'], $orb['py'], $orb['pz']);
        $this->level->addSound(new FizzSound($pos));
        for ($i = 0; $i < 10; $i++) {
            $this->level->addParticle(new PortalParticle(new Vector3($orb['px'] + mt_rand(-5, 5) / 10, $orb['py'] + mt_rand(-5, 5) / 10, $orb['pz'] + mt_rand(-5, 5) / 10)));
            $this->level->addParticle(new InstantEnchantParticle(new Vector3($orb['px'] + mt_rand(-4, 4) / 10, $orb['py'] + mt_rand(-4, 4) / 10, $orb['pz'] + mt_rand(-4, 4) / 10)));
        }
        BlockEffects::sendRemove($eid);
        unset($this->orbs[$eid]);
        return true;
    }

    public function stop() {
        if (!$this->active) return; $this->active = false;
        if ($this->player->isOnline() && $this->player->hasEffect(Effect::SPEED)) $this->player->removeEffect(Effect::SPEED);
        foreach (array_keys($this->orbs) as $eid) BlockEffects::sendRemove($eid);
        $this->orbs = []; $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AzureDragonTask extends Task {
    private $plugin, $player, $dmg, $segs, $cloudPos, $impactPos, $lv;
    private $tick = 0, $postTick = 0, $impacted = false, $closed = false;
    private $stunned = [], $scatterVelocities = [];
    private $headX, $headY, $headZ, $dirX, $dirY, $dirZ, $speed = 3.5;
    public function __construct($pl, $p, $d, $s, $cp, $ip, $l) {
        $this->plugin = $pl; $this->player = $p; $this->dmg = $d; $this->segs = $s; $this->cloudPos = $cp; $this->impactPos = $ip; $this->lv = $l;
        $this->headX = $cp->x; $this->headY = $cp->y; $this->headZ = $cp->z;
        $dx = $ip->x - $cp->x; $dy = $ip->y - $cp->y; $dz = $ip->z - $cp->z;
        $len = sqrt($dx * $dx + $dy * $dy + $dz * $dz);
        $this->dirX = $len > 0 ? $dx / $len : 0; $this->dirY = $len > 0 ? $dy / $len : 0; $this->dirZ = $len > 0 ? $dz / $len : 0;
        $l->addSound(new GhastSound($cp));
    }
    public function onRun($t) {
        if ($this->closed) return; $this->tick++;
        if (!$this->player->isAlive()) { $this->cleanup(); return; }
        if ($this->impacted) {
            $this->postTick++;
            if ($this->postTick === 1) { $this->initScatter();
            } elseif ($this->postTick > 1) { if ($this->tickScatter() && $this->postTick > 10) { $this->cleanup(); return; } }
            foreach ($this->stunned as $id => $d) { if ($d["e"]->isAlive()) {
                $d["e"]->setMotion(new Vector3(0, 0, 0)); $d["e"]->teleport($d["p"]);
                if ($this->postTick === 49) BaseFruit::staticSafeSetMotion($this->player, $d["e"], new Vector3(0, 3.0, 0));
            } }
            $cx = $this->impactPos->x; $cz = $this->impactPos->z;
            if ($this->postTick % 3 === 0) { for ($i = 0; $i < 4; $i++) {
                $this->lv->addParticle(new ExplodeParticle(new Vector3($cx + mt_rand(-40, 40) / 10, $this->impactPos->y + mt_rand(0, 30) / 10, $cz + mt_rand(-40, 40) / 10)));
                $this->lv->addParticle(new PortalParticle(new Vector3($cx + mt_rand(-30, 30) / 10, $this->impactPos->y + mt_rand(0, 50) / 10, $cz + mt_rand(-30, 30) / 10)));
            } }
            if ($this->postTick > 52) $this->cleanup(); return;
        }
        if ($this->tick <= 20) { $this->summonPhase(); return; }
        $dist = sqrt(($this->headX - $this->impactPos->x) ** 2 + ($this->headY - $this->impactPos->y) ** 2 + ($this->headZ - $this->impactPos->z) ** 2);
        if ($dist <= $this->speed) { $this->headX = $this->impactPos->x; $this->headY = $this->impactPos->y; $this->headZ = $this->impactPos->z; $this->impacted = true; $this->impact(); return; }
        $this->headX += $this->dirX * $this->speed; $this->headY += $this->dirY * $this->speed; $this->headZ += $this->dirZ * $this->speed;
        $this->moveBody();
        if ($this->tick % 2 === 0) { for ($i = 0; $i < 6; $i++) {
            $this->lv->addParticle(new PortalParticle(new Vector3($this->headX + mt_rand(-20, 20) / 10, $this->headY + mt_rand(-10, 10) / 10, $this->headZ + mt_rand(-20, 20) / 10)));
            $this->lv->addParticle(new EnchantmentTableParticle(new Vector3($this->headX - $this->dirX * ($i * 2.0), $this->headY - $this->dirY * ($i * 2.0), $this->headZ - $this->dirZ * ($i * 2.0))));
        } }
        if ($this->tick % 4 === 0) { $pk = new AddEntityPacket(); $pk->eid = BlockEffects::newEid(); $pk->type = 93; $pk->x = $this->headX; $pk->y = $this->headY; $pk->z = $this->headZ; foreach ($this->lv->getPlayers() as $pl) $pl->dataPacket($pk); }
    }
    private function summonPhase() {
        $cp = $this->cloudPos; $prog = $this->tick / 20; $pulse = sin($this->tick * 0.5) * 1.5;
        foreach ($this->segs as $i => $eid) {
            $baseAng = ($i / count($this->segs)) * M_PI * 2; $ang = $baseAng + $this->tick * 0.18; $rad = 3.5 + $pulse + ($i % 3) * 0.8;
            $bx = $cp->x + cos($ang) * $rad; $by = $cp->y + sin($ang * 0.4) * 1.2 + ($prog * 1.5); $bz = $cp->z + sin($ang) * $rad;
            BlockEffects::sendMove($this->lv, $eid, $bx, $by, $bz, 0);
            if ($this->tick % 2 === 0) {
                $this->lv->addParticle(new PortalParticle(new Vector3($bx + mt_rand(-15, 15) / 10, $by + mt_rand(-10, 10) / 10, $bz + mt_rand(-15, 15) / 10)));
                $this->lv->addParticle(new WhiteSmokeParticle(new Vector3($bx + mt_rand(-12, 12) / 10, $by - mt_rand(5, 25) / 10, $bz + mt_rand(-12, 12) / 10)));
            }
        }
    }
    private function moveBody() {
        $travelTick = $this->tick - 20;
        foreach ($this->segs as $i => $eid) {
            $lag = $i * 1.8; $bx = $this->headX - $this->dirX * $lag; $by = $this->headY - $this->dirY * $lag; $bz = $this->headZ - $this->dirZ * $lag;
            $wave = sin($travelTick * 0.35 + $i * 0.6) * (0.9 + $i * 0.12);
            $bx += -$this->dirZ * $wave; $bz += $this->dirX * $wave; $by += cos($travelTick * 0.25 + $i * 0.5) * 0.4;
            BlockEffects::sendMove($this->lv, $eid, $bx, $by, $bz, 0);
        }
    }
    private function impact() {
        $this->lv->addSound(new ExplodeSound($this->impactPos)); $this->lv->addSound(new GhastSound($this->impactPos));
        $gy = $this->lv->getHighestBlockAt(floor($this->impactPos->x), floor($this->impactPos->z));
        for ($i = 0; $i < 12; $i++) {
            $pk = new AddEntityPacket(); $pk->eid = BlockEffects::newEid(); $pk->type = 93;
            $pk->x = $this->impactPos->x + mt_rand(-80, 80) / 10; $pk->y = $gy; $pk->z = $this->impactPos->z + mt_rand(-80, 80) / 10;
            foreach ($this->lv->getPlayers() as $pl) $pl->dataPacket($pk);
        }
        for ($i = 0; $i < 18; $i++) {
            $this->lv->addParticle(new ExplodeParticle(new Vector3($this->impactPos->x + mt_rand(-50, 50) / 10, $this->impactPos->y + mt_rand(0, 40) / 10, $this->impactPos->z + mt_rand(-50, 50) / 10)));
            $this->lv->addParticle(new HugeExplodeParticle(new Vector3($this->impactPos->x + mt_rand(-30, 30) / 10, $this->impactPos->y + mt_rand(0, 20) / 10, $this->impactPos->z + mt_rand(-30, 30) / 10)));
        }
        foreach ($this->lv->getEntities() as $e) {
            if ($e->getId() === $this->player->getId() || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e->distance($this->impactPos) <= 16) {
                if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
                $e->attack($this->dmg, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->dmg));
                $this->stunned[$e->getId()] = ["e" => $e, "p" => $e->getPosition()];
            }
        }
    }
    private function initScatter() {
        $this->lv->addSound(new ExplodeSound($this->impactPos)); $this->scatterVelocities = [];
        foreach ($this->segs as $i => $eid) {
            $ang = mt_rand(0, 628) / 100; $spd = mt_rand(30, 70) / 100;
            $this->scatterVelocities[$i] = ["x" => cos($ang) * $spd, "y" => mt_rand(20, 50) / 100, "z" => sin($ang) * $spd, "px" => $this->headX, "py" => $this->headY, "pz" => $this->headZ];
        }
    }
    private function tickScatter() {
        $gravity = 0.045; $allDone = true;
        foreach ($this->segs as $i => $eid) {
            if (!isset($this->scatterVelocities[$i])) continue;
            $v = &$this->scatterVelocities[$i];
            $v["px"] += $v["x"]; $v["py"] += $v["y"]; $v["pz"] += $v["z"]; $v["y"] -= $gravity;
            $groundY = $this->lv->getHighestBlockAt(floor($v["px"]), floor($v["pz"]));
            if ($v["py"] > $groundY) { BlockEffects::sendMove($this->lv, $eid, $v["px"], $v["py"], $v["pz"], 0); $allDone = false; }
            else { BlockEffects::sendRemove($eid); unset($this->scatterVelocities[$i]); unset($this->segs[$i]); }
        } return $allDone;
    }
    private function cleanup() {
        if ($this->closed) return; $this->closed = true;
        foreach ($this->segs as $eid) BlockEffects::sendRemove($eid);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class CrushingJudgementTask extends Task {
    private $plugin, $player, $dmg, $pos, $lv, $eids, $cloudY;
    private $tick = 0, $postTick = 0, $stunned = [], $closed = false, $finalDone = false, $scatterVelocities = [];
    public function __construct($pl, $p, $d, $pos, $l, $e, $cy) {
        $this->plugin = $pl; $this->player = $p; $this->dmg = $d; $this->pos = $pos; $this->lv = $l; $this->eids = $e; $this->cloudY = $cy;
        $l->addSound(new GhastSound($pos));
    }
    public function onRun($t) {
        if ($this->closed) return; $this->tick++;
        if (!$this->player->isAlive()) { $this->cleanup(); return; }
        $cx = $this->pos->x; $cz = $this->pos->z;
        if ($this->finalDone) {
            $this->postTick++;
            if ($this->postTick <= 14) {
                $this->moveBeam($cx, $cz);
                foreach ($this->lv->getEntities() as $e) {
                    if ($e->getId() === $this->player->getId() || !$e->isAlive()) continue;
                    if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
                    if ($e->distance($this->pos) <= 13) {
                        if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
                        $dx = $cx - $e->x; $dz = $cz - $e->z; $len = sqrt($dx * $dx + $dz * $dz);
                        if ($len > 0) $e->setMotion(new Vector3($dx / $len * 0.5, 0.1, $dz / $len * 0.5));
                    }
                }
            } elseif ($this->postTick === 15) { $this->initScatterAndDamage($cx, $cz);
            } elseif ($this->postTick > 15) { if ($this->tickScatter() && $this->postTick > 20) { $this->cleanup(); return; } }
            foreach ($this->stunned as $id => $d) { if ($d["e"]->isAlive()) {
                $d["e"]->setMotion(new Vector3(0, 0, 0)); $d["e"]->teleport($d["p"]);
                if ($this->postTick === 49) BaseFruit::staticSafeSetMotion($this->player, $d["e"], new Vector3(0, 2.3, 0));
            } }
            if ($this->postTick % 4 === 0 && $this->postTick < 50) { for ($i = 0; $i < 4; $i++) {
                $this->lv->addParticle(new WhiteSmokeParticle(new Vector3($cx + mt_rand(-35, 35) / 10, $this->pos->y + mt_rand(0, 30) / 10, $cz + mt_rand(-35, 35) / 10)));
                $this->lv->addParticle(new PortalParticle(new Vector3($cx + mt_rand(-25, 25) / 10, $this->pos->y + mt_rand(0, 35) / 10, $cz + mt_rand(-25, 25) / 10)));
            } }
            if ($this->postTick > 52) $this->cleanup(); return;
        }
        if ($this->tick <= 24) { $this->moveCloud($cx, $cz, 18 - (($this->tick / 24) * 12), 13 - (($this->tick / 24) * 9), 8 - (($this->tick / 24) * 6)); return; }
        if ($this->tick <= 84) {
            $this->moveCloud($cx, $cz, 6, 4, 2);
            if ($this->tick % 6 === 0) {
                $strikePos = new Vector3($cx + mt_rand(-35, 35) / 10, $this->pos->y, $cz + mt_rand(-35, 35) / 10);
                $this->lv->addSound(new ExplodeSound($strikePos)); $this->barrageDamage($strikePos, $cx, $cz);
            } return;
        }
        if (!$this->finalDone) { $this->finalDone = true; $this->lv->addSound(new GhastSound($this->pos)); }
    }
    private function moveCloud($cx, $cz, $r1, $r2, $r3) {
        $spin1 = $this->tick * 0.32; $spin2 = -$this->tick * 0.38; $spin3 = $this->tick * 0.45;
        for ($i = 0; $i < 12; $i++) { $ang = ($i / 12) * M_PI * 2 + $spin1; BlockEffects::sendMove($this->lv, $this->eids[$i], $cx + cos($ang) * $r1, $this->cloudY + sin($spin1 + $i) * 1.2, $cz + sin($ang) * $r1, 0); }
        for ($i = 12; $i < 24; $i++) { $ang = (($i - 12) / 12) * M_PI * 2 + $spin2; BlockEffects::sendMove($this->lv, $this->eids[$i], $cx + cos($ang) * $r2, $this->cloudY - 3 + cos($spin2 + $i) * 1.2, $cz + sin($ang) * $r2, 0); }
        for ($i = 24; $i < 36; $i++) { $ang = (($i - 24) / 12) * M_PI * 2 + $spin3; BlockEffects::sendMove($this->lv, $this->eids[$i], $cx + cos($ang) * $r3, $this->cloudY - 6 + sin($spin3 + $i) * 1.0, $cz + sin($ang) * $r3, 0); }
        for ($i = 0; $i < 2; $i++) {
            $this->lv->addParticle(new PortalParticle(new Vector3($cx + mt_rand(-50, 50) / 10, $this->cloudY + mt_rand(-15, 15) / 10, $cz + mt_rand(-50, 50) / 10)));
            $this->lv->addParticle(new EnchantmentTableParticle(new Vector3($cx + mt_rand(-40, 40) / 10, $this->cloudY - mt_rand(0, 30) / 10, $cz + mt_rand(-40, 40) / 10)));
            $this->lv->addParticle(new WhiteSmokeParticle(new Vector3($cx + mt_rand(-50, 50) / 10, $this->cloudY - mt_rand(10, 70) / 10, $cz + mt_rand(-50, 50) / 10)));
        }
    }
    private function moveBeam($cx, $cz) {
        $height = $this->cloudY - $this->pos->y; $spin = $this->tick * 0.8;
        foreach ($this->eids as $i => $eid) {
            $f = ($i % 18) / 17; $layer = (int)($i / 18); $ang = $spin + ($i * 0.7); $rad = $layer === 0 ? 0.35 : 0.75; $y = $this->pos->y + ($height * $f);
            BlockEffects::sendMove($this->lv, $eid, $cx + cos($ang) * $rad, $y, $cz + sin($ang) * $rad, 0);
        }
    }
    private function initScatterAndDamage($cx, $cz) {
        $this->lv->addSound(new ExplodeSound($this->pos));
        for ($i = 0; $i < 18; $i++) {
            $this->lv->addParticle(new ExplodeParticle(new Vector3($cx + mt_rand(-40, 40) / 10, $this->pos->y + mt_rand(0, 50) / 10, $cz + mt_rand(-40, 40) / 10)));
            $this->lv->addParticle(new InstantEnchantParticle(new Vector3($cx + mt_rand(-30, 30) / 10, $this->pos->y + mt_rand(0, 90) / 10, $cz + mt_rand(-30, 30) / 10)));
        }
        foreach ($this->lv->getEntities() as $e) {
            if ($e->getId() === $this->player->getId() || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e->distance($this->pos) <= 13) {
                if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
                $e->attack($this->dmg * 2.6, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->dmg * 2.6));
                $this->stunned[$e->getId()] = ["e" => $e, "p" => $e->getPosition()];
            }
        }
        $this->scatterVelocities = [];
        foreach ($this->eids as $i => $eid) { $ang = mt_rand(0, 628) / 100; $spd = mt_rand(25, 65) / 100; $this->scatterVelocities[$i] = ["x" => cos($ang) * $spd, "y" => mt_rand(18, 45) / 100, "z" => sin($ang) * $spd, "px" => $cx, "py" => $this->pos->y + 1.0, "pz" => $cz]; }
    }
    private function tickScatter() {
        $gravity = 0.045; $allDone = true;
        foreach ($this->eids as $i => $eid) {
            if (!isset($this->scatterVelocities[$i])) continue;
            $v = &$this->scatterVelocities[$i];
            $v["px"] += $v["x"]; $v["py"] += $v["y"]; $v["pz"] += $v["z"]; $v["y"] -= $gravity;
            $groundY = $this->lv->getHighestBlockAt(floor($v["px"]), floor($v["pz"]));
            if ($v["py"] > $groundY) { BlockEffects::sendMove($this->lv, $eid, $v["px"], $v["py"], $v["pz"], 0); $allDone = false; }
            else { BlockEffects::sendRemove($eid); unset($this->scatterVelocities[$i]); unset($this->eids[$i]); }
        } return $allDone;
    }
    private function barrageDamage(Vector3 $strikePos, $cx, $cz) {
        $pk = new AddEntityPacket(); $pk->eid = BlockEffects::newEid(); $pk->type = 93;
        $pk->x = $strikePos->x; $pk->y = $this->lv->getHighestBlockAt(floor($strikePos->x), floor($strikePos->z)); $pk->z = $strikePos->z;
        foreach ($this->lv->getPlayers() as $pl) $pl->dataPacket($pk);
        for ($i = 0; $i < 5; $i++) {
            $this->lv->addParticle(new PortalParticle(new Vector3($strikePos->x + mt_rand(-15, 15) / 10, $strikePos->y + mt_rand(0, 30) / 10, $strikePos->z + mt_rand(-15, 15) / 10)));
            $this->lv->addParticle(new InstantEnchantParticle(new Vector3($strikePos->x + mt_rand(-10, 10) / 10, $strikePos->y + mt_rand(0, 40) / 10, $strikePos->z + mt_rand(-10, 10) / 10)));
        }
        foreach ($this->lv->getEntities() as $e) {
            if ($e->getId() === $this->player->getId() || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            
            // FIX: Only hit entities near the specific lightning strike, not the whole storm
            if ($e->distance($strikePos) <= 4.5) { 
                if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
                $dx = $strikePos->x - $e->x; $dz = $strikePos->z - $e->z; $len = sqrt($dx * $dx + $dz * $dz);
                if ($len > 0) $e->setMotion(new Vector3($dx / $len * 0.45, 0.08, $dz / $len * 0.45));
                
                // FIX: Bypass I-Frames so barrage hits actually register
                $e->noDamageTicks = 0; 
                
                $e->attack($this->dmg * 0.22, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->dmg * 0.22));
            }
        }
    }
    private function cleanup() {
        if ($this->closed) return; $this->closed = true;
        foreach ($this->eids as $eid) BlockEffects::sendRemove($eid);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}