<?php

namespace OnePieceRaid\Awaken\fruits;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\Task;
use pocketmine\level\particle\InstantEnchantParticle;
use pocketmine\level\particle\EnchantParticle;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\BlazeShootSound;
use pocketmine\level\sound\ExplodeSound;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;
use OnePiece\Devil\BlockEffects;

class AwakenLight extends AwakenBaseFruit {

    public function getFruitId() { return "pika_pika"; }
    public function getAbility1Name() { return "§e§lSacred Light Erasure"; }
    public function getAbility2Name() { return "§e§lAma no Murakumo"; }
    public function getAbility1Cooldown() { return 14.0; }
    public function getAbility2Cooldown() { return 26.0; }

    public function onAwaken1(Player $p) { $p->sendMessage("§e§l[AWAKEN] §fSacred Light Erasure unlocked!"); }
    public function onAwaken2(Player $p) { $p->sendMessage("§e§l[AWAKEN] §fAma no Murakumo unlocked!"); }

    public function useAbility1(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;
        $level = $player->getLevel();
        $eids = [];
        for ($i = 0; $i < 6; $i++) {
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($level, $eid, 41, 0, $player->x, $player->y, $player->z);
            $eids[] = $eid;
        }
        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new SacredErasureTask($plugin, $player, 2.35, $eids, $level), 1);
        $player->sendTip("§e§lJUDGMENT OF LIGHT");
        $level->addSound(new AnvilUseSound($player));
    }

    public function useAbility2(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;
        $level = $player->getLevel();
        $spears = [];
        for ($i = 0; $i < 25; $i++) {
            $eid = BlockEffects::newEid();
            $rx = $player->x + mt_rand(-15, 15);
            $rz = $player->z + mt_rand(-15, 15);
            $ry = $player->y + 25 + mt_rand(0, 10);
            BlockEffects::sendSpawn($level, $eid, 41, 0, $rx, $ry, $rz);
            $spears[] = ["eid" => $eid, "pos" => new Vector3($rx, $ry, $rz)];
        }
        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new MurakumoTask($plugin, $player, 8.82, $spears, $level), 1);
        $player->sendTip("§e§lCELESTIAL RAIN");
        $level->addSound(new BlazeShootSound($player));
    }
}

class SacredErasureTask extends Task {
    private $plugin, $player, $dmg, $eids, $level, $tick = 0, $targets = [];
    public function __construct($pl, $p, $d, $e, $l) {
        $this->plugin = $pl; $this->player = $p; $this->dmg = $d; $this->eids = $e; $this->level = $l;
    }
    public function onRun($t) {
        $this->tick++;
        if ($this->tick > 60 || !$this->player->isAlive()) { $this->cleanup(); return; }
        $px = $this->player->x; $py = $this->player->y; $pz = $this->player->z;
        foreach ($this->eids as $i => $eid) {
            $ang = ($this->tick * 0.25) + ($i * M_PI / 3);
            BlockEffects::sendMove($this->level, $eid, $px + cos($ang) * 4.5, $py + 0.5, $pz + sin($ang) * 4.5, 0);
            $this->level->addParticle(new DustParticle(new Vector3($px + cos($ang) * 4.5, $py + 0.5, $pz + sin($ang) * 4.5), 255, 255, 0));
        }
        foreach ($this->level->getEntities() as $e) {
            if ($e->getId() === $this->player->getId() || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e->distance($this->player) <= 12) {
                if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
                $eid = $e->getId();
                if (!isset($this->targets[$eid])) {
                    $beid = BlockEffects::newEid();
                    BlockEffects::sendSpawn($this->level, $beid, 41, 0, $e->x, $e->y - 2, $e->z);
                    $this->targets[$eid] = ["entity" => $e, "beid" => $beid];
                }
                $target = $this->targets[$eid]["entity"];
                $target->setMotion(new Vector3(0, 0, 0));
                $target->teleport(new Vector3($target->x, $target->y, $target->z));
                for ($h = 0; $h < 22; $h++) {
                    $pos = new Vector3($target->x, $target->y + ($h * 0.5), $target->z);
                    $this->level->addParticle(new DustParticle($pos, 255, 255, 0));
                    $this->level->addParticle(new InstantEnchantParticle($pos));
                    if ($h === 0) {
                        for ($r = 0; $r < 4; $r++) {
                            $sang = ($this->tick * 0.4) + ($r * M_PI / 2);
                            $this->level->addParticle(new DustParticle($pos->add(cos($sang) * 1.5, 0.1, sin($sang) * 1.5), 255, 240, 0));
                        }
                    }
                }
                if ($this->tick % 8 == 0) {
                    $target->attack($this->dmg, new EntityDamageByEntityEvent($this->player, $target, EntityDamageEvent::CAUSE_MAGIC, $this->dmg));
                    $this->level->addParticle(new HugeExplodeParticle($target->add(0, 1, 0)));
                }
                BlockEffects::sendMove($this->level, $this->targets[$eid]["beid"], $target->x, $target->y - 1 + ($this->tick * 0.04), $target->z, 0);
            }
        }
    }
    private function cleanup() {
        foreach ($this->eids as $eid) BlockEffects::sendRemove($eid);
        foreach ($this->targets as $t) BlockEffects::sendRemove($t["beid"]);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class MurakumoTask extends Task {
    private $plugin, $player, $dmg, $spears, $level, $tick = 0;
    public function __construct($pl, $p, $d, $s, $l) {
        $this->plugin = $pl; $this->player = $p; $this->dmg = $d; $this->spears = $s; $this->level = $l;
    }
    public function onRun($t) {
        $this->tick++;
        if ($this->tick > 100 || empty($this->spears)) { $this->cleanup(); return; }
        foreach ($this->spears as $i => &$sp) {
            $sp["pos"]->y -= 2.6;
            BlockEffects::sendMove($this->level, $sp["eid"], $sp["pos"]->x, $sp["pos"]->y, $sp["pos"]->z, 0);
            for ($j = 0; $j < 6; $j++) $this->level->addParticle(new DustParticle($sp["pos"]->add(0, $j * 0.7, 0), 255, 255, 0));
            $this->level->addParticle(new InstantEnchantParticle($sp["pos"]));
            if ($sp["pos"]->y <= $this->level->getHighestBlockAt($sp["pos"]->x, $sp["pos"]->z) + 0.5) {
                $this->impact($sp["pos"]);
                BlockEffects::sendRemove($sp["eid"]);
                unset($this->spears[$i]);
            }
        }
    }
    private function impact($pos) {
        $this->level->addSound(new ExplodeSound($pos));
        $this->level->addParticle(new HugeExplodeParticle($pos));
        for ($i = -7; $i <= 7; $i++) {
            $this->level->addParticle(new DustParticle($pos->add($i, 0.2, 0), 255, 255, 0));
            $this->level->addParticle(new DustParticle($pos->add(0, 0.2, $i), 255, 255, 0));
            $this->level->addParticle(new InstantEnchantParticle($pos->add($i, mt_rand(0, 5), 0)));
            if (abs($i) % 2 === 0) $this->level->addParticle(new EnchantParticle($pos->add($i, 0.5, $i)));
        }
        foreach ($this->level->getEntities() as $e) {
            if ($e->getId() === $this->player->getId() || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
            if ($e->distance($pos) <= 6.5) {
                $e->attack($this->dmg, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->dmg));
                $e->setMotion(new Vector3(0, 1.6, 0));
            }
        }
    }
    private function cleanup() {
        foreach ($this->spears as $sp) BlockEffects::sendRemove($sp["eid"]);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}