<?php

namespace OnePieceRaid\Awaken\fruits;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\entity\Effect;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\Task;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\particle\LargeExplodeParticle;
use pocketmine\level\particle\EnchantParticle;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\FizzSound;
use pocketmine\level\sound\BlazeShootSound;
use pocketmine\level\sound\ExplodeSound;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;
use OnePiece\Devil\BlockEffects;

class AwakenDark extends AwakenBaseFruit {

    public function getFruitId()          { return "yami_yami"; }
    public function getAbility1Name()     { return "Black Hole Vortex"; }
    public function getAbility2Name()     { return "Dark Star Liberation"; }
    public function getAbility1Cooldown() { return 15.0; }
    public function getAbility2Cooldown() { return 22.0; }

    public function onAwaken1(Player $player) {
        $player->sendMessage("§5[AWAKEN] §fBlack Hole Vortex awakened!");
        $player->sendMessage("§7The void consumes all light. An absolute gravitational prison.");
    }

    public function onAwaken2(Player $player) {
        $player->sendMessage("§5[AWAKEN] §fDark Star Liberation awakened!");
        $player->sendMessage("§7A singularity that seeks out enemies and detonates in total darkness.");
    }

    public function useAbility1(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;

        $mm       = method_exists($plugin, "getMasteryManager") ? $plugin->getMasteryManager() : null;
        $mastery  = ($mm !== null) ? $mm->getLevel($player->getName()) : 0;
        $bonusSec = (min(50, $mastery) / 50) * 4.0;
        $totalTicks = (int)((6.0 + $bonusSec) * 20);

        $mult   = 1.0;
        $damage = 0.71 * $mult;

        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(
            new AwakenDarkVortexTask($plugin, $player, $damage, $totalTicks),
            1
        );

        $player->sendTip("§5§lBLACK HOLE VORTEX");
        $player->getLevel()->addSound(new AnvilUseSound($player));
    }

    public function useAbility2(Player $player) {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($plugin === null) return;

        $damage = 5.0;

        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(
            new AwakenDarkStarTask($plugin, $player, $damage),
            1
        );

        $player->sendTip("§5§lDARK STAR LIBERATION");
        $player->getLevel()->addSound(new BlazeShootSound($player));
    }
}

class AwakenDarkVortexTask extends Task {

    private $plugin, $player, $level, $damage, $totalTicks;
    private $ticksRan = 0;
    private $attachedBlocks = [];
    private $envDebris      = [];
    private $outerRing      = [];
    private $angle          = 0.0;
    private $cx, $cy, $cz;

    public function __construct($plugin, Player $player, $damage, $totalTicks) {
        $this->plugin      = $plugin;
        $this->player      = $player;
        $this->level       = $player->getLevel();
        $this->damage      = $damage;
        $this->totalTicks  = $totalTicks;
        $this->cx          = $player->x;
        $this->cy          = $player->y;
        $this->cz          = $player->z;

        for ($i = 0; $i < 16; $i++) {
            $angle = (2 * M_PI / 16) * $i;
            $eid   = BlockEffects::newEid();
            BlockEffects::sendSpawn($this->level, $eid, 49, 0,
                $this->cx + cos($angle) * 9,
                $this->cy + 0.5,
                $this->cz + sin($angle) * 9
            );
            $this->outerRing[] = ["eid" => $eid, "angle" => (float)$angle];
        }

        $this->level->addSound(new AnvilUseSound($player));
    }

    public function onRun($currentTick) {
        if ($this->player === null || !$this->player->isOnline() || $this->player->closed) {
            $this->cleanup();
            return;
        }

        $this->ticksRan++;
        if ($this->ticksRan > $this->totalTicks) {
            $this->cleanup();
            return;
        }

        $this->player->setMotion(new Vector3(0, 0, 0));
        $this->angle += 0.22;
        $this->cx = $this->player->x;
        $this->cy = $this->player->y;
        $this->cz = $this->player->z;

        $this->tickOuterRing();
        $this->drawDenseVortex();
        $this->processEntities();
        $this->processEnvironment();
    }

    private function tickOuterRing() {
        foreach ($this->outerRing as &$seg) {
            $seg["angle"] -= 0.08;
            $r = 9 - ($this->ticksRan / $this->totalTicks) * 3;
            BlockEffects::sendMove(
                $this->level, $seg["eid"],
                $this->cx + cos($seg["angle"]) * $r,
                $this->cy + 0.5 + sin($seg["angle"] * 2) * 0.3,
                $this->cz + sin($seg["angle"]) * $r,
                (int)($seg["angle"] * 100)
            );
        }
    }

    private function drawDenseVortex() {
        for ($i = 0; $i < 35; $i++) {
            $r  = mt_rand(0, 90) / 10;
            $a  = mt_rand(0, 628) / 100;
            $v  = new Vector3(
                $this->cx + cos($a) * $r,
                $this->cy + mt_rand(0, 15) / 100,
                $this->cz + sin($a) * $r
            );
            $this->level->addParticle(new SmokeParticle($v));
            if ($i % 2 === 0) {
                $this->level->addParticle(new PortalParticle($v));
            }
            if ($i % 5 === 0) {
                $this->level->addParticle(new DustParticle($v, 30, 0, 50));
            }
        }

        for ($i = 0; $i < 6; $i++) {
            $a  = $this->angle + ($i * M_PI / 3);
            $r  = 4.0 + sin($this->ticksRan * 0.1) * 1.5;
            $this->level->addParticle(new DustParticle(
                new Vector3($this->cx + cos($a) * $r, $this->cy + 1.0, $this->cz + sin($a) * $r),
                80, 0, 120
            ));
        }

        if ($this->ticksRan % 8 === 0) {
            $this->level->addSound(new FizzSound(new Vector3($this->cx, $this->cy, $this->cz)));
        }
    }

    private function processEntities() {
        $center     = new Vector3($this->cx, $this->cy, $this->cz);
        $currentEids = [];

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;

            $dist = $e->distance($center);
            if ($dist > 13.0) continue;

            $eid = $e->getId();
            $currentEids[$eid] = true;

            if (!isset($this->attachedBlocks[$eid])) {
                $beid = BlockEffects::newEid();
                BlockEffects::sendSpawn($this->level, $beid, 95, 15, $e->x, $e->y + 1.2, $e->z);
                $this->attachedBlocks[$eid] = $beid;
            } else {
                BlockEffects::sendMove($this->level, $this->attachedBlocks[$eid], $e->x, $e->y + 0.9, $e->z);
            }

            for ($i = 0; $i < 4; $i++) {
                $this->level->addParticle(new DustParticle(
                    new Vector3($e->x + mt_rand(-3,3)/10.0, $e->y + 1, $e->z + mt_rand(-3,3)/10.0),
                    60, 0, 90
                ));
            }

            $dx = $this->cx - $e->x;
            $dz = $this->cz - $e->z;
            $len = sqrt($dx * $dx + $dz * $dz);
            $hoverY = $this->cy + 1.4;
            $motY   = ($e->y < $hoverY) ? 0.25 : -0.18;

            $e->setMotion(new Vector3(0, 0, 0));

            if ($len > 6.5) {
                $pull = 0.05;
                $lSafe = max(0.01, $len);
                $e->setMotion(new Vector3(($dx / $lSafe) * $pull, $motY, ($dz / $lSafe) * $pull));
            } elseif ($len < 5.5) {
                $repel = ($len < 1.0) ? 1.8 : 0.7;
                $lSafe = max(0.01, $len);
                $vx = ($len > 0.1) ? -($dx / $lSafe) : (mt_rand(-10, 10) / 10.0);
                $vz = ($len > 0.1) ? -($dz / $lSafe) : (mt_rand(-10, 10) / 10.0);
                $e->setMotion(new Vector3($vx * $repel, $motY, $vz * $repel));
            } else {
                $e->setMotion(new Vector3(0, $motY, 0));
            }

            if ($this->ticksRan % 20 === 0) {
                $ev = new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $this->damage);
                $e->attack($this->damage, $ev);
            }
        }

        foreach ($this->attachedBlocks as $tid => $beid) {
            if (!isset($currentEids[$tid])) {
                BlockEffects::sendRemove($beid);
                unset($this->attachedBlocks[$tid]);
            }
        }
    }

    private function processEnvironment() {
        if ($this->ticksRan % 6 === 0) {
            $sx = $this->cx + (mt_rand(-140, 140) / 10);
            $sz = $this->cz + (mt_rand(-140, 140) / 10);
            $dx = $sx - $this->cx; $dz = $sz - $this->cz;
            if (sqrt($dx * $dx + $dz * $dz) < 5) return;

            $eid    = BlockEffects::newEid();
            $floorY = (int)$this->cy;
            while ($floorY > 0) {
                $bId = $this->level->getBlockIdAt((int)$sx, $floorY, (int)$sz);
                if ($bId !== 0 && $bId !== 8 && $bId !== 9) break;
                $floorY--;
            }
            $bId = $this->level->getBlockIdAt((int)$sx, $floorY, (int)$sz);
            $bDm = $this->level->getBlockDataAt((int)$sx, $floorY, (int)$sz);
            if ($bId === 0) { $bId = 49; $bDm = 0; }

            BlockEffects::sendSpawn($this->level, $eid, $bId, $bDm, $sx, (float)$floorY, $sz);
            $this->envDebris[$eid] = [
                "x" => $sx, "y" => (float)$floorY, "z" => $sz,
                "vy" => 0.5, "life" => 55, "stage" => 0,
                "accel" => 0.08, "baseY" => (float)$this->cy
            ];
        }

        foreach ($this->envDebris as $eid => &$data) {
            $data["life"]--;
            $dx = $this->cx - $data["x"];
            $dz = $this->cz - $data["z"];
            $len = sqrt($dx * $dx + $dz * $dz);

            if ($data["stage"] === 0) {
                $data["y"]  += $data["vy"];
                $data["vy"] -= 0.035;
                if ($data["y"] >= $data["baseY"] + 2.2) $data["stage"] = 1;
            } else {
                if ($len > 0.5) {
                    $data["accel"] += 0.18;
                    $ps = min(2.0, $data["accel"]);
                    $data["x"] += ($dx / $len) * $ps;
                    $data["z"] += ($dz / $len) * $ps;
                    $data["y"] -= 0.08;
                }
            }

            if ($data["life"] <= 0 || $data["y"] < $data["baseY"] - 3.5 || $len < 1.0) {
                BlockEffects::sendRemove($eid);
                unset($this->envDebris[$eid]);
            } else {
                BlockEffects::sendMove($this->level, $eid,
                    $data["x"], $data["y"], $data["z"],
                    $data["life"] * 30, $data["life"] * 18
                );
                $this->level->addParticle(new DustParticle(
                    new Vector3($data["x"], $data["y"], $data["z"]), 40, 0, 60
                ));
            }
        }
    }

    private function cleanup() {
        foreach ($this->outerRing as $seg) BlockEffects::sendRemove($seg["eid"]);
        foreach ($this->attachedBlocks as $eid) BlockEffects::sendRemove($eid);
        foreach ($this->envDebris as $eid => $d) BlockEffects::sendRemove($eid);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenDarkStarTask extends Task {

    private $plugin, $player, $level, $damage;
    private $ticksRan = 0, $chargeTicks = 45, $launched = false, $launchTicks = 0;
    private $x, $y, $z;
    private $starEids = [], $auraEids = [];
    private $currentRadius = 0.1;
    private $targetPos = null;
    private $dirX, $dirY, $dirZ;

    public function __construct($plugin, Player $player, $damage) {
        $this->plugin  = $plugin;
        $this->player  = $player;
        $this->level   = $player->getLevel();
        $this->damage  = $damage;

        for ($i = 0; $i < 10; $i++) {
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($this->level, $eid, 49, 0, $player->x, $player->y + 1.5, $player->z);
            $this->starEids[] = $eid;
        }

        for ($i = 0; $i < 6; $i++) {
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($this->level, $eid, 95, 15, $player->x, $player->y + 1.5, $player->z);
            $this->auraEids[] = $eid;
        }
    }

    public function onRun($currentTick) {
        if ($this->player === null || !$this->player->isOnline()) {
            $this->cleanup();
            return;
        }

        $this->ticksRan++;

        if (!$this->launched) {
            $this->runCharge();
        } else {
            $this->runLaunch();
        }
    }

    private function runCharge() {
        $this->player->addEffect(
            Effect::getEffect(Effect::DAMAGE_RESISTANCE)->setAmplifier(5)->setDuration(10)->setVisible(false)
        );

        $prog = min(1.0, $this->ticksRan / $this->chargeTicks);
        $this->x = $this->player->x;
        $this->y = $this->player->y + 1.5 + ($prog * 3.5);
        $this->z = $this->player->z;
        $this->currentRadius = min(3.2, 0.1 + $this->ticksRan * 0.1);

        foreach ($this->starEids as $i => $eid) {
            $phi   = acos(-1 + (2 * $i) / 10);
            $theta = sqrt(10 * M_PI) * $phi + ($this->ticksRan * 0.4);
            $bx    = $this->x + $this->currentRadius * sin($phi) * cos($theta);
            $by    = $this->y + $this->currentRadius * cos($phi);
            $bz    = $this->z + $this->currentRadius * sin($phi) * sin($theta);
            BlockEffects::sendMove($this->level, $eid, $bx, $by, $bz);
            if ($this->ticksRan % 2 === 0) {
                $this->level->addParticle(new SmokeParticle(new Vector3($bx, $by, $bz)));
                $this->level->addParticle(new DustParticle(new Vector3($bx, $by, $bz), 80, 0, 120));
            }
        }

        foreach ($this->auraEids as $i => $eid) {
            $a = ($this->ticksRan * 0.18) + ($i * M_PI / 3);
            $r = $this->currentRadius + 0.8;
            BlockEffects::sendMove($this->level, $eid,
                $this->x + cos($a) * $r, $this->y, $this->z + sin($a) * $r,
                (int)($a * 100)
            );
        }

        for ($i = 0; $i < 8; $i++) {
            $a = mt_rand(0, 628) / 100;
            $r = mt_rand(0, (int)($this->currentRadius * 10)) / 10.0;
            $this->level->addParticle(new PortalParticle(new Vector3(
                $this->x + cos($a) * $r, $this->y + mt_rand(0, 30) / 10.0, $this->z + sin($a) * $r
            )));
        }

        if ($this->ticksRan >= $this->chargeTicks) {
            $this->initLaunch();
        }
    }

    private function initLaunch() {
        $lookDir     = $this->player->getDirectionVector()->normalize();
        $targetBlock = $this->player->getTargetBlock(70);

        if ($targetBlock !== null) {
            $this->targetPos = new Vector3(
                $targetBlock->x + 0.5, $targetBlock->y + 0.5, $targetBlock->z + 0.5
            );
        } else {
            $this->targetPos = $this->player->add(
                $lookDir->x * 70, $lookDir->y * 70, $lookDir->z * 70
            );
        }

        if ($this->player->pitch > 70 || $this->targetPos->distance($this->player) < 4) {
            $this->x = $this->player->x + $lookDir->x * 2;
            $this->y = $this->player->y;
            $this->z = $this->player->z + $lookDir->z * 2;
            $this->triggerVoidImpact();
            return;
        }

        $diff = $this->targetPos->subtract(new Vector3($this->x, $this->y, $this->z));
        $dist = $diff->length();
        if ($dist > 0) {
            $spd        = 3.8;
            $this->dirX = ($diff->x / $dist) * $spd;
            $this->dirY = ($diff->y / $dist) * $spd;
            $this->dirZ = ($diff->z / $dist) * $spd;
        }

        $this->launched = true;
        $this->level->addSound(new BlazeShootSound($this->player));
    }

    private function runLaunch() {
        $this->launchTicks++;
        $this->applyMagneticGuidance();

        $this->x += $this->dirX;
        $this->y += $this->dirY;
        $this->z += $this->dirZ;

        foreach ($this->starEids as $i => $eid) {
            $phi   = acos(-1 + (2 * $i) / 10);
            $theta = sqrt(10 * M_PI) * $phi + ($this->launchTicks * 0.7);
            $rad   = 1.1;
            BlockEffects::sendMove($this->level, $eid,
                $this->x + $rad * sin($phi) * cos($theta),
                $this->y + $rad * cos($phi),
                $this->z + $rad * sin($phi) * sin($theta),
                $this->launchTicks * 60
            );
        }

        foreach ($this->auraEids as $i => $eid) {
            $a = ($this->launchTicks * 0.35) + ($i * M_PI / 3);
            BlockEffects::sendMove($this->level, $eid,
                $this->x + cos($a) * 1.8, $this->y, $this->z + sin($a) * 1.8,
                (int)($a * 100)
            );
        }

        for ($i = 0; $i < 8; $i++) {
            $this->level->addParticle(new SmokeParticle(new Vector3(
                $this->x + mt_rand(-15, 15) / 10.0,
                $this->y + mt_rand(-15, 15) / 10.0,
                $this->z + mt_rand(-15, 15) / 10.0
            )));
            if ($i % 2 === 0) {
                $this->level->addParticle(new PortalParticle(new Vector3(
                    $this->x + mt_rand(-10, 10) / 10.0,
                    $this->y + mt_rand(-10, 10) / 10.0,
                    $this->z + mt_rand(-10, 10) / 10.0
                )));
            }
        }

        if ($this->launchTicks > 4 && ($this->checkCollision() || $this->launchTicks > 130)) {
            $this->triggerVoidImpact();
        }
    }

    private function applyMagneticGuidance() {
        $currentPos = new Vector3($this->x, $this->y, $this->z);
        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
            if ($e->distance($currentPos) < 6.5) {
                $targetDir = $e->getPosition()->add(0, 1, 0)->subtract($currentPos)->normalize();
                $this->dirX = ($this->dirX * 0.75) + ($targetDir->x * 0.85);
                $this->dirY = ($this->dirY * 0.75) + ($targetDir->y * 0.85);
                $this->dirZ = ($this->dirZ * 0.75) + ($targetDir->z * 0.85);
                break;
            }
        }
    }

    private function checkCollision() {
        $pos = new Vector3($this->x, $this->y, $this->z);
        $b   = $this->level->getBlock($pos);
        if ($b->getId() !== 0 && $b->getId() !== 8 && $b->getId() !== 9) return true;
        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
            if ($e->distance($pos) <= 4.0) return true;
        }
        return false;
    }

    private function triggerVoidImpact() {
        $groundY = $this->y;
        while ($groundY > 0) {
            if ($this->level->getBlockIdAt((int)$this->x, (int)$groundY - 1, (int)$this->z) !== 0) break;
            $groundY--;
        }
        $pos = new Vector3($this->x, $groundY, $this->z);

        $found   = BlockEffects::scanBlocks($this->level, $pos->x, $pos->y, $pos->z, 7, 12);
        $debris  = [];
        foreach ($found as $i => $b) {
            $deid  = BlockEffects::newEid();
            $angle = ($i / max(1, count($found))) * M_PI * 2;
            BlockEffects::sendSpawn($this->level, $deid, $b["id"], $b["damage"], $pos->x, $pos->y + 0.5, $pos->z);
            $debris[$deid] = [
                "eid" => $deid,
                "x"   => $pos->x, "y" => $pos->y + 0.5, "z" => $pos->z,
                "vx"  => cos($angle) * 1.6, "vy" => 1.0, "vz" => sin($angle) * 1.6,
                "life"=> 50, "tick" => 0
            ];
        }

        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(
            new AwakenDarkImpactDebrisTask($this->plugin, $this->level, $debris),
            1
        );

        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(
            new AwakenVoidSingularityTask($this->plugin, $this->player, $pos, $this->damage),
            1
        );

        $this->level->addParticle(new HugeExplodeParticle($pos));
        $this->level->addParticle(new LargeExplodeParticle($pos));
        $this->level->addSound(new ExplodeSound($pos));
        $this->cleanup();
    }

    private function cleanup() {
        foreach ($this->starEids as $eid) BlockEffects::sendRemove($eid);
        foreach ($this->auraEids as $eid) BlockEffects::sendRemove($eid);
        if ($this->player !== null && $this->player->isOnline()) {
            $this->player->removeEffect(Effect::DAMAGE_RESISTANCE);
        }
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenDarkImpactDebrisTask extends Task {
    private $plugin, $level, $debris;
    public function __construct($plugin, $level, array $debris) {
        $this->plugin  = $plugin;
        $this->level   = $level;
        $this->debris  = $debris;
    }
    public function onRun($currentTick) {
        if (empty($this->debris)) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }
        $toRemove = BlockEffects::tickDebris($this->debris, $this->level, -55, 0.08, 0.90);
        foreach ($toRemove as $eid) unset($this->debris[$eid]);
    }
}

class AwakenVoidSingularityTask extends Task {
    private $plugin, $player, $pos, $damage, $ticks = 0, $eids = [];

    public function __construct($plugin, Player $player, $pos, $damage) {
        $this->plugin  = $plugin;
        $this->player  = $player;
        $this->pos     = $pos;
        $this->damage  = $damage;

        $level = $player->getLevel();
        for ($i = 0; $i < 8; $i++) {
            $eid   = BlockEffects::newEid();
            $angle = (2 * M_PI / 8) * $i;
            BlockEffects::sendSpawn($level, $eid, 49, 0,
                $pos->x + cos($angle) * 3, $pos->y + 0.5, $pos->z + sin($angle) * 3
            );
            $this->eids[] = ["eid" => $eid, "angle" => (float)$angle];
        }
    }

    public function onRun($currentTick) {
        $this->ticks++;
        if ($this->ticks > 70 || $this->player === null) {
            $this->cleanup();
            return;
        }

        $level = $this->player->getLevel();

        foreach ($this->eids as &$seg) {
            $seg["angle"] -= 0.15;
            $r = 3.0 - ($this->ticks / 70) * 2.5;
            BlockEffects::sendMove($level, $seg["eid"],
                $this->pos->x + cos($seg["angle"]) * $r,
                $this->pos->y + 0.5 + sin($seg["angle"] * 2) * 0.3,
                $this->pos->z + sin($seg["angle"]) * $r,
                (int)($seg["angle"] * 100)
            );
        }

        for ($i = 0; $i < 20; $i++) {
            $a = mt_rand(0, 628) / 100;
            $r = mt_rand(0, 90) / 10;
            $level->addParticle(new SmokeParticle(new Vector3(
                $this->pos->x + cos($a) * $r,
                $this->pos->y + mt_rand(0, 30) / 10.0,
                $this->pos->z + sin($a) * $r
            )));
            if ($i % 3 === 0) {
                $level->addParticle(new PortalParticle(new Vector3(
                    $this->pos->x + cos($a) * $r,
                    $this->pos->y + mt_rand(0, 30) / 10.0,
                    $this->pos->z + sin($a) * $r
                )));
            }
            if ($i % 5 === 0) {
                $level->addParticle(new DustParticle(new Vector3(
                    $this->pos->x + cos($a) * $r,
                    $this->pos->y + mt_rand(0, 30) / 10.0,
                    $this->pos->z + sin($a) * $r
                ), 60, 0, 100));
            }
        }

        foreach ($level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e instanceof Player && !$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue;
            if ($e->distance($this->pos) > 10) continue;

            $e->setMotion(new Vector3(0, 0, 0));

            if ($this->ticks % 10 === 0) {
                $dmg = $this->damage * 0.30;
                $ev  = new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_MAGIC, $dmg);
                $e->attack($dmg, $ev);
            }
        }

        if ($this->ticks % 12 === 0) {
            $level->addSound(new FizzSound($this->pos));
        }
    }

    private function cleanup() {
        foreach ($this->eids as $seg) BlockEffects::sendRemove($seg["eid"]);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}
