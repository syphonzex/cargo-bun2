<?php

namespace OnePieceRaid\Awaken;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use OnePiece\NPC\NPCEntity;
use OnePieceRaid\Main;

class AwakenBossAbilityTask extends Task {

    private $plugin;
    private $instanceKey;

    public function __construct(Main $plugin, $instanceKey) {
        $this->plugin      = $plugin;
        $this->instanceKey = $instanceKey;
    }

    public function onRun($currentTick) {
        $am   = $this->plugin->getAwakenManager();
        $inst = $am->getInstanceData($this->instanceKey);

        if ($inst === null) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $phase = $inst["phase"];

        if (!in_array($phase, ["fighting", "boss_intro"])) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        if ($phase !== "fighting" || empty($inst["boss_alive"])) {
            return;
        }

        $raidKey = $inst["raid_key"];
        $boss    = $am->getBossEntity($this->instanceKey);

        if (!($boss instanceof NPCEntity) || !$boss->isAlive() || $boss->closed) {
            return;
        }

        $ability = mt_rand(0, 1) === 0 ? "ability1" : "ability2";
        $used    = AwakenBossAbility::useAbility($boss, $raidKey, $ability);

        if ($used) {
            $name = AwakenBossAbility::getAbilityName($raidKey, $ability);
            $am->broadcastToInstance($this->instanceKey, "§4§l[AWAKEN BOSS] §r§c" . $name . "!");
        }
    }
}