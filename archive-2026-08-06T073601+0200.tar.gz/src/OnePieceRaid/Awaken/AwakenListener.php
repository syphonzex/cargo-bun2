<?php

namespace OnePieceRaid\Awaken;

use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\Player;
use OnePiece\NPC\NPCEntity;
use OnePieceRaid\Main;

class AwakenListener implements Listener {

    private $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $plugin->getServer()->getPluginManager()->registerEvents($this, $plugin);
    }

    /**
     * @priority HIGHEST
     * @ignoreCancelled false
     */
    public function onEntityDamage(EntityDamageEvent $event) {
        $entity = $event->getEntity();
        if (!($entity instanceof Player)) return;

        $am = $this->plugin->getAwakenManager();
        if (!$am->isInAwakenWorld($entity)) return;

        if (!($event instanceof EntityDamageByEntityEvent)) return;
        $damager = $event->getDamager();
        if (!($damager instanceof Player)) return;

        $event->setCancelled(true);
        $damager->sendTip("§c[AWAKEN] PvP is disabled in raid instances.");
    }

    /**
     * @priority HIGH
     * @ignoreCancelled false
     */
    public function onNpcDeath(EntityDeathEvent $event) {
        $entity = $event->getEntity();
        if (!($entity instanceof NPCEntity)) return;

        $am = $this->plugin->getAwakenManager();
        if (!$am->isAwakenNpc($entity->npcId)) return;

        $instanceKey = $am->getInstanceKeyFromNpcId($entity->npcId);
        if ($instanceKey === null) return;

        $am->onNpcDeath($instanceKey);
    }

    /**
     * @priority HIGH
     * @ignoreCancelled false
     */
    public function onNpcDamage(EntityDamageEvent $event) {
        if (!($event instanceof EntityDamageByEntityEvent)) return;

        $entity  = $event->getEntity();
        $damager = $event->getDamager();

        if (!($entity instanceof NPCEntity)) return;
        if (!$this->plugin->getAwakenManager()->isAwakenNpc($entity->npcId)) return;

        if ($damager instanceof Player) {
            $am  = $this->plugin->getAwakenManager();
            $key = $am->getInstanceKeyFromNpcId($entity->npcId);
            if ($key !== null) {
                $inst = $am->getInstanceData($key);
                if ($inst !== null && !in_array($damager->getName(), $inst["players"])) {
                    $event->setCancelled(true);
                    return;
                }
            }
        }
    }

    /**
     * @priority HIGH
     * @ignoreCancelled false
     */
public function onPlayerDeath(PlayerDeathEvent $event) {
    $player = $event->getEntity();
    if (!($player instanceof Player)) return;

    $am = $this->plugin->getAwakenManager();
    if (!$am->isInAwakenWorld($player)) return;

    $event->setDeathMessage("");
    $event->setDrops([]);

    $instanceKey = $am->getInstanceByPlayer($player->getName());
    $am->removePlayerFromInstance($player->getName());

    if ($instanceKey !== null) {
        $inst = $am->getInstanceData($instanceKey);
        if ($inst !== null && in_array($inst["phase"], ["fighting", "boss_intro", "between_rounds", "starting"])) {
            if ($am->getOnlinePlayerCountInInstance($instanceKey) <= 0) {
                $am->broadcastToInstance($instanceKey, "§c§l[AWAKEN RAID] §r§cAll players have fallen. Raid failed!");
                $am->resolveInstance($instanceKey, false);
            }
        }
    }

    $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
        new class($this->plugin, $player->getName()) extends \pocketmine\scheduler\Task {
            private $plugin, $pName;
            public function __construct($pl, $pn) {
                $this->plugin = $pl;
                $this->pName = $pn;
            }
            public function onRun($t) {
                $p = \pocketmine\Server::getInstance()->getPlayerExact($this->pName);
                if ($p !== null && $p->isOnline()) {
                    $p->sendMessage("§c[AWAKEN] You died and were removed from the raid.");
                }
            }
        }, 20
    );
}

    /**
     * @priority HIGH
     */
public function onPlayerQuit(PlayerQuitEvent $event) {
    $player = $event->getPlayer();
    $am = $this->plugin->getAwakenManager();

    if (!$am->isInAwakenWorld($player)) return;

    $instanceKey = $am->getInstanceByPlayer($player->getName());
    $am->removePlayerFromInstance($player->getName());

    if ($instanceKey !== null) {
        $inst = $am->getInstanceData($instanceKey);
        if ($inst !== null && in_array($inst["phase"], ["fighting", "boss_intro", "between_rounds", "starting"])) {
            if ($am->getOnlinePlayerCountInInstance($instanceKey) <= 0) {
                $am->broadcastToInstance($instanceKey, "§c§l[AWAKEN RAID] §r§cAll players have left. Raid failed!");
                $am->resolveInstance($instanceKey, false);
                return;
            }
        }
        if ($am->isInstanceEmpty($instanceKey)) {
            $am->despawnAllEntities($instanceKey);
            $am->deleteInstanceWorld($instanceKey);
        }
    }
}
}
