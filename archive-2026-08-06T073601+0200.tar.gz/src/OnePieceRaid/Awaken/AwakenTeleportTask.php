<?php

namespace OnePieceRaid\Awaken;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use OnePieceRaid\Main;

class AwakenTeleportTask extends Task {

    private $plugin;
    private $instanceKey;
    private $fruitId;

    public function __construct(Main $plugin, $instanceKey, $fruitId) {
        $this->plugin      = $plugin;
        $this->instanceKey = $instanceKey;
        $this->fruitId     = $fruitId;
    }

public function onRun($currentTick) {
    $am   = $this->plugin->getAwakenManager();
    $inst = $am->getInstanceData($this->instanceKey);

    if ($inst === null) return;

    $server  = Server::getInstance();
    $players = $inst["players"];

    foreach ($players as $pName) {
        $p = $server->getPlayerExact($pName);
        if ($p === null || !$p->isOnline()) continue;

        $playerFruitId = $am->getPlayerFruitId($p);
        $playerRaidKey = $am->getRaidKeyForFruit($playerFruitId);
        $instRaidKey   = $inst["raid_key"] ?? null;
        $hasFruit      = ($playerRaidKey !== null && $instRaidKey !== null && strtolower($playerRaidKey) === strtolower($instRaidKey));

        if ($hasFruit) {
            $teleported = $am->teleportToAwakenSpawn($p);
            if ($teleported) {
                $p->sendMessage("§b§l[AWAKEN] §r§fYou have been transported to the awakening area!");
            } else {
                $server->dispatchCommand($p, "stp sea3");
                $server->dispatchCommand($p, "zone tp Sea_Castle");
            }
        } else {
            $server->dispatchCommand($p, "stp sea3");
            $server->dispatchCommand($p, "zone tp Sea_Castle");
            $p->sendMessage("§a§l[AWAKEN] §r§fRaid complete! Good fight.");
        }
    }

    $am->despawnAllEntities($this->instanceKey);

    $server->getScheduler()->scheduleDelayedTask(
        new class($this->plugin, $this->instanceKey) extends Task {
            private $plugin, $key;
            public function __construct($p, $k) { $this->plugin = $p; $this->key = $k; }
            public function onRun($t) { $this->plugin->getAwakenManager()->deleteInstanceWorld($this->key); }
        },
        40
    );
}
}
