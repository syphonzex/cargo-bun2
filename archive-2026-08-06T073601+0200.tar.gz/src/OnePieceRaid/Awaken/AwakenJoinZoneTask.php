<?php
namespace OnePieceRaid\Awaken;

use pocketmine\scheduler\Task;
use OnePieceRaid\Main;

class AwakenJoinZoneTask extends Task {
    private $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun($currentTick) {
        $this->plugin->getAwakenManager()->scanJoinZones();
    }
}