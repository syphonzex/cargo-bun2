<?php
namespace OnePieceRaid\Awaken;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use OnePieceRaid\Main;

class AwakenRaidTimerTask extends Task {
    private $plugin;
    private $instanceKey;

    public function __construct(Main $plugin, $instanceKey) {
        $this->plugin = $plugin;
        $this->instanceKey = $instanceKey;
    }

    public function onRun($currentTick) {
        $am = $this->plugin->getAwakenManager();
        $inst = $am->getInstanceData($this->instanceKey);

        if ($inst === null) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        if (!in_array($inst["phase"], ["fighting", "boss_intro", "between_rounds", "starting"])) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $elapsed = time() - ($inst["raid_start_time"] ?? time());
        $remaining = AwakenManager::RAID_TIME_LIMIT - $elapsed;

        if ($remaining <= 0) {
            $am->broadcastToInstancePopup($this->instanceKey, "§c§lTIME'S UP!");
            $am->resolveInstance($this->instanceKey, false);
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $mins = floor($remaining / 60);
        $secs = $remaining % 60;
        $timeStr = sprintf("%02d:%02d", $mins, $secs);
        $am->broadcastToInstancePopup($this->instanceKey, "§e§lTime left: §r§f" . $timeStr);
    }
}