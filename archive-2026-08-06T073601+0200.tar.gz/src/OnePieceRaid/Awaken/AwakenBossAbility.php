<?php

namespace OnePieceRaid\Awaken;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\scheduler\Task;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\block\Block;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\EnchantmentTableParticle;
use pocketmine\level\particle\EnchantParticle;
use pocketmine\level\particle\ExplodeParticle;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\particle\InstantEnchantParticle;
use pocketmine\level\particle\LargeExplodeParticle;
use pocketmine\level\particle\LavaDripParticle;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\particle\RedstoneParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\SporeParticle;
use pocketmine\level\particle\TerrainParticle;
use pocketmine\level\particle\WaterDripParticle;
use pocketmine\level\particle\WhiteSmokeParticle;
use pocketmine\level\sound\AnvilFallSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\BlazeShootSound;
use pocketmine\level\sound\ExplodeSound;
use pocketmine\level\sound\FizzSound;
use pocketmine\network\protocol\AddEntityPacket;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;
use OnePiece\Devil\BlockEffects;

class AwakenBossAbility {

    private static $COOLDOWNS = [
        "ice"  => ["ability1" => 180, "ability2" => 300],
        "sand" => ["ability1" => 160, "ability2" => 280],
        "flame" => ["ability1" => 200, "ability2" => 320],
        "light" => ["ability1" => 190, "ability2" => 310],
        "magma" => ["ability1" => 170, "ability2" => 330],
        "dark"  => ["ability1" => 210, "ability2" => 290],
        "rubber" => ["ability1" => 150, "ability2" => 260],
        "lightning" => ["ability1" => 220, "ability2" => 350],
    ];

    private static $bossCooldowns    = [];
    private static $bossGlobalCooldowns = [];
    private static $bossTasks        = [];

    public static function useAbility(NPCEntity $boss, $raidKey, $ability) {
        $bid  = $boss->getId();
        $tick = Server::getInstance()->getTick();

        if (isset(self::$bossGlobalCooldowns[$bid]) && $tick < self::$bossGlobalCooldowns[$bid]) {
            return false;
        }
        if (isset(self::$bossCooldowns[$bid][$ability]) && $tick < self::$bossCooldowns[$bid][$ability]) {
            return false;
        }

        $success = false;
        switch ($raidKey) {
            case "ice":
                if ($ability === "ability1") $success = self::iceGlacialCage($boss);
                else                         $success = self::iceAbsoluteZeroField($boss);
                break;
            case "sand":
                if ($ability === "ability1") $success = self::sandDesertBurial($boss);
                else                         $success = self::sandSandstormVortex($boss);
                break;
            case "flame":
                if ($ability === "ability1") $success = self::flameFireDragonJudgement($boss);
                else                         $success = self::flameDaiEnkaiEmperor($boss);
                break;
            case "light":
                if ($ability === "ability1") $success = self::lightSacredErasure($boss);
                else                         $success = self::lightAmaNoMurakumo($boss);
                break;
            case "magma":
                if ($ability === "ability1") $success = self::magmaCrimsonClaw($boss);
                else                         $success = self::magmaGreatEruption($boss);
                break;
            case "dark":
                if ($ability === "ability1") $success = self::darkBlackHoleVortex($boss);
                else                         $success = self::darkDarkStarLiberation($boss);
                break;
            case "rubber":
                if ($ability === "ability1") $success = self::rubberRedHawk($boss);
                else                         $success = self::rubberJetGatling($boss);
                break;
            case "lightning":
                if ($ability === "ability1") $success = self::lightningRagingDragon($boss);
                else                         $success = self::lightningCrushingJudgement($boss);
                break;
        }

        if ($success) {
            $cds = self::$COOLDOWNS[$raidKey] ?? ["ability1" => 200, "ability2" => 300];
            $cd  = $cds[$ability];
            self::$bossCooldowns[$bid][$ability]  = $tick + $cd;
            self::$bossGlobalCooldowns[$bid]      = $tick + max(40, (int)($cd * 0.25));
        }

        return $success;
    }

    public static function getAbilityName($raidKey, $ability) {
        $names = [
            "ice"  => [
                "ability1" => "Glacial Cage",
                "ability2" => "Absolute Zero Field",
            ],
            "sand" => [
                "ability1" => "Desert Burial",
                "ability2" => "Sandstorm Vortex",
            ],
            "flame" => [
                "ability1" => "Fire Dragon Judgement",
                "ability2" => "Dai Enkai: Flame Emperor",
            ],
            "light" => [
                "ability1" => "Sacred Light Erasure",
                "ability2" => "Ama no Murakumo",
            ],
            "magma" => [
                "ability1" => "Meikyo: Crimson Claw",
                "ability2" => "Great Eruption: Guren",
            ],
            "dark" => [
                "ability1" => "Black Hole Vortex",
                "ability2" => "Dark Star Liberation",
            ],
            "rubber" => [
                "ability1" => "Red Hawk",
                "ability2" => "Jet Gatling",
            ],
            "lightning" => [
                "ability1" => "Raging Dragon",
                "ability2" => "Crushing Judgement",
            ],
        ];
        return $names[$raidKey][$ability] ?? "Unknown";
    }

    public static function cleanupBoss($bossId) {
        if (isset(self::$bossTasks[$bossId])) {
            foreach (self::$bossTasks[$bossId] as $tid) {
                try {
                    Server::getInstance()->getScheduler()->cancelTask($tid);
                } catch (\Exception $e) {}
            }
            unset(self::$bossTasks[$bossId]);
        }
        unset(self::$bossCooldowns[$bossId]);
        unset(self::$bossGlobalCooldowns[$bossId]);
    }

    private static function registerTask(NPCEntity $boss, Task $task, $interval = 1) {
        Server::getInstance()->getScheduler()->scheduleRepeatingTask($task, $interval);
        self::$bossTasks[$boss->getId()][] = $task->getTaskId();
    }

    private static function getInstancePlayers(NPCEntity $boss) {
        $players = [];
        $level   = $boss->getLevel();
        if ($level === null) return $players;
        foreach ($level->getPlayers() as $p) {
            if ($p->isAlive() && !$p->closed && $p->spawned) {
                $players[] = $p;
            }
        }
        return $players;
    }

    private static function iceGlacialCage(NPCEntity $boss) {
        $players = self::getInstancePlayers($boss);
        if (empty($players)) return false;

        $level  = $boss->getLevel();
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

        $targets = [];
        foreach ($players as $p) {
            $colEids = [];
            for ($h = 0; $h < 6; $h++) {
                $eid = BlockEffects::newEid();
                BlockEffects::sendSpawn($level, $eid, 79, 0, $p->x, $p->y - 6 + $h, $p->z);
                $colEids[] = $eid;
            }
            $cage = [];
            $offsets = [
                [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1],
                [1, 0, 1], [-1, 0, 1], [1, 0, -1], [-1, 0, -1],
                [0, 2, 0],
            ];
            foreach ($offsets as $o) {
                $eid = BlockEffects::newEid();
                BlockEffects::sendSpawn($level, $eid, 79, 0, $p->x + $o[0], $p->y + $o[1], $p->z + $o[2]);
                $cage[] = $eid;
            }
            $targets[] = [
                "player"  => $p,
                "lockX"   => $p->x,
                "lockY"   => $p->y,
                "lockZ"   => $p->z,
                "colEids" => $colEids,
                "cage"    => $cage,
            ];
        }

        $task = new AwakenIceGlacialCageTask($plugin, $boss, $targets, $level);
        self::registerTask($boss, $task, 1);

        $level->addSound(new AnvilFallSound($boss->getPosition()));
        return true;
    }

    private static function iceAbsoluteZeroField(NPCEntity $boss) {
        $level  = $boss->getLevel();
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

        $eids = [];
        for ($i = 0; $i < 32; $i++) {
            $eid  = BlockEffects::newEid();
            $meta = ($i % 3 === 0) ? 0 : (($i % 3 === 1) ? 0 : 0);
            BlockEffects::sendSpawn($level, $eid, 79, 0, $boss->x, $boss->y, $boss->z);
            $eids[] = $eid;
        }

        $task = new AwakenIceAbsoluteZeroTask($plugin, $boss, $eids, $level);
        self::registerTask($boss, $task, 1);

        $level->addSound(new FizzSound($boss->getPosition()));
        $level->addSound(new AnvilUseSound($boss->getPosition()));
        return true;
    }

    private static function sandDesertBurial(NPCEntity $boss) {
        $players = self::getInstancePlayers($boss);
        if (empty($players)) return false;

        $level  = $boss->getLevel();
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

        $ringCount  = 3;
        $perRing    = 12;
        $ringEids   = [];

        for ($r = 0; $r < $ringCount; $r++) {
            $radius = 5.0 + ($r * 2.5);
            $row    = [];
            for ($i = 0; $i < $perRing; $i++) {
                $angle = (M_PI * 2 / $perRing) * $i;
                $eid   = BlockEffects::newEid();
                BlockEffects::sendSpawn($level, $eid, 12, 0,
                    $boss->x + cos($angle) * $radius,
                    $boss->y - 4,
                    $boss->z + sin($angle) * $radius
                );
                $row[] = ["eid" => $eid, "angle" => (float)$angle, "radius" => $radius];
            }
            $ringEids[] = $row;
        }

        $task = new AwakenSandDesertBurialTask($plugin, $boss, $players, $ringEids, $level);
        self::registerTask($boss, $task, 1);

        $level->addSound(new AnvilFallSound($boss->getPosition()));
        $level->addSound(new ExplodeSound($boss->getPosition()));
        return true;
    }

    private static function sandSandstormVortex(NPCEntity $boss) {
        $level  = $boss->getLevel();
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

        $rings    = 3;
        $perRing  = 14;
        $ringEids = [];

        for ($r = 0; $r < $rings; $r++) {
            $row = [];
            for ($i = 0; $i < $perRing; $i++) {
                $angle = (M_PI * 2 / $perRing) * $i;
                $eid   = BlockEffects::newEid();
                BlockEffects::sendSpawn($level, $eid, 12, 0, $boss->x, $boss->y + 1, $boss->z);
                $row[] = ["eid" => $eid, "angle" => (float)$angle, "band" => $r];
            }
            $ringEids[] = $row;
        }

        $task = new AwakenSandstormVortexTask($plugin, $boss, $ringEids, $level);
        self::registerTask($boss, $task, 1);

        $level->addSound(new FizzSound($boss->getPosition()));
        $level->addSound(new AnvilUseSound($boss->getPosition()));
        return true;
    }
    
    private static function flameFireDragonJudgement(NPCEntity $boss) {
    $level  = $boss->getLevel();
    $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

    $segs = [];
    for ($i = 0; $i < 12; $i++) {
        $eid  = BlockEffects::newEid();
        $block = ($i === 0) ? 87 : 35;
        $meta  = ($i === 0) ? 0 : 14;
        BlockEffects::sendSpawn($level, $eid, $block, $meta, $boss->x, $boss->y + 1, $boss->z);
        $segs[] = ["eid" => $eid];
    }

    $task = new AwakenFlameDragonTask($plugin, $boss, $segs, $level);
    self::registerTask($boss, $task, 1);

    $level->addSound(new ExplodeSound($boss->getPosition()));
    $level->addSound(new BlazeShootSound($boss->getPosition()));
    return true;
}

    private static function flameDaiEnkaiEmperor(NPCEntity $boss) {
    $level  = $boss->getLevel();
    $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

    $eids = [];
    for ($i = 0; $i < 24; $i++) {
        $eid  = BlockEffects::newEid();
        $meta = ($i < 8) ? 14 : (($i < 16) ? 1 : 4);
        BlockEffects::sendSpawn($level, $eid, 35, $meta, $boss->x, $boss->y + 4.5, $boss->z);
        $eids[] = $eid;
    }

    $task = new AwakenFlameEmperorTask($plugin, $boss, $eids, $level);
    self::registerTask($boss, $task, 1);

    $level->addSound(new FizzSound($boss->getPosition()));
    $level->addSound(new BlazeShootSound($boss->getPosition()));
    return true;
}
    
    private static function lightSacredErasure(NPCEntity $boss) {
    $level  = $boss->getLevel();
    $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

    $eids = [];
    for ($i = 0; $i < 6; $i++) {
        $eid = BlockEffects::newEid();
        BlockEffects::sendSpawn($level, $eid, 41, 0, $boss->x, $boss->y, $boss->z);
        $eids[] = $eid;
    }

    $task = new AwakenLightErasureTask($plugin, $boss, $eids, $level);
    self::registerTask($boss, $task, 1);

    $level->addSound(new AnvilUseSound($boss->getPosition()));
    $level->addSound(new BlazeShootSound($boss->getPosition()));
    return true;
}

    private static function lightAmaNoMurakumo(NPCEntity $boss) {
    $level  = $boss->getLevel();
    $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

    $spears = [];
    for ($i = 0; $i < 25; $i++) {
        $eid = BlockEffects::newEid();
        $rx  = $boss->x + mt_rand(-15, 15);
        $rz  = $boss->z + mt_rand(-15, 15);
        $ry  = $boss->y + 25 + mt_rand(0, 10);
        BlockEffects::sendSpawn($level, $eid, 41, 0, $rx, $ry, $rz);
        $spears[] = ["eid" => $eid, "pos" => new Vector3($rx, $ry, $rz)];
    }

    $task = new AwakenLightMurakumoTask($plugin, $boss, $spears, $level);
    self::registerTask($boss, $task, 1);

    $level->addSound(new BlazeShootSound($boss->getPosition()));
    $level->addSound(new AnvilUseSound($boss->getPosition()));
    return true;
}
    
    private static function magmaCrimsonClaw(NPCEntity $boss) {
    $level  = $boss->getLevel();
    $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

    $eids = [];
    for ($i = 0; $i < 10; $i++) {
        $eid   = BlockEffects::newEid();
        $block = ($i < 4) ? 49 : 159;
        $meta  = ($i < 4) ? 0 : 14;
        BlockEffects::sendSpawn($level, $eid, $block, $meta, $boss->x, $boss->y, $boss->z);
        $eids[] = $eid;
    }

    $task = new AwakenMagmaClawTask($plugin, $boss, $eids, $level);
    self::registerTask($boss, $task, 1);

    $level->addSound(new BlazeShootSound($boss->getPosition()));
    $level->addSound(new FizzSound($boss->getPosition()));
    return true;
}

    private static function magmaGreatEruption(NPCEntity $boss) {
    $level  = $boss->getLevel();
    $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

    $cx = $boss->x;
    $cy = $boss->y;
    $cz = $boss->z;

    $coreEid = BlockEffects::newEid();
    BlockEffects::sendSpawn($level, $coreEid, 49, 0, $cx, $cy + 30, $cz);

    $shell = [];
    for ($i = 0; $i < 14; $i++) {
        $eid   = BlockEffects::newEid();
        $angle = (2 * M_PI / 14) * $i;
        $block = ($i % 2 === 0) ? 87 : 159;
        $meta  = ($i % 2 === 0) ? 0 : 14;
        BlockEffects::sendSpawn($level, $eid, $block, $meta, $cx, $cy + 30, $cz);
        $shell[] = ["eid" => $eid, "a" => (float)$angle];
    }

    $task = new AwakenMagmaGurenTask($plugin, $boss, $coreEid, $shell, $level, $cx, $cy, $cz);
    self::registerTask($boss, $task, 1);

    $level->addSound(new ExplodeSound(new Vector3($cx, $cy, $cz)));
    $level->addSound(new BlazeShootSound(new Vector3($cx, $cy, $cz)));
    return true;
}
    
    private static function darkBlackHoleVortex(NPCEntity $boss) {
    $level  = $boss->getLevel();
    $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

    $task = new AwakenDarkVortexTask($plugin, $boss, $level);
    self::registerTask($boss, $task, 1);

    $level->addSound(new AnvilUseSound($boss->getPosition()));
    $level->addSound(new FizzSound($boss->getPosition()));
    return true;
}

    private static function darkDarkStarLiberation(NPCEntity $boss) {
    $level  = $boss->getLevel();
    $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

    $task = new AwakenDarkStarTask($plugin, $boss, $level);
    self::registerTask($boss, $task, 1);

    $level->addSound(new BlazeShootSound($boss->getPosition()));
    $level->addSound(new AnvilUseSound($boss->getPosition()));
    return true;
}
    
    private static function rubberRedHawk(NPCEntity $boss) {
    $level  = $boss->getLevel();
    $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

    $task = new AwakenRedHawkTask($plugin, $boss, $level);
    self::registerTask($boss, $task, 1);

    $level->addSound(new AnvilUseSound($boss->getPosition()));
    $level->addSound(new BlazeShootSound($boss->getPosition()));
    return true;
}

    private static function rubberJetGatling(NPCEntity $boss) {
    $level  = $boss->getLevel();
    $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

    $task = new AwakenJetGatlingTask($plugin, $boss, $level);
    self::registerTask($boss, $task, 1);

    $level->addSound(new BlazeShootSound($boss->getPosition()));
    return true;
}
    
    private static function lightningRagingDragon(NPCEntity $boss) {
    $level  = $boss->getLevel();
    $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

    $players = self::getInstancePlayers($boss);
    if (empty($players)) return false;

    $target = $players[array_rand($players)];

    $cloudPos  = new Vector3($boss->x, $boss->y + 18, $boss->z);
    $impactPos = new Vector3(
        $target->x,
        $level->getHighestBlockAt((int)floor($target->x), (int)floor($target->z)),
        $target->z
    );

    $blockPool = [[35, 3], [57, 0], [79, 0], [20, 0], [57, 0], [20, 0], [35, 3], [79, 0]];
    $segs = [];
    for ($i = 0; $i < 8; $i++) {
        $eid = BlockEffects::newEid();
        $b   = $blockPool[$i % count($blockPool)];
        BlockEffects::sendSpawn($level, $eid, $b[0], $b[1], $cloudPos->x, $cloudPos->y, $cloudPos->z);
        $segs[] = $eid;
    }

    $task = new AwakenLightningDragonTask($plugin, $boss, 10.2, $segs, $cloudPos, $impactPos, $level);
    self::registerTask($boss, $task, 1);

    $level->addSound(new ExplodeSound($boss->getPosition()));
    $level->addSound(new FizzSound($boss->getPosition()));
    return true;
}

    private static function lightningCrushingJudgement(NPCEntity $boss) {
    $level  = $boss->getLevel();
    $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");

    $players = self::getInstancePlayers($boss);
    if (empty($players)) return false;

    $target = $players[array_rand($players)];

    $impactPos = new Vector3(
        $target->x,
        $level->getHighestBlockAt((int)floor($target->x), (int)floor($target->z)),
        $target->z
    );
    $cloudY = $impactPos->y + 24;

    $eids = [];
    for ($i = 0; $i < 36; $i++) {
        $eid = BlockEffects::newEid();
        if ($i % 3 === 0)      { $id = 35; $data = 3; }
        elseif ($i % 3 === 1)  { $id = 57; $data = 0; }
        else                   { $id = 79; $data = 0; }
        BlockEffects::sendSpawn($level, $eid, $id, $data, $impactPos->x, $cloudY, $impactPos->z);
        $eids[] = $eid;
    }

    $task = new AwakenLightningJudgementTask($plugin, $boss, 3.98, $impactPos, $level, $eids, $cloudY);
    self::registerTask($boss, $task, 1);

    $level->addSound(new ExplodeSound($boss->getPosition()));
    $level->addSound(new FizzSound($boss->getPosition()));
    return true;
}
}

class AwakenIceGlacialCageTask extends Task {

    private $plugin, $boss, $targets, $level, $tick = 0, $cleaned = false;

    const RISE_TICKS  = 20;
    const HOLD_TICKS  = 40;
    const BURST_TICK  = 61;
    const TOTAL_TICKS = 80;

    public function __construct($plugin, NPCEntity $boss, array $targets, $level) {
        $this->plugin  = $plugin;
        $this->boss    = $boss;
        $this->targets = $targets;
        $this->level   = $level;
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed || $this->tick > self::TOTAL_TICKS) {
            $this->cleanup();
            return;
        }

        if ($this->tick <= self::RISE_TICKS) {
            $this->doRise();
        } elseif ($this->tick <= self::RISE_TICKS + self::HOLD_TICKS) {
            $this->doHold();
        } elseif ($this->tick === self::BURST_TICK) {
            $this->doBurst();
        }
    }

    private function doRise() {
        $prog = $this->tick / self::RISE_TICKS;

        foreach ($this->targets as &$t) {
            $p = $t["player"];
            if (!$p->isAlive() || $p->closed) continue;

            $p->setMotion(new Vector3(0, 0, 0));
            $p->teleport(new Vector3($t["lockX"], $t["lockY"], $t["lockZ"]));

            $rise = ($prog * 6) - 6;
            foreach ($t["colEids"] as $h => $eid) {
                BlockEffects::sendMove($this->level, $eid, $t["lockX"], $t["lockY"] - 6 + $h + ($prog * 6), $t["lockZ"]);
            }

            $cageOffsets = [
                [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1],
                [1, 0, 1], [-1, 0, 1], [1, 0, -1], [-1, 0, -1],
                [0, 2, 0],
            ];
            foreach ($t["cage"] as $i => $eid) {
                $o    = $cageOffsets[$i];
                $offY = $o[1] * $prog;
                BlockEffects::sendMove($this->level, $eid, $t["lockX"] + $o[0], $t["lockY"] - (1 - $prog) * 3 + $offY, $t["lockZ"] + $o[2]);
            }

            if ($this->tick % 3 === 0) {
                for ($i = 0; $i < 6; $i++) {
                    $a = ($i / 6) * M_PI * 2;
                    $this->level->addParticle(new DustParticle(
                        new Vector3($t["lockX"] + cos($a) * 1.2, $t["lockY"] + $this->tick * 0.1, $t["lockZ"] + sin($a) * 1.2),
                        180, 230, 255
                    ));
                }
                $this->level->addParticle(new WaterDripParticle(new Vector3($t["lockX"], $t["lockY"] + 1, $t["lockZ"])));
            }
        }
        unset($t);

        if ($this->tick % 5 === 0) {
            $this->level->addSound(new AnvilUseSound($this->boss->getPosition()));
        }
    }

    private function doHold() {
        $holdTick = $this->tick - self::RISE_TICKS;

        foreach ($this->targets as &$t) {
            $p = $t["player"];
            if (!$p->isAlive() || $p->closed) continue;

            $p->setMotion(new Vector3(0, 0, 0));
            $p->teleport(new Vector3($t["lockX"], $t["lockY"], $t["lockZ"]));

            if ($holdTick % 10 === 0) {
                $dmg = 3.5;
                $p->attack($dmg, new EntityDamageByEntityEvent($this->boss, $p, EntityDamageEvent::CAUSE_MAGIC, $dmg));
                for ($i = 0; $i < 8; $i++) {
                    $a = ($i / 8) * M_PI * 2;
                    $this->level->addParticle(new CriticalParticle(
                        new Vector3($t["lockX"] + cos($a) * 0.9, $t["lockY"] + 1, $t["lockZ"] + sin($a) * 0.9)
                    ));
                }
                $this->level->addParticle(new HugeExplodeParticle(new Vector3($t["lockX"], $t["lockY"] + 1, $t["lockZ"])));
            }

            if ($holdTick % 4 === 0) {
                $this->level->addParticle(new WaterDripParticle(
                    new Vector3($t["lockX"] + mt_rand(-5, 5) / 10.0, $t["lockY"] + mt_rand(0, 20) / 10.0, $t["lockZ"] + mt_rand(-5, 5) / 10.0)
                ));
                $this->level->addParticle(new DustParticle(
                    new Vector3($t["lockX"], $t["lockY"] + 1.5, $t["lockZ"]),
                    165, 220, 255
                ));
            }
        }
        unset($t);
    }

    private function doBurst() {
        foreach ($this->targets as $t) {
            $p = $t["player"];

            $allEids = array_merge($t["colEids"], $t["cage"]);
            foreach ($allEids as $eid) {
                BlockEffects::sendRemove($eid);
            }

            if (!$p->isAlive() || $p->closed) continue;

            $dmg = 8.0;
            $p->attack($dmg, new EntityDamageByEntityEvent($this->boss, $p, EntityDamageEvent::CAUSE_MAGIC, $dmg));
            $p->setMotion(new Vector3(0, 1.2, 0));

            $this->level->addParticle(new HugeExplodeParticle(new Vector3($t["lockX"], $t["lockY"] + 1, $t["lockZ"])));
            $this->level->addParticle(new LargeExplodeParticle(new Vector3($t["lockX"], $t["lockY"] + 1, $t["lockZ"])));

            for ($i = 0; $i < 20; $i++) {
                $a = ($i / 20) * M_PI * 2;
                $r = 1.5 + mt_rand(0, 10) / 10.0;
                $this->level->addParticle(new DustParticle(
                    new Vector3($t["lockX"] + cos($a) * $r, $t["lockY"] + mt_rand(0, 20) / 10.0, $t["lockZ"] + sin($a) * $r),
                    200, 240, 255
                ));
                if ($i % 4 === 0) {
                    $this->level->addParticle(new TerrainParticle(
                        new Vector3($t["lockX"] + cos($a) * $r, $t["lockY"] + 0.5, $t["lockZ"] + sin($a) * $r),
                        Block::get(79, 0)
                    ));
                }
            }

            for ($i = 0; $i < 8; $i++) {
                $this->level->addParticle(new CriticalParticle(
                    new Vector3($t["lockX"] + mt_rand(-15, 15) / 10.0, $t["lockY"] + mt_rand(5, 25) / 10.0, $t["lockZ"] + mt_rand(-15, 15) / 10.0)
                ));
            }

            $this->level->addSound(new ExplodeSound(new Vector3($t["lockX"], $t["lockY"], $t["lockZ"])));
            $this->level->addSound(new FizzSound(new Vector3($t["lockX"], $t["lockY"], $t["lockZ"])));
        }
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->targets as $t) {
            $allEids = array_merge($t["colEids"], $t["cage"]);
            foreach ($allEids as $eid) {
                BlockEffects::sendRemove($eid);
            }
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenIceAbsoluteZeroTask extends Task {

    private $plugin, $boss, $eids, $level, $tick = 0, $cleaned = false;
    private $victims = [];

    const TOTAL_TICKS  = 100;
    const PULL_RADIUS  = 14.0;
    const ORBIT_RADIUS = 6.0;
    const ORBIT_BANDS  = 4;
    const PER_BAND     = 8;

    public function __construct($plugin, NPCEntity $boss, array $eids, $level) {
        $this->plugin = $plugin;
        $this->boss   = $boss;
        $this->eids   = $eids;
        $this->level  = $level;
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed || $this->tick > self::TOTAL_TICKS) {
            $this->cleanup();
            return;
        }

        $bx = $this->boss->x;
        $by = $this->boss->y;
        $bz = $this->boss->z;

        $this->updateBlocks($bx, $by, $bz);
        $this->spawnParticles($bx, $by, $bz);
        $this->processTargets($bx, $by, $bz);
    }

    private function updateBlocks($bx, $by, $bz) {
        $totalBands = self::ORBIT_BANDS;
        $perBand    = self::PER_BAND;

        foreach ($this->eids as $i => $eid) {
            $band   = (int)($i / $perBand);
            $slot   = $i % $perBand;
            $speed  = 0.18 + ($band * 0.06);
            $radius = self::ORBIT_RADIUS - ($band * 0.8);
            $yOff   = $band * 0.6;

            $angle  = ($this->tick * $speed) + ($slot * (M_PI * 2 / $perBand));
            $yWave  = sin($this->tick * 0.15 + $band) * 0.4;

            $tx = $bx + cos($angle) * $radius;
            $ty = $by + $yOff + $yWave;
            $tz = $bz + sin($angle) * $radius;

            BlockEffects::sendMove($this->level, $eid, $tx, $ty, $tz, (int)($angle * 60));
        }
    }

    private function spawnParticles($bx, $by, $bz) {
        for ($ring = 0; $ring < 5; $ring++) {
            $r    = 2.5 + ($ring * 2.0);
            $pts  = 8 + ($ring * 3);
            $spin = $this->tick * (0.12 + $ring * 0.03);
            for ($i = 0; $i < $pts; $i++) {
                $a = ($i / $pts) * M_PI * 2 + $spin;
                $this->level->addParticle(new DustParticle(
                    new Vector3($bx + cos($a) * $r, $by + sin($this->tick * 0.2 + $ring) * 0.5, $bz + sin($a) * $r),
                    160 + (int)($ring * 10), 220, 255
                ));
            }
        }

        if ($this->tick % 3 === 0) {
            for ($i = 0; $i < 12; $i++) {
                $a = mt_rand(0, 628) / 100;
                $r = mt_rand(10, (int)(self::PULL_RADIUS * 10)) / 10.0;
                $this->level->addParticle(new WaterDripParticle(
                    new Vector3($bx + cos($a) * $r, $by + mt_rand(0, 20) / 10.0, $bz + sin($a) * $r)
                ));
            }
        }

        if ($this->tick % 5 === 0) {
            for ($i = 0; $i < 6; $i++) {
                $a = ($i / 6) * M_PI * 2 + $this->tick * 0.2;
                $this->level->addParticle(new CriticalParticle(
                    new Vector3($bx + cos($a) * (self::ORBIT_RADIUS + 0.5), $by + 1.0, $bz + sin($a) * (self::ORBIT_RADIUS + 0.5))
                ));
            }
        }

        if ($this->tick % 8 === 0) {
            $this->level->addSound(new FizzSound(new Vector3($bx, $by, $bz)));
        }
    }

    private function processTargets($bx, $by, $bz) {
        $center = new Vector3($bx, $by, $bz);

        foreach ($this->level->getPlayers() as $p) {
            if (!$p->isAlive() || $p->closed || !$p->spawned) continue;

            $dist = $p->distance($center);
            if ($dist > self::PULL_RADIUS) continue;

            $pid = $p->getId();
            if (!isset($this->victims[$pid])) {
                $this->victims[$pid] = $p->getPosition();
            }

            $dx  = $bx - $p->x;
            $dz  = $bz - $p->z;
            $len = sqrt($dx * $dx + $dz * $dz);

            $hoverY = $by + 1.0;
            $motY   = ($p->y < $hoverY) ? 0.18 : -0.12;

            if ($dist > self::ORBIT_RADIUS + 0.5) {
                $pull = 0.04;
                $safeLen = max(0.01, $len);
                $p->setMotion(new Vector3(($dx / $safeLen) * $pull, $motY, ($dz / $safeLen) * $pull));
            } elseif ($dist < self::ORBIT_RADIUS - 0.5) {
                $repel   = ($dist < 1.0) ? 1.4 : 0.55;
                $safeLen = max(0.01, $len);
                $vx      = ($len > 0.1) ? -($dx / $safeLen) : mt_rand(-10, 10) / 10.0;
                $vz      = ($len > 0.1) ? -($dz / $safeLen) : mt_rand(-10, 10) / 10.0;
                $p->setMotion(new Vector3($vx * $repel, $motY, $vz * $repel));
            } else {
                $p->setMotion(new Vector3(0, $motY, 0));
            }

            if ($this->tick % 15 === 0) {
                $dmg = 4.5;
                $p->attack($dmg, new EntityDamageByEntityEvent($this->boss, $p, EntityDamageEvent::CAUSE_MAGIC, $dmg));
                $this->level->addParticle(new CriticalParticle($p->getPosition()->add(0, 1, 0)));
                $this->level->addParticle(new HugeExplodeParticle($p->getPosition()->add(0, 1, 0)));
                $this->level->addParticle(new DustParticle(
                    $p->getPosition()->add(0, 1, 0),
                    180, 230, 255
                ));
            }

            if ($this->tick % 5 === 0) {
                $this->level->addParticle(new WaterDripParticle($p->getPosition()->add(0, 1.5, 0)));
            }
        }

        $currentPids = [];
        foreach ($this->level->getPlayers() as $p) {
            if ($p->distance($center) <= self::PULL_RADIUS) $currentPids[$p->getId()] = true;
        }
        foreach ($this->victims as $pid => $pos) {
            if (!isset($currentPids[$pid])) unset($this->victims[$pid]);
        }
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->eids as $eid) {
            BlockEffects::sendRemove($eid);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenSandDesertBurialTask extends Task {

    private $plugin, $boss, $players, $ringEids, $level, $tick = 0, $cleaned = false;
    private $lockedPlayers = [];

    const RISE_TICKS     = 22;
    const HOLD_TICKS     = 35;
    const COLLAPSE_TICKS = 18;
    const TOTAL_TICKS    = 85;

    public function __construct($plugin, NPCEntity $boss, array $players, array $ringEids, $level) {
        $this->plugin   = $plugin;
        $this->boss     = $boss;
        $this->players  = $players;
        $this->ringEids = $ringEids;
        $this->level    = $level;

        foreach ($players as $p) {
            $this->lockedPlayers[$p->getId()] = [
                "player" => $p,
                "lockX"  => $p->x,
                "lockY"  => $p->y,
                "lockZ"  => $p->z,
            ];
        }
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed || $this->tick > self::TOTAL_TICKS) {
            $this->cleanup();
            return;
        }

        if ($this->tick <= self::RISE_TICKS) {
            $this->doRise();
        } elseif ($this->tick <= self::RISE_TICKS + self::HOLD_TICKS) {
            $this->doHold();
        } elseif ($this->tick <= self::RISE_TICKS + self::HOLD_TICKS + self::COLLAPSE_TICKS) {
            $this->doCollapse();
        } else {
            $this->cleanup();
        }
    }

    private function doRise() {
        $prog = $this->tick / self::RISE_TICKS;
        $bx   = $this->boss->x;
        $by   = $this->boss->y;
        $bz   = $this->boss->z;

        foreach ($this->ringEids as $ringIndex => $ring) {
            foreach ($ring as $seg) {
                $targetY = $by + ($ringIndex * 0.4);
                $currentY = $by - 4 + ($prog * ($targetY - ($by - 4) + 4));
                BlockEffects::sendMove($this->level, $seg["eid"],
                    $bx + cos($seg["angle"]) * $seg["radius"],
                    $currentY,
                    $bz + sin($seg["angle"]) * $seg["radius"],
                    $this->tick * 8
                );
            }
        }

        foreach ($this->lockedPlayers as $data) {
            $p = $data["player"];
            if (!$p->isAlive() || $p->closed) continue;
            $dx  = $bx - $p->x;
            $dz  = $bz - $p->z;
            $len = sqrt($dx * $dx + $dz * $dz);
            if ($len > 0 && $len > 2.5) {
                $pull = 0.06 * $prog;
                $p->setMotion(new Vector3(($dx / $len) * $pull, 0, ($dz / $len) * $pull));
            }
        }

        if ($this->tick % 3 === 0) {
            for ($i = 0; $i < 14; $i++) {
                $a = mt_rand(0, 628) / 100;
                $r = mt_rand(10, 100) / 10.0;
                $this->level->addParticle(new DustParticle(
                    new Vector3($bx + cos($a) * $r, $by + mt_rand(0, 15) / 10.0, $bz + sin($a) * $r),
                    210, 180, 100
                ));
            }
        }

        if ($this->tick % 6 === 0) {
            $this->level->addSound(new AnvilUseSound(new Vector3($bx, $by, $bz)));
        }
    }

    private function doHold() {
        $holdTick = $this->tick - self::RISE_TICKS;
        $bx = $this->boss->x;
        $by = $this->boss->y;
        $bz = $this->boss->z;

        foreach ($this->ringEids as $ringIndex => $ring) {
            $rotSpeed = 0.03 + ($ringIndex * 0.015);
            foreach ($ring as &$seg) {
                $seg["angle"] += ($ringIndex % 2 === 0 ? $rotSpeed : -$rotSpeed);
                BlockEffects::sendMove($this->level, $seg["eid"],
                    $bx + cos($seg["angle"]) * $seg["radius"],
                    $by + ($ringIndex * 0.4) + sin($holdTick * 0.15 + $ringIndex) * 0.2,
                    $bz + sin($seg["angle"]) * $seg["radius"],
                    $holdTick * 6
                );
            }
            unset($seg);
        }

        foreach ($this->lockedPlayers as $pid => $data) {
            $p = $data["player"];
            if (!$p->isAlive() || $p->closed) continue;
            $p->setMotion(new Vector3(0, 0, 0));
            $p->teleport(new Vector3($data["lockX"], $data["lockY"], $data["lockZ"]));

            if ($holdTick % 12 === 0) {
                $dmg = 3.0;
                $p->attack($dmg, new EntityDamageByEntityEvent($this->boss, $p, EntityDamageEvent::CAUSE_MAGIC, $dmg));
                $this->level->addParticle(new ExplodeParticle($p->getPosition()->add(0, 1, 0)));
                for ($i = 0; $i < 6; $i++) {
                    $a = ($i / 6) * M_PI * 2;
                    $this->level->addParticle(new DustParticle(
                        new Vector3($data["lockX"] + cos($a) * 0.8, $data["lockY"] + mt_rand(0, 15) / 10.0, $data["lockZ"] + sin($a) * 0.8),
                        210, 180, 100
                    ));
                }
            }
        }

        if ($holdTick % 4 === 0) {
            for ($i = 0; $i < 10; $i++) {
                $a = mt_rand(0, 628) / 100;
                $r = mt_rand(5, 120) / 10.0;
                $this->level->addParticle(new SmokeParticle(
                    new Vector3($bx + cos($a) * $r, $by + mt_rand(0, 20) / 10.0, $bz + sin($a) * $r)
                ));
                $this->level->addParticle(new DustParticle(
                    new Vector3($bx + cos($a) * $r, $by + mt_rand(5, 25) / 10.0, $bz + sin($a) * $r),
                    190, 160, 80
                ));
            }
        }
    }

    private function doCollapse() {
        $collapseTick = $this->tick - self::RISE_TICKS - self::HOLD_TICKS;
        $prog         = $collapseTick / self::COLLAPSE_TICKS;
        $bx = $this->boss->x;
        $by = $this->boss->y;
        $bz = $this->boss->z;

        foreach ($this->ringEids as $ringIndex => $ring) {
            foreach ($ring as $seg) {
                $collapseRadius = $seg["radius"] * (1.0 - $prog * 0.85);
                BlockEffects::sendMove($this->level, $seg["eid"],
                    $bx + cos($seg["angle"]) * $collapseRadius,
                    $by + ($ringIndex * 0.4) - ($prog * 3.0),
                    $bz + sin($seg["angle"]) * $collapseRadius,
                    $collapseTick * 15
                );
            }
        }

        if ($collapseTick === (int)(self::COLLAPSE_TICKS * 0.5)) {
            foreach ($this->lockedPlayers as $data) {
                $p = $data["player"];
                if (!$p->isAlive() || $p->closed) continue;
                $dmg = 9.0;
                $p->attack($dmg, new EntityDamageByEntityEvent($this->boss, $p, EntityDamageEvent::CAUSE_MAGIC, $dmg));
                $dx  = $p->x - $bx;
                $dz  = $p->z - $bz;
                $len = sqrt($dx * $dx + $dz * $dz);
                if ($len > 0) {
                    $p->setMotion(new Vector3(($dx / $len) * 1.4, 0.9, ($dz / $len) * 1.4));
                }
                $this->level->addParticle(new HugeExplodeParticle($p->getPosition()->add(0, 1, 0)));
                $this->level->addSound(new ExplodeSound($p->getPosition()));
            }

            for ($i = 0; $i < 28; $i++) {
                $a = ($i / 28) * M_PI * 2;
                $r = mt_rand(5, 30) / 10.0;
                $this->level->addParticle(new DustParticle(
                    new Vector3($bx + cos($a) * $r, $by + mt_rand(0, 25) / 10.0, $bz + sin($a) * $r),
                    210, 180, 100
                ));
                $this->level->addParticle(new TerrainParticle(
                    new Vector3($bx + cos($a) * $r, $by + 0.5, $bz + sin($a) * $r),
                    Block::get(12, 0)
                ));
            }
            $this->level->addParticle(new HugeExplodeParticle(new Vector3($bx, $by + 1, $bz)));
            $this->level->addParticle(new LargeExplodeParticle(new Vector3($bx, $by + 1, $bz)));
            $this->level->addSound(new ExplodeSound(new Vector3($bx, $by, $bz)));
        }

        if ($collapseTick % 3 === 0) {
            for ($i = 0; $i < 8; $i++) {
                $a = mt_rand(0, 628) / 100;
                $r = mt_rand(5, 80) / 10.0;
                $this->level->addParticle(new SmokeParticle(
                    new Vector3($bx + cos($a) * $r, $by + mt_rand(5, 20) / 10.0, $bz + sin($a) * $r)
                ));
            }
        }
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->ringEids as $ring) {
            foreach ($ring as $seg) {
                BlockEffects::sendRemove($seg["eid"]);
            }
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenSandstormVortexTask extends Task {

    private $plugin, $boss, $ringEids, $level, $tick = 0, $cleaned = false;
    private $hitLog = [];

    const EXPAND_TICKS   = 30;
    const HOLD_TICKS     = 20;
    const COLLAPSE_TICKS = 30;
    const TOTAL_TICKS    = 95;

    const MIN_RADIUS = 2.0;
    const MAX_RADIUS = 13.0;

    public function __construct($plugin, NPCEntity $boss, array $ringEids, $level) {
        $this->plugin   = $plugin;
        $this->boss     = $boss;
        $this->ringEids = $ringEids;
        $this->level    = $level;
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed || $this->tick > self::TOTAL_TICKS) {
            $this->cleanup();
            return;
        }

        $bx = $this->boss->x;
        $by = $this->boss->y;
        $bz = $this->boss->z;

        $radius = $this->getCurrentRadius();

        $this->updateRings($bx, $by, $bz, $radius);
        $this->spawnParticles($bx, $by, $bz, $radius);
        $this->processPlayers($bx, $by, $bz, $radius);
    }

    private function getCurrentRadius() {
        if ($this->tick <= self::EXPAND_TICKS) {
            $prog = $this->tick / self::EXPAND_TICKS;
            return self::MIN_RADIUS + ($prog * (self::MAX_RADIUS - self::MIN_RADIUS));
        } elseif ($this->tick <= self::EXPAND_TICKS + self::HOLD_TICKS) {
            return self::MAX_RADIUS;
        } else {
            $prog = ($this->tick - self::EXPAND_TICKS - self::HOLD_TICKS) / self::COLLAPSE_TICKS;
            return self::MAX_RADIUS - ($prog * (self::MAX_RADIUS - self::MIN_RADIUS));
        }
    }

    private function isExpanding() {
        return $this->tick <= self::EXPAND_TICKS;
    }

    private function isCollapsing() {
        return $this->tick > self::EXPAND_TICKS + self::HOLD_TICKS;
    }

    private function updateRings($bx, $by, $bz, $radius) {
        foreach ($this->ringEids as $bandIndex => $ring) {
            $bandRadius = $radius - ($bandIndex * 1.5);
            if ($bandRadius < 1.0) $bandRadius = 1.0;

            $yOff     = $bandIndex * 0.7;
            $rotSpeed = 0.14 + ($bandIndex * 0.05);
            $dir      = ($bandIndex % 2 === 0) ? 1 : -1;

            foreach ($this->ringEids[$bandIndex] as &$seg) {
                $seg["angle"] += $rotSpeed * $dir;
                $yWave = sin($this->tick * 0.12 + $bandIndex * 1.2) * 0.3;
                BlockEffects::sendMove($this->level, $seg["eid"],
                    $bx + cos($seg["angle"]) * $bandRadius,
                    $by + 1 + $yOff + $yWave,
                    $bz + sin($seg["angle"]) * $bandRadius,
                    $this->tick * 10
                );
            }
            unset($seg);
        }
    }

private function spawnParticles($bx, $by, $bz, $radius) {
    for ($layer = 0; $layer < 4; $layer++) {
        $layerR = $radius * (0.4 + $layer * 0.2);
        $pts    = 6 + ($layer * 2);
        $spin   = $this->tick * (0.16 + $layer * 0.04) * ($layer % 2 === 0 ? 1 : -1);
        for ($i = 0; $i < $pts; $i++) {
            $a = ($i / $pts) * M_PI * 2 + $spin;
            $this->level->addParticle(new DustParticle(
                new Vector3(
                    $bx + cos($a) * $layerR,
                    $by + 1 + ($layer * 0.5) + sin($this->tick * 0.1 + $layer) * 0.3,
                    $bz + sin($a) * $layerR
                ),
                200 - ($layer * 15), 165 - ($layer * 10), 80 - ($layer * 10)
            ));
        }
    }

    if ($this->tick % 3 === 0) {
        $maxR = max(10, (int)($radius * 10));
        for ($i = 0; $i < 10; $i++) {
            $a = mt_rand(0, 628) / 100;
            $r = mt_rand(5, $maxR) / 10.0;
            $this->level->addParticle(new SmokeParticle(
                new Vector3($bx + cos($a) * $r, $by + mt_rand(0, 25) / 10.0, $bz + sin($a) * $r)
            ));
        }
    }

    if ($this->tick % 4 === 0) {
        for ($i = 0; $i < 8; $i++) {
            $a = ($i / 8) * M_PI * 2 + $this->tick * 0.2;
            $this->level->addParticle(new TerrainParticle(
                new Vector3($bx + cos($a) * $radius, $by + 1, $bz + sin($a) * $radius),
                Block::get(12, 0)
            ));
        }
    }

    if ($this->tick % 8 === 0) {
        $this->level->addSound(new FizzSound(new Vector3($bx, $by, $bz)));
    }
}

    private function processPlayers($bx, $by, $bz, $radius) {
        $center    = new Vector3($bx, $by, $bz);
        $expanding = $this->isExpanding();
        $collapsing = $this->isCollapsing();

        foreach ($this->level->getPlayers() as $p) {
            if (!$p->isAlive() || $p->closed || !$p->spawned) continue;

            $dist = $p->distance($center);
            if ($dist > self::MAX_RADIUS + 3.0) continue;

            $dx     = $p->x - $bx;
            $dz     = $p->z - $bz;
            $hLen   = sqrt($dx * $dx + $dz * $dz);
            $safeLen = max(0.01, $hLen);

            if ($expanding && $dist < $radius + 1.5 && $dist > 1.0) {
                $pushForce = 0.35;
                $p->setMotion(new Vector3(($dx / $safeLen) * $pushForce, 0.25, ($dz / $safeLen) * $pushForce));
            } elseif ($collapsing && $dist < self::MAX_RADIUS + 1.0 && $dist > 1.0) {
                $pullForce = 0.3;
                $p->setMotion(new Vector3(-($dx / $safeLen) * $pullForce, 0.1, -($dz / $safeLen) * $pullForce));
            }

            $wallInner = $radius - 2.5;
            $wallOuter = $radius + 1.5;
            $inWall    = ($dist >= $wallInner && $dist <= $wallOuter);

            if ($inWall) {
                $hitKey = $p->getId() . "_" . (int)($this->tick / 8);
                if (!isset($this->hitLog[$hitKey])) {
                    $this->hitLog[$hitKey] = true;
                    $dmg = 4.0;
                    $p->attack($dmg, new EntityDamageByEntityEvent($this->boss, $p, EntityDamageEvent::CAUSE_MAGIC, $dmg));

                    $this->level->addParticle(new ExplodeParticle($p->getPosition()->add(0, 1, 0)));
                    $this->level->addParticle(new LargeExplodeParticle($p->getPosition()->add(0, 1, 0)));

                    for ($i = 0; $i < 10; $i++) {
                        $a = ($i / 10) * M_PI * 2;
                        $this->level->addParticle(new DustParticle(
                            new Vector3($p->x + cos($a) * 0.9, $p->y + mt_rand(0, 18) / 10.0, $p->z + sin($a) * 0.9),
                            220, 185, 100
                        ));
                        if ($i % 3 === 0) {
                            $this->level->addParticle(new TerrainParticle(
                                new Vector3($p->x + cos($a) * 0.9, $p->y + 0.5, $p->z + sin($a) * 0.9),
                                Block::get(12, 0)
                            ));
                        }
                    }

                    $this->level->addSound(new AnvilUseSound($p->getPosition()));
                }
            }

            if ($this->tick % 3 === 0 && $dist < $radius) {
                $this->level->addParticle(new SmokeParticle(
                    new Vector3($p->x + mt_rand(-5, 5) / 10.0, $p->y + 1, $p->z + mt_rand(-5, 5) / 10.0)
                ));
            }
        }
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->ringEids as $ring) {
            foreach ($ring as $seg) {
                BlockEffects::sendRemove($seg["eid"]);
            }
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenFlameDragonTask extends Task {

    private $plugin, $boss, $segs, $level, $tick = 0, $cleaned = false;
    private $bx, $by, $bz, $dragged = [], $target = null, $initialDir;

    const TOTAL_TICKS = 55;
    const MOVE_SPEED  = 1.8;
    const DAMAGE      = 10.0;
    const HIT_RADIUS  = 3.0;

    public function __construct($plugin, NPCEntity $boss, array $segs, $level) {
        $this->plugin = $plugin;
        $this->boss   = $boss;
        $this->segs   = $segs;
        $this->level  = $level;

        $this->bx = $boss->x;
        $this->by = $boss->y + 1;
        $this->bz = $boss->z;

        $this->initialDir = $this->boss->getDirectionVector();
        $this->target     = $this->findLockTarget();
    }

    private function findLockTarget() {
        $best   = null;
        $minDot = 0.80;

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;

            $toEntity = $e->getPosition()->subtract($this->boss->getPosition());
            if ($toEntity->length() > 20) continue;

            $dot = $this->initialDir->dot($toEntity->normalize());
            if ($dot > $minDot) {
                $minDot = $dot;
                $best   = $e;
            }
        }

        return $best;
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed || $this->tick > self::TOTAL_TICKS) {
            $this->cleanup();
            return;
        }

        $headPos = new Vector3($this->bx, $this->by, $this->bz);
        $moveDir = $this->initialDir;

        if ($this->target !== null && $this->target->isAlive() && !$this->target->closed) {
            $moveDir = $this->target->getPosition()->add(0, 1, 0)->subtract($headPos)->normalize();
        }

        $this->bx += $moveDir->x * self::MOVE_SPEED;
        $this->by += $moveDir->y * self::MOVE_SPEED;
        $this->bz += $moveDir->z * self::MOVE_SPEED;

        $currentHead = new Vector3($this->bx, $this->by, $this->bz);

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive() || isset($this->dragged[$e->getId()])) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;

            if ($e->distance($currentHead) <= self::HIT_RADIUS) {
                $this->dragged[$e->getId()] = $e;
                $e->attack(self::DAMAGE, new EntityDamageByEntityEvent($this->boss, $e, EntityDamageEvent::CAUSE_MAGIC, self::DAMAGE));
                $this->level->addParticle(new HugeExplodeParticle($e->getPosition()->add(0, 1, 0)));
            }
        }

        $this->updateSegments($moveDir);
        $this->dragVictims($currentHead);
    }

    private function updateSegments($moveDir) {
        foreach ($this->segs as $i => $s) {
            $lag = $i * 1.2;
            $sx  = $this->bx - $moveDir->x * $lag;
            $sz  = $this->bz - $moveDir->z * $lag;
            $sy  = ($this->by - $moveDir->y * $lag) + sin(($this->tick - $i) * 0.4) * 0.5;

            BlockEffects::sendMove($this->level, $s["eid"], $sx, $sy, $sz, 0);

            if ($this->tick % 2 === 0) {
                $this->level->addParticle(new FlameParticle(new Vector3($sx, $sy, $sz)));
                if ($i % 3 === 0) {
                    $this->level->addParticle(new SmokeParticle(new Vector3($sx, $sy, $sz)));
                }
            }

            if ($i === 0) {
                $this->level->addParticle(new HugeExplodeParticle(new Vector3($sx, $sy, $sz)));
                if ($this->tick % 4 === 0) {
                    $this->level->addParticle(new LavaDripParticle(new Vector3($sx, $sy, $sz)));
                }
            }
        }
    }

    private function dragVictims($headPos) {
        foreach ($this->dragged as $id => $e) {
            if ($e->isAlive() && !$e->closed) {
                $e->setMotion(new Vector3(0, 0, 0));
                $e->teleport($headPos);

                if ($this->tick % 5 === 0) {
                    $this->level->addParticle(new FlameParticle($e->getPosition()->add(0, 1, 0)));
                    $this->level->addParticle(new CriticalParticle($e->getPosition()->add(0, 1.5, 0)));
                }
            } else {
                unset($this->dragged[$id]);
            }
        }
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        $pos = new Vector3($this->bx, $this->by, $this->bz);
        $this->level->addSound(new ExplodeSound($pos));
        $this->level->addParticle(new HugeExplodeParticle($pos));
        $this->level->addParticle(new LargeExplodeParticle($pos));

        for ($i = 0; $i < 16; $i++) {
            $a = ($i / 16) * M_PI * 2;
            $r = mt_rand(10, 30) / 10.0;
            $this->level->addParticle(new FlameParticle(
                new Vector3($pos->x + cos($a) * $r, $pos->y + mt_rand(-5, 10) / 10.0, $pos->z + sin($a) * $r)
            ));
            if ($i % 4 === 0) {
                $this->level->addParticle(new TerrainParticle(
                    new Vector3($pos->x + cos($a) * $r, $pos->y, $pos->z + sin($a) * $r),
                    Block::get(87, 0)
                ));
            }
        }

        foreach ($this->dragged as $e) {
            if ($e->isAlive() && !$e->closed) {
                $e->setMotion(new Vector3(mt_rand(-10, 10) / 10.0, 0.8, mt_rand(-10, 10) / 10.0));
            }
        }

        foreach ($this->segs as $s) {
            BlockEffects::sendRemove($s["eid"]);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenFlameEmperorTask extends Task {

    private $plugin, $boss, $eids, $level, $tick = 0, $cleaned = false;
    private $bx, $by, $bz, $launched = false, $target = null, $vDir;

    const CHARGE_TICKS = 20;
    const TOTAL_TICKS  = 95;
    const MOVE_SPEED   = 1.5;
    const DAMAGE       = 9.0;
    const HIT_RADIUS   = 3.0;
    const EXPLODE_RADIUS = 9.0;

    public function __construct($plugin, NPCEntity $boss, array $eids, $level) {
        $this->plugin = $plugin;
        $this->boss   = $boss;
        $this->eids   = $eids;
        $this->level  = $level;
    }

    private function findLockTarget($dir) {
        $best   = null;
        $minDot = 0.80;

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;

            $toEntity = $e->getPosition()->subtract($this->boss->getPosition());
            if ($toEntity->length() > 18) continue;

            $dot = $dir->dot($toEntity->normalize());
            if ($dot > $minDot) {
                $minDot = $dot;
                $best   = $e;
            }
        }

        return $best;
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed) {
            $this->cleanup();
            return;
        }

        if (!$this->launched) {
            $this->doCharge();
        } else {
            $this->doLaunch();
        }

        $this->updateOrbitals();
    }

    private function doCharge() {
        $this->bx = $this->boss->x;
        $this->by = $this->boss->y + 4.5;
        $this->bz = $this->boss->z;

        if ($this->tick >= self::CHARGE_TICKS) {
            $this->launched = true;
            $this->vDir     = $this->boss->getDirectionVector();
            $this->target   = $this->findLockTarget($this->vDir);
            $this->level->addSound(new BlazeShootSound(new Vector3($this->bx, $this->by, $this->bz)));
            $this->level->addSound(new ExplodeSound(new Vector3($this->bx, $this->by, $this->bz)));
        }

        if ($this->tick % 2 === 0) {
            $this->level->addParticle(new LavaDripParticle(
                new Vector3($this->bx + mt_rand(-15, 15) / 10.0, $this->by, $this->bz + mt_rand(-15, 15) / 10.0)
            ));
        }

        if ($this->tick % 3 === 0) {
            for ($i = 0; $i < 6; $i++) {
                $a = ($i / 6) * M_PI * 2 + $this->tick * 0.2;
                $this->level->addParticle(new FlameParticle(
                    new Vector3($this->bx + cos($a) * 2.5, $this->by, $this->bz + sin($a) * 2.5)
                ));
            }
        }

        if ($this->tick % 8 === 0) {
            $this->level->addSound(new FizzSound(new Vector3($this->bx, $this->by, $this->bz)));
        }
    }

    private function doLaunch() {
        $center  = new Vector3($this->bx, $this->by, $this->bz);
        $moveDir = $this->vDir;

        if ($this->target !== null && $this->target->isAlive() && !$this->target->closed) {
            $moveDir = $this->target->getPosition()->add(0, 1, 0)->subtract($center)->normalize();
        }

        $this->bx += $moveDir->x * self::MOVE_SPEED;
        $this->by += $moveDir->y * self::MOVE_SPEED;
        $this->bz += $moveDir->z * self::MOVE_SPEED;

        $newCenter = new Vector3($this->bx, $this->by, $this->bz);

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;

            if ($e->distance($newCenter) <= self::HIT_RADIUS) {
                $this->explode($newCenter);
                $this->cleanup();
                return;
            }
        }

        if ($this->tick > self::TOTAL_TICKS) {
            $this->explode($newCenter);
            $this->cleanup();
        }

        if ($this->tick % 2 === 0) {
            for ($i = 0; $i < 8; $i++) {
                $a = mt_rand(0, 628) / 100;
                $r = mt_rand(10, 30) / 10.0;
                $this->level->addParticle(new FlameParticle(
                    new Vector3($this->bx + cos($a) * $r, $this->by + mt_rand(-10, 10) / 10.0, $this->bz + sin($a) * $r)
                ));
            }
        }
    }

    private function updateOrbitals() {
        $rot = $this->tick * 0.3;

        foreach ($this->eids as $i => $eid) {
            $ang = ($i % 8) * (M_PI / 4) + $rot;

            if ($i < 8) {
                $tx = $this->bx + cos($ang) * 2.5;
                $ty = $this->by;
                $tz = $this->bz + sin($ang) * 2.5;
            } elseif ($i < 16) {
                $tx = $this->bx;
                $ty = $this->by + cos($ang) * 2.5;
                $tz = $this->bz + sin($ang) * 2.5;
            } else {
                $tx = $this->bx + cos($ang) * 2.0;
                $ty = $this->by + sin($ang) * 2.0;
                $tz = $this->bz + cos($ang) * 2.0;
            }

            BlockEffects::sendMove($this->level, $eid, $tx, $ty, $tz, (int)($ang * 60));

            if ($this->tick % 2 === 0) {
                $this->level->addParticle(new FlameParticle(new Vector3($tx, $ty, $tz)));
            }
        }
    }

    private function explode($pos) {
        $this->level->addSound(new ExplodeSound($pos));
        $this->level->addParticle(new HugeExplodeParticle($pos));
        $this->level->addParticle(new LargeExplodeParticle($pos));

        for ($i = 0; $i < 28; $i++) {
            $a = ($i / 28) * M_PI * 2;
            $r = mt_rand(10, 50) / 10.0;
            $this->level->addParticle(new FlameParticle(
                new Vector3($pos->x + cos($a) * $r, $pos->y + mt_rand(-20, 40) / 10.0, $pos->z + sin($a) * $r)
            ));
            $this->level->addParticle(new LargeExplodeParticle(
                new Vector3($pos->x + cos($a) * $r, $pos->y + mt_rand(0, 20) / 10.0, $pos->z + sin($a) * $r)
            ));

            if ($i % 4 === 0) {
                $this->level->addParticle(new TerrainParticle(
                    new Vector3($pos->x + cos($a) * $r, $pos->y, $pos->z + sin($a) * $r),
                    Block::get(87, 0)
                ));
            }
        }

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;

            if ($e->distance($pos) <= self::EXPLODE_RADIUS) {
                $e->attack(self::DAMAGE, new EntityDamageByEntityEvent($this->boss, $e, EntityDamageEvent::CAUSE_MAGIC, self::DAMAGE));

                $dx = $e->x - $pos->x;
                $dz = $e->z - $pos->z;
                $len = sqrt($dx * $dx + $dz * $dz);
                if ($len > 0) {
                    $e->setMotion(new Vector3(($dx / $len) * 0.6, 1.2, ($dz / $len) * 0.6));
                }

                $this->level->addParticle(new HugeExplodeParticle($e->getPosition()->add(0, 1, 0)));
            }
        }
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->eids as $eid) {
            BlockEffects::sendRemove($eid);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenLightErasureTask extends Task {

    private $plugin, $boss, $eids, $level, $tick = 0, $cleaned = false;
    private $targets = [];

    const TOTAL_TICKS  = 60;
    const DAMAGE       = 4.7;
    const LOCK_RADIUS  = 12.0;
    const ORBIT_RADIUS = 4.5;

    public function __construct($plugin, NPCEntity $boss, array $eids, $level) {
        $this->plugin = $plugin;
        $this->boss   = $boss;
        $this->eids   = $eids;
        $this->level  = $level;
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed || $this->tick > self::TOTAL_TICKS) {
            $this->cleanup();
            return;
        }

        $bx = $this->boss->x;
        $by = $this->boss->y;
        $bz = $this->boss->z;

        $this->updateOrbits($bx, $by, $bz);
        $this->processTargets($bx, $by, $bz);
    }

    private function updateOrbits($bx, $by, $bz) {
        foreach ($this->eids as $i => $eid) {
            $ang = ($this->tick * 0.25) + ($i * M_PI / 3);
            $ox  = $bx + cos($ang) * self::ORBIT_RADIUS;
            $oy  = $by + 0.5;
            $oz  = $bz + sin($ang) * self::ORBIT_RADIUS;

            BlockEffects::sendMove($this->level, $eid, $ox, $oy, $oz, (int)($ang * 60));

            if ($this->tick % 2 === 0) {
                $this->level->addParticle(new DustParticle(
                    new Vector3($ox, $oy, $oz),
                    255, 255, 0
                ));
                $this->level->addParticle(new InstantEnchantParticle(new Vector3($ox, $oy, $oz)));
            }
        }

        if ($this->tick % 3 === 0) {
            for ($i = 0; $i < 8; $i++) {
                $a = ($i / 8) * M_PI * 2 + $this->tick * 0.2;
                $this->level->addParticle(new DustParticle(
                    new Vector3($bx + cos($a) * self::ORBIT_RADIUS, $by + 0.5, $bz + sin($a) * self::ORBIT_RADIUS),
                    255, 240, 0
                ));
            }
        }
    }

    private function processTargets($bx, $by, $bz) {
        $center = new Vector3($bx, $by, $bz);

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;

            if ($e->distance($center) <= self::LOCK_RADIUS) {
                $eid = $e->getId();

                if (!isset($this->targets[$eid])) {
                    $beid = BlockEffects::newEid();
                    BlockEffects::sendSpawn($this->level, $beid, 41, 0, $e->x, $e->y - 2, $e->z);
                    $this->targets[$eid] = [
                        "entity" => $e,
                        "beid"   => $beid,
                        "lockX"  => $e->x,
                        "lockY"  => $e->y,
                        "lockZ"  => $e->z,
                    ];
                }

                $target = $this->targets[$eid]["entity"];

                if (!$target->isAlive() || $target->closed) {
                    BlockEffects::sendRemove($this->targets[$eid]["beid"]);
                    unset($this->targets[$eid]);
                    continue;
                }

                $target->setMotion(new Vector3(0, 0, 0));
                $target->teleport(new Vector3(
                    $this->targets[$eid]["lockX"],
                    $this->targets[$eid]["lockY"],
                    $this->targets[$eid]["lockZ"]
                ));

                for ($h = 0; $h < 22; $h++) {
                    $pos = new Vector3($target->x, $target->y + ($h * 0.5), $target->z);
                    $this->level->addParticle(new DustParticle($pos, 255, 255, 0));
                    $this->level->addParticle(new InstantEnchantParticle($pos));

                    if ($h === 0) {
                        for ($r = 0; $r < 4; $r++) {
                            $sang = ($this->tick * 0.4) + ($r * M_PI / 2);
                            $this->level->addParticle(new DustParticle(
                                $pos->add(cos($sang) * 1.5, 0.1, sin($sang) * 1.5),
                                255, 240, 0
                            ));
                        }
                    }
                }

                if ($this->tick % 8 === 0) {
                    $target->attack(self::DAMAGE, new EntityDamageByEntityEvent(
                        $this->boss, $target, EntityDamageEvent::CAUSE_MAGIC, self::DAMAGE
                    ));
                    $this->level->addParticle(new HugeExplodeParticle($target->getPosition()->add(0, 1, 0)));
                }

                BlockEffects::sendMove(
                    $this->level,
                    $this->targets[$eid]["beid"],
                    $target->x,
                    $target->y - 1 + ($this->tick * 0.04),
                    $target->z,
                    $this->tick * 10
                );
            }
        }

        foreach ($this->targets as $eid => $data) {
            $e = $data["entity"];
            if ($e->distance($center) > self::LOCK_RADIUS || !$e->isAlive() || $e->closed) {
                BlockEffects::sendRemove($data["beid"]);
                unset($this->targets[$eid]);
            }
        }
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->eids as $eid) {
            BlockEffects::sendRemove($eid);
        }

        foreach ($this->targets as $t) {
            BlockEffects::sendRemove($t["beid"]);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenLightMurakumoTask extends Task {

    private $plugin, $boss, $spears, $level, $tick = 0, $cleaned = false;

    const TOTAL_TICKS  = 100;
    const DAMAGE       = 8.82;
    const FALL_SPEED   = 2.6;
    const IMPACT_RADIUS = 6.5;

    public function __construct($plugin, NPCEntity $boss, array $spears, $level) {
        $this->plugin = $plugin;
        $this->boss   = $boss;
        $this->spears = $spears;
        $this->level  = $level;
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if ($this->tick > self::TOTAL_TICKS || empty($this->spears)) {
            $this->cleanup();
            return;
        }

        foreach ($this->spears as $i => &$sp) {
            $sp["pos"]->y -= self::FALL_SPEED;
            BlockEffects::sendMove($this->level, $sp["eid"], $sp["pos"]->x, $sp["pos"]->y, $sp["pos"]->z, $this->tick * 15);

            for ($j = 0; $j < 6; $j++) {
                $this->level->addParticle(new DustParticle(
                    $sp["pos"]->add(0, $j * 0.7, 0),
                    255, 255, 0
                ));
            }

            $this->level->addParticle(new InstantEnchantParticle($sp["pos"]));

            if ($this->tick % 2 === 0) {
                $this->level->addParticle(new EnchantParticle($sp["pos"]->add(0, 1, 0)));
            }

            if ($sp["pos"]->y <= $this->level->getHighestBlockAt($sp["pos"]->x, $sp["pos"]->z) + 0.5) {
                $this->impact($sp["pos"]);
                BlockEffects::sendRemove($sp["eid"]);
                unset($this->spears[$i]);
            }
        }
        unset($sp);
    }

    private function impact($pos) {
        $this->level->addSound(new ExplodeSound($pos));
        $this->level->addParticle(new HugeExplodeParticle($pos));

        for ($i = -7; $i <= 7; $i++) {
            $this->level->addParticle(new DustParticle($pos->add($i, 0.2, 0), 255, 255, 0));
            $this->level->addParticle(new DustParticle($pos->add(0, 0.2, $i), 255, 255, 0));
            $this->level->addParticle(new InstantEnchantParticle($pos->add($i, mt_rand(0, 5), 0)));

            if (abs($i) % 2 === 0) {
                $this->level->addParticle(new EnchantParticle($pos->add($i, 0.5, $i)));
            }
        }

        for ($ring = 0; $ring < 3; $ring++) {
            $r = 2.0 + ($ring * 1.5);
            for ($a = 0; $a < 12; $a++) {
                $angle = ($a / 12) * M_PI * 2;
                $this->level->addParticle(new DustParticle(
                    $pos->add(cos($angle) * $r, 0.3, sin($angle) * $r),
                    255, 240, 0
                ));
            }
        }

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;

            if ($e->distance($pos) <= self::IMPACT_RADIUS) {
                $e->attack(self::DAMAGE, new EntityDamageByEntityEvent(
                    $this->boss, $e, EntityDamageEvent::CAUSE_MAGIC, self::DAMAGE
                ));
                $e->setMotion(new Vector3(0, 1.6, 0));
                $this->level->addParticle(new HugeExplodeParticle($e->getPosition()->add(0, 1, 0)));
            }
        }
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->spears as $sp) {
            BlockEffects::sendRemove($sp["eid"]);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenMagmaClawTask extends Task {

    private $plugin, $boss, $eids, $level, $tick = 0, $cleaned = false;
    private $targets = [], $dashDir;

    private $offsets = [
        [2.0, 0.0, 0.5], [2.0, 0.0, -0.5], [2.2, 0.5, 0.0], [2.2, -0.5, 0.0],
        [1.0, 0.0, 0.8], [1.0, 0.0, -0.8], [1.5, 0.5, 0.5], [1.5, 0.5, -0.5],
        [0.5, 0.0, 0.0], [1.2, -0.5, 0.0]
    ];

    const TOTAL_TICKS = 25;
    const DAMAGE      = 8.5;
    const DASH_SPEED  = 1.4;
    const GRAB_RADIUS = 5.2;

    public function __construct($plugin, NPCEntity $boss, array $eids, $level) {
        $this->plugin = $plugin;
        $this->boss   = $boss;
        $this->eids   = $eids;
        $this->level  = $level;
        $this->dashDir = $boss->getDirectionVector();
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed || $this->tick > self::TOTAL_TICKS) {
            $this->cleanup();
            return;
        }

        $this->boss->setMotion($this->dashDir->multiply(self::DASH_SPEED));

        $bx  = $this->boss->x;
        $by  = $this->boss->y;
        $bz  = $this->boss->z;
        $yaw = ($this->boss->yaw + 90) * M_PI / 180;

        $this->updateClaw($bx, $by, $bz, $yaw);
        $this->grabTargets($bx, $by, $bz, $yaw);

        $this->level->addParticle(new SmokeParticle(new Vector3($bx, $by + 0.5, $bz)));

        if ($this->tick === self::TOTAL_TICKS) {
            $this->explode($bx, $by, $bz);
        }
    }

    private function updateClaw($bx, $by, $bz, $yaw) {
        foreach ($this->eids as $k => $id) {
            $lx = $this->offsets[$k][0];
            $ly = $this->offsets[$k][1];
            $lz = $this->offsets[$k][2];

            $rx = $lx * cos($yaw) - $lz * sin($yaw);
            $rz = $lx * sin($yaw) + $lz * cos($yaw);

            BlockEffects::sendMove($this->level, $id, $bx + $rx, $by + 1 + $ly, $bz + $rz, 0);

            if ($this->tick % 3 === 0) {
                $this->level->addParticle(new FlameParticle(
                    new Vector3($bx + $rx, $by + 1 + $ly, $bz + $rz)
                ));
            }

            if ($this->tick % 5 === 0 && $k % 2 === 0) {
                $this->level->addParticle(new LavaDripParticle(
                    new Vector3($bx + $rx, $by + 1 + $ly, $bz + $rz)
                ));
            }
        }
    }

    private function grabTargets($bx, $by, $bz, $yaw) {
        $center = new Vector3($bx, $by, $bz);

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;

            if ($e->distance($center) <= self::GRAB_RADIUS) {
                if (!isset($this->targets[$e->getId()])) {
                    $this->targets[$e->getId()] = $e;
                }

                $e->setMotion(new Vector3(0, 0, 0));

                $tx = 2.6 * cos($yaw);
                $tz = 2.6 * sin($yaw);
                $e->teleport(new Vector3($bx + $tx, $by, $bz + $tz));

                if ($this->tick % 5 === 0) {
                    $this->level->addParticle(new FlameParticle($e->getPosition()->add(0, 1, 0)));
                    $this->level->addParticle(new CriticalParticle($e->getPosition()->add(0, 1.5, 0)));
                }
            }
        }
    }

    private function explode($bx, $by, $bz) {
        $pos = new Vector3($bx, $by, $bz);
        $this->level->addSound(new ExplodeSound($pos));
        $this->level->addParticle(new LargeExplodeParticle($pos));

        for ($i = 0; $i < 16; $i++) {
            $a = ($i / 16) * M_PI * 2;
            $r = mt_rand(10, 30) / 10.0;
            $this->level->addParticle(new FlameParticle(
                new Vector3($bx + cos($a) * $r, $by + mt_rand(0, 20) / 10.0, $bz + sin($a) * $r)
            ));
            if ($i % 4 === 0) {
                $this->level->addParticle(new TerrainParticle(
                    new Vector3($bx + cos($a) * $r, $by + 0.5, $bz + sin($a) * $r),
                    Block::get(49, 0)
                ));
            }
        }

        foreach ($this->targets as $e) {
            if ($e->isAlive() && !$e->closed) {
                $e->attack(self::DAMAGE, new EntityDamageByEntityEvent(
                    $this->boss, $e, EntityDamageEvent::CAUSE_MAGIC, self::DAMAGE
                ));
                $e->setMotion(new Vector3($this->dashDir->x * 1.8, 0.7, $this->dashDir->z * 1.8));
                $this->level->addParticle(new LargeExplodeParticle($e->getPosition()->add(0, 1, 0)));
            }
        }
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->eids as $id) {
            BlockEffects::sendRemove($id);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenMagmaGurenTask extends Task {

    private $plugin, $boss, $core, $shell, $level, $tick = 0, $cleaned = false;
    private $cx, $cy, $cz, $my;

    const TOTAL_TICKS  = 70;
    const DAMAGE       = 10.0;
    const FALL_SPEED   = 1.4;
    const EXPLODE_RADIUS = 9.0;

    public function __construct($plugin, NPCEntity $boss, $coreEid, array $shell, $level, $cx, $cy, $cz) {
        $this->plugin = $plugin;
        $this->boss   = $boss;
        $this->core   = $coreEid;
        $this->shell  = $shell;
        $this->level  = $level;
        $this->cx     = $cx;
        $this->cy     = $cy;
        $this->cz     = $cz;
        $this->my     = $cy + 30.0;
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed || $this->tick > self::TOTAL_TICKS) {
            $this->cleanup();
            return;
        }

        $this->my -= self::FALL_SPEED;

        BlockEffects::sendMove($this->level, $this->core, $this->cx, $this->my, $this->cz, $this->tick * 8);

        foreach ($this->shell as &$s) {
            $a = $s["a"] + $this->tick * 0.5;
            $ox = $this->cx + cos($a) * 3.0;
            $oy = $this->my + sin($this->tick * 0.5);
            $oz = $this->cz + sin($a) * 3.0;

            BlockEffects::sendMove($this->level, $s["eid"], $ox, $oy, $oz, $this->tick * 12);

            if ($this->tick % 2 === 0) {
                $pos = new Vector3($ox, $oy, $oz);
                $this->level->addParticle(new CriticalParticle($pos));
                $this->level->addParticle(new RedstoneParticle($pos));
            }
        }
        unset($s);

        if ($this->tick % 3 === 0) {
            $this->level->addParticle(new FlameParticle(new Vector3($this->cx, $this->my, $this->cz)));
            $this->level->addParticle(new LavaDripParticle(new Vector3($this->cx, $this->my, $this->cz)));
        }

        if ($this->my <= $this->cy + 0.5) {
            $this->explode();
            $this->cleanup();
        }
    }

    private function explode() {
        $pos = new Vector3($this->cx, $this->cy, $this->cz);
        $this->level->addSound(new ExplodeSound($pos));
        $this->level->addParticle(new LargeExplodeParticle($pos));

        for ($i = 0; $i < 20; $i++) {
            $a = ($i / 20) * M_PI * 2;
            $r = mt_rand(10, 50) / 10.0;
            $this->level->addParticle(new FlameParticle(
                new Vector3($this->cx + cos($a) * $r, $this->cy + mt_rand(0, 30) / 10.0, $this->cz + sin($a) * $r)
            ));
            $this->level->addParticle(new LavaDripParticle(
                new Vector3($this->cx + cos($a) * $r, $this->cy + mt_rand(10, 40) / 10.0, $this->cz + sin($a) * $r)
            ));

            if ($i % 4 === 0) {
                $this->level->addParticle(new TerrainParticle(
                    new Vector3($this->cx + cos($a) * $r, $this->cy + 0.5, $this->cz + sin($a) * $r),
                    Block::get(87, 0)
                ));
            }
        }

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;

            if ($e->distance($pos) <= self::EXPLODE_RADIUS) {
                $e->attack(self::DAMAGE, new EntityDamageByEntityEvent(
                    $this->boss, $e, EntityDamageEvent::CAUSE_MAGIC, self::DAMAGE
                ));

                $dx = $e->x - $this->cx;
                $dz = $e->z - $this->cz;
                $len = sqrt($dx * $dx + $dz * $dz);
                if ($len > 0) {
                    $e->setMotion(new Vector3(($dx / $len) * 0.5, 1.2, ($dz / $len) * 0.5));
                }

                $this->level->addParticle(new LargeExplodeParticle($e->getPosition()->add(0, 1, 0)));
            }
        }

        $puddleTask = new AwakenMagmaPuddleTask($this->plugin, $this->boss, $pos, $this->level);
        Server::getInstance()->getScheduler()->scheduleRepeatingTask($puddleTask, 1);
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        BlockEffects::sendRemove($this->core);

        foreach ($this->shell as $s) {
            BlockEffects::sendRemove($s["eid"]);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenMagmaPuddleTask extends Task {

    private $plugin, $boss, $pos, $level, $tick = 0, $cleaned = false;
    private $eids = [];

    const TOTAL_TICKS  = 100;
    const DAMAGE       = 1.2;
    const PUDDLE_RADIUS = 5.5;

    public function __construct($plugin, NPCEntity $boss, Vector3 $pos, $level) {
        $this->plugin = $plugin;
        $this->boss   = $boss;
        $this->pos    = $pos;
        $this->level  = $level;

        for ($i = 0; $i < 6; $i++) {
            $eid = BlockEffects::newEid();
            $a   = (2 * M_PI / 6) * $i;
            BlockEffects::sendSpawn($level, $eid, 159, 14,
                $pos->x + cos($a) * 2.5,
                $pos->y,
                $pos->z + sin($a) * 2.5
            );
            $this->eids[] = $eid;
        }
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if ($this->tick > self::TOTAL_TICKS) {
            $this->cleanup();
            return;
        }

        if ($this->tick % 10 === 0) {
            $this->level->addSound(new FizzSound($this->pos));

            foreach ($this->level->getEntities() as $e) {
                if ($e === $this->boss || !$e->isAlive()) continue;
                if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;

                if ($e->distance($this->pos) <= self::PUDDLE_RADIUS) {
                    $e->attack(self::DAMAGE, new EntityDamageByEntityEvent(
                        $this->boss, $e, EntityDamageEvent::CAUSE_MAGIC, self::DAMAGE
                    ));
                }
            }
        }

        $randX = mt_rand(-30, 30) / 10.0;
        $randZ = mt_rand(-30, 30) / 10.0;
        $pPos  = new Vector3($this->pos->x + $randX, $this->pos->y + 0.5, $this->pos->z + $randZ);

        if ($this->tick < 70) {
            $this->level->addParticle(new FlameParticle($pPos));
        } else {
            $this->level->addParticle(new WhiteSmokeParticle($pPos));
        }

        if ($this->tick % 4 === 0) {
            $this->level->addParticle(new LavaDripParticle($pPos));
        }
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->eids as $id) {
            BlockEffects::sendRemove($id);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenDarkVortexTask extends Task {

    private $plugin, $boss, $level, $tick = 0, $cleaned = false;
    private $attachedBlocks = [], $envDebris = [], $outerRing = [];
    private $angle = 0.0, $cx, $cy, $cz;

    const TOTAL_TICKS = 120;
    const DAMAGE      = 2.5;
    const PULL_RADIUS = 13.0;
    const ORBIT_INNER = 5.5;
    const ORBIT_OUTER = 6.5;

    public function __construct($plugin, NPCEntity $boss, $level) {
        $this->plugin = $plugin;
        $this->boss   = $boss;
        $this->level  = $level;
        $this->cx     = $boss->x;
        $this->cy     = $boss->y;
        $this->cz     = $boss->z;

        for ($i = 0; $i < 16; $i++) {
            $angle = (2 * M_PI / 16) * $i;
            $eid   = BlockEffects::newEid();
            BlockEffects::sendSpawn($level, $eid, 49, 0,
                $this->cx + cos($angle) * 9,
                $this->cy + 0.5,
                $this->cz + sin($angle) * 9
            );
            $this->outerRing[] = ["eid" => $eid, "angle" => (float)$angle];
        }
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed || $this->tick > self::TOTAL_TICKS) {
            $this->cleanup();
            return;
        }

        $this->boss->setMotion(new Vector3(0, 0, 0));
        $this->angle += 0.22;
        $this->cx = $this->boss->x;
        $this->cy = $this->boss->y;
        $this->cz = $this->boss->z;

        $this->updateOuterRing();
        $this->spawnVortexParticles();
        $this->processEntities();
        $this->processEnvironment();
    }

    private function updateOuterRing() {
        foreach ($this->outerRing as &$seg) {
            $seg["angle"] -= 0.08;
            $r = 9 - ($this->tick / self::TOTAL_TICKS) * 3;
            BlockEffects::sendMove(
                $this->level, $seg["eid"],
                $this->cx + cos($seg["angle"]) * $r,
                $this->cy + 0.5 + sin($seg["angle"] * 2) * 0.3,
                $this->cz + sin($seg["angle"]) * $r,
                (int)($seg["angle"] * 100)
            );
        }
        unset($seg);
    }

    private function spawnVortexParticles() {
        for ($i = 0; $i < 35; $i++) {
            $r = mt_rand(0, 90) / 10;
            $a = mt_rand(0, 628) / 100;
            $v = new Vector3(
                $this->cx + cos($a) * $r,
                $this->cy + mt_rand(0, 15) / 100,
                $this->cz + sin($a) * $r
            );
            $this->level->addParticle(new SmokeParticle($v));
            if ($i % 2 === 0) {
                $this->level->addParticle(new PortalParticle($v));
            }
            if ($i % 5 === 0) {
                $this->level->addParticle(new DustParticle($v, 30, 0, 50));
            }
        }

        for ($i = 0; $i < 6; $i++) {
            $a = $this->angle + ($i * M_PI / 3);
            $r = 4.0 + sin($this->tick * 0.1) * 1.5;
            $this->level->addParticle(new DustParticle(
                new Vector3($this->cx + cos($a) * $r, $this->cy + 1.0, $this->cz + sin($a) * $r),
                80, 0, 120
            ));
        }

        if ($this->tick % 8 === 0) {
            $this->level->addSound(new FizzSound(new Vector3($this->cx, $this->cy, $this->cz)));
        }
    }

    private function processEntities() {
        $center = new Vector3($this->cx, $this->cy, $this->cz);
        $currentEids = [];

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;

            $dist = $e->distance($center);
            if ($dist > self::PULL_RADIUS) continue;

            $eid = $e->getId();
            $currentEids[$eid] = true;

            if (!isset($this->attachedBlocks[$eid])) {
                $beid = BlockEffects::newEid();
                BlockEffects::sendSpawn($this->level, $beid, 95, 15, $e->x, $e->y + 1.2, $e->z);
                $this->attachedBlocks[$eid] = $beid;
            } else {
                BlockEffects::sendMove($this->level, $this->attachedBlocks[$eid], $e->x, $e->y + 0.9, $e->z);
            }

            for ($i = 0; $i < 4; $i++) {
                $this->level->addParticle(new DustParticle(
                    new Vector3($e->x + mt_rand(-3, 3) / 10.0, $e->y + 1, $e->z + mt_rand(-3, 3) / 10.0),
                    60, 0, 90
                ));
            }

            $dx = $this->cx - $e->x;
            $dz = $this->cz - $e->z;
            $len = sqrt($dx * $dx + $dz * $dz);
            $hoverY = $this->cy + 1.4;
            $motY = ($e->y < $hoverY) ? 0.25 : -0.18;

            if ($len > self::ORBIT_OUTER) {
                $pull = 0.05;
                $lSafe = max(0.01, $len);
                $e->setMotion(new Vector3(($dx / $lSafe) * $pull, $motY, ($dz / $lSafe) * $pull));
            } elseif ($len < self::ORBIT_INNER) {
                $repel = ($len < 1.0) ? 1.8 : 0.7;
                $lSafe = max(0.01, $len);
                $vx = ($len > 0.1) ? -($dx / $lSafe) : (mt_rand(-10, 10) / 10.0);
                $vz = ($len > 0.1) ? -($dz / $lSafe) : (mt_rand(-10, 10) / 10.0);
                $e->setMotion(new Vector3($vx * $repel, $motY, $vz * $repel));
            } else {
                $e->setMotion(new Vector3(0, $motY, 0));
            }

            if ($this->tick % 20 === 0) {
                $e->attack(self::DAMAGE, new EntityDamageByEntityEvent(
                    $this->boss, $e, EntityDamageEvent::CAUSE_MAGIC, self::DAMAGE
                ));
                $this->level->addParticle(new CriticalParticle($e->getPosition()->add(0, 1, 0)));
            }
        }

        foreach ($this->attachedBlocks as $tid => $beid) {
            if (!isset($currentEids[$tid])) {
                BlockEffects::sendRemove($beid);
                unset($this->attachedBlocks[$tid]);
            }
        }
    }

    private function processEnvironment() {
        if ($this->tick % 6 === 0) {
            $sx = $this->cx + (mt_rand(-140, 140) / 10);
            $sz = $this->cz + (mt_rand(-140, 140) / 10);
            $dx = $sx - $this->cx;
            $dz = $sz - $this->cz;
            if (sqrt($dx * $dx + $dz * $dz) < 5) return;

            $eid = BlockEffects::newEid();
            $floorY = (int)$this->cy;
            while ($floorY > 0) {
                $bId = $this->level->getBlockIdAt((int)$sx, $floorY, (int)$sz);
                if ($bId !== 0 && $bId !== 8 && $bId !== 9) break;
                $floorY--;
            }
            $bId = $this->level->getBlockIdAt((int)$sx, $floorY, (int)$sz);
            $bDm = $this->level->getBlockDataAt((int)$sx, $floorY, (int)$sz);
            if ($bId === 0) {
                $bId = 49;
                $bDm = 0;
            }

            BlockEffects::sendSpawn($this->level, $eid, $bId, $bDm, $sx, (float)$floorY, $sz);
            $this->envDebris[$eid] = [
                "x" => $sx, "y" => (float)$floorY, "z" => $sz,
                "vy" => 0.5, "life" => 55, "stage" => 0,
                "accel" => 0.08, "baseY" => (float)$this->cy
            ];
        }

        foreach ($this->envDebris as $eid => &$data) {
            $data["life"]--;
            $dx = $this->cx - $data["x"];
            $dz = $this->cz - $data["z"];
            $len = sqrt($dx * $dx + $dz * $dz);

            if ($data["stage"] === 0) {
                $data["y"] += $data["vy"];
                $data["vy"] -= 0.035;
                if ($data["y"] >= $data["baseY"] + 2.2) $data["stage"] = 1;
            } else {
                if ($len > 0.5) {
                    $data["accel"] += 0.18;
                    $ps = min(2.0, $data["accel"]);
                    $data["x"] += ($dx / $len) * $ps;
                    $data["z"] += ($dz / $len) * $ps;
                    $data["y"] -= 0.08;
                }
            }

            if ($data["life"] <= 0 || $data["y"] < $data["baseY"] - 3.5 || $len < 1.0) {
                BlockEffects::sendRemove($eid);
                unset($this->envDebris[$eid]);
            } else {
                BlockEffects::sendMove($this->level, $eid,
                    $data["x"], $data["y"], $data["z"],
                    $data["life"] * 30, $data["life"] * 18
                );
                $this->level->addParticle(new DustParticle(
                    new Vector3($data["x"], $data["y"], $data["z"]), 40, 0, 60
                ));
            }
        }
        unset($data);
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->outerRing as $seg) {
            BlockEffects::sendRemove($seg["eid"]);
        }
        foreach ($this->attachedBlocks as $eid) {
            BlockEffects::sendRemove($eid);
        }
        foreach ($this->envDebris as $eid => $d) {
            BlockEffects::sendRemove($eid);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenDarkStarTask extends Task {

    private $plugin, $boss, $level, $tick = 0, $cleaned = false;
    private $chargeTicks = 45, $launched = false, $launchTick = 0;
    private $x, $y, $z;
    private $starEids = [], $auraEids = [];
    private $currentRadius = 0.1;
    private $targetPos = null;
    private $dirX, $dirY, $dirZ;

    const DAMAGE = 7.5;

    public function __construct($plugin, NPCEntity $boss, $level) {
        $this->plugin = $plugin;
        $this->boss   = $boss;
        $this->level  = $level;

        for ($i = 0; $i < 10; $i++) {
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($level, $eid, 49, 0, $boss->x, $boss->y + 1.5, $boss->z);
            $this->starEids[] = $eid;
        }

        for ($i = 0; $i < 6; $i++) {
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($level, $eid, 95, 15, $boss->x, $boss->y + 1.5, $boss->z);
            $this->auraEids[] = $eid;
        }
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed) {
            $this->cleanup();
            return;
        }

        if (!$this->launched) {
            $this->runCharge();
        } else {
            $this->runLaunch();
        }
    }

    private function runCharge() {
        $this->boss->setMotion(new Vector3(0, 0, 0));

        $prog = min(1.0, $this->tick / $this->chargeTicks);
        $this->x = $this->boss->x;
        $this->y = $this->boss->y + 1.5 + ($prog * 3.5);
        $this->z = $this->boss->z;
        $this->currentRadius = min(3.2, 0.1 + $this->tick * 0.1);

        foreach ($this->starEids as $i => $eid) {
            $phi = acos(-1 + (2 * $i) / 10);
            $theta = sqrt(10 * M_PI) * $phi + ($this->tick * 0.4);
            $bx = $this->x + $this->currentRadius * sin($phi) * cos($theta);
            $by = $this->y + $this->currentRadius * cos($phi);
            $bz = $this->z + $this->currentRadius * sin($phi) * sin($theta);
            BlockEffects::sendMove($this->level, $eid, $bx, $by, $bz);
            if ($this->tick % 2 === 0) {
                $this->level->addParticle(new SmokeParticle(new Vector3($bx, $by, $bz)));
                $this->level->addParticle(new DustParticle(new Vector3($bx, $by, $bz), 80, 0, 120));
            }
        }

        foreach ($this->auraEids as $i => $eid) {
            $a = ($this->tick * 0.18) + ($i * M_PI / 3);
            $r = $this->currentRadius + 0.8;
            BlockEffects::sendMove($this->level, $eid,
                $this->x + cos($a) * $r, $this->y, $this->z + sin($a) * $r,
                (int)($a * 100)
            );
        }

        for ($i = 0; $i < 8; $i++) {
            $a = mt_rand(0, 628) / 100;
            $r = mt_rand(0, (int)($this->currentRadius * 10)) / 10.0;
            $this->level->addParticle(new PortalParticle(new Vector3(
                $this->x + cos($a) * $r, $this->y + mt_rand(0, 30) / 10.0, $this->z + sin($a) * $r
            )));
        }

        if ($this->tick >= $this->chargeTicks) {
            $this->initLaunch();
        }
    }

    private function initLaunch() {
        $lookDir = $this->boss->getDirectionVector()->normalize();
        $this->targetPos = $this->boss->add($lookDir->x * 50, $lookDir->y * 50, $lookDir->z * 50);

        $diff = $this->targetPos->subtract(new Vector3($this->x, $this->y, $this->z));
        $dist = $diff->length();
        if ($dist > 0) {
            $spd = 3.8;
            $this->dirX = ($diff->x / $dist) * $spd;
            $this->dirY = ($diff->y / $dist) * $spd;
            $this->dirZ = ($diff->z / $dist) * $spd;
        }

        $this->launched = true;
        $this->level->addSound(new BlazeShootSound(new Vector3($this->x, $this->y, $this->z)));
    }

    private function runLaunch() {
        $this->launchTick++;
        $this->applyMagneticGuidance();

        $this->x += $this->dirX;
        $this->y += $this->dirY;
        $this->z += $this->dirZ;

        foreach ($this->starEids as $i => $eid) {
            $phi = acos(-1 + (2 * $i) / 10);
            $theta = sqrt(10 * M_PI) * $phi + ($this->launchTick * 0.7);
            $rad = 1.1;
            BlockEffects::sendMove($this->level, $eid,
                $this->x + $rad * sin($phi) * cos($theta),
                $this->y + $rad * cos($phi),
                $this->z + $rad * sin($phi) * sin($theta),
                $this->launchTick * 60
            );
        }

        foreach ($this->auraEids as $i => $eid) {
            $a = ($this->launchTick * 0.35) + ($i * M_PI / 3);
            BlockEffects::sendMove($this->level, $eid,
                $this->x + cos($a) * 1.8, $this->y, $this->z + sin($a) * 1.8,
                (int)($a * 100)
            );
        }

        for ($i = 0; $i < 8; $i++) {
            $this->level->addParticle(new SmokeParticle(new Vector3(
                $this->x + mt_rand(-15, 15) / 10.0,
                $this->y + mt_rand(-15, 15) / 10.0,
                $this->z + mt_rand(-15, 15) / 10.0
            )));
            if ($i % 2 === 0) {
                $this->level->addParticle(new PortalParticle(new Vector3(
                    $this->x + mt_rand(-10, 10) / 10.0,
                    $this->y + mt_rand(-10, 10) / 10.0,
                    $this->z + mt_rand(-10, 10) / 10.0
                )));
            }
        }

        if ($this->launchTick > 4 && ($this->checkCollision() || $this->launchTick > 130)) {
            $this->triggerVoidImpact();
        }
    }

    private function applyMagneticGuidance() {
        $currentPos = new Vector3($this->x, $this->y, $this->z);
        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e->distance($currentPos) < 6.5) {
                $targetDir = $e->getPosition()->add(0, 1, 0)->subtract($currentPos)->normalize();
                $this->dirX = ($this->dirX * 0.75) + ($targetDir->x * 0.85);
                $this->dirY = ($this->dirY * 0.75) + ($targetDir->y * 0.85);
                $this->dirZ = ($this->dirZ * 0.75) + ($targetDir->z * 0.85);
                break;
            }
        }
    }

    private function checkCollision() {
        $pos = new Vector3($this->x, $this->y, $this->z);
        $b = $this->level->getBlock($pos);
        if ($b->getId() !== 0 && $b->getId() !== 8 && $b->getId() !== 9) return true;
        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e->distance($pos) <= 4.0) return true;
        }
        return false;
    }

    private function triggerVoidImpact() {
        $groundY = $this->y;
        while ($groundY > 0) {
            if ($this->level->getBlockIdAt((int)$this->x, (int)$groundY - 1, (int)$this->z) !== 0) break;
            $groundY--;
        }
        $pos = new Vector3($this->x, $groundY, $this->z);

        $found = BlockEffects::scanBlocks($this->level, $pos->x, $pos->y, $pos->z, 7, 12);
        $debris = [];
        foreach ($found as $i => $b) {
            $deid = BlockEffects::newEid();
            $angle = ($i / max(1, count($found))) * M_PI * 2;
            BlockEffects::sendSpawn($this->level, $deid, $b["id"], $b["damage"], $pos->x, $pos->y + 0.5, $pos->z);
            $debris[$deid] = [
                "eid" => $deid,
                "x" => $pos->x, "y" => $pos->y + 0.5, "z" => $pos->z,
                "vx" => cos($angle) * 1.6, "vy" => 1.0, "vz" => sin($angle) * 1.6,
                "life" => 50, "tick" => 0
            ];
        }

        Server::getInstance()->getScheduler()->scheduleRepeatingTask(
            new AwakenDarkImpactDebrisTask($this->plugin, $this->level, $debris),
            1
        );

        Server::getInstance()->getScheduler()->scheduleRepeatingTask(
            new AwakenVoidSingularityTask($this->plugin, $this->boss, $pos, self::DAMAGE, $this->level),
            1
        );

        $this->level->addParticle(new HugeExplodeParticle($pos));
        $this->level->addParticle(new LargeExplodeParticle($pos));
        $this->level->addSound(new ExplodeSound($pos));
        $this->cleanup();
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->starEids as $eid) {
            BlockEffects::sendRemove($eid);
        }
        foreach ($this->auraEids as $eid) {
            BlockEffects::sendRemove($eid);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenDarkImpactDebrisTask extends Task {

    private $plugin, $level, $debris;

    public function __construct($plugin, $level, array $debris) {
        $this->plugin = $plugin;
        $this->level = $level;
        $this->debris = $debris;
    }

    public function onRun($currentTick) {
        if (empty($this->debris)) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $toRemove = BlockEffects::tickDebris($this->debris, $this->level, -55, 0.08, 0.90);
        foreach ($toRemove as $eid) {
            unset($this->debris[$eid]);
        }
    }
}

class AwakenVoidSingularityTask extends Task {

    private $plugin, $boss, $pos, $damage, $level, $tick = 0, $cleaned = false;
    private $eids = [];

    const TOTAL_TICKS = 70;

    public function __construct($plugin, NPCEntity $boss, Vector3 $pos, $damage, $level) {
        $this->plugin = $plugin;
        $this->boss = $boss;
        $this->pos = $pos;
        $this->damage = $damage;
        $this->level = $level;

        for ($i = 0; $i < 8; $i++) {
            $eid = BlockEffects::newEid();
            $angle = (2 * M_PI / 8) * $i;
            BlockEffects::sendSpawn($level, $eid, 49, 0,
                $pos->x + cos($angle) * 3, $pos->y + 0.5, $pos->z + sin($angle) * 3
            );
            $this->eids[] = ["eid" => $eid, "angle" => (float)$angle];
        }
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if ($this->tick > self::TOTAL_TICKS) {
            $this->cleanup();
            return;
        }

        foreach ($this->eids as &$seg) {
            $seg["angle"] -= 0.15;
            $r = 3.0 - ($this->tick / self::TOTAL_TICKS) * 2.5;
            BlockEffects::sendMove($this->level, $seg["eid"],
                $this->pos->x + cos($seg["angle"]) * $r,
                $this->pos->y + 0.5 + sin($seg["angle"] * 2) * 0.3,
                $this->pos->z + sin($seg["angle"]) * $r,
                (int)($seg["angle"] * 100)
            );
        }
        unset($seg);

        for ($i = 0; $i < 20; $i++) {
            $a = mt_rand(0, 628) / 100;
            $r = mt_rand(0, 90) / 10;
            $this->level->addParticle(new SmokeParticle(new Vector3(
                $this->pos->x + cos($a) * $r,
                $this->pos->y + mt_rand(0, 30) / 10.0,
                $this->pos->z + sin($a) * $r
            )));
            if ($i % 3 === 0) {
                $this->level->addParticle(new PortalParticle(new Vector3(
                    $this->pos->x + cos($a) * $r,
                    $this->pos->y + mt_rand(0, 30) / 10.0,
                    $this->pos->z + sin($a) * $r
                )));
            }
            if ($i % 5 === 0) {
                $this->level->addParticle(new DustParticle(new Vector3(
                    $this->pos->x + cos($a) * $r,
                    $this->pos->y + mt_rand(0, 30) / 10.0,
                    $this->pos->z + sin($a) * $r
                ), 60, 0, 100));
            }
        }

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e->distance($this->pos) > 10) continue;

            $e->setMotion(new Vector3(0, 0, 0));

            if ($this->tick % 10 === 0) {
                $dmg = $this->damage * 0.30;
                $e->attack($dmg, new EntityDamageByEntityEvent(
                    $this->boss, $e, EntityDamageEvent::CAUSE_MAGIC, $dmg
                ));
                $this->level->addParticle(new CriticalParticle($e->getPosition()->add(0, 1, 0)));
            }
        }

        if ($this->tick % 12 === 0) {
            $this->level->addSound(new FizzSound($this->pos));
        }
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->eids as $seg) {
            BlockEffects::sendRemove($seg["eid"]);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenRedHawkTask extends Task {

    private $plugin, $boss, $level, $tick = 0, $cleaned = false;
    private $windupEids = [], $phase = 0, $dashDir;

    const WINDUP_TICKS = 12;
    const DASH_TICKS   = 8;
    const TOTAL_TICKS  = 25;
    const DAMAGE       = 13.5;
    const DASH_SPEED   = 1.8;

    public function __construct($plugin, NPCEntity $boss, $level) {
        $this->plugin = $plugin;
        $this->boss   = $boss;
        $this->level  = $level;
        $this->dashDir = $boss->getDirectionVector();

        for ($i = 0; $i < 8; $i++) {
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($level, $eid, 87, 0,
                $boss->x + mt_rand(-10, 10) / 10.0,
                $boss->y + mt_rand(5, 15) / 10.0,
                $boss->z + mt_rand(-10, 10) / 10.0
            );
            $this->windupEids[] = $eid;
        }
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed || $this->tick > self::TOTAL_TICKS) {
            $this->cleanup();
            return;
        }

        if ($this->tick <= self::WINDUP_TICKS) {
            $this->runWindup();
        } elseif ($this->tick <= self::WINDUP_TICKS + self::DASH_TICKS) {
            if ($this->phase === 0) {
                $this->phase = 1;
                foreach ($this->windupEids as $eid) {
                    BlockEffects::sendRemove($eid);
                }
                $this->windupEids = [];
            }
            $this->runDash();
        } else {
            if ($this->phase === 1) {
                $this->phase = 2;
                $this->triggerImpact();
            }
        }
    }

    private function runWindup() {
        $bx = $this->boss->x;
        $by = $this->boss->y;
        $bz = $this->boss->z;

        foreach ($this->windupEids as $i => $eid) {
            $a = (2 * M_PI / count($this->windupEids)) * $i + ($this->tick * 0.3);
            $r = 1.5 + sin($this->tick * 0.5) * 0.5;
            BlockEffects::sendMove($this->level, $eid,
                $bx + cos($a) * $r,
                $by + 1 + ($this->tick * 0.05),
                $bz + sin($a) * $r,
                $this->tick * 25
            );
            $this->level->addParticle(new FlameParticle(new Vector3(
                $bx + cos($a) * $r,
                $by + 1,
                $bz + sin($a) * $r
            )));
        }

        if ($this->tick % 3 === 0) {
            for ($i = 0; $i < 4; $i++) {
                $this->level->addParticle(new CriticalParticle(new Vector3(
                    $bx + mt_rand(-10, 10) / 10.0,
                    $by + 1,
                    $bz + mt_rand(-10, 10) / 10.0
                )));
            }
        }
    }

    private function runDash() {
        $this->boss->setMotion(new Vector3(
            $this->dashDir->x * self::DASH_SPEED,
            0.35,
            $this->dashDir->z * self::DASH_SPEED
        ));

        for ($i = 0; $i < 3; $i++) {
            $this->level->addParticle(new FlameParticle(new Vector3(
                $this->boss->x + mt_rand(-10, 10) / 10.0,
                $this->boss->y + mt_rand(0, 15) / 10.0,
                $this->boss->z + mt_rand(-10, 10) / 10.0
            )));
        }
    }

    private function triggerImpact() {
        $center = new Vector3($this->boss->x, $this->boss->y, $this->boss->z);

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e->distance($center) > 4.5) continue;

            $e->attack(self::DAMAGE, new EntityDamageByEntityEvent(
                $this->boss, $e, EntityDamageEvent::CAUSE_MAGIC, self::DAMAGE
            ));
            $e->setMotion(new Vector3(
                $this->dashDir->x * 2.2,
                0.6,
                $this->dashDir->z * 2.2
            ));
        }

        for ($i = 0; $i < 20; $i++) {
            $this->level->addParticle(new FlameParticle(new Vector3(
                $this->boss->x + mt_rand(-20, 20) / 10.0,
                $this->boss->y + mt_rand(0, 20) / 10.0,
                $this->boss->z + mt_rand(-20, 20) / 10.0
            )));
            if ($i % 2 === 0) {
                $this->level->addParticle(new CriticalParticle(new Vector3(
                    $this->boss->x + mt_rand(-15, 15) / 10.0,
                    $this->boss->y + 1,
                    $this->boss->z + mt_rand(-15, 15) / 10.0
                )));
            }
        }

        $ringEids = [];
        for ($i = 0; $i < 12; $i++) {
            $angle = (2 * M_PI / 12) * $i;
            $eid   = BlockEffects::newEid();
            BlockEffects::sendSpawn($this->level, $eid, 87, 0,
                $this->boss->x + cos($angle) * 3,
                $this->boss->y,
                $this->boss->z + sin($angle) * 3
            );
            $ringEids[] = $eid;
        }

        Server::getInstance()->getScheduler()->scheduleDelayedTask(
            new AwakenRedHawkRingCleanupTask($this->plugin, $ringEids),
            25
        );

        $this->level->addParticle(new HugeExplodeParticle($center));
        $this->level->addSound(new ExplodeSound($center));
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->windupEids as $eid) {
            BlockEffects::sendRemove($eid);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenRedHawkRingCleanupTask extends Task {

    private $plugin, $eids;

    public function __construct($plugin, array $eids) {
        $this->plugin = $plugin;
        $this->eids   = $eids;
    }

    public function onRun($currentTick) {
        foreach ($this->eids as $eid) {
            BlockEffects::sendRemove($eid);
        }
    }
}

class AwakenJetGatlingTask extends Task {

    private $plugin, $boss, $level, $tick = 0, $cleaned = false;
    private $shellEids = [], $hitLog = [];
    private $projectileTasks = [];

    const TOTAL_TICKS = 70;
    const DAMAGE      = 5.5;

    public function __construct($plugin, NPCEntity $boss, $level) {
        $this->plugin = $plugin;
        $this->boss   = $boss;
        $this->level  = $level;

        for ($i = 0; $i < 10; $i++) {
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($level, $eid, 1, 0,
                $boss->x, $boss->y + 1, $boss->z
            );
            $this->shellEids[] = ["eid" => $eid, "angle" => (2 * M_PI / 10) * $i];
        }
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed || $this->tick > self::TOTAL_TICKS) {
            $this->cleanup();
            return;
        }

        $bx = $this->boss->x;
        $by = $this->boss->y;
        $bz = $this->boss->z;

        foreach ($this->shellEids as &$seg) {
            $seg["angle"] += 0.45;
            $r = 2.0;
            BlockEffects::sendMove($this->level, $seg["eid"],
                $bx + cos($seg["angle"]) * $r,
                $by + 1.0 + sin($seg["angle"] * 2) * 0.4,
                $bz + sin($seg["angle"]) * $r,
                (int)($seg["angle"] * 100)
            );
        }
        unset($seg);

        if ($this->tick % 3 === 0) {
            $dir = $this->boss->getDirectionVector();
            $shotX = $bx + $dir->x * 2;
            $shotY = $by + 1;
            $shotZ = $bz + $dir->z * 2;
            $shotEid = BlockEffects::newEid();
            BlockEffects::sendSpawn($this->level, $shotEid, 1, 0, $shotX, $shotY, $shotZ);

            $projectile = new AwakenJetGatlingProjectileTask(
                $this->plugin, $this->boss, self::DAMAGE, $shotEid, $dir, $this->level, $this->hitLog
            );
            Server::getInstance()->getScheduler()->scheduleRepeatingTask($projectile, 1);
            $this->projectileTasks[] = $projectile->getTaskId();
        }

        for ($i = 0; $i < 4; $i++) {
            $this->level->addParticle(new CriticalParticle(new Vector3(
                $bx + mt_rand(-20, 20) / 10.0, $by + 1, $bz + mt_rand(-20, 20) / 10.0
            )));
        }
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->shellEids as $seg) {
            BlockEffects::sendRemove($seg["eid"]);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenJetGatlingProjectileTask extends Task {

    private $plugin, $boss, $damage, $eid, $dir, $level, $hitLog;
    private $sx, $sy, $sz, $tick = 0, $cleaned = false;

    const MAX_TICKS = 15;
    const SPEED     = 2.0;

    public function __construct($plugin, NPCEntity $boss, $damage, $eid, Vector3 $dir, $level, &$hitLog) {
        $this->plugin  = $plugin;
        $this->boss    = $boss;
        $this->damage  = $damage;
        $this->eid     = $eid;
        $this->dir     = $dir;
        $this->level   = $level;
        $this->hitLog  = &$hitLog;
        $this->sx      = $boss->x + $dir->x * 2;
        $this->sy      = $boss->y + 1;
        $this->sz      = $boss->z + $dir->z * 2;
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if ($this->tick > self::MAX_TICKS) {
            $this->cleanup();
            return;
        }

        $this->sx += $this->dir->x * self::SPEED;
        $this->sy += $this->dir->y * 0.5;
        $this->sz += $this->dir->z * self::SPEED;

        BlockEffects::sendMove($this->level, $this->eid, $this->sx, $this->sy, $this->sz, $this->tick * 20);
        $this->level->addParticle(new CriticalParticle(new Vector3($this->sx, $this->sy, $this->sz)));
        $this->level->addParticle(new FlameParticle(new Vector3($this->sx, $this->sy, $this->sz)));

        $pos = new Vector3($this->sx, $this->sy, $this->sz);

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;

            $key = $this->eid . "_" . $e->getId();
            if (isset($this->hitLog[$key])) continue;

            if ($e->distance($pos) <= 2.0) {
                $e->attack($this->damage, new EntityDamageByEntityEvent(
                    $this->boss, $e, EntityDamageEvent::CAUSE_MAGIC, $this->damage
                ));
                $this->hitLog[$key] = true;
                $this->level->addParticle(new ExplodeParticle($e->getPosition()->add(0, 1, 0)));
                $this->cleanup();
                return;
            }
        }

        $b = $this->level->getBlock($pos);
        if ($b->getId() !== 0 && $b->getId() !== 8 && $b->getId() !== 9) {
            $this->cleanup();
            return;
        }
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        BlockEffects::sendRemove($this->eid);
        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenLightningDragonTask extends Task {

    private $plugin, $boss, $dmg, $segs, $cloudPos, $impactPos, $level;
    private $tick = 0, $postTick = 0, $impacted = false, $cleaned = false;
    private $stunned = [], $scatterVelocities = [];
    private $headX, $headY, $headZ, $dirX, $dirY, $dirZ, $speed = 3.5;

    public function __construct($plugin, NPCEntity $boss, $dmg, array $segs, Vector3 $cloudPos, Vector3 $impactPos, $level) {
        $this->plugin    = $plugin;
        $this->boss      = $boss;
        $this->dmg       = $dmg;
        $this->segs      = $segs;
        $this->cloudPos  = $cloudPos;
        $this->impactPos = $impactPos;
        $this->level     = $level;
        $this->headX     = $cloudPos->x;
        $this->headY     = $cloudPos->y;
        $this->headZ     = $cloudPos->z;

        $dx  = $impactPos->x - $cloudPos->x;
        $dy  = $impactPos->y - $cloudPos->y;
        $dz  = $impactPos->z - $cloudPos->z;
        $len = sqrt($dx * $dx + $dy * $dy + $dz * $dz);
        $this->dirX = ($len > 0) ? $dx / $len : 0;
        $this->dirY = ($len > 0) ? $dy / $len : 0;
        $this->dirZ = ($len > 0) ? $dz / $len : 0;

        $level->addSound(new ExplodeSound($cloudPos));
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed) {
            $this->cleanup();
            return;
        }

        if ($this->impacted) {
            $this->postTick++;

            if ($this->postTick === 1) {
                $this->initScatter();
            } elseif ($this->postTick > 1) {
                if ($this->tickScatter() && $this->postTick > 10) {
                    $this->cleanup();
                    return;
                }
            }

            foreach ($this->stunned as $id => $d) {
                if ($d["e"]->isAlive() && !$d["e"]->closed) {
                    $d["e"]->setMotion(new Vector3(0, 0, 0));
                    $d["e"]->teleport($d["p"]);
                    if ($this->postTick === 49) {
                        $d["e"]->setMotion(new Vector3(0, 3.0, 0));
                    }
                }
            }

            if ($this->postTick % 3 === 0) {
                $cx = $this->impactPos->x;
                $cz = $this->impactPos->z;
                for ($i = 0; $i < 4; $i++) {
                    $this->level->addParticle(new ExplodeParticle(new Vector3(
                        $cx + mt_rand(-40, 40) / 10,
                        $this->impactPos->y + mt_rand(0, 30) / 10,
                        $cz + mt_rand(-40, 40) / 10
                    )));
                    $this->level->addParticle(new PortalParticle(new Vector3(
                        $cx + mt_rand(-30, 30) / 10,
                        $this->impactPos->y + mt_rand(0, 50) / 10,
                        $cz + mt_rand(-30, 30) / 10
                    )));
                }
            }

            if ($this->postTick > 52) {
                $this->cleanup();
            }
            return;
        }

        if ($this->tick <= 20) {
            $this->summonPhase();
            return;
        }

        $dist = sqrt(
            ($this->headX - $this->impactPos->x) ** 2 +
            ($this->headY - $this->impactPos->y) ** 2 +
            ($this->headZ - $this->impactPos->z) ** 2
        );

        if ($dist <= $this->speed) {
            $this->headX    = $this->impactPos->x;
            $this->headY    = $this->impactPos->y;
            $this->headZ    = $this->impactPos->z;
            $this->impacted = true;
            $this->impact();
            return;
        }

        $this->headX += $this->dirX * $this->speed;
        $this->headY += $this->dirY * $this->speed;
        $this->headZ += $this->dirZ * $this->speed;

        $this->moveBody();

        if ($this->tick % 2 === 0) {
            for ($i = 0; $i < 6; $i++) {
                $this->level->addParticle(new PortalParticle(new Vector3(
                    $this->headX + mt_rand(-20, 20) / 10,
                    $this->headY + mt_rand(-10, 10) / 10,
                    $this->headZ + mt_rand(-20, 20) / 10
                )));
                $this->level->addParticle(new EnchantmentTableParticle(new Vector3(
                    $this->headX - $this->dirX * ($i * 2.0),
                    $this->headY - $this->dirY * ($i * 2.0),
                    $this->headZ - $this->dirZ * ($i * 2.0)
                )));
            }
        }

        if ($this->tick % 4 === 0) {
            $pk      = new AddEntityPacket();
            $pk->eid = BlockEffects::newEid();
            $pk->type = 93;
            $pk->x   = $this->headX;
            $pk->y   = $this->headY;
            $pk->z   = $this->headZ;
            foreach ($this->level->getPlayers() as $pl) {
                $pl->dataPacket($pk);
            }
        }
    }

    private function summonPhase() {
        $cp    = $this->cloudPos;
        $prog  = $this->tick / 20;
        $pulse = sin($this->tick * 0.5) * 1.5;

        foreach ($this->segs as $i => $eid) {
            $baseAng = ($i / count($this->segs)) * M_PI * 2;
            $ang     = $baseAng + $this->tick * 0.18;
            $rad     = 3.5 + $pulse + ($i % 3) * 0.8;
            $bx      = $cp->x + cos($ang) * $rad;
            $by      = $cp->y + sin($ang * 0.4) * 1.2 + ($prog * 1.5);
            $bz      = $cp->z + sin($ang) * $rad;

            BlockEffects::sendMove($this->level, $eid, $bx, $by, $bz, 0);

            if ($this->tick % 2 === 0) {
                $this->level->addParticle(new PortalParticle(new Vector3(
                    $bx + mt_rand(-15, 15) / 10,
                    $by + mt_rand(-10, 10) / 10,
                    $bz + mt_rand(-15, 15) / 10
                )));
                $this->level->addParticle(new WhiteSmokeParticle(new Vector3(
                    $bx + mt_rand(-12, 12) / 10,
                    $by - mt_rand(5, 25) / 10,
                    $bz + mt_rand(-12, 12) / 10
                )));
            }
        }
    }

    private function moveBody() {
        $travelTick = $this->tick - 20;
        foreach ($this->segs as $i => $eid) {
            $lag  = $i * 1.8;
            $bx   = $this->headX - $this->dirX * $lag;
            $by   = $this->headY - $this->dirY * $lag;
            $bz   = $this->headZ - $this->dirZ * $lag;
            $wave = sin($travelTick * 0.35 + $i * 0.6) * (0.9 + $i * 0.12);
            $bx  += -$this->dirZ * $wave;
            $bz  += $this->dirX * $wave;
            $by  += cos($travelTick * 0.25 + $i * 0.5) * 0.4;
            BlockEffects::sendMove($this->level, $eid, $bx, $by, $bz, 0);
        }
    }

    private function impact() {
        $this->level->addSound(new ExplodeSound($this->impactPos));
        $this->level->addSound(new FizzSound($this->impactPos));

        $gy = $this->level->getHighestBlockAt(
            (int)floor($this->impactPos->x),
            (int)floor($this->impactPos->z)
        );

        for ($i = 0; $i < 12; $i++) {
            $pk       = new AddEntityPacket();
            $pk->eid  = BlockEffects::newEid();
            $pk->type = 93;
            $pk->x    = $this->impactPos->x + mt_rand(-80, 80) / 10;
            $pk->y    = $gy;
            $pk->z    = $this->impactPos->z + mt_rand(-80, 80) / 10;
            foreach ($this->level->getPlayers() as $pl) {
                $pl->dataPacket($pk);
            }
        }

        for ($i = 0; $i < 18; $i++) {
            $this->level->addParticle(new ExplodeParticle(new Vector3(
                $this->impactPos->x + mt_rand(-50, 50) / 10,
                $this->impactPos->y + mt_rand(0, 40) / 10,
                $this->impactPos->z + mt_rand(-50, 50) / 10
            )));
            $this->level->addParticle(new HugeExplodeParticle(new Vector3(
                $this->impactPos->x + mt_rand(-30, 30) / 10,
                $this->impactPos->y + mt_rand(0, 20) / 10,
                $this->impactPos->z + mt_rand(-30, 30) / 10
            )));
        }

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e->distance($this->impactPos) > 16) continue;

            $e->attack($this->dmg, new EntityDamageByEntityEvent(
                $this->boss, $e, EntityDamageEvent::CAUSE_MAGIC, $this->dmg
            ));
            $this->stunned[$e->getId()] = ["e" => $e, "p" => $e->getPosition()];
        }
    }

    private function initScatter() {
        $this->level->addSound(new ExplodeSound($this->impactPos));
        $this->scatterVelocities = [];

        foreach ($this->segs as $i => $eid) {
            $ang = mt_rand(0, 628) / 100;
            $spd = mt_rand(30, 70) / 100;
            $this->scatterVelocities[$i] = [
                "x" => cos($ang) * $spd, "y" => mt_rand(20, 50) / 100,
                "z" => sin($ang) * $spd, "px" => $this->headX,
                "py" => $this->headY, "pz" => $this->headZ
            ];
        }
    }

    private function tickScatter() {
        $gravity = 0.045;
        $allDone = true;

        foreach ($this->segs as $i => $eid) {
            if (!isset($this->scatterVelocities[$i])) continue;
            $v = &$this->scatterVelocities[$i];
            $v["px"] += $v["x"];
            $v["py"] += $v["y"];
            $v["pz"] += $v["z"];
            $v["y"]  -= $gravity;
            $groundY = $this->level->getHighestBlockAt((int)floor($v["px"]), (int)floor($v["pz"]));
            if ($v["py"] > $groundY) {
                BlockEffects::sendMove($this->level, $eid, $v["px"], $v["py"], $v["pz"], 0);
                $allDone = false;
            } else {
                BlockEffects::sendRemove($eid);
                unset($this->scatterVelocities[$i]);
                unset($this->segs[$i]);
            }
        }

        return $allDone;
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->segs as $eid) {
            BlockEffects::sendRemove($eid);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class AwakenLightningJudgementTask extends Task {

    private $plugin, $boss, $dmg, $pos, $level, $eids, $cloudY;
    private $tick = 0, $postTick = 0, $cleaned = false, $finalDone = false;
    private $stunned = [], $scatterVelocities = [];

    public function __construct($plugin, NPCEntity $boss, $dmg, Vector3 $pos, $level, array $eids, $cloudY) {
        $this->plugin  = $plugin;
        $this->boss    = $boss;
        $this->dmg     = $dmg;
        $this->pos     = $pos;
        $this->level   = $level;
        $this->eids    = $eids;
        $this->cloudY  = $cloudY;

        $level->addSound(new ExplodeSound($pos));
        $level->addSound(new FizzSound($pos));
    }

    public function onRun($currentTick) {
        if ($this->cleaned) return;

        $this->tick++;

        if (!$this->boss->isAlive() || $this->boss->closed) {
            $this->cleanup();
            return;
        }

        $cx = $this->pos->x;
        $cz = $this->pos->z;

        if ($this->finalDone) {
            $this->postTick++;

            if ($this->postTick <= 14) {
                $this->moveBeam($cx, $cz);

                foreach ($this->level->getEntities() as $e) {
                    if ($e === $this->boss || !$e->isAlive()) continue;
                    if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
                    if ($e->distance($this->pos) <= 13) {
                        $dx  = $cx - $e->x;
                        $dz  = $cz - $e->z;
                        $len = sqrt($dx * $dx + $dz * $dz);
                        if ($len > 0) {
                            $e->setMotion(new Vector3($dx / $len * 0.5, 0.1, $dz / $len * 0.5));
                        }
                    }
                }
            } elseif ($this->postTick === 15) {
                $this->initScatterAndDamage($cx, $cz);
            } elseif ($this->postTick > 15) {
                if ($this->tickScatter() && $this->postTick > 20) {
                    $this->cleanup();
                    return;
                }
            }

            foreach ($this->stunned as $id => $d) {
                if ($d["e"]->isAlive() && !$d["e"]->closed) {
                    $d["e"]->setMotion(new Vector3(0, 0, 0));
                    $d["e"]->teleport($d["p"]);
                    if ($this->postTick === 49) {
                        $d["e"]->setMotion(new Vector3(0, 2.3, 0));
                    }
                }
            }

            if ($this->postTick % 4 === 0 && $this->postTick < 50) {
                for ($i = 0; $i < 4; $i++) {
                    $this->level->addParticle(new WhiteSmokeParticle(new Vector3(
                        $cx + mt_rand(-35, 35) / 10,
                        $this->pos->y + mt_rand(0, 30) / 10,
                        $cz + mt_rand(-35, 35) / 10
                    )));
                    $this->level->addParticle(new PortalParticle(new Vector3(
                        $cx + mt_rand(-25, 25) / 10,
                        $this->pos->y + mt_rand(0, 35) / 10,
                        $cz + mt_rand(-25, 25) / 10
                    )));
                }
            }

            if ($this->postTick > 52) {
                $this->cleanup();
            }
            return;
        }

        if ($this->tick <= 24) {
            $r1 = 18 - (($this->tick / 24) * 12);
            $r2 = 13 - (($this->tick / 24) * 9);
            $r3 = 8  - (($this->tick / 24) * 6);
            $this->moveCloud($cx, $cz, $r1, $r2, $r3);
            return;
        }

        if ($this->tick <= 84) {
            $this->moveCloud($cx, $cz, 6, 4, 2);
            if ($this->tick % 6 === 0) {
                $strikePos = new Vector3(
                    $cx + mt_rand(-35, 35) / 10,
                    $this->pos->y,
                    $cz + mt_rand(-35, 35) / 10
                );
                $this->level->addSound(new ExplodeSound($strikePos));
                $this->barrageDamage($strikePos, $cx, $cz);
            }
            return;
        }

        if (!$this->finalDone) {
            $this->finalDone = true;
            $this->level->addSound(new FizzSound($this->pos));
            $this->level->addSound(new ExplodeSound($this->pos));
        }
    }

    private function moveCloud($cx, $cz, $r1, $r2, $r3) {
        $spin1 = $this->tick * 0.32;
        $spin2 = -$this->tick * 0.38;
        $spin3 = $this->tick * 0.45;

        for ($i = 0; $i < 12; $i++) {
            $ang = ($i / 12) * M_PI * 2 + $spin1;
            BlockEffects::sendMove($this->level, $this->eids[$i],
                $cx + cos($ang) * $r1,
                $this->cloudY + sin($spin1 + $i) * 1.2,
                $cz + sin($ang) * $r1, 0
            );
        }
        for ($i = 12; $i < 24; $i++) {
            $ang = (($i - 12) / 12) * M_PI * 2 + $spin2;
            BlockEffects::sendMove($this->level, $this->eids[$i],
                $cx + cos($ang) * $r2,
                $this->cloudY - 3 + cos($spin2 + $i) * 1.2,
                $cz + sin($ang) * $r2, 0
            );
        }
        for ($i = 24; $i < 36; $i++) {
            $ang = (($i - 24) / 12) * M_PI * 2 + $spin3;
            BlockEffects::sendMove($this->level, $this->eids[$i],
                $cx + cos($ang) * $r3,
                $this->cloudY - 6 + sin($spin3 + $i) * 1.0,
                $cz + sin($ang) * $r3, 0
            );
        }

        for ($i = 0; $i < 2; $i++) {
            $this->level->addParticle(new PortalParticle(new Vector3(
                $cx + mt_rand(-50, 50) / 10,
                $this->cloudY + mt_rand(-15, 15) / 10,
                $cz + mt_rand(-50, 50) / 10
            )));
            $this->level->addParticle(new EnchantmentTableParticle(new Vector3(
                $cx + mt_rand(-40, 40) / 10,
                $this->cloudY - mt_rand(0, 30) / 10,
                $cz + mt_rand(-40, 40) / 10
            )));
            $this->level->addParticle(new WhiteSmokeParticle(new Vector3(
                $cx + mt_rand(-50, 50) / 10,
                $this->cloudY - mt_rand(10, 70) / 10,
                $cz + mt_rand(-50, 50) / 10
            )));
        }
    }

    private function moveBeam($cx, $cz) {
        $height = $this->cloudY - $this->pos->y;
        $spin   = $this->tick * 0.8;

        foreach ($this->eids as $i => $eid) {
            $f     = ($i % 18) / 17;
            $layer = (int)($i / 18);
            $ang   = $spin + ($i * 0.7);
            $rad   = ($layer === 0) ? 0.35 : 0.75;
            $y     = $this->pos->y + ($height * $f);
            BlockEffects::sendMove($this->level, $eid,
                $cx + cos($ang) * $rad, $y, $cz + sin($ang) * $rad, 0
            );
        }
    }

    private function initScatterAndDamage($cx, $cz) {
        $this->level->addSound(new ExplodeSound($this->pos));

        for ($i = 0; $i < 18; $i++) {
            $this->level->addParticle(new ExplodeParticle(new Vector3(
                $cx + mt_rand(-40, 40) / 10,
                $this->pos->y + mt_rand(0, 50) / 10,
                $cz + mt_rand(-40, 40) / 10
            )));
            $this->level->addParticle(new InstantEnchantParticle(new Vector3(
                $cx + mt_rand(-30, 30) / 10,
                $this->pos->y + mt_rand(0, 90) / 10,
                $cz + mt_rand(-30, 30) / 10
            )));
        }

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e->distance($this->pos) <= 13) {
                $e->attack($this->dmg * 2.6, new EntityDamageByEntityEvent(
                    $this->boss, $e, EntityDamageEvent::CAUSE_MAGIC, $this->dmg * 2.6
                ));
                $this->stunned[$e->getId()] = ["e" => $e, "p" => $e->getPosition()];
            }
        }

        $this->scatterVelocities = [];
        foreach ($this->eids as $i => $eid) {
            $ang = mt_rand(0, 628) / 100;
            $spd = mt_rand(25, 65) / 100;
            $this->scatterVelocities[$i] = [
                "x" => cos($ang) * $spd, "y" => mt_rand(18, 45) / 100,
                "z" => sin($ang) * $spd, "px" => $cx,
                "py" => $this->pos->y + 1.0, "pz" => $cz
            ];
        }
    }

    private function tickScatter() {
        $gravity = 0.045;
        $allDone = true;

        foreach ($this->eids as $i => $eid) {
            if (!isset($this->scatterVelocities[$i])) continue;
            $v = &$this->scatterVelocities[$i];
            $v["px"] += $v["x"];
            $v["py"] += $v["y"];
            $v["pz"] += $v["z"];
            $v["y"]  -= $gravity;
            $groundY = $this->level->getHighestBlockAt((int)floor($v["px"]), (int)floor($v["pz"]));
            if ($v["py"] > $groundY) {
                BlockEffects::sendMove($this->level, $eid, $v["px"], $v["py"], $v["pz"], 0);
                $allDone = false;
            } else {
                BlockEffects::sendRemove($eid);
                unset($this->scatterVelocities[$i]);
                unset($this->eids[$i]);
            }
        }

        return $allDone;
    }

    private function barrageDamage(Vector3 $strikePos, $cx, $cz) {
        $pk       = new AddEntityPacket();
        $pk->eid  = BlockEffects::newEid();
        $pk->type = 93;
        $pk->x    = $strikePos->x;
        $pk->y    = $this->level->getHighestBlockAt((int)floor($strikePos->x), (int)floor($strikePos->z));
        $pk->z    = $strikePos->z;
        foreach ($this->level->getPlayers() as $pl) {
            $pl->dataPacket($pk);
        }

        for ($i = 0; $i < 5; $i++) {
            $this->level->addParticle(new PortalParticle(new Vector3(
                $strikePos->x + mt_rand(-15, 15) / 10,
                $strikePos->y + mt_rand(0, 30) / 10,
                $strikePos->z + mt_rand(-15, 15) / 10
            )));
            $this->level->addParticle(new InstantEnchantParticle(new Vector3(
                $strikePos->x + mt_rand(-10, 10) / 10,
                $strikePos->y + mt_rand(0, 40) / 10,
                $strikePos->z + mt_rand(-10, 10) / 10
            )));
        }

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->boss || !$e->isAlive()) continue;
            if (!($e instanceof Player || $e instanceof NPCEntity || $e instanceof FactoryEntity)) continue;
            if ($e->distance($this->pos) > 13) continue;

            $dx  = $cx - $e->x;
            $dz  = $cz - $e->z;
            $len = sqrt($dx * $dx + $dz * $dz);
            if ($len > 0) {
                $e->setMotion(new Vector3($dx / $len * 0.45, 0.08, $dz / $len * 0.45));
            }
            $e->attack($this->dmg * 0.22, new EntityDamageByEntityEvent(
                $this->boss, $e, EntityDamageEvent::CAUSE_MAGIC, $this->dmg * 0.22
            ));
        }
    }

    private function cleanup() {
        if ($this->cleaned) return;
        $this->cleaned = true;

        foreach ($this->eids as $eid) {
            BlockEffects::sendRemove($eid);
        }

        Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}