<?php

namespace OnePieceRaid\Awaken;

use pocketmine\scheduler\Task;
use OnePieceRaid\Main;

class AwakenStartCountdownTask extends Task {

    private $plugin;
    private $instanceKey;

    public function __construct(Main $plugin, $instanceKey) {
        $this->plugin      = $plugin;
        $this->instanceKey = $instanceKey;
    }

    public function onRun($currentTick) {
        $am   = $this->plugin->getAwakenManager();
        $inst = $am->getInstanceData($this->instanceKey);

        if ($inst === null) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }

        $done = $am->tickCountdown($this->instanceKey);
        if ($done) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
        }
    }
}
