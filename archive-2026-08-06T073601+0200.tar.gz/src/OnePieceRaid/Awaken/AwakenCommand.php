<?php

namespace OnePieceRaid\Awaken;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use OnePieceRaid\Main;

class AwakenCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct(
            "awaken",
            "Awaken Raid system",
            "<create|setworld|setroundspawn|setbossspawn|setjoinzone|removejoinzone|setspawn|setprice|buy|list|info>",
            []
        );
        $this->plugin = $plugin;
        $this->setPermission("op");
    }

    public function execute(CommandSender $sender, $label, array $args) {
        $am = $this->plugin->getAwakenManager();

        if (empty($args)) {
            $this->sendHelp($sender);
            return true;
        }

        $sub = strtolower(array_shift($args));

        switch ($sub) {

            case "create":
                if (!$sender->isOp()) { $sender->sendMessage("§cNo permission."); return true; }
                if (empty($args)) { $sender->sendMessage("§cUsage: /awaken create <key>"); return true; }
                $key = strtolower($args[0]);
                if ($am->createRaid($key)) {
                    $sender->sendMessage("§a[AWAKEN] Raid §f" . $key . "§a created.");
                } else {
                    $sender->sendMessage("§c[AWAKEN] Raid §f" . $key . "§c already exists.");
                }
                break;

            case "setworld":
                if (!$sender->isOp()) { $sender->sendMessage("§cNo permission."); return true; }
                if (count($args) < 2) { $sender->sendMessage("§cUsage: /awaken setworld <key> <worldname>"); return true; }
                $key   = strtolower($args[0]);
                $world = $args[1];
                if (!$am->raidExists($key)) { $sender->sendMessage("§c[AWAKEN] Raid not found."); return true; }
                $server = $this->plugin->getServer();
                if (!$server->isLevelLoaded($world) && !$server->loadLevel($world)) {
                    $sender->sendMessage("§c[AWAKEN] World §f" . $world . "§c does not exist or failed to load.");
                    return true;
                }
                $am->setWorld($key, $world);
                $sender->sendMessage("§a[AWAKEN] Template world for §f" . $key . "§a set to §f" . $world . "§a.");
                break;

            case "setroundspawn":
                if (!$sender->isOp()) { $sender->sendMessage("§cNo permission."); return true; }
                if (!($sender instanceof Player)) { $sender->sendMessage("§cIn-game only."); return true; }
                if (count($args) < 2) { $sender->sendMessage("§cUsage: /awaken setroundspawn <key> <round>"); return true; }
                $key   = strtolower($args[0]);
                $round = (int)$args[1];
                if (!$am->raidExists($key)) { $sender->sendMessage("§c[AWAKEN] Raid not found."); return true; }
                if ($round < 1 || $round > 5) { $sender->sendMessage("§cRound must be 1-5."); return true; }
                $pos   = $sender->getPosition();
                $world = $pos->getLevel()->getFolderName();
                $am->setRoundSpawn($key, $round, $pos->x, $pos->y, $pos->z, $world);
                $sender->sendMessage("§a[AWAKEN] Round §f" . $round . "§a spawn set for §f" . $key . "§a at §f" . (int)$pos->x . "/" . (int)$pos->y . "/" . (int)$pos->z . "§a.");
                break;

            case "setbossspawn":
                if (!$sender->isOp()) { $sender->sendMessage("§cNo permission."); return true; }
                if (!($sender instanceof Player)) { $sender->sendMessage("§cIn-game only."); return true; }
                if (empty($args)) { $sender->sendMessage("§cUsage: /awaken setbossspawn <key>"); return true; }
                $key = strtolower($args[0]);
                if (!$am->raidExists($key)) { $sender->sendMessage("§c[AWAKEN] Raid not found."); return true; }
                $pos   = $sender->getPosition();
                $world = $pos->getLevel()->getFolderName();
                $am->setBossSpawn($key, $pos->x, $pos->y, $pos->z, $world);
                $sender->sendMessage("§a[AWAKEN] Boss spawn set for §f" . $key . "§a at §f" . (int)$pos->x . "/" . (int)$pos->y . "/" . (int)$pos->z . "§a.");
                break;

case "setjoinzone":
    if (!$sender->isOp()) { $sender->sendMessage("§cNo permission."); return true; }
    if (!($sender instanceof Player)) { $sender->sendMessage("§cIn-game only."); return true; }
    if (empty($args)) { $sender->sendMessage("§cUsage: /awaken setjoinzone <number>"); return true; }
    $number = (int)$args[0];
    $pos = $sender->getPosition();
    $world = $pos->getLevel()->getFolderName();
    $am->setJoinZone($number, $pos->x, $pos->y, $pos->z, $world);
    $sender->sendMessage("§a[AWAKEN] Join zone §f#" . $number . " §a set at §f" . (int)$pos->x . "/" . (int)$pos->y . "/" . (int)$pos->z . " §ain §f" . $world . "§a.");
    break;

case "removejoinzone":
    if (!$sender->isOp()) { $sender->sendMessage("§cNo permission."); return true; }
    if (empty($args)) { $sender->sendMessage("§cUsage: /awaken removejoinzone <number>"); return true; }
    $number = (int)$args[0];
    if ($am->removeJoinZone($number)) {
        $sender->sendMessage("§a[AWAKEN] Join zone §f#" . $number . " §aremoved.");
    } else {
        $sender->sendMessage("§c[AWAKEN] Join zone §f#" . $number . " §cdoes not exist.");
    }
    break;

            case "setspawn":
                if (!$sender->isOp()) { $sender->sendMessage("§cNo permission."); return true; }
                if (!($sender instanceof Player)) { $sender->sendMessage("§cIn-game only."); return true; }
                $pos   = $sender->getPosition();
                $world = $pos->getLevel()->getFolderName();
                $am->setAwakenSpawn($pos->x, $pos->y, $pos->z, $world);
                $sender->sendMessage("§a[AWAKEN] Awakening reward spawn set at §f" . (int)$pos->x . "/" . (int)$pos->y . "/" . (int)$pos->z . " §ain §f" . $world . "§a.");
                break;

            case "setprice":
                if (!$sender->isOp()) { $sender->sendMessage("§cNo permission."); return true; }
                if (count($args) < 3) { $sender->sendMessage("§cUsage: /awaken setprice <key> <ability1|ability2> <price>"); return true; }
                $key     = strtolower($args[0]);
                $ability = strtolower($args[1]);
                $price   = (int)$args[2];
                if (!$am->raidExists($key)) { $sender->sendMessage("§c[AWAKEN] Raid not found."); return true; }
                if ($ability !== "ability1" && $ability !== "ability2") {
                    $sender->sendMessage("§cAbility must be §fability1§c or §fability2§c.");
                    return true;
                }
                if ($price < 0) { $sender->sendMessage("§cPrice cannot be negative."); return true; }
                $am->setPrice($key, $ability, $price);
                $sender->sendMessage("§a[AWAKEN] Price for §f" . $key . " " . $ability . "§a set to §f" . number_format($price) . " Berry§a.");
                break;

            case "buy":
                if (!($sender instanceof Player)) { $sender->sendMessage("§cIn-game only."); return true; }
                if (empty($args)) { $sender->sendMessage("§cUsage: /awaken buy <key> [fruit]"); return true; }
                $key       = strtolower($args[0]);
                $useFruit  = isset($args[1]) && strtolower($args[1]) === "fruit";
                $am->buyTicket($sender, $key, $useFruit);
                break;

            case "list":
                $raids = $am->getAllRaids();
                if (empty($raids)) { $sender->sendMessage("§c[AWAKEN] No awaken raids configured."); return true; }
                $sender->sendMessage("§b§l[AWAKEN RAIDS]");
                foreach ($raids as $key => $data) {
                    if ($key === "awaken_spawn") continue;
                    $worldStr   = $data["world"] ?? "§cNot set";
                    $rounds     = count($data["round_spawns"] ?? []);
                    $hasBoss    = ($data["boss_spawn"] !== null) ? "§aYes" : "§cNo";
                    $hasJoin    = ($data["join_zone"] !== null) ? "§aYes" : "§cNo";
                    $sender->sendMessage("§e" . $key . " §8| §7World: §f" . $worldStr . " §8| §7Rounds: §f" . $rounds . "/5 §8| §7Boss: " . $hasBoss . " §8| §7Join Zone: " . $hasJoin);
                }
                break;

case "region":
    if (!$sender->isOp()) { $sender->sendMessage("§cNo permission."); return true; }
    if (!($sender instanceof Player)) { $sender->sendMessage("§cIn-game only."); return true; }
    if (count($args) < 2) { $sender->sendMessage("§cUsage: /awaken region <key> <1|2>"); return true; }
    $key = strtolower($args[0]);
    $corner = (int)$args[1];
    if ($corner !== 1 && $corner !== 2) { $sender->sendMessage("§cCorner must be 1 or 2."); return true; }
    if (!$am->raidExists($key)) { $sender->sendMessage("§c[AWAKEN] Raid not found."); return true; }
    $pos = $sender->getPosition();
    $world = $pos->getLevel()->getFolderName();
    $am->setRegion($key, $corner, $pos->x, $pos->y, $pos->z, $world);
    $sender->sendMessage("§a[AWAKEN] Region corner §f" . $corner . "§a set for §f" . $key . "§a at §f" . (int)$pos->x . "/" . (int)$pos->y . "/" . (int)$pos->z . "§a.");
    break;

            case "info":
                if (empty($args)) { $sender->sendMessage("§cUsage: /awaken info <key>"); return true; }
                $key  = strtolower($args[0]);
                $data = $am->getRaid($key);
                if ($data === null) { $sender->sendMessage("§c[AWAKEN] Raid not found."); return true; }
                $sender->sendMessage("§b§l[AWAKEN: " . strtoupper($key) . "]");
                $sender->sendMessage("§7World: §f" . ($data["world"] ?? "Not set"));
                $sender->sendMessage("§7Round Spawns: §f" . count($data["round_spawns"] ?? []) . "/5");
                $sender->sendMessage("§7Boss Spawn: §f" . ($data["boss_spawn"] !== null ? "Set" : "Not set"));
                $sender->sendMessage("§7Join Zones: §f" . count($am->getAllJoinZones()) . " §7configured globally");
                $sender->sendMessage("§7Ability 1 Price: §f" . number_format($data["price_ability1"] ?? 500000) . " Berry");
                $sender->sendMessage("§7Ability 2 Price: §f" . number_format($data["price_ability2"] ?? 1000000) . " Berry");

                $instances = $am->getAllInstances();
                $active    = 0;
                foreach ($instances as $inst) {
                    if ($inst["raid_key"] === $key) $active++;
                }
                $sender->sendMessage("§7Active instances: §f" . $active);
                break;

            default:
                $this->sendHelp($sender);
        }

        return true;
    }

    private function sendHelp(CommandSender $sender) {
        $sender->sendMessage("§b§l[AWAKEN RAID COMMANDS]");
        if ($sender->isOp()) {
            $sender->sendMessage("§f/awaken create <key>                     §7Create awaken raid");
            $sender->sendMessage("§f/awaken setworld <key> <world>           §7Set template world");
            $sender->sendMessage("§f/awaken setroundspawn <key> <1-5>        §7Set round center spawn");
            $sender->sendMessage("§f/awaken setbossspawn <key>               §7Set boss spawn");
            $sender->sendMessage("§f/awaken setjoinzone <key>                §7Set player join zone");
            $sender->sendMessage("§f/awaken setspawn                         §7Set awakening reward area");
            $sender->sendMessage("§f/awaken setprice <key> <ability1|2> <n>  §7Set unlock price");
            $sender->sendMessage("§f/awaken list                             §7List all awaken raids");
            $sender->sendMessage("§f/awaken info <key>                       §7Detailed info");
            $sender->sendMessage("§f/awaken setjoinzone <number>          §7Set 3x3 join area");
            $sender->sendMessage("§f/awaken removejoinzone <number>       §7Remove join area");
            $sender->sendMessage("§f/awaken region <key> <1|2> §7Set raid region corners");
        }
        $sender->sendMessage("§f/awaken buy <key>          §7Buy raid ticket (500k Berry)");
        $sender->sendMessage("§f/awaken buy <key> fruit    §7Pay with a devil fruit item");
    }
}
