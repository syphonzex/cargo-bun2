<?php

namespace OnePieceRaid\Raid;

use pocketmine\scheduler\Task;
use OnePieceRaid\Main;

class RaidExpireTask extends Task {

    private $plugin;
    private $raidKey;

    public function __construct(Main $plugin, $raidKey) {
        $this->plugin  = $plugin;
        $this->raidKey = $raidKey;
    }

    public function onRun($currentTick) {
        $rm = $this->plugin->getRaidManager();
        if (!$rm->isActive($this->raidKey)) return;
        $rm->resolveRaid($this->raidKey, false);
    }
}
