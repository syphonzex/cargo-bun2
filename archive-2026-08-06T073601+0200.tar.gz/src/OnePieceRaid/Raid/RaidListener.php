<?php

namespace OnePieceRaid\Raid;

use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\Player;
use OnePiece\NPC\NPCEntity;
use OnePieceRaid\Main;

class RaidListener implements Listener {

    private $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $plugin->getServer()->getPluginManager()->registerEvents($this, $plugin);
    }

    /**
     * @priority HIGH
     * @ignoreCancelled false
     */
    public function onEntityDamage(EntityDamageEvent $event) {
        if (!($event instanceof EntityDamageByEntityEvent)) return;

        $entity  = $event->getEntity();
        $damager = $event->getDamager();

        if (!($entity instanceof NPCEntity)) return;
        if (!$this->plugin->getRaidManager()->isRaidNpc($entity->npcId)) return;

        if (!($damager instanceof Player)) return;

        $key = $this->plugin->getRaidManager()->getRaidKeyFromNpcId($entity->npcId);
        if ($key === null || !$this->plugin->getRaidManager()->isActive($key)) return;

        $this->plugin->getRaidManager()->recordDamage($key, $damager->getName(), $event->getFinalDamage());
    }

    /**
     * @priority HIGHEST
     * @ignoreCancelled false
     */
    public function onEntityDeath(EntityDeathEvent $event) {
        $entity = $event->getEntity();

        if (!($entity instanceof NPCEntity)) return;
        if (!$this->plugin->getRaidManager()->isRaidNpc($entity->npcId)) return;

        $key = $this->plugin->getRaidManager()->getRaidKeyFromNpcId($entity->npcId);
        if ($key === null) return;

        $this->plugin->getRaidManager()->onPirateDeath($key);
    }
}