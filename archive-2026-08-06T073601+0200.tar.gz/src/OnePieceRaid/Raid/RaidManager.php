<?php

namespace OnePieceRaid\Raid;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\entity\Entity;
use pocketmine\math\Vector3;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\LargeExplodeParticle;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ShortTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\utils\Config;
use OnePiece\NPC\NPCEntity;
use OnePieceRaid\Main;
use OnePieceRaid\Raid\RaidExpireTask;
use OnePieceRaid\Raid\RaidStartTask;
use OnePieceRaid\Raid\RaidWaveTask;

class RaidManager {

    private $plugin;
    private $config;
    private $raids     = [];
    private $active    = [];
    private $resolving = [];

    const RARITY_WEIGHTS = [
        "common"    => 5500,
        "rare"      => 2000,
        "legendary" => 100,
        "mythical"  => 10,
        "god"  => 1,
    ];

    const SPAWN_RADIUS    = 6;
    const WAVE_DELAY_TICKS = 100;
    const NPC_ID_PREFIX   = "raid_";

    // New constants for NPC levels
    const RAID_NPC_LEVEL_MIN = 300;
    const RAID_NPC_LEVEL_MAX = 350;
    const RAID_BOSS_LEVEL    = 400;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->config = new Config($plugin->getDataFolder() . "raids.yml", Config::YAML);
        $this->raids  = $this->config->getAll();
    }

    public function saveAll() {
        $this->config->setAll($this->raids);
        $this->config->save();
    }

    public function createRaid($name) {
        $key = strtolower($name);
        if (isset($this->raids[$key])) return false;
        $this->raids[$key] = [
            "name"         => $name,
            "pos"          => null,
            "level"        => null,
            "start_time"   => 3600,
            "duration"     => 600,
            "waves"        => 3,
            "per_wave"     => 5,
            "npc_level"    => 15, // This will largely be overridden by the new constants
            "npc_category" => "commander",
        ];
        $this->saveAll();
        return true;
    }

    public function raidExists($name)    { return isset($this->raids[strtolower($name)]); }
    public function getRaid($name)       { return $this->raids[strtolower($name)] ?? null; }
    public function getAllRaids()        { return $this->raids; }
    public function isActive($key)       { return isset($this->active[strtolower($key)]); }
    public function getActiveData($key)  { return $this->active[strtolower($key)] ?? null; }

    public function setPos($name, $x, $y, $z, $level) {
        $key = strtolower($name);
        if (!isset($this->raids[$key])) return false;
        $this->raids[$key]["pos"]   = ["x" => (int)$x, "y" => (int)$y, "z" => (int)$z];
        $this->raids[$key]["level"] = $level;
        $this->saveAll();
        return true;
    }

    public function setStartTime($name, $seconds) {
        $key = strtolower($name);
        if (!isset($this->raids[$key])) return false;
        $this->raids[$key]["start_time"] = (int)$seconds;
        $this->saveAll();
        return true;
    }

    public function setDuration($name, $seconds) {
        $key = strtolower($name);
        if (!isset($this->raids[$key])) return false;
        $this->raids[$key]["duration"] = (int)$seconds;
        $this->saveAll();
        return true;
    }

    public function setWaves($name, $waves) {
        $key = strtolower($name);
        if (!isset($this->raids[$key])) return false;
        $this->raids[$key]["waves"] = max(1, (int)$waves);
        $this->saveAll();
        return true;
    }

    public function setPerWave($name, $count) {
        $key = strtolower($name);
        if (!isset($this->raids[$key])) return false;
        $this->raids[$key]["per_wave"] = max(1, (int)$count);
        $this->saveAll();
        return true;
    }

    public function deleteRaid($name) {
        $key = strtolower($name);
        if (!isset($this->raids[$key])) return false;
        if (isset($this->active[$key])) $this->forceEnd($key);
        unset($this->raids[$key]);
        $this->saveAll();
        return true;
    }

    public function startRaid($key) {
        $key  = strtolower($key);
        $data = $this->raids[$key] ?? null;
        if ($data === null || $data["pos"] === null) return false;
        if (isset($this->active[$key])) return false;

        $fruitId = $this->rollFruit();
        if ($fruitId === null) return false;

        $this->active[$key] = [
            "name"             => $data["name"],
            "fruit_id"         => $fruitId,
            "damage_log"       => [],
            "current_wave"     => 0,
            "spawned_in_wave"  => 0,
            "total_waves"      => (int)$data["waves"],
            "per_wave"         => (int)$data["per_wave"],
            "npc_level"        => (int)($data["npc_level"] ?? 15), // Kept for reference but dynamically overwritten now
            "npc_category"     => $data["npc_category"] ?? "commander",
            "entity_ids"       => [],
            "alive_count"      => 0,
            "pos"              => $data["pos"],
            "level"            => $data["level"],
            "duration"         => (int)$data["duration"],
        ];

        unset($this->resolving[$key]);

        $this->broadcast("§fAn unusual group of pirates seem to enter sea castle..");
        $this->spawnStartParticles($key);

        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
            new RaidExpireTask($this->plugin, $key),
            $data["duration"] * 20
        );

        $this->scheduleNextWave($key);
        return true;
    }

    public function scheduleNextWave($key) {
        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
            new RaidWaveTask($this->plugin, $key),
            self::WAVE_DELAY_TICKS
        );
    }

    public function spawnWave($key) {
        if (!isset($this->active[$key])) return;
        if (isset($this->resolving[$key])) return;

        if ($this->active[$key]["current_wave"] < $this->active[$key]["total_waves"]) {
            $this->active[$key]["current_wave"]++;
            $this->active[$key]["spawned_in_wave"] = 0;
            $this->broadcast("§cThe pirates are raiding sea castle!");
        }

        $this->spawnSingleNpc($key);
    }

    private function spawnSingleNpc($key) {
        if (!isset($this->active[$key])) return;

        $data = &$this->active[$key];
        $data["spawned_in_wave"]++;
        
        $wave     = $data["current_wave"];
        $total    = $data["total_waves"];
        $perWave  = $data["per_wave"];
        $index    = $data["spawned_in_wave"];
        $pos      = $data["pos"];
        $lvlName  = $data["level"];
        // Original $npcLevel from config is replaced by dynamic calculation below
        $npcCat   = $data["npc_category"];

        $isBoss = ($wave === $total && $index === $perWave);
        
        // Determine the actual NPC level based on the new constants
        $actualNpcLevel = $isBoss 
            ? self::RAID_BOSS_LEVEL 
            : mt_rand(self::RAID_NPC_LEVEL_MIN, self::RAID_NPC_LEVEL_MAX);

        $server = Server::getInstance();
        if (!$server->isLevelLoaded($lvlName)) $server->loadLevel($lvlName);
        $level = $server->getLevelByName($lvlName);
        if ($level === null) return;

        $npcPlugin = $server->getPluginManager()->getPlugin("OnePieceNPC");
        // Pass the actual determined level to getNpcStats
        $npcStats   = $this->getNpcStats($actualNpcLevel, $npcCat, $isBoss);
        
        $skinBytes = str_repeat("\xFF", 64 * 64 * 4);
        if ($npcPlugin !== null) {
            $skinBytes = $npcPlugin->getNPCManager()->loadSkinBytes($this->getPirateSkinFile($npcPlugin));
        }

        $angle  = (2 * M_PI / $perWave) * $index;
        $radius = self::SPAWN_RADIUS + mt_rand(-1, 2);
        $sx     = $pos["x"] + (int)round(cos($angle) * $radius);
        $sz     = $pos["z"] + (int)round(sin($angle) * $radius);
        $sy     = $pos["y"];

        for ($p = 0; $p < 6; $p++) {
            $px = $sx + mt_rand(-5, 5) / 10.0;
            $pz = $sz + mt_rand(-5, 5) / 10.0;
            $level->addParticle(new PortalParticle(new Vector3($px, $sy + 1, $pz)));
            $level->addParticle(new SmokeParticle(new Vector3($px, $sy + 1.5, $pz)));
        }

        $fakeNpcId = self::NPC_ID_PREFIX . $key . "_w" . $wave . "_" . $index;
        $displayName = $isBoss 
            ? "§4§lRAID BOSS §r§7[Lv." . $actualNpcLevel . "]" 
            : "§c§lPirate §r§7[Lv." . $actualNpcLevel . "]";

        $nbt = new CompoundTag("", [
            new ListTag("Pos", [
                new DoubleTag("", (float)$sx + 0.5),
                new DoubleTag("", (float)$sy),
                new DoubleTag("", (float)$sz + 0.5),
            ]),
            new ListTag("Motion", [
                new DoubleTag("", 0.0),
                new DoubleTag("", 0.0),
                new DoubleTag("", 0.0),
            ]),
            new ListTag("Rotation", [
                new FloatTag("", (float)mt_rand(0, 359)),
                new FloatTag("", 0.0),
            ]),
            new ListTag("Inventory", []),
            new ShortTag("Health", (int)$npcStats["hp"]),
            new ShortTag("MaxHealth", (int)$npcStats["hp"]),
            new ByteTag("Movement", 1),
            new ByteTag("WallCheck", 1),
            new StringTag("NPCId", $fakeNpcId),
            new StringTag("NPCDisplayName", $displayName),
            new CompoundTag("Skin", [
                new StringTag("Name", "Standard_Steve"),
                new StringTag("Data", $skinBytes),
            ]),
        ]);

        $chunk = $level->getChunk($sx >> 4, $sz >> 4, true);
        if ($chunk === null) return;

        $entity = null;
        try {
            $entity = Entity::createEntity("OP", $chunk, $nbt);
        } catch (\Exception $e) {}

        if (!($entity instanceof NPCEntity)) {
            try {
                $entity = new NPCEntity($chunk, $nbt);
            } catch (\Exception $e) { return; }
        }

        $entity->npcId                = $fakeNpcId;
        $entity->npcPosNum            = $index;
        $entity->npcLevel             = $actualNpcLevel; // Set the dynamically determined level
        $entity->npcCategory          = $npcCat;
        $entity->npcDamage            = $npcStats["damage"];
        $entity->npcSpeed             = $npcStats["speed"];
        $entity->npcMeleeRange        = $isBoss ? 2.5 : 1.6;
        $entity->npcAttackCooldown    = $isBoss ? 15 : 20;
        $entity->bossAbilitiesEnabled = $isBoss;
        $entity->npcFruitId           = "";
        $entity->npcFightingStyle     = "";
        $entity->npcWeaponId          = "";
        $entity->martialAbilities     = [];
        $entity->martialCooldowns     = [];
        $entity->npcHakiArmament      = $isBoss;
        $entity->npcHakiObservation   = $isBoss;
        $entity->npcHakiConqueror     = $isBoss;

        try {
            if ($entity->getAttributeMap() !== null) {
                $entity->setMaxHealth((int)$npcStats["hp"]);
                $entity->setHealth((int)$npcStats["hp"]);
            }
        } catch (\Exception $e) {}

        if (method_exists($entity, "setSkin"))              $entity->setSkin($skinBytes, "Standard_Steve");
        if (method_exists($entity, "setNameTagVisible"))    $entity->setNameTagVisible(true);
        if (method_exists($entity, "setNameTagAlwaysVisible")) $entity->setNameTagAlwaysVisible(true);

        $entity->spawnToAll();
        if (method_exists($entity, "updateNametagHealth")) $entity->updateNametagHealth();

        $data["entity_ids"][] = $entity->getId();
        $data["alive_count"]++;
    }

    public function isRaidNpc($npcId) {
        return strpos($npcId, self::NPC_ID_PREFIX) === 0;
    }

    public function getRaidKeyFromNpcId($npcId) {
        if (!$this->isRaidNpc($npcId)) return null;
        $stripped = substr($npcId, strlen(self::NPC_ID_PREFIX));
        $wPos     = strrpos($stripped, "_w");
        if ($wPos === false) return null;
        return substr($stripped, 0, $wPos);
    }

    public function recordDamage($key, $playerName, $damage) {
        if (!isset($this->active[$key])) return;
        if (isset($this->resolving[$key])) return;
        if (!isset($this->active[$key]["damage_log"][$playerName])) {
            $this->active[$key]["damage_log"][$playerName] = 0.0;
        }
        $this->active[$key]["damage_log"][$playerName] += $damage;
    }

    public function onPirateDeath($key) {
        if (!isset($this->active[$key])) return;
        if (isset($this->resolving[$key])) return;

        $this->active[$key]["alive_count"] = max(0, $this->active[$key]["alive_count"] - 1);

        $alive   = $this->active[$key]["alive_count"];
        $wave    = $this->active[$key]["current_wave"];
        $total   = $this->active[$key]["total_waves"];
        $perWave = $this->active[$key]["per_wave"];
        $spawned = $this->active[$key]["spawned_in_wave"];
        $lvlName = $this->active[$key]["level"];

        $level = Server::getInstance()->getLevelByName($lvlName);
        if ($level !== null) {
            foreach ($level->getPlayers() as $p) {
                $p->sendPopup("§c[RAID] §fWave " . $wave . "/" . $total . " | §cEnemies: §f" . $alive . " §cremaining");
            }
        }

        if ($alive <= 0) {
            if ($spawned < $perWave) {
                $this->spawnSingleNpc($key);
            } elseif ($wave < $total) {
                $this->scheduleNextWave($key);
            } else {
                $this->resolveRaid($key, true);
            }
        }
    }

    public function resolveRaid($key, $success = true) {
        if (!isset($this->active[$key])) return;
        if (isset($this->resolving[$key])) return;

        $this->resolving[$key] = true;

        $active  = $this->active[$key];
        $log     = $active["damage_log"];
        $fruitId = $active["fruit_id"];

        $this->despawnAllEntities($key);
        unset($this->active[$key]);
        unset($this->resolving[$key]);

        if (!$success) {
            $this->broadcast("§cThe pirates have stopped raiding..");
            return;
        }

        if (empty($log)) {
            $this->broadcast("§cPirate completed with no reward given.");
            return;
        }

        $fruitDisplay = $this->getFruitDisplay($fruitId);
        $fruitColor   = $this->getFruitColor($fruitId);

        arsort($log);
        $total   = array_sum($log);
        reset($log);
        $topName = key($log);
        $topDmg  = $log[$topName];

        $this->broadcast("§aAll pirates were defeated! The raid is over!");

        $rank = 1;
        foreach ($log as $pName => $dmg) {
            $pct   = $total > 0 ? round(($dmg / $total) * 100, 1) : 0;
            $color = $rank === 1 ? "§e" : ($rank === 2 ? "§7" : ($rank === 3 ? "§6" : "§8"));
            $this->broadcast($color . "#" . $rank . " §f" . $pName . " §7- " . number_format((int)$dmg) . " dmg §8(" . $pct . "%)");
            $participant = Server::getInstance()->getPlayerExact($pName);
            if ($participant !== null && $participant->isOnline()) {
                $participant->sendMessage("§c§l[RAID] §r§7Your contribution: §f" . number_format((int)$dmg) . " dmg §8(" . $pct . "%) §7- Rank §f#" . $rank);
            }
            if (++$rank > 5) break;
        }

        $winner = Server::getInstance()->getPlayerExact($topName);
        if ($winner !== null && $winner->isOnline()) {
            $item = \pocketmine\item\Item::get(\pocketmine\item\Item::GOLDEN_APPLE, 0, 1);
            $item->setCustomName($fruitColor . $fruitDisplay);
            $winner->getInventory()->addItem($item);
            $winner->sendMessage("§c§l[RAID] §r§aYou received §f" . $fruitDisplay . " §aas your raid reward!");
            \pocketmine\Server::getInstance()->getLogger()->info("[Raid Debug] Player " . $topName . " obtained fruit: " . $fruitId . " from raid: " . $active["name"]);
        } else {
            $this->broadcast("§c" . $topName . " was offline — the prize fruit was lost.");
        }
    }

    public function forceEnd($key) {
        $key = strtolower($key);
        if (!isset($this->active[$key])) return;
        $this->despawnAllEntities($key);
        unset($this->active[$key]);
        unset($this->resolving[$key]);
    }

    private function despawnAllEntities($key) {
        if (!isset($this->active[$key])) return;
        $ids = $this->active[$key]["entity_ids"] ?? [];
        foreach (Server::getInstance()->getLevels() as $level) {
            foreach ($ids as $eid) {
                $entity = $level->getEntity($eid);
                if ($entity !== null && !$entity->closed) {
                    $entity->despawnFromAll();
                    $entity->close();
                }
            }
        }
        $this->active[$key]["entity_ids"]  = [];
        $this->active[$key]["alive_count"] = 0;
    }

    private function spawnStartParticles($key) {
        $active  = $this->active[$key] ?? null;
        if ($active === null) return;
        $lvlName = $active["level"];
        $pos     = $active["pos"];
        $server  = Server::getInstance();
        if (!$server->isLevelLoaded($lvlName)) $server->loadLevel($lvlName);
        $level = $server->getLevelByName($lvlName);
        if ($level === null) return;

        $cx = $pos["x"] + 0.5;
        $cy = $pos["y"] + 1.0;
        $cz = $pos["z"] + 0.5;

        for ($i = 0; $i < 24; $i++) {
            $angle = (2 * M_PI / 24) * $i;
            $px = $cx + cos($angle) * 4.0;
            $pz = $cz + sin($angle) * 4.0;
            $level->addParticle(new PortalParticle(new Vector3($px, $cy, $pz)));
            $level->addParticle(new PortalParticle(new Vector3($px, $cy + 1.0, $pz)));
        }
        for ($i = 0; $i < 12; $i++) {
            $level->addParticle(new SmokeParticle(new Vector3(
                $cx + mt_rand(-30, 30) / 10.0,
                $cy + mt_rand(0, 3),
                $cz + mt_rand(-30, 30) / 10.0
            )));
        }
        $level->addParticle(new LargeExplodeParticle(new Vector3($cx, $cy, $cz)));
    }

    private function getNpcStats($level, $category, $isBoss = false) {
        $npcPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceNPC");
        if ($npcPlugin !== null) {
            $stats = $npcPlugin->getNPCManager()->getStats($level, $category);
            if ($isBoss) {
                $stats["hp"] *= 5;
                $stats["damage"] *= 2;
            }
            return $stats;
        }
        
        // Fallback if OnePieceNPC plugin is not available
        if ($isBoss) {
            $hp    = 1000 + ($level * 50);
            $dmg   = 5.0 + ($level * 0.5);
            $speed = 0.8;
        } else {
            $hp    = 100 + ($level * 20);
            $dmg   = 2.0 + ($level * 0.1);
            $speed = min(2.0, 0.8 + ($level * 0.02));
        }
        return ["hp" => $hp, "damage" => $dmg, "speed" => $speed];
    }

    private function getPirateSkinFile($npcPlugin) {
        $skinPath = $npcPlugin->getDataFolder() . "skins/";
        $files    = glob($skinPath . "*.png");
        if (empty($files)) return "default";
        $names  = array_map("basename", $files);
        $pirate = array_filter($names, function($n) { return strpos(strtolower($n), "pirate") !== false; });
        if (!empty($pirate)) {
            $pirate = array_values($pirate);
            return $pirate[array_rand($pirate)];
        }
        return $names[array_rand($names)];
    }

    public function rollFruit() {
        $devilPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin === null || !$devilPlugin->isEnabled()) return null;

        $berryPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceBerry");
        $paused = [];
        if ($berryPlugin !== null && $berryPlugin->isEnabled()) {
            $paused = $berryPlugin->getPausedFruits();
        }

        $fm     = $devilPlugin->getFruitManager();
        $fruits = $fm->getAllFruits();
        $pool   = [];
        foreach ($fruits as $id => $fruit) {
            if (in_array($id, $paused)) continue;
            $weight = self::RARITY_WEIGHTS[$fruit->getRarity()] ?? 1000;
            for ($i = 0; $i < $weight; $i++) $pool[] = $id;
        }
        return empty($pool) ? null : $pool[array_rand($pool)];
    }

    public function getFruitDisplay($fruitId) {
        $dp = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($dp === null) return $fruitId;
        $fruit = $dp->getFruitManager()->getFruit($fruitId);
        return $fruit !== null ? $fruit->getDisplayName() : $fruitId;
    }

    public function getFruitColor($fruitId) {
        $dp = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($dp === null) return "§f";
        $fruit = $dp->getFruitManager()->getFruit($fruitId);
        return $fruit !== null ? $fruit->getRarityColor() : "§f";
    }

    public function getFruitRarity($fruitId) {
        $dp = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($dp === null) return "unknown";
        $fruit = $dp->getFruitManager()->getFruit($fruitId);
        return $fruit !== null ? $fruit->getRarity() : "unknown";
    }

    public function formatTime($seconds) {
        $h = floor($seconds / 3600);
        $m = floor(($seconds % 3600) / 60);
        $s = $seconds % 60;
        if ($h > 0) return "{$h}h {$m}m {$s}s";
        if ($m > 0) return "{$m}m {$s}s";
        return "{$s}s";
    }

    public function startSchedulers() {
        foreach ($this->raids as $key => $data) {
            if ($data["pos"] === null) continue;
            $this->scheduleRaid($key);
        }
    }

    public function scheduleRaid($key) {
        $data = $this->raids[$key] ?? null;
        if ($data === null || $data["pos"] === null) return;
        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
            new RaidStartTask($this->plugin, $key),
            $data["start_time"] * 20
        );
    }

    private function broadcast($msg) {
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            $p->sendMessage($msg);
        }
    }
}