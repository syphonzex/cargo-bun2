<?php

namespace OnePieceRaid\Raid;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use OnePieceRaid\Main;

class RaidCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct(
            "raid",
            "Manage Pirate Raids",
            "/raid <create|setpos|time|duration|waves|perwave|start|stop|remove|list|info>",
            []
        );
        $this->plugin = $plugin;
        $this->setPermission("op");
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage("§cNo permission.");
            return true;
        }

        $rm = $this->plugin->getRaidManager();

        if (empty($args)) {
            $this->sendHelp($sender);
            return true;
        }

        $sub = strtolower(array_shift($args));

        switch ($sub) {

            case "create":
                if (empty($args)) { $sender->sendMessage("§cUsage: /raid create <name>"); return true; }
                $name = implode(" ", $args);
                if ($rm->createRaid($name)) {
                    $sender->sendMessage("§aRaid §f" . $name . " §acreated. Use §f/raid setpos " . $name . " §ato place it.");
                } else {
                    $sender->sendMessage("§cRaid §f" . $name . " §calready exists.");
                }
                break;

            case "setpos":
                if (!($sender instanceof Player)) { $sender->sendMessage("§cIn-game only."); return true; }
                if (empty($args)) { $sender->sendMessage("§cUsage: /raid setpos <name>"); return true; }
                $name = implode(" ", $args);
                if (!$rm->raidExists($name)) { $sender->sendMessage("§cRaid not found."); return true; }
                $pos   = $sender->getPosition();
                $level = $pos->getLevel()->getFolderName();
                $rm->setPos($name, (int)$pos->x, (int)$pos->y, (int)$pos->z, $level);
                $sender->sendMessage("§aRaid center set for §f" . $name . " §aat §f" . (int)$pos->x . "/" . (int)$pos->y . "/" . (int)$pos->z . " §ain world §f" . $level . "§a.");
                break;

            case "time":
                if (count($args) < 2) { $sender->sendMessage("§cUsage: /raid time <name> <seconds>"); return true; }
                $seconds = (int)array_pop($args);
                $name    = implode(" ", $args);
                if (!$rm->raidExists($name)) { $sender->sendMessage("§cRaid not found."); return true; }
                if ($seconds < 10) { $sender->sendMessage("§cMinimum is 10 seconds."); return true; }
                $rm->setStartTime($name, $seconds);
                $sender->sendMessage("§aRaid §f" . $name . " §awill spawn every §f" . $rm->formatTime($seconds) . "§a.");
                break;

            case "duration":
                if (count($args) < 2) { $sender->sendMessage("§cUsage: /raid duration <name> <seconds>"); return true; }
                $seconds = (int)array_pop($args);
                $name    = implode(" ", $args);
                if (!$rm->raidExists($name)) { $sender->sendMessage("§cRaid not found."); return true; }
                if ($seconds < 60) { $sender->sendMessage("§cMinimum is 60 seconds."); return true; }
                $rm->setDuration($name, $seconds);
                $sender->sendMessage("§aRaid §f" . $name . " §awill expire after §f" . $rm->formatTime($seconds) . "§a.");
                break;

            case "waves":
                if (count($args) < 2) { $sender->sendMessage("§cUsage: /raid waves <name> <count>"); return true; }
                $count = (int)array_pop($args);
                $name  = implode(" ", $args);
                if (!$rm->raidExists($name)) { $sender->sendMessage("§cRaid not found."); return true; }
                if ($count < 1) { $sender->sendMessage("§cMinimum is 1 wave."); return true; }
                $rm->setWaves($name, $count);
                $sender->sendMessage("§aRaid §f" . $name . " §awill have §f" . $count . " §awaves.");
                break;

            case "perwave":
                if (count($args) < 2) { $sender->sendMessage("§cUsage: /raid perwave <name> <count>"); return true; }
                $count = (int)array_pop($args);
                $name  = implode(" ", $args);
                if (!$rm->raidExists($name)) { $sender->sendMessage("§cRaid not found."); return true; }
                if ($count < 1) { $sender->sendMessage("§cMinimum is 1 pirate per wave."); return true; }
                $rm->setPerWave($name, $count);
                $sender->sendMessage("§aRaid §f" . $name . " §awill spawn §f" . $count . " §apirates per wave.");
                break;

            case "start":
                if (empty($args)) { $sender->sendMessage("§cUsage: /raid start <name>"); return true; }
                $name = implode(" ", $args);
                $key  = strtolower($name);
                if (!$rm->raidExists($name)) { $sender->sendMessage("§cRaid not found."); return true; }
                if ($rm->isActive($key)) { $sender->sendMessage("§cRaid §f" . $name . " §cis already active!"); return true; }
                if ($rm->startRaid($key)) {
                    $sender->sendMessage("§aRaid §f" . $name . " §astarted manually!");
                } else {
                    $sender->sendMessage("§cFailed. Make sure position is set and OnePieceDevil is loaded.");
                }
                break;

            case "stop":
                if (empty($args)) { $sender->sendMessage("§cUsage: /raid stop <name>"); return true; }
                $name = implode(" ", $args);
                $key  = strtolower($name);
                if (!$rm->isActive($key)) { $sender->sendMessage("§cRaid §f" . $name . " §cis not active."); return true; }
                $rm->forceEnd($key);
                $sender->sendMessage("§aRaid §f" . $name . " §astopped.");
                break;

            case "remove":
            case "delete":
                if (empty($args)) { $sender->sendMessage("§cUsage: /raid remove <name>"); return true; }
                $name = implode(" ", $args);
                if ($rm->deleteRaid($name)) {
                    $sender->sendMessage("§aRaid §f" . $name . " §adeleted.");
                } else {
                    $sender->sendMessage("§cRaid not found.");
                }
                break;

            case "list":
                $raids = $rm->getAllRaids();
                if (empty($raids)) { $sender->sendMessage("§cNo raids configured."); return true; }
                $sender->sendMessage("§c§l[RAIDS]");
                foreach ($raids as $key => $data) {
                    $posStr = $data["pos"] !== null
                        ? $data["pos"]["x"] . "/" . $data["pos"]["y"] . "/" . $data["pos"]["z"] . " (" . $data["level"] . ")"
                        : "§cNot set";
                    $status = $rm->isActive($key) ? "§aACTIVE" : "§7Idle";
                    $sender->sendMessage("§e" . $data["name"] . " §8| " . $status . " §8| " . $rm->formatTime($data["start_time"]) . " interval §8| " . $data["waves"] . " waves x " . $data["per_wave"] . " pirates §8| §7" . $posStr);
                }
                break;

            case "info":
                if (empty($args)) { $sender->sendMessage("§cUsage: /raid info <name>"); return true; }
                $name = implode(" ", $args);
                $key  = strtolower($name);
                $data = $rm->getRaid($name);
                if ($data === null) { $sender->sendMessage("§cRaid not found."); return true; }
                $posStr = $data["pos"] !== null
                    ? $data["pos"]["x"] . "/" . $data["pos"]["y"] . "/" . $data["pos"]["z"] . " (" . $data["level"] . ")"
                    : "§cNot set";
                $sender->sendMessage("§c§l[" . $data["name"] . "]");
                $sender->sendMessage("§7Position: §f" . $posStr);
                $sender->sendMessage("§7Interval: §f" . $rm->formatTime($data["start_time"]));
                $sender->sendMessage("§7Duration: §f" . $rm->formatTime($data["duration"]));
                $sender->sendMessage("§7Waves: §f" . $data["waves"] . " §7(§f" . $data["per_wave"] . " §7pirates each)");
                if ($rm->isActive($key)) {
                    $active       = $rm->getActiveData($key);
                    $fruitDisplay = $rm->getFruitDisplay($active["fruit_id"]);
                    $fruitColor   = $rm->getFruitColor($active["fruit_id"]);
                    $rarity       = $rm->getFruitRarity($active["fruit_id"]);
                    $sender->sendMessage("§aStatus: ACTIVE — Wave §f" . $active["current_wave"] . "§a/§f" . $active["total_waves"] . " §a| Alive: §f" . $active["alive_count"]);
                    $sender->sendMessage("§7Prize: " . $fruitColor . $fruitDisplay . " §8[" . strtoupper($rarity) . "]");
                    $log = $active["damage_log"];
                    if (!empty($log)) {
                        arsort($log);
                        $sender->sendMessage("§7Damage leaderboard:");
                        $rank = 1;
                        foreach ($log as $pName => $dmg) {
                            $sender->sendMessage("§7  #" . $rank . " §f" . $pName . " §7— " . number_format((int)$dmg));
                            if (++$rank > 5) break;
                        }
                    } else {
                        $sender->sendMessage("§7No damage dealt yet.");
                    }
                } else {
                    $sender->sendMessage("§7Status: Idle");
                }
                break;

            default:
                $this->sendHelp($sender);
        }

        return true;
    }

    private function sendHelp(CommandSender $sender) {
        $sender->sendMessage("§c§l[RAID COMMANDS]");
        $sender->sendMessage("§f/raid create <name>           §7Create a new raid");
        $sender->sendMessage("§f/raid setpos <name>           §7Set center to your position");
        $sender->sendMessage("§f/raid time <name> <sec>       §7Seconds between each raid");
        $sender->sendMessage("§f/raid duration <name> <sec>   §7How long before it expires");
        $sender->sendMessage("§f/raid waves <name> <count>    §7Number of waves");
        $sender->sendMessage("§f/raid perwave <name> <count>  §7Pirates per wave");
        $sender->sendMessage("§f/raid start <name>            §7Manually start the raid now");
        $sender->sendMessage("§f/raid stop <name>             §7Force-stop an active raid");
        $sender->sendMessage("§f/raid remove <name>           §7Delete a raid permanently");
        $sender->sendMessage("§f/raid list                    §7Show all raids");
        $sender->sendMessage("§f/raid info <name>             §7Live wave status and damage log");
    }
}
