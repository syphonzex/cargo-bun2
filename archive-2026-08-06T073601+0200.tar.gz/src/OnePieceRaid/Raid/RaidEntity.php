<?php

namespace OnePieceRaid\Raid;

use pocketmine\entity\Entity;
use pocketmine\entity\Human;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Timings;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\ExplodeParticle;
use pocketmine\math\Vector2;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\network\protocol\AddPlayerPacket;
use pocketmine\network\protocol\AnimatePacket;
use pocketmine\network\protocol\MobEquipmentPacket;
use pocketmine\network\protocol\PlayerListPacket;
use pocketmine\Player;
use pocketmine\Server;

class RaidEntity extends Human {

    public $width      = 0.6;
    public $height     = 1.8;
    public $eyeHeight  = 1.62;

    protected $gravity    = 0.08;
    protected $drag       = 0.02;
    protected $stepHeight = 0.6;

    public $raidKey    = null;
    public $raidWave   = 0;
    public $npcDamage  = 4.0;
    public $npcSpeed   = 1.0;
    public $npcRange   = 1.8;

    private $spawnX = 0.0;
    private $spawnY = 0.0;
    private $spawnZ = 0.0;
    private $leashRangeSq = 625.0;
    private $aggroRangeSq = 400.0;
    private $meleeRangeSq = 3.24;

    private $attackDelay       = 0;
    private $targetCheckTimer  = 0;
    private $slowTickTimer     = 0;
    private $lastAttackerName  = null;
    private $baseTarget        = null;
    private $returning         = false;
    private $idle              = true;
    private $returnSpeed       = 1.5;

    const IDX_NAMETAG      = 2;
    const IDX_SHOW_NAMETAG = 3;

    public function getName()   { return "Pirate"; }
    public function getSaveId() { return "Pirate"; }

    private function getRaidManager() {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceRaid");
        return $plugin !== null ? $plugin->getRaidManager() : null;
    }

    public function initEntity() {
        parent::initEntity();
        $maxHp = isset($this->namedtag->MaxHealth) ? (int)$this->namedtag->MaxHealth->getValue() : 200;
        try {
            if ($this->getAttributeMap() !== null) {
                $this->setMaxHealth($maxHp);
                $this->setHealth($maxHp);
            }
        } catch (\Exception $e) {}
        if (isset($this->namedtag->RaidKey))  $this->raidKey  = $this->namedtag->RaidKey->getValue();
        if (isset($this->namedtag->RaidWave)) $this->raidWave = (int)$this->namedtag->RaidWave->getValue();
        $this->spawnX = $this->x;
        $this->spawnY = $this->y;
        $this->spawnZ = $this->z;
        $this->dataProperties[self::DATA_NO_AI]        = [self::DATA_TYPE_BYTE, 1];
        $this->dataProperties[self::IDX_NAMETAG]      = [Entity::DATA_TYPE_STRING, "§c§lPirate §r§7[Wave " . $this->raidWave . "]"];
        $this->dataProperties[self::IDX_SHOW_NAMETAG] = [Entity::DATA_TYPE_BYTE, 1];
    }

    public function setLastAttacker($name) {
        $this->lastAttackerName = $name;
    }

    public function attack($damage, EntityDamageEvent $source) {
        if ($this->closed || !$this->isAlive()) return;

        $attackerName = null;
        if ($source instanceof EntityDamageByEntityEvent) {
            $raw = $source->getDamager();
            if ($raw instanceof Player) {
                $attackerName = $raw->getName();
                $this->lastAttackerName = $attackerName;
                $this->baseTarget = $raw;
                $this->idle = false;
                $this->returning = false;
            }
        } elseif (in_array($source->getCause(), [
            EntityDamageEvent::CAUSE_MAGIC,
            EntityDamageEvent::CAUSE_FIRE,
            EntityDamageEvent::CAUSE_ENTITY_EXPLOSION,
        ])) {
            $attackerName = $this->lastAttackerName;
        }

        if ($attackerName === null) return;

        $dm = $this->getRaidManager();
        if ($dm === null || $this->raidKey === null || !$dm->isActive($this->raidKey)) return;

        $finalDamage = max(1, $source->getFinalDamage());
        $dm->recordDamage($this->raidKey, $attackerName, $finalDamage);

        $newHp = $this->getHealth() - $finalDamage;
        if ($newHp <= 0) {
            $this->spawnDeathParticles();
            $dm->onPirateDeath($this->raidKey, $this);
            $this->despawnFromAll();
            $this->close();
            return;
        }
        $this->setHealth(max(0.5, $newHp));
    }

    private function spawnDeathParticles() {
        if ($this->level === null) return;
        $center = new Vector3($this->x, $this->y + 1, $this->z);
        for ($i = 0; $i < 8; $i++) {
            $ox = mt_rand(-10, 10) / 10.0;
            $oz = mt_rand(-10, 10) / 10.0;
            $this->level->addParticle(new SmokeParticle(new Vector3($center->x + $ox, $center->y, $center->z + $oz)));
        }
        $this->level->addParticle(new ExplodeParticle($center));
    }

    public function knockBack(Entity $attacker, $damage, $x, $z, $base = 0.4) {}

    private function distanceToSpawnSquared() {
        $dx = $this->x - $this->spawnX;
        $dz = $this->z - $this->spawnZ;
        return $dx * $dx + $dz * $dz;
    }

    private function sendArmSwing() {
        $pk         = new AnimatePacket();
        $pk->eid    = $this->getId();
        $pk->action = 1;
        foreach ($this->getLevel()->getPlayers() as $p) {
            $p->dataPacket($pk);
        }
    }

    protected function checkTarget() {
        if ($this->returning) {
            if ($this->distanceToSpawnSquared() <= 1.0) {
                $this->returning = false;
                $this->idle      = true;
                $this->baseTarget = null;
                $this->motionX = 0;
                $this->motionZ = 0;
            }
            return;
        }

        if ($this->baseTarget instanceof Player) {
            if (!$this->baseTarget->isAlive() || $this->baseTarget->closed || !$this->baseTarget->spawned) {
                $this->baseTarget = null;
            } elseif (!$this->baseTarget->isSurvival() && !$this->baseTarget->isAdventure()) {
                $this->baseTarget = null;
            } elseif ($this->distanceToSpawnSquared() > $this->leashRangeSq) {
                $this->baseTarget = null;
                $this->returning  = true;
                $this->idle       = false;
                return;
            } elseif ($this->distanceSquared($this->baseTarget) > ($this->aggroRangeSq * 2)) {
                $this->baseTarget = null;
            }
        }

        if (!($this->baseTarget instanceof Player)) {
            $near  = PHP_INT_MAX;
            $found = null;
            foreach ($this->getLevel()->getPlayers() as $p) {
                if (!$p->isAlive() || !$p->spawned || $p->closed) continue;
                if (!$p->isSurvival() && !$p->isAdventure()) continue;
                $dist = $this->distanceSquared($p);
                if ($dist > $this->aggroRangeSq || $dist >= $near) continue;
                $near  = $dist;
                $found = $p;
            }
            if ($found !== null) {
                $this->baseTarget = $found;
                $this->idle       = false;
                $this->returning  = false;
            } else {
                if (!$this->idle) {
                    if ($this->distanceToSpawnSquared() > 1.0) {
                        $this->returning = true;
                    } else {
                        $this->idle    = true;
                        $this->motionX = 0;
                        $this->motionZ = 0;
                    }
                }
                $this->baseTarget = null;
            }
        }
    }

    protected function updateMove($tickDiff) {
        if ($this->idle) {
            $this->targetCheckTimer += $tickDiff;
            if ($this->targetCheckTimer >= 5) {
                $this->targetCheckTimer = 0;
                $this->checkTarget();
            }
            if ($this->idle) {
                $this->motionX = 0;
                $this->motionZ = 0;
                if (!$this->onGround) {
                    $this->motionY -= $this->gravity;
                    $this->move(0, $this->motionY * $tickDiff, 0);
                    $this->updateMovement();
                }
                return null;
            }
        }

        $this->targetCheckTimer += $tickDiff;
        if ($this->targetCheckTimer >= 5) {
            $this->targetCheckTimer = 0;
            $this->checkTarget();
        }

        if ($this->idle) {
            $this->motionX = 0;
            $this->motionZ = 0;
            $this->updateMovement();
            return null;
        }

        if ($this->returning) {
            $x    = $this->spawnX - $this->x;
            $z    = $this->spawnZ - $this->z;
            $diff = abs($x) + abs($z);
            if ($diff > 0) {
                $this->motionX = $this->returnSpeed * 0.15 * ($x / $diff);
                $this->motionZ = $this->returnSpeed * 0.15 * ($z / $diff);
                $this->yaw     = -atan2($x / $diff, $z / $diff) * 180 / M_PI;
            }
        } elseif ($this->baseTarget instanceof Player) {
            $x    = $this->baseTarget->x - $this->x;
            $y    = $this->baseTarget->y - $this->y;
            $z    = $this->baseTarget->z - $this->z;
            $diff = abs($x) + abs($z);
            if ($x * $x + $z * $z < 0.7) {
                $this->motionX = 0;
                $this->motionZ = 0;
            } elseif ($diff > 0) {
                $this->motionX = $this->npcSpeed * 0.15 * ($x / $diff);
                $this->motionZ = $this->npcSpeed * 0.15 * ($z / $diff);
            }
            if ($diff > 0) {
                $this->yaw   = -atan2($x / $diff, $z / $diff) * 180 / M_PI;
                $this->pitch = $y == 0 ? 0 : rad2deg(-atan2($y, sqrt($x * $x + $z * $z)));
            }
        }

        $dx = $this->motionX * $tickDiff;
        $dz = $this->motionZ * $tickDiff;

        if ($this->onGround && $this->isCollidedHorizontally) {
            $this->motionY = 0.42;
        }

        $be = new Vector2($this->x + $dx, $this->z + $dz);
        $this->move($dx, $this->motionY * $tickDiff, $dz);

        if ($this->onGround) {
            $this->motionY = 0;
        } elseif ($this->motionY > -$this->gravity * 4) {
            $this->motionY = -$this->gravity * 4;
        } else {
            $this->motionY -= $this->gravity;
        }

        $this->updateMovement();
        return $this->baseTarget;
    }

    public function onUpdate($currentTick) {
        if ($this->closed) return false;

        $tickDiff = $currentTick - $this->lastUpdate;
        if ($tickDiff <= 0) return false;
        $this->lastUpdate = $currentTick;

        $this->entityBaseTick($tickDiff);

        if ($this->closed || !$this->isAlive()) return false;

        $target = $this->updateMove($tickDiff);

        if (!$this->idle && !$this->returning && $target instanceof Player && $target->isAlive()) {
            $dist = $this->distanceSquared($target);
            if ($this->attackDelay <= 0 && $dist <= $this->meleeRangeSq) {
                $this->sendArmSwing();
                $ev = new EntityDamageByEntityEvent($this, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->npcDamage);
                $target->attack($this->npcDamage, $ev);
                $this->attackDelay = 20;
            }
        }

        if ($this->attackDelay > 0) $this->attackDelay -= $tickDiff;

        return !$this->closed;
    }

    public function entityBaseTick($tickDiff = 1, $EnchantL = 0) {
        Timings::$timerEntityBaseTick->startTiming();

        if ($this->closed) {
            Timings::$timerEntityBaseTick->stopTiming();
            return false;
        }

        if (!$this->isAlive()) {
            $this->despawnFromAll();
            $this->close();
            Timings::$timerEntityBaseTick->stopTiming();
            return false;
        }

        if (count($this->effects) > 0) {
            foreach ($this->effects as $effect) {
                if ($effect->canTick()) $effect->applyEffect($this);
                $effect->setDuration($effect->getDuration() - $tickDiff);
                if ($effect->getDuration() <= 0) $this->removeEffect($effect->getId());
            }
        }

        $hasUpdate = false;

        if ($this->y <= -16 && $this->isAlive()) {
            $ev = new EntityDamageEvent($this, EntityDamageEvent::CAUSE_VOID, 10);
            $this->attack($ev->getFinalDamage(), $ev);
            $hasUpdate = true;
        }

        if ($this->noDamageTicks > 0) {
            $this->noDamageTicks -= $tickDiff;
            if ($this->noDamageTicks < 0) $this->noDamageTicks = 0;
        }

        $this->age        += $tickDiff;
        $this->ticksLived += $tickDiff;
        if ($this->attackTime > 0) $this->attackTime -= $tickDiff;

        Timings::$timerEntityBaseTick->stopTiming();
        return $hasUpdate;
    }

    public function getDrops()        { return []; }
    public function getXpDropAmount() { return 0; }

    public function spawnTo(Player $player) {
        if ($player !== $this && !isset($this->hasSpawned[$player->getLoaderId()])) {
            $this->hasSpawned[$player->getLoaderId()] = $player;

            $pk           = new AddPlayerPacket();
            $pk->uuid     = $this->getUniqueId();
            $pk->username = "";
            $pk->eid      = $this->getId();
            $pk->x        = $this->x;
            $pk->y        = $this->y;
            $pk->z        = $this->z;
            $pk->yaw      = $this->yaw;
            $pk->pitch    = $this->pitch;
            $pk->item     = $this->getInventory()->getItemInHand();
            $pk->metadata = $this->dataProperties;
            $player->dataPacket($pk);

            $this->inventory->sendArmorContents($player);

            $add               = new PlayerListPacket();
            $add->type         = PlayerListPacket::TYPE_ADD;
            $add->entries[]    = [$this->getUniqueId(), $this->getId(), "", $this->skinId, $this->skin];
            $player->dataPacket($add);

            $remove            = new PlayerListPacket();
            $remove->type      = PlayerListPacket::TYPE_REMOVE;
            $remove->entries[] = [$this->getUniqueId()];
            $player->dataPacket($remove);
        }
    }
}