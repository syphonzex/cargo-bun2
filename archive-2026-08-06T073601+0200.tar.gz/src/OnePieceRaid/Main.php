<?php

namespace OnePieceRaid;

use pocketmine\plugin\PluginBase;
use OnePieceRaid\Raid\RaidManager;
use OnePieceRaid\Raid\RaidListener;
use OnePieceRaid\Raid\RaidCommand;
use OnePieceRaid\Awaken\AwakenManager;
use OnePieceRaid\Awaken\AwakenListener;
use OnePieceRaid\Awaken\AwakenCommand;
use OnePieceRaid\Awaken\AwakenFruitCommand;

class Main extends PluginBase {

    private $raidManager;
    private $awakenManager;

    public function onEnable() {
        @mkdir($this->getDataFolder());

        $this->raidManager   = new RaidManager($this);
        $this->awakenManager = new AwakenManager($this);

        new RaidListener($this);
        new AwakenListener($this);

        $cmdMap = $this->getServer()->getCommandMap();
        $cmdMap->register("onepieceraid", new RaidCommand($this));
        $cmdMap->register("onepieceraid", new AwakenCommand($this));
        $cmdMap->register("onepieceraid", new AwakenFruitCommand($this));

        $this->raidManager->startSchedulers();
        $this->awakenManager->startSchedulers();

        $this->getLogger()->info("OnePieceRaid enabled.");
    }

    public function onDisable() {
        foreach ($this->raidManager->getAllRaids() as $key => $data) {
            if ($this->raidManager->isActive($key)) {
                $this->raidManager->forceEnd($key);
            }
        }

        foreach ($this->awakenManager->getAllInstances() as $instanceKey => $inst) {
            $this->awakenManager->despawnAllEntities($instanceKey);
            $this->awakenManager->deleteInstanceWorld($instanceKey);
        }
    }

    public function getRaidManager()   { return $this->raidManager; }
    public function getAwakenManager() { return $this->awakenManager; }
}
