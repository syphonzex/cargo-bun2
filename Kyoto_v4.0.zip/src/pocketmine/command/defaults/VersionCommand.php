<?php namespace pocketmine\command\defaults;use pocketmine\command\CommandSender;class VersionCommand extends VanillaCommand{public function __construct($name){parent::__construct($name,"%pocketmine.command.version.description","%pocketmine.command.version.usage",["ver","about","kyo","kyoto"]);$this->setPermission("pocketmine.command.version");}public function execute(CommandSender $sender, $currentAlias, array $args){
$sender->sendMessage("§8x - - - - - - - - - - - - - - - - - - x");
$sender->sendMessage("§aKyoto-v4.0 §8*§eMultiVersion§8* §fby §dTubunga");
$sender->sendMessage("PHP Version: §e7.0.3");
$sender->sendMessage("API: §e4.0.0 §7(Modded API)");
$sender->sendMessage("§8x - - - - - - - - - - - - - - - - - - x");}}