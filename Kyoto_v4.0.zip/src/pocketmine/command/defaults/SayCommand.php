<?php


namespace pocketmine\command\defaults;

use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\event\TranslationContainer;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class SayCommand extends VanillaCommand{

	public function __construct($name){
		parent::__construct(
			$name,
			"%pocketmine.command.say.description",
			"%commands.say.usage",
			["broadcast", "announce"]
		);
		$this->setPermission("pocketmine.command.say");
	}

	public function execute(CommandSender $sender, $currentAlias, array $args){
		if(!$this->testPermission($sender)){
			return true;
		}

		if(count($args) === 0){
			$sender->sendMessage(new TranslationContainer("commands.generic.usage", [$this->usageMessage]));

			return false;
		}

		$sender->getServer()->broadcastMessage(new TranslationContainer(TextFormat::GRAY . "%chat.type.announcement", [$sender instanceof Player ? "§b" .$sender->getName(). "§7" : ($sender instanceof ConsoleCommandSender ? "§bCONSOLE§7" : $sender->getName()), "§b" . implode(" ", $args)]));
		return true;
	}
}
