<?php

namespace OnePiece\Devil\fruits;

use OnePiece\Devil\BaseFruit;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\sound\ExplodeSound;

class BombBomb extends BaseFruit {

    public function getId() { 
        return "bomb_bomb"; 
    }

    public function getDisplayName() { 
        return "Bomb-Bomb Fruit"; 
    }

    public function getDescription() { 
        return "Turn any part of your body into a bomb!"; 
    }

    public function getType() { 
        return "paramecia"; 
    }

    public function getRarity() { 
        return "rare"; 
    }

    public function getAbilityNames() {
        return ["ability1" => "Nose Fancy Cannon", "ability2" => "Full Body Detonation"];
    }

    public function getAbilityCooldowns() {
        return ["ability1" => 5.0, "ability2" => 15.0];
    }

    public function useAbility(Player $player, $ability) {
        switch ($ability) {
            case "ability1": return $this->noseFancyCannon($player);
            case "ability2": return $this->fullBodyDetonation($player);
        }
        return 0;
    }

    private function noseFancyCannon(Player $player) {
        $mult = min(1.5, $this->getHakiMultiplier($player));
        $damage = min(7.0, 3.5 * $mult);
        $target = $this->findFrontTarget($player, 15.0);

        if ($target !== null) {
            $pos = $target->getPosition();
            
            $player->getLevel()->addParticle(new HugeExplodeParticle($pos));
            $player->getLevel()->addSound(new ExplodeSound($pos));
            
            for ($i = 0; $i < 12; $i++) {
                $v = new Vector3(
                    $pos->x + (lcg_value() - 0.5) * 3,
                    $pos->y + (lcg_value() - 0.5) * 3 + 1,
                    $pos->z + (lcg_value() - 0.5) * 3
                );
                $player->getLevel()->addParticle(new FlameParticle($v));
                if ($i % 2 === 0) {
                    $player->getLevel()->addParticle(new LavaParticle($v));
                }
            }

            $this->dealAbilityDamage($player, $target, $damage);

            $dx = $target->x - $player->x;
            $dz = $target->z - $player->z;
            $len = sqrt($dx * $dx + $dz * $dz);
            if ($len > 0) {
                $force = 0.8 + (lcg_value() * 0.4);
                $this->safeSetMotion($player, $target, new Vector3($dx / $len * $force, 0.35, $dz / $len * $force));
            }

            $player->sendTip("§cNOSE FANCY CANNON!");
            if ($target instanceof Player) {
                $target->sendTip("§cBoom!");
            }
        } else {
            $dir = $player->getDirectionVector();
            $pos = $player->add($dir->x * 4, $dir->y * 4 + 1, $dir->z * 4);
            
            $player->getLevel()->addParticle(new HugeExplodeParticle($pos));
            $player->getLevel()->addSound(new ExplodeSound($pos));
            
            for ($i = 0; $i < 12; $i++) {
                $v = new Vector3(
                    $pos->x + (lcg_value() - 0.5) * 3,
                    $pos->y + (lcg_value() - 0.5) * 3,
                    $pos->z + (lcg_value() - 0.5) * 3
                );
                $player->getLevel()->addParticle(new FlameParticle($v));
                if ($i % 2 === 0) {
                    $player->getLevel()->addParticle(new LavaParticle($v));
                }
            }
            
            $player->sendTip("§cNOSE FANCY CANNON! §7(Missed)");
        }

        return $this->getAbilityCooldowns()["ability1"];
    }

    private function fullBodyDetonation(Player $player) {
        $mult = min(1.5, $this->getHakiMultiplier($player));
        $damage = min(10.0, 5.0 * $mult);
        $radius = 6.0;
        $pos = $player->getPosition();

        $player->getLevel()->addParticle(new HugeExplodeParticle($pos));
        $player->getLevel()->addSound(new ExplodeSound($pos));
        
        for ($i = 0; $i < 30; $i++) {
            $v = new Vector3(
                $pos->x + (lcg_value() - 0.5) * ($radius * 1.2),
                $pos->y + lcg_value() * ($radius * 0.8),
                $pos->z + (lcg_value() - 0.5) * ($radius * 1.2)
            );
            $player->getLevel()->addParticle(new FlameParticle($v));
            if ($i % 3 === 0) {
                $player->getLevel()->addParticle(new LavaParticle($v));
            }
        }
        
        $hits = 0;
        foreach ($this->getNearbyTargets($player, $radius) as $t) {
            $this->dealAbilityDamage($player, $t, $damage);

            $dx = $t->x - $pos->x;
            $dz = $t->z - $pos->z;
            $len = sqrt($dx * $dx + $dz * $dz);
            if ($len > 0) {
                $force = 1.2 - (($len / $radius) * 0.5);
                $force = max(0.7, min(1.2, $force));
                $this->safeSetMotion($player, $t, new Vector3($dx / $len * $force, 0.35, $dz / $len * $force));
            }

            if ($t instanceof Player) {
                $t->sendTip("§cFULL BODY DETONATION!");
            }
            $hits++;
        }

        $player->sendTip("§cFULL BODY DETONATION! §7Blasted $hits enemies!");

        return $this->getAbilityCooldowns()["ability2"];
    }

    public function onEquip(Player $player) {
        $player->sendMessage("§cExplosive powers! §7(Nose Fancy Cannon | Full Body Detonation)");
    }

    public function onUnequip(Player $player) {
        $player->sendMessage("§7Explosive powers deactivated...");
    }
}