<?php

namespace OnePiece\Devil\fruits;

use OnePiece\Devil\BaseFruit;
use OnePiece\Devil\Main;
use OnePiece\Devil\BlockEffects;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;
use pocketmine\entity\Effect;
use pocketmine\utils\TextFormat;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\Task;
use pocketmine\level\Level;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\sound\FizzSound;
use pocketmine\level\sound\ExplodeSound;
use pocketmine\level\sound\GhastShootSound;
use pocketmine\level\sound\GhastSound;
use pocketmine\network\protocol\LevelEventPacket;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;

class MaguMagu extends BaseFruit {

    public function getId() { return "magu_magu"; }
    public function getDisplayName() { return "Magma-Magma Fruit"; }
    public function getDescription() { return "Turn your body into absolute magma!"; }
    public function getType() { return "logia"; }
    public function getRarity() { return "legendary"; }

    public function getAbilityNames() {
        return [
            "ability1" => "Magma Fist",
            "ability2" => "Magma Hound"
        ];
    }

    public function getAbilityCooldowns() {
        return [
            "ability1" => 7.0,
            "ability2" => 18.0
        ];
    }

    public function useAbility(Player $player, $ability) {
        switch ($ability) {
            case "ability1":
                return $this->magmaFist($player);
            case "ability2":
                return $this->magmaHound($player);
        }
        return 0;
    }

    private function magmaFist(Player $player) {
        $mult = min(1.5, $this->getHakiMultiplier($player));
        $baseDamage = min(10.0, 4.5 * $mult);

        $task = new MagmaFistTask($this->plugin, $player, $baseDamage);
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($task, 1);

        $player->sendTip(TextFormat::RED . TextFormat::BOLD . "DAI FUNKA! (MAGMA FIST)");
        $player->getLevel()->addSound(new GhastShootSound($player->getPosition()));

        return $this->getAbilityCooldowns()["ability1"];
    }

    private function magmaHound(Player $player) {
        $mult = min(1.5, $this->getHakiMultiplier($player));
        $damage = min(8.0, 3.5 * $mult);

        $masteryLevel = 1;
        if ($this->plugin->getMasteryManager() !== null) {
            $masteryLevel = $this->plugin->getMasteryManager()->getLevel($player->getName());
        }
        $bonus = (min(100, $masteryLevel) / 100) * 2.0; 
        $durationTicks = (int)((4.0 + $bonus) * 20);

        $task = new MagmaHoundTask($this->plugin, $player, $damage, $durationTicks);
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($task, 1);

        $player->sendTip(TextFormat::RED . TextFormat::BOLD . "INUGAMI GUREN! (MAGMA HOUND)");
        $player->getLevel()->addSound(new GhastSound($player->getPosition()));

        return $this->getAbilityCooldowns()["ability2"];
    }

    public function onEquip(Player $player) {
        $player->sendMessage(TextFormat::RED . "=== Magu-Magu no Mi ===");
        $player->sendMessage(TextFormat::GOLD . "Magma-Magma Fruit - Absolute Lethality (Legendary)");
        $player->sendMessage("");
        $player->sendMessage(TextFormat::RED . "[Ability 1]: " . TextFormat::WHITE . "MAGMA FIST");
        $player->sendMessage(TextFormat::GRAY . "  Fires a giant magma fist leaving a burning puddle");
        $player->sendMessage(TextFormat::RED . "[Ability 2]: " . TextFormat::WHITE . "MAGMA HOUND");
        $player->sendMessage(TextFormat::GRAY . "  Transform into a magma beast, dragging enemies in");
        $player->sendMessage(TextFormat::RED . "========================");
    }

    public function onUnequip(Player $player) {
        $player->sendMessage(TextFormat::GRAY . "The magma cools into solid rock...");
    }
}

class MagmaFistTask extends Task {

    private $plugin;
    private $player;
    private $level;
    private $damage;
    private $ticksRan = 0;
    private $maxTicks = 35;
    private $x, $y, $z;
    private $dirX, $dirY, $dirZ;
    private $fistEids = [];

    public function __construct($plugin, Player $player, $damage) {
        $this->plugin = $plugin;
        $this->player = $player;
        $this->level = $player->getLevel();
        $this->damage = $damage;
        
        $pos = $player->getPosition();
        $dir = $player->getDirectionVector()->normalize();
        
        $this->x = $pos->x + $dir->x * 1.5;
        $this->y = $pos->y + $player->getEyeHeight();
        $this->z = $pos->z + $dir->z * 1.5;
        
        $this->dirX = $dir->x * 1.6;
        $this->dirY = $dir->y * 1.6;
        $this->dirZ = $dir->z * 1.6;

        $blocks = [291, 415]; 
        for ($i = 0; $i < 3; $i++) {
            $eid = BlockEffects::newEid();
            $b = $blocks[array_rand($blocks)];
            BlockEffects::sendSpawn($this->level, $eid, $b, 0, $this->x, $this->y, $this->z);
            $this->fistEids[] = $eid;
        }
    }

    public function onRun($currentTick) {
        if ($this->player === null || !$this->player->isOnline() || !$this->player->isAlive()) {
            $this->cleanup();
            return;
        }

        $this->ticksRan++;

        if ($this->ticksRan > $this->maxTicks) {
            $this->explode();
            return;
        }

        $this->x += $this->dirX;
        $this->y += $this->dirY;
        $this->z += $this->dirZ;

        if (count($this->fistEids) === 3) {
            BlockEffects::sendMove($this->level, $this->fistEids[0], $this->x, $this->y, $this->z);
            BlockEffects::sendMove($this->level, $this->fistEids[1], $this->x + 0.4, $this->y + 0.2, $this->z - 0.4);
            BlockEffects::sendMove($this->level, $this->fistEids[2], $this->x - 0.4, $this->y - 0.2, $this->z + 0.4);
        }

        $this->spawnFistVFX();

        if ($this->checkCollision()) {
            $this->explode();
            return;
        }
    }

    private function spawnFistVFX() {
        for ($i = 0; $i < 6; $i++) {
            $ox = (mt_rand(-10, 10) / 10);
            $oy = (mt_rand(-10, 10) / 10);
            $oz = (mt_rand(-10, 10) / 10);
            
            $this->level->addParticle(new DustParticle(new Vector3($this->x + $ox, $this->y + $oy, $this->z + $oz), 255, 100, 0));
            $this->level->addParticle(new FlameParticle(new Vector3($this->x + $ox, $this->y + $oy, $this->z + $oz)));
        }
    }

    private function checkCollision() {
        if ($this->y <= 0 || $this->y >= 255) return true;
        
        $block = $this->level->getBlock(new Vector3($this->x, $this->y, $this->z));
        if ($block->getId() !== 0 && $block->getId() !== 8 && $block->getId() !== 9 && $block->getId() !== 10 && $block->getId() !== 11) {
            return true;
        }

        $radius = 2.5;
        $posVec = new Vector3($this->x, $this->y, $this->z);

        foreach ($this->level->getEntities() as $entity) {
            if ($entity === $this->player) continue;
            if (!$entity->isAlive()) continue;

            if ($entity instanceof Player) {
                if (!$this->plugin->canTargetPlayer($this->player->getName(), $entity)) continue;
            } elseif (!($entity instanceof NPCEntity) && !($entity instanceof FactoryEntity)) {
                continue;
            }

            if ($entity->distance($posVec) <= $radius) {
                return true;
            }
        }
        return false;
    }

    private function explode() {
        if (!empty($this->fistEids)) {
            BlockEffects::voidAndRemove($this->plugin, $this->level, $this->fistEids);
            $this->fistEids = [];
        }

        $pos = new Vector3($this->x, $this->y, $this->z);
        $this->level->addSound(new ExplodeSound($pos));
        $this->level->addParticle(new HugeExplodeParticle($pos));

        $groundY = $this->y;
        while ($groundY > 0) {
            $checkBlock = $this->level->getBlockIdAt((int)$this->x, (int)$groundY - 1, (int)$this->z);
            if ($checkBlock !== 0 && $checkBlock !== 8 && $checkBlock !== 9) {
                break;
            }
            $groundY--;
        }

        $blocks = [291, 415];
        $debris = [];
        for ($i = 0; $i < 15; $i++) {
            $angle = ($i / 15) * M_PI * 2 + (mt_rand(-30, 30) / 100);
            $speed = 1.0 + (mt_rand(0, 100) / 100) * 1.5;
            $b = $blocks[array_rand($blocks)];
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($this->level, $eid, $b, 0, $this->x, $this->y + 0.5, $this->z);
            $debris[$eid] = [
                "eid" => $eid, "x" => $this->x, "y" => $this->y + 0.5, "z" => $this->z,
                "vx" => cos($angle) * $speed, "vy" => 0.5 + mt_rand(0, 40) / 100, "vz" => sin($angle) * $speed,
                "life" => 20 + mt_rand(0, 10), "tick" => 0
            ];
        }

        foreach ($this->level->getEntities() as $entity) {
            if ($entity === $this->player) continue;
            if (!$entity->isAlive()) continue;

            if ($entity instanceof Player) {
                if (!$this->plugin->canTargetPlayer($this->player->getName(), $entity)) continue;
            } elseif (!($entity instanceof NPCEntity) && !($entity instanceof FactoryEntity)) {
                continue;
            }

            if ($entity->distance($pos) <= 6.0) {
                $ev = new EntityDamageByEntityEvent($this->player, $entity, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage);
                $entity->attack($this->damage, $ev);
                BaseFruit::staticSafeSetOnFire($this->player, $entity, 5);

                $dx = $entity->x - $this->x;
                $dz = $entity->z - $this->z;
                $len = sqrt($dx * $dx + $dz * $dz);
                if ($len > 0) {
                    BaseFruit::staticSafeSetMotion($this->player, $entity, new Vector3($dx / $len * 1.5, 0.6, $dz / $len * 1.5));
                }
            }
        }

        $puddleTask = new MagmaPuddleTask($this->plugin, $this->player, $this->x, $groundY, $this->z, $this->damage * 0.3, $debris);
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($puddleTask, 1);

        $this->cleanup();
    }

    private function cleanup() {
        if (!empty($this->fistEids)) {
            BlockEffects::voidAndRemove($this->plugin, $this->level, $this->fistEids);
            $this->fistEids = [];
        }
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class MagmaPuddleTask extends Task {

    private $plugin;
    private $player;
    private $level;
    private $cx, $cy, $cz;
    private $damage;
    private $ticksRan = 0;
    private $maxTicks = 100;
    private $debris;
    private $puddleEids = [];

    public function __construct($plugin, Player $player, $cx, $cy, $cz, $damage, $debris) {
        $this->plugin = $plugin;
        $this->player = $player;
        $this->level = $player->getLevel();
        $this->cx = $cx;
        $this->cy = $cy;
        $this->cz = $cz;
        $this->damage = $damage;
        $this->debris = $debris;

        $blocks = [291, 415]; 
        for ($i = 0; $i < 12; $i++) {
            $angle = ($i / 12) * M_PI * 2;
            $r = mt_rand(5, 35) / 10;
            $eid = BlockEffects::newEid();
            $b = $blocks[array_rand($blocks)];
            BlockEffects::sendSpawn($this->level, $eid, $b, 0, $this->cx + cos($angle)*$r, $this->cy, $this->cz + sin($angle)*$r);
            $this->puddleEids[] = $eid;
        }
    }

    public function onRun($currentTick) {
        $this->ticksRan++;

        if ($this->ticksRan > $this->maxTicks) {
            $this->cleanup();
            return;
        }

        if (!empty($this->debris)) {
            $toRemove = BlockEffects::tickDebris($this->debris, $this->level, -50, 0.12, 0.90);
            foreach ($toRemove as $eid) unset($this->debris[$eid]);
        }

        $radius = 4.5;
        
        for ($i = 0; $i < 3; $i++) {
            $angle = mt_rand(0, 628) / 100;
            $r = mt_rand(0, (int)($radius * 10)) / 10;
            $x = $this->cx + cos($angle) * $r;
            $z = $this->cz + sin($angle) * $r;
            
            $this->level->addParticle(new DustParticle(new Vector3($x, $this->cy + 0.5, $z), 255, 100, 0));
            $this->level->addParticle(new FlameParticle(new Vector3($x, $this->cy + 0.5, $z)));
        }

        if ($this->ticksRan % 10 === 0) {
            $this->level->addSound(new FizzSound(new Vector3($this->cx, $this->cy, $this->cz)));
            
            if ($this->player !== null && $this->player->isOnline()) {
                $pos = new Vector3($this->cx, $this->cy, $this->cz);
                foreach ($this->level->getEntities() as $entity) {
                    if ($entity === $this->player) continue;
                    if (!$entity->isAlive()) continue;

                    if ($entity instanceof Player) {
                        if (!$this->plugin->canTargetPlayer($this->player->getName(), $entity)) continue;
                    } elseif (!($entity instanceof NPCEntity) && !($entity instanceof FactoryEntity)) {
                        continue;
                    }

                    if ($entity->distance($pos) <= $radius) {
                        $ev = new EntityDamageByEntityEvent($this->player, $entity, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage);
                        $entity->attack($this->damage, $ev);
                        BaseFruit::staticSafeSetOnFire($this->player, $entity, 3);
                    }
                }
            }
        }
    }

    private function cleanup() {
        if (!empty($this->debris)) {
            BlockEffects::voidAndRemove($this->plugin, $this->level, array_keys($this->debris));
            $this->debris = [];
        }
        if (!empty($this->puddleEids)) {
            BlockEffects::voidAndRemove($this->plugin, $this->level, $this->puddleEids);
            $this->puddleEids = [];
        }
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class MagmaHoundTask extends Task {

    private $plugin;
    private $player;
    private $level;
    private $damage;
    private $ticksRan = 0;
    private $maxTicks;
    private $debris = [];
    private $isExploded = false;
    private $postExplosionTicks = 0;

    public function __construct($plugin, Player $player, $damage, $maxTicks) {
        $this->plugin = $plugin;
        $this->player = $player;
        $this->level = $player->getLevel();
        $this->damage = $damage;
        $this->maxTicks = $maxTicks;
    }

    public function onRun($currentTick) {
        if ($this->player === null || !$this->player->isOnline() || !$this->player->isAlive()) {
            $this->cleanup();
            return;
        }

        $pos = $this->player->getPosition();

        if ($this->isExploded) {
            $this->postExplosionTicks++;
            if ($this->postExplosionTicks > 35) {
                $this->cleanup();
                return;
            }
            if (!empty($this->debris)) {
                $toRemove = BlockEffects::tickDebris($this->debris, $this->level, -50, 0.12, 0.85);
                foreach ($toRemove as $eid) unset($this->debris[$eid]);
            }
            return;
        }

        $this->ticksRan++;

        $res = Effect::getEffect(Effect::DAMAGE_RESISTANCE);
        $res->setAmplifier(5);
        $res->setDuration(10);
        $res->setVisible(false);
        $this->player->addEffect($res);

        if ($this->ticksRan > $this->maxTicks) {
            $this->finalBurst($pos);
            $this->isExploded = true;
            return;
        }

        $this->spawnHoundVFX($pos);
        $this->trapAndDamageEntities($pos, 10.0); 

        if ($this->ticksRan % 4 === 0) {
            $blocks = [291, 415];
            $angle = mt_rand(0, 628) / 100;
            $b = $blocks[array_rand($blocks)];
            $eid = BlockEffects::newEid();
            
            $radius = 3.0;
            BlockEffects::sendSpawn($this->level, $eid, $b, 0, $pos->x + cos($angle)*$radius, $pos->y - 0.5, $pos->z + sin($angle)*$radius);
            
            $this->debris[$eid] = [
                "eid" => $eid, "angle" => $angle, "radius" => $radius, "baseY" => $pos->y,
                "life" => 15, "tick" => 0
            ];
        }

        if (!empty($this->debris)) {
            $toRemove = BlockEffects::tickSpiralDebris($this->debris, $this->level, $pos->x, $pos->z, 0.35, 0.2, 0.05);
            foreach ($toRemove as $eid) unset($this->debris[$eid]);
        }
    }

    private function spawnHoundVFX(Vector3 $pos) {
        $dir = $this->player->getDirectionVector();
        
        for ($i = 0; $i < 8; $i++) {
            $ox = (mt_rand(-20, 20) / 10);
            $oy = (mt_rand(0, 30) / 10);
            $oz = (mt_rand(-20, 20) / 10);
            
            $this->level->addParticle(new DustParticle(new Vector3($pos->x + $ox, $pos->y + $oy, $pos->z + $oz), 255, 100, 0));
            $this->level->addParticle(new FlameParticle(new Vector3($pos->x + $ox, $pos->y + $oy, $pos->z + $oz)));
        }

        $headX = $pos->x + $dir->x * 2.0;
        $headY = $pos->y + $dir->y * 2.0 + 1.5;
        $headZ = $pos->z + $dir->z * 2.0;

        for ($i = 0; $i < 5; $i++) {
            $ox = (mt_rand(-10, 10) / 10);
            $oy = (mt_rand(-10, 10) / 10);
            $oz = (mt_rand(-10, 10) / 10);
            $this->level->addParticle(new DustParticle(new Vector3($headX + $ox, $headY + $oy, $headZ + $oz), 255, 100, 0));
            $this->level->addParticle(new FlameParticle(new Vector3($headX + $ox, $headY + $oy, $headZ + $oz)));
        }
        
        if ($this->ticksRan % 3 === 0) {
            $this->level->addSound(new FizzSound($pos));
        }
    }

    private function trapAndDamageEntities(Vector3 $pos, $pullRadius) {
        foreach ($this->level->getEntities() as $entity) {
            if ($entity === $this->player) continue;
            if (!$entity->isAlive()) continue;

            if ($entity instanceof Player) {
                if (!$this->plugin->canTargetPlayer($this->player->getName(), $entity)) continue;
            } elseif (!($entity instanceof NPCEntity) && !($entity instanceof FactoryEntity)) {
                continue;
            }

            $dist = $entity->distance($pos);
            if ($dist <= $pullRadius) {
                $dx = $pos->x - $entity->x;
                $dz = $pos->z - $entity->z;
                $len = sqrt($dx * $dx + $dz * $dz);
                
                $weak = Effect::getEffect(Effect::WEAKNESS);
                $weak->setAmplifier(5);
                $weak->setDuration(20);
                $weak->setVisible(false);
                BaseFruit::staticSafeAddEffect($this->player, $entity, $weak);
                
                $hoverY = $pos->y + 2.5;
                $motY = ($entity->y < $hoverY) ? 0.2 : -0.1;

                if ($len > 1.5) {
                    $pullForce = min(0.8, 3.5 / $len);
                    BaseFruit::staticSafeSetMotion($this->player, $entity, new Vector3($dx / $len * $pullForce, $motY, $dz / $len * $pullForce));
                } else {
                    BaseFruit::staticSafeSetMotion($this->player, $entity, new Vector3(0, $motY, 0));
                }

                if ($this->ticksRan % 10 === 0 && $dist <= 4.0) {
                    $ev = new EntityDamageByEntityEvent($this->player, $entity, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage * 0.5);
                    $entity->attack($this->damage * 0.5, $ev);
                    BaseFruit::staticSafeSetOnFire($this->player, $entity, 3);
                }
            }
        }
    }

    private function finalBurst(Vector3 $pos) {
        $this->level->addSound(new ExplodeSound($pos));
        $this->level->addParticle(new HugeExplodeParticle($pos));

        if (!empty($this->debris)) {
            BlockEffects::voidAndRemove($this->plugin, $this->level, array_keys($this->debris));
            $this->debris = [];
        }

        $blocks = [291, 415];
        for ($i = 0; $i < 30; $i++) {
            $angle = ($i / 30) * M_PI * 2 + (mt_rand(-30, 30) / 100);
            $speed = 1.0 + (mt_rand(0, 100) / 100) * 2.0;
            $b = $blocks[array_rand($blocks)];
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($this->level, $eid, $b, 0, $pos->x, $pos->y + 0.5, $pos->z);
            $this->debris[$eid] = [
                "eid" => $eid, "x" => $pos->x, "y" => $pos->y + 0.5, "z" => $pos->z,
                "vx" => cos($angle) * $speed, "vy" => 0.8 + mt_rand(0, 50) / 100, "vz" => sin($angle) * $speed,
                "life" => 30 + mt_rand(0, 15), "tick" => 0
            ];
        }

        for ($i = 0; $i < 30; $i++) {
            $a = ($i / 30) * M_PI * 2;
            $x = $pos->x + cos($a) * 6;
            $z = $pos->z + sin($a) * 6;
            $this->level->addParticle(new DustParticle(new Vector3($x, $pos->y + 1, $z), 255, 100, 0));
            $this->level->addParticle(new SmokeParticle(new Vector3($x, $pos->y + 1, $z)));
        }

        foreach ($this->level->getEntities() as $entity) {
            if ($entity === $this->player) continue;
            if (!$entity->isAlive()) continue;

            if ($entity instanceof Player) {
                if (!$this->plugin->canTargetPlayer($this->player->getName(), $entity)) continue;
            } elseif (!($entity instanceof NPCEntity) && !($entity instanceof FactoryEntity)) {
                continue;
            }

            if ($entity->distance($pos) <= 10.0) {
                $ev = new EntityDamageByEntityEvent($this->player, $entity, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage * 1.8);
                $entity->attack($this->damage * 1.8, $ev);
                BaseFruit::staticSafeSetOnFire($this->player, $entity, 8);

                $dx = $entity->x - $pos->x;
                $dz = $entity->z - $pos->z;
                $len = sqrt($dx * $dx + $dz * $dz);
                if ($len > 0) {
                    BaseFruit::staticSafeSetMotion($this->player, $entity, new Vector3($dx / $len * 2.5, 1.0, $dz / $len * 2.5));
                }
            }
        }
    }

    private function cleanup() {
        if (!empty($this->debris)) {
            BlockEffects::voidAndRemove($this->plugin, $this->level, array_keys($this->debris));
            $this->debris = [];
        }
        if ($this->player !== null && $this->player->isOnline()) {
            $this->player->removeEffect(Effect::DAMAGE_RESISTANCE);
        }
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}