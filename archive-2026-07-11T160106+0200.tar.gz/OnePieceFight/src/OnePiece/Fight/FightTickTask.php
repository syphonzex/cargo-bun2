<?php

namespace OnePiece\Fight;

use pocketmine\scheduler\PluginTask;
use pocketmine\item\Item;

class FightTickTask extends PluginTask {

    private $plugin;
    private $lastHeld = [];

    public function __construct(Main $plugin) {
        parent::__construct($plugin);
        $this->plugin = $plugin;
    }

    public function onRun($currentTick) {
        $this->plugin->getSwordMastery()->tickCooldowns();
        $this->plugin->getStyleMastery()->tickCooldowns();

        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if (!$this->plugin->isInOPWorld($player)) {
                unset($this->lastHeld[$player->getName()]);
                continue;
            }

            $name = $player->getName();
            $slot = $player->getInventory()->getHeldItemSlot();
            $item = $player->getInventory()->getItemInHand();
            $lastSlot = isset($this->lastHeld[$name]) ? $this->lastHeld[$name] : -1;

            if ($slot !== $lastSlot && $item->getId() === Item::AIR) {
                $mode = $this->plugin->getPlayerMode($player);
                if ($mode === "style") {
                    $style = $this->plugin->getStyleManager()->getPlayerStyle($player);
                    if ($style !== null) {
                        $player->sendTip($style->getRarityColor() . $style->getDisplayName() . " §8| §7Tap §8| §7Sneak+Tap");
                    } else {
                        $player->sendTip("§7Combat");
                    }
                } else {
                    if ($slot !== 0) {
                        $player->sendTip("§7Combat");
                    }
                }
            }

            $this->lastHeld[$name] = $slot;
        }
    }
}