<?php

namespace OnePiece\Fight\FightingStyles;

use OnePiece\Fight\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class StyleCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("style", "Fighting Style commands", "/style <equip|buy|info|list>", ["fstyle"]);
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (empty($args)) {
            if ($sender instanceof Player) return $this->showInfo($sender);
            return false;
        }

        switch (strtolower($args[0])) {
            case "buy":
                return $this->handleBuy($sender, $args);
            case "equip":
                if ($sender instanceof Player) return $this->handleEquip($sender, $args);
                return false;
            case "give":
                return $this->handleGive($sender, $args);
            case "force":
                return $this->handleForce($sender, $args);
            case "remove":
                return $this->handleRemove($sender, $args);
            case "info":
                if ($sender instanceof Player) return $this->showInfo($sender);
                return false;
            case "list":
                if ($sender instanceof Player) return $this->showList($sender);
                return false;
            default:
                if ($sender instanceof Player) return $this->showInfo($sender);
                return false;
        }
    }

    private function handleBuy(CommandSender $sender, array $args) {
        if (count($args) < 3) {
            $sender->sendMessage("§cUsage: /style buy <player> <styleId>");
            return true;
        }

        $target = $this->plugin->getServer()->getPlayerExact($args[1]);
        if ($target === null) {
            $sender->sendMessage("§cPlayer not found.");
            return true;
        }

        $styleId = strtolower($args[2]);
        $style = $this->plugin->getStyleManager()->getStyle($styleId);
        if ($style === null) {
            $sender->sendMessage("§cUnknown style.");
            return true;
        }

        if ($target->getExpLevel() < $style->getLevelRequirement()) {
            $target->sendMessage("§cYou need Level " . $style->getLevelRequirement() . " to obtain this style!");
            return true;
        }

        if ($this->plugin->getStyleMastery()->hasStyle($target->getName(), $styleId)) {
            $this->plugin->getStyleManager()->equipStyle($target, $styleId);
            $this->plugin->setPlayerMode($target, "style");
            $this->plugin->updateWeaponSlot($target);
            $target->sendMessage("§eYou have switched to " . $style->getDisplayName() . ".");
            return true;
        }

        $price = 0;
        switch($styleId) {
            case "black_leg": $price = 50000; break;
            case "fishman_karate": $price = 200000; break;
            case "dragon_breath": $price = 1000000; break;
            case "superhuman": $price = 5000000; break;
            default: $price = 0; break;
        }

        $berryPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceBerry");
        if ($berryPlugin === null) {
            $sender->sendMessage("§cBerry system not found. Transaction aborted.");
            return true;
        }

        $bm = $berryPlugin->getBerryManager();
        if (!$bm->has($target->getName(), $price)) {
            $target->sendMessage("§cYou need §e" . $bm->format($price) . " §cto learn this style! You have: §e" . $bm->format($bm->get($target->getName())));
            return true;
        }

        $bm->remove($target->getName(), $price);
        $this->plugin->getStyleManager()->giveStyle($target, $styleId);
        $this->plugin->getStyleManager()->equipStyle($target, $styleId);
        
        $target->sendMessage("§a§l[SHOP] §r§aYou learned §f" . $style->getDisplayName() . " §afor §e" . $bm->format($price) . "§a!");
        $this->plugin->setPlayerMode($target, "style");
        $this->plugin->updateWeaponSlot($target);

        return true;
    }

    private function showInfo(Player $sender) {
        $mast = $this->plugin->getStyleMastery();
        $sm   = $this->plugin->getStyleManager();
        $name = $sender->getName();

        $sender->sendMessage(TextFormat::GOLD . "==============================");
        $sender->sendMessage(TextFormat::GOLD . "  Fighting Style Info");
        $sender->sendMessage(TextFormat::GOLD . "==============================");

        $owned = $mast->getOwnedStyles($name);
        if (empty($owned)) {
            $sender->sendMessage(TextFormat::GRAY . "You don't own any fighting styles.");
        } else {
            $equipped = $mast->getEquipped($name);
            $sender->sendMessage(TextFormat::YELLOW . "Owned Styles:");
            foreach ($owned as $sId => $data) {
                $style = $sm->getStyle($sId);
                if ($style === null) continue;
                $lv = isset($data["level"]) ? $data["level"] : 1;
                $tag = ($sId === $equipped) ? " §a[EQUIPPED]" : "";
                $sender->sendMessage($style->getRarityColor() . "  " . $style->getDisplayName() . " §7- Mastery Lv." . $lv . $tag);
            }

            if ($equipped !== null) {
                $style = $sm->getStyle($equipped);
                if ($style !== null) {
                    $level = $mast->getLevel($name);
                    $exp   = $mast->getExp($name);
                    $next  = $mast->getExpToNext($name);
                    $bar   = $mast->getProgressBar($name);

                    $sender->sendMessage("");
                    $sender->sendMessage(TextFormat::GOLD . "Equipped: " . $style->getRarityColor() . $style->getDisplayName());
                    $sender->sendMessage(TextFormat::YELLOW . "Mastery: " . TextFormat::WHITE . "Lv." . $level . " " . $bar);
                    $sender->sendMessage(TextFormat::YELLOW . "EXP: " . TextFormat::WHITE . $exp . "/" . $next);

                    $abilNames = $style->getAbilityNames();
                    $abilCds   = $style->getAbilityCooldowns();
                    $a1unlocked = $mast->canUseAbility($name, "ability1");
                    $a2unlocked = $mast->canUseAbility($name, "ability2");
                    $a1name = isset($abilNames["ability1"]) ? $abilNames["ability1"] : "Ability 1";
                    $a2name = isset($abilNames["ability2"]) ? $abilNames["ability2"] : "Ability 2";
                    $a1cd   = isset($abilCds["ability1"])   ? $abilCds["ability1"]   : 0;
                    $a2cd   = isset($abilCds["ability2"])   ? $abilCds["ability2"]   : 0;

                    $sender->sendMessage(TextFormat::YELLOW . "Tap: " . ($a1unlocked ? TextFormat::WHITE . $a1name . " §7(" . $a1cd . "s cd)" : TextFormat::RED . "[LOCKED Lv.25]"));
                    $sender->sendMessage(TextFormat::YELLOW . "Sneak+Tap: " . ($a2unlocked ? TextFormat::WHITE . $a2name . " §7(" . $a2cd . "s cd)" : TextFormat::RED . "[LOCKED Lv.50]"));
                }
            }
        }

        $sender->sendMessage(TextFormat::GOLD . "==============================");
        return true;
    }

    private function showList(Player $sender) {
        $mast = $this->plugin->getStyleMastery();
        $name = $sender->getName();

        $sender->sendMessage(TextFormat::GOLD . "==============================");
        $sender->sendMessage(TextFormat::GOLD . "  Fighting Styles");
        $sender->sendMessage(TextFormat::GOLD . "==============================");

        foreach ($this->plugin->getStyleManager()->getAllStyles() as $style) {
            $owned = $mast->hasStyle($name, $style->getId()) ? " §a[OWNED]" : "";
            $sender->sendMessage(
                $style->getRarityColor() . $style->getDisplayName() .
                TextFormat::GRAY . " | Lv." . $style->getLevelRequirement() .
                " | ID: " . $style->getId() . $owned
            );
        }

        $sender->sendMessage(TextFormat::GRAY . "Use /style equip <id> to equip an owned style.");
        $sender->sendMessage(TextFormat::GOLD . "==============================");
        return true;
    }

    private function handleEquip(Player $sender, array $args) {
        if (count($args) < 2) {
            $sender->sendMessage(TextFormat::RED . "Usage: /style equip <styleId>");
            return true;
        }

        $styleId = strtolower($args[1]);
        $this->plugin->getStyleManager()->equipStyle($sender, $styleId);

        if ($this->plugin->getPlayerMode($sender) === "style") {
            $this->plugin->updateWeaponSlot($sender);
        }

        return true;
    }

    private function handleForce(CommandSender $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only!");
            return true;
        }

        if (count($args) < 3) {
            $sender->sendMessage(TextFormat::RED . "Usage: /style force <player> <styleId>");
            return true;
        }

        $target = $this->plugin->getServer()->getPlayerExact($args[1]);
        if ($target === null) {
            $sender->sendMessage(TextFormat::RED . "Player not found!");
            return true;
        }

        $styleId = strtolower($args[2]);
        if ($this->plugin->getStyleManager()->getStyle($styleId) === null) {
            $sender->sendMessage(TextFormat::RED . "Unknown style: " . $styleId);
            return true;
        }

        $this->plugin->getStyleManager()->forceStyle($target, $styleId);
        $sender->sendMessage(TextFormat::GREEN . "Force-given " . $styleId . " to " . $target->getName());
        return true;
    }

    private function handleGive(CommandSender $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only!");
            return true;
        }

        if (count($args) < 3) {
            $sender->sendMessage(TextFormat::RED . "Usage: /style give <player> <styleId>");
            return true;
        }

        $target = $this->plugin->getServer()->getPlayerExact($args[1]);
        if ($target === null) {
            $sender->sendMessage(TextFormat::RED . "Player not found!");
            return true;
        }

        $styleId = strtolower($args[2]);
        if ($this->plugin->getStyleManager()->getStyle($styleId) === null) {
            $sender->sendMessage(TextFormat::RED . "Unknown style: " . $styleId);
            return true;
        }

        $this->plugin->getStyleManager()->giveStyle($target, $styleId);
        $sender->sendMessage(TextFormat::GREEN . "Given " . $styleId . " to " . $target->getName());
        return true;
    }

    private function handleRemove(CommandSender $sender, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage(TextFormat::RED . "OP only!");
            return true;
        }

        if (count($args) < 2) {
            $sender->sendMessage(TextFormat::RED . "Usage: /style remove <player> [styleId]");
            return true;
        }

        $target = $this->plugin->getServer()->getPlayerExact($args[1]);
        if ($target === null) {
            $sender->sendMessage(TextFormat::RED . "Player not found!");
            return true;
        }

        $styleId = isset($args[2]) ? strtolower($args[2]) : null;
        $this->plugin->getStyleManager()->removeStyle($target, $styleId);
        $sender->sendMessage(TextFormat::GREEN . "Removed style from " . $target->getName());
        return true;
    }
}