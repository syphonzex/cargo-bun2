<?php

namespace OnePiece\Fight\FightingStyles\styles;

use OnePiece\Fight\FightingStyles\BaseFightingStyle;
use OnePiece\Fight\Main;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\particle\InkParticle;
use pocketmine\level\particle\HappyVillagerParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\particle\InstantEnchantParticle;
use pocketmine\level\sound\AnvilFallSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\ExplodeSound;
use pocketmine\level\sound\GhastShootSound;
use pocketmine\level\sound\EndermanTeleportSound;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\item\Item;
use pocketmine\scheduler\Task;
use OnePiece\Devil\BlockEffects;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;

class Superhuman extends BaseFightingStyle {

    public function getId()               { return "superhuman"; }
    public function getDisplayName()      { return "Superhuman"; }
    public function getItemId()           { return Item::AIR; }
    public function getLevelRequirement() { return 700; }
    public function getRarity()           { return "mythical"; }

    public function getAbilityNames() {
        return [
            "ability1" => "Conqueror Fist",
            "ability2" => "Storm Barrage",
        ];
    }

    public function getAbilityCooldowns() {
        return [
            "ability1" => 12,
            "ability2" => 30,
        ];
    }

    public function useAbility(Player $player, $ability) {
        if ($ability === "ability1") return $this->conquerorFist($player);
        if ($ability === "ability2") return $this->stormBarrage($player);
        return 0;
    }

    private function conquerorFist(Player $player) {
        $target = $this->findFrontTarget($player, 7.0);
        if ($target === null) return 0;

        if ($target instanceof Player) {
            if (!$this->plugin->canTargetPlayer($player->getName(), $target)) return 0;
        } elseif (!($target instanceof NPCEntity) && !($target instanceof FactoryEntity)) {
            return 0;
        }

        $damage = $this->getStyleDamage($player, 16.0);
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(new ConquerorFistTask($this->plugin, $this, $player, $target, $damage), 1);
        $player->getLevel()->addSound(new GhastShootSound($player->getPosition()));
        return 12;
    }

    private function stormBarrage(Player $player) {
        $target = $this->findFrontTarget($player, 8.0);
        if ($target === null) return 0;

        if ($target instanceof Player) {
            if (!$this->plugin->canTargetPlayer($player->getName(), $target)) return 0;
        } elseif (!($target instanceof NPCEntity) && !($target instanceof FactoryEntity)) {
            return 0;
        }

        $damage = $this->getStyleDamage($player, 5.5);
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(new SuperhumanBarrageTask($this->plugin, $this, $player, $target, $damage), 1);
        $player->getLevel()->addSound(new EndermanTeleportSound($player->getPosition()));
        return 30;
    }
}

class ConquerorFistTask extends Task {
    private $plugin, $style, $player, $target, $damage, $ticks = 0;

    public function __construct($plugin, $style, $player, $target, $damage) {
        $this->plugin = $plugin; $this->style = $style; $this->player = $player;
        $this->target = $target; $this->damage = $damage;
    }

    public function onRun($currentTick) {
        if (!$this->player->isOnline() || !$this->target->isAlive()) { $this->cleanup(); return; }
        $this->ticks++;

        if ($this->ticks < 10) {
            $this->player->setMotion(new Vector3(0, 0, 0));
            for ($i = 0; $i < 5; $i++) {
                $angle = $i * M_PI / 2.5 + $this->ticks;
                $v = $this->player->getPosition()->add(cos($angle) * 1.5, 1.2, sin($angle) * 1.5);
                $this->player->getLevel()->addParticle(new InkParticle($v));
                $this->player->getLevel()->addParticle(new HappyVillagerParticle($v));
            }
            return;
        }

        $lv = $this->player->getLevel();
        $pos = $this->target->getPosition();
        
        $this->target->attack($this->damage, new EntityDamageByEntityEvent($this->player, $this->target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage));
        $this->target->setMotion($this->player->getDirectionVector()->multiply(3.2)->add(0, 0.8, 0));

        $lv->addParticle(new HugeExplodeParticle($pos->add(0, 1, 0)));
        $lv->addSound(new ExplodeSound($pos));
        $lv->addSound(new AnvilFallSound($pos));

        $eids = BlockEffects::spawnDebris($this->plugin, $lv, $pos->x, $pos->y + 1, $pos->z, 12, 1.5, 2.5, 40);
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(new \OnePiece\Devil\fruits\DarkQuakeDebrisTask($this->plugin, $lv, $eids), 1);

        for ($i = 0; $i < 30; $i++) {
            $a = ($i / 30) * M_PI * 2;
            $v = $pos->add(cos($a) * 3.5, 0.5, sin($a) * 3.5);
            $lv->addParticle(new InkParticle($v));
            $lv->addParticle(new PortalParticle($v));
            if ($i % 3 === 0) $lv->addParticle(new HappyVillagerParticle($v));
        }

        $this->cleanup();
    }

    private function cleanup() {
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}

class SuperhumanBarrageTask extends Task {
    private $plugin, $style, $player, $target, $damage, $ticks = 0, $hits = 0;
    private $lockPos;

    public function __construct($plugin, $style, $player, $target, $damage) {
        $this->plugin = $plugin; $this->style = $style; $this->player = $player;
        $this->target = $target; $this->damage = $damage;
        $this->lockPos = $target->getPosition();
    }

    public function onRun($currentTick) {
        if (!$this->player->isOnline() || !$this->target->isAlive() || $this->hits >= 5) { $this->cleanup(); return; }
        $this->ticks++;

        $this->target->teleport($this->lockPos);
        $this->target->setMotion(new Vector3(0, 0, 0));

        if ($this->ticks % 4 === 0) {
            $this->hits++;
            $angles = [0, 90, 180, 270, 0, 45]; // Added extra for index safety
            $a = deg2rad($angles[$this->hits - 1]);
            
            $newPos = $this->lockPos->add(cos($a) * 3, 0, sin($a) * 3);
            
            // Manual lookAt calculation for 0.14.3
            $xdiff = $this->lockPos->x - $newPos->x;
            $zdiff = $this->lockPos->z - $newPos->z;
            $angle = atan2($zdiff, $xdiff);
            $yaw = ($angle * 180 / M_PI) - 90;
            if ($yaw < 0) $yaw += 360;

            $this->player->teleport($newPos);
            $this->player->setRotation($yaw, 0);

            $lv = $this->player->getLevel();
            $this->target->attack($this->damage, new EntityDamageByEntityEvent($this->player, $this->target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage));
            $lv->addSound(new AnvilUseSound($this->lockPos));

            for ($i = 0; $i < 12; $i++) {
                $v = $this->lockPos->add(mt_rand(-10, 10)/10, mt_rand(5, 20)/10, mt_rand(-10, 10)/10);
                $lv->addParticle(new InkParticle($v));
                $lv->addParticle(new CriticalParticle($v));
                if ($i % 4 === 0) $lv->addParticle(new InstantEnchantParticle($v));
            }

            if ($this->hits === 5) {
                $lv->addParticle(new HugeExplodeParticle($this->lockPos->add(0, 1, 0)));
                $lv->addSound(new ExplodeSound($this->lockPos));
                $this->target->setMotion(new Vector3(0, 2.8, 0));
            }
        }
    }

    private function cleanup() {
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}