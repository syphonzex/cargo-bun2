<?php

namespace OnePiece\Fight\FightingStyles\styles;

use OnePiece\Fight\Main;
use OnePiece\Fight\FightingStyles\BaseFightingStyle;
use pocketmine\Player;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\entity\Effect;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\sound\ExplodeSound;

class BlackLeg extends BaseFightingStyle {

    public function __construct(Main $plugin) {
        parent::__construct($plugin);
    }

    public function getId()               { return "black_leg"; }
    public function getDisplayName()      { return "Black Leg"; }
    public function getItemId()           { return Item::AIR; }
    public function getLevelRequirement() { return 50; }
    public function getRarity()           { return "rare"; }

    public function getAbilityNames() {
        return [
            "ability1" => "Diable Jambe",
            "ability2" => "Premier Coup de Vent",
        ];
    }

    public function getAbilityCooldowns() {
        return [
            "ability1" => 7,
            "ability2" => 18,
        ];
    }

    public function useAbility(Player $player, $ability) {
        if ($ability === "ability1") {
            return $this->diableJambe($player);
        } elseif ($ability === "ability2") {
            return $this->premierCoupDeVent($player);
        }
        return 0;
    }

    private function diableJambe(Player $player) {
        $target = $this->findFrontTarget($player, 6);

        if ($target === null) {
            $player->sendTip("§c[Black Leg] No target found!");
            $this->spawnFireKickParticles($player);
            return 0;
        }

        $base = 2;
        $damage = $this->getStyleDamage($player, $base);

        $this->spawnDiableJambeEffect($player, $target);

        $this->dealDamage($player, $target, $damage);

        $target->setOnFire(2);

        $dir = $target->subtract($player)->normalize();
        $kb = min(5, 2);
        //$target->setMotion(new Vector3($dir->x * $kb, 0.35, $dir->z * $kb));

        $player->sendTip("§6[Black Leg] §eDiable Jambe! §f" . round($damage, 1) . " DMG");

        if ($target instanceof Player) {
            $target->sendTip("§c[BURNING] §f" . round($damage, 1) . " damage!");
        }

        return 7;
    }

    private function premierCoupDeVent(Player $player) {
        $targets = $this->getNearbyTargets($player, 6);

        $this->spawnWindKickEffect($player);

        if (empty($targets)) {
            $player->sendTip("§c[Black Leg] No targets in range!");
            return 0;
        }

        $base = 5;
        $damage = $this->getStyleDamage($player, $base);
        $hitCount = 0;

        foreach ($targets as $target) {
            $this->dealDamage($player, $target, $damage);

            $dir = $target->subtract($player);
            $dist = $dir->length();
            if ($dist > 0) {
                $dir = $dir->normalize();
            } else {
                $dir = $player->getDirectionVector();
            }

            $kbStr = min(2, 1);
            $target->setMotion(new Vector3($dir->x * $kbStr, 0.5, $dir->z * $kbStr));

            if ($target instanceof Player) {
                $target->sendTip("§b[WIND BLAST] §f" . round($damage, 1) . " damage!");
            }

            $hitCount++;
        }

        $player->sendTip("§6[Black Leg] §bPremier Coup de Vent! §fHit " . $hitCount . " target(s) for " . round($damage, 1) . " DMG");

        return 18;
    }

    private function spawnFireKickParticles(Player $player) {
        $level = $player->getLevel();
        $dir = $player->getDirectionVector();
        $pos = $player->add(0, 1, 0);

        for ($i = 1; $i <= 6; $i++) {
            $p = $pos->add($dir->x * $i, $dir->y * $i, $dir->z * $i);
            $level->addParticle(new FlameParticle($p));
            $level->addParticle(new FlameParticle($p->add(
                (mt_rand(-3, 3) / 10),
                (mt_rand(-3, 3) / 10),
                (mt_rand(-3, 3) / 10)
            )));
        }
    }

    private function spawnDiableJambeEffect(Player $player, $target) {
        $level = $player->getLevel();
        $start = $player->add(0, 1, 0);
        $end = $target->add(0, 1, 0);
        $dir = $end->subtract($start);
        $dist = $start->distance($end);

        if ($dist <= 0) return;

        $steps = (int)($dist * 3);
        for ($i = 0; $i <= $steps; $i++) {
            $progress = $i / max(1, $steps);
            $p = new Vector3(
                $start->x + $dir->x * $progress,
                $start->y + $dir->y * $progress,
                $start->z + $dir->z * $progress
            );
            $level->addParticle(new FlameParticle($p));
            $level->addParticle(new FlameParticle($p->add(
                (mt_rand(-2, 2) / 10),
                (mt_rand(-2, 2) / 10),
                (mt_rand(-2, 2) / 10)
            )));
        }

        $tp = $target->add(0, 1, 0);
        for ($i = 0; $i < 8; $i++) {
            $level->addParticle(new FlameParticle($tp->add(
                (mt_rand(-5, 5) / 10),
                (mt_rand(-5, 5) / 10),
                (mt_rand(-5, 5) / 10)
            )));
        }

        for ($i = 0; $i < 4; $i++) {
            $level->addParticle(new SmokeParticle($tp->add(
                (mt_rand(-5, 5) / 10),
                (mt_rand(0, 10) / 10),
                (mt_rand(-5, 5) / 10)
            )));
        }
    }

    private function spawnWindKickEffect(Player $player) {
        $level = $player->getLevel();
        $center = $player->add(0, 1, 0);

        $level->addSound(new ExplodeSound($center));

        for ($angle = 0; $angle < 360; $angle += 15) {
            $rad = deg2rad($angle);
            for ($r = 1; $r <= 6; $r++) {
                $x = $center->x + cos($rad) * $r;
                $z = $center->z + sin($rad) * $r;
                $y = $center->y + ($r * 0.05);
                $level->addParticle(new SmokeParticle(new Vector3($x, $y, $z)));
            }
        }

        for ($angle = 0; $angle < 360; $angle += 30) {
            $rad = deg2rad($angle);
            for ($r = 2; $r <= 6; $r += 2) {
                $x = $center->x + cos($rad) * $r;
                $z = $center->z + sin($rad) * $r;
                $y = $center->y;
                $level->addParticle(new FlameParticle(new Vector3($x, $y, $z)));
            }
        }
    }
}