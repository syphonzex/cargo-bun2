<?php

namespace OnePiece\Fight;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class EquipCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("opequip", "Switch between Sword or Fighting Style mode", "/opequip <sword|style>");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage(TextFormat::RED . "In-game only.");
            return true;
        }

        if (!$this->plugin->isInOPWorld($sender)) {
            $sender->sendMessage(TextFormat::RED . "You can only use this in the OP world!");
            return true;
        }

        if (empty($args)) {
            $current = $this->plugin->getPlayerMode($sender);
            $sender->sendMessage(TextFormat::GOLD . "==============================");
            $sender->sendMessage(TextFormat::GOLD . "  Current Mode: " . TextFormat::WHITE . ($current === "sword" ? "Sword" : "Fighting Style"));
            $sender->sendMessage("");
            $sender->sendMessage(TextFormat::GRAY . "/opequip sword - Switch to Sword");
            $sender->sendMessage(TextFormat::GRAY . "/opequip style - Switch to Fighting Style");
            $sender->sendMessage(TextFormat::GOLD . "==============================");
            return true;
        }

        $mode = strtolower($args[0]);

        if ($mode === "sword") {
            if ($this->plugin->getSwordMastery()->getEquipped($sender->getName()) === null) {
                $sender->sendMessage(TextFormat::RED . "You don't have any sword equipped! Use /sword equip <id> first.");
                return true;
            }
            $this->plugin->setPlayerMode($sender, "sword");
            $sword = $this->plugin->getSwordManager()->getPlayerSword($sender);
            $sn = $sword !== null ? $sword->getRarityColor() . $sword->getDisplayName() : "Sword";
            $sender->sendMessage(TextFormat::GOLD . "Switched to Sword mode! Using: " . $sn);
            $this->plugin->updateWeaponSlot($sender);
            return true;
        }

        if ($mode === "style") {
            if ($this->plugin->getStyleMastery()->getEquipped($sender->getName()) === null) {
                $sender->sendMessage(TextFormat::RED . "You don't have any fighting style equipped! Use /style equip <id> first.");
                return true;
            }
            $this->plugin->setPlayerMode($sender, "style");
            $style = $this->plugin->getStyleManager()->getPlayerStyle($sender);
            $sn = $style !== null ? $style->getRarityColor() . $style->getDisplayName() : "Style";
            $sender->sendMessage(TextFormat::GOLD . "Switched to Fighting Style mode! Using: " . $sn);
            $this->plugin->updateWeaponSlot($sender);
            return true;
        }

        $sender->sendMessage(TextFormat::RED . "Usage: /opequip <sword|style>");
        return true;
    }
}