<?php

namespace OnePiece\Fight\Swords;

use OnePiece\Fight\Main;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class SwordManager {

    private $plugin;
    private $swords = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function register(BaseSword $sword) {
        $this->swords[strtolower($sword->getId())] = $sword;
    }

    public function getSword($id) {
        return isset($this->swords[strtolower($id)]) ? $this->swords[strtolower($id)] : null;
    }

    public function getAllSwords() {
        return $this->swords;
    }

    public function loadPlayer(Player $player) {
        $this->plugin->getSwordMastery()->load($player->getName());
    }

    public function savePlayer(Player $player) {
        $this->plugin->getSwordMastery()->save($player->getName());
    }

    public function playerHasSword(Player $player) {
        return $this->plugin->getSwordMastery()->getEquipped($player->getName()) !== null;
    }

    public function getPlayerSwordId(Player $player) {
        return $this->plugin->getSwordMastery()->getEquipped($player->getName());
    }

    public function getPlayerSword(Player $player) {
        $id = $this->getPlayerSwordId($player);
        if ($id === null) return null;
        return $this->getSword($id);
    }

    public function forceSword(Player $player, $swordId) {
        $swordId = strtolower($swordId);
        $sword = $this->getSword($swordId);
        if ($sword === null) return false;

        $mastery = $this->plugin->getSwordMastery();
        $name = $player->getName();
        $mastery->addSword($name, $swordId);
        $mastery->setEquipped($name, $swordId);
        $mastery->save($name);

        $player->sendMessage(TextFormat::GOLD . "You were force-given " . $sword->getRarityColor() . $sword->getDisplayName() . TextFormat::GOLD . "!");
        return true;
    }

    public function giveSword(Player $player, $swordId) {
        $swordId = strtolower($swordId);
        $sword = $this->getSword($swordId);
        if ($sword === null) return false;

        $lvReq = $sword->getLevelRequirement();
        if ($this->plugin->getStatsPlugin() !== null) {
            $sm = $this->plugin->getStatsPlugin()->getStatManager();
            $sp = $sm->getStatPlayer($player);
            if ($sp !== null && $sp->getLevel() < $lvReq) {
                $player->sendMessage(TextFormat::RED . "You need Level " . $lvReq . " to use " . $sword->getDisplayName() . "!");
                return false;
            }
        }

        $mastery = $this->plugin->getSwordMastery();
        $name = $player->getName();
        $mastery->addSword($name, $swordId);
        $mastery->setEquipped($name, $swordId);
        $mastery->save($name);

        $player->sendMessage(TextFormat::GOLD . "You obtained " . $sword->getRarityColor() . $sword->getDisplayName() . TextFormat::GOLD . "!");
        $player->sendMessage(TextFormat::GRAY . "Tap to use Ability 1, Sneak+Tap for Ability 2.");
        return true;
    }

    public function equipSword(Player $player, $swordId) {
        $swordId = strtolower($swordId);
        $mastery = $this->plugin->getSwordMastery();
        $name = $player->getName();

        if (!$mastery->hasSword($name, $swordId)) {
            $player->sendMessage(TextFormat::RED . "You don't own that sword!");
            return false;
        }

        $sword = $this->getSword($swordId);
        if ($sword === null) return false;

        $mastery->setEquipped($name, $swordId);
        $mastery->save($name);

        $player->sendMessage(TextFormat::GOLD . "Equipped " . $sword->getRarityColor() . $sword->getDisplayName() . TextFormat::GOLD . "!");
        return true;
    }

    public function removeSword(Player $player, $swordId = null) {
        $mastery = $this->plugin->getSwordMastery();
        $name = $player->getName();

        if ($swordId !== null) {
            $mastery->removeSword($name, strtolower($swordId));
        } else {
            $equipped = $mastery->getEquipped($name);
            if ($equipped !== null) {
                $mastery->removeSword($name, $equipped);
            }
        }

        $mastery->save($name);
        $player->sendMessage(TextFormat::GRAY . "Sword removed.");
        return true;
    }
}