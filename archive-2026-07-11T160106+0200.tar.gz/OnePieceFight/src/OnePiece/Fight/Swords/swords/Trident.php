<?php

namespace OnePiece\Fight\Swords\swords;

use OnePiece\Fight\Swords\BaseSword;
use OnePiece\Devil\BlockEffects;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat;
use pocketmine\level\particle\BubbleParticle;
use pocketmine\level\particle\WaterParticle;
use pocketmine\level\particle\RainSplashParticle;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\sound\AnvilFallSound;
use pocketmine\level\sound\FizzSound;
use pocketmine\level\sound\PopSound;
use pocketmine\scheduler\Task;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;

class Trident extends BaseSword {

    public function getId() { return "trident"; }
    public function getDisplayName() { return "Trident"; }
    public function getItemId() { return 256; }
    public function getMeleeDamage() { return 4.0; }
    public function getLevelRequirement() { return 400; }
    public function getRarity() { return "legendary"; }

    public function getAbilityNames() {
        return ["ability1" => "Ocean Spear", "ability2" => "Maelstrom Burst"];
    }

    public function getAbilityCooldowns() {
        return ["ability1" => 9, "ability2" => 35];
    }

    public function useAbility(Player $player, $ability) {
        if ($ability === "ability1") return $this->oceanSpear($player);
        if ($ability === "ability2") return $this->maelstromBurst($player);
        return 0;
    }

    private function oceanSpear(Player $player) {
        $damage = $this->getSwordDamage($player, 11.0);
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(new OceanSpearTask($this->plugin, $this, $player, $damage), 1);
        $player->getLevel()->addSound(new PopSound($player->getPosition()));
        return 9;
    }

    private function maelstromBurst(Player $player) {
        $damage = $this->getSwordDamage($player, 20.0);
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(new TridentMaelstromTask($this->plugin, $this, $player, $damage), 1);
        $player->getLevel()->addSound(new FizzSound($player->getPosition()));
        return 35;
    }
}

class OceanSpearTask extends Task {
    private $plugin, $sword, $player, $level, $damage, $dir, $pos, $ticks = 0;

    public function __construct($plugin, $sword, Player $player, $damage) {
        $this->plugin = $plugin; $this->sword = $sword; $this->player = $player;
        $this->level = $player->getLevel(); $this->damage = $damage;
        $this->dir = $player->getDirectionVector();
        $this->pos = $player->getPosition()->add(0, 1.4, 0);
    }

    public function onRun($currentTick) {
        if ($this->ticks >= 14) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }
        $this->ticks++;
        $this->pos = $this->pos->add($this->dir->multiply(1.3));

        for ($i = 0; $i < 6; $i++) {
            $angle = ($this->ticks * 0.8) + ($i * M_PI / 3);
            $v = $this->pos->add(cos($angle) * 0.6, sin($angle) * 0.6, sin($angle) * 0.6);
            $this->level->addParticle(new BubbleParticle($v));
            $this->level->addParticle(new WaterParticle($v));
            $this->level->addParticle(new DustParticle($v, 0, 100, 255));
        }

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive() || $e->distance($this->pos) > 2.8) continue;
            if ($e instanceof Player) { if (!$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue; }
            elseif (!($e instanceof NPCEntity) && !($e instanceof FactoryEntity)) continue;

            $ev = new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage);
            $e->attack($this->damage, $ev);
            $e->setMotion($this->dir->multiply(2.6)->add(0, 0.4, 0));
            $this->level->addParticle(new RainSplashParticle($e->getPosition()->add(0, 1, 0)));
            $this->level->addSound(new FizzSound($this->pos));
            $this->ticks = 99;
        }
    }
}

class TridentMaelstromTask extends Task {
    private $plugin, $sword, $player, $level, $damage, $center, $ticks = 0, $eids = [];

    public function __construct($plugin, $sword, Player $player, $damage) {
        $this->plugin = $plugin; $this->sword = $sword; $this->player = $player;
        $this->level = $player->getLevel(); $this->damage = $damage;
        $this->center = $player->getPosition();
        
        $blocks = [35, 95, 95]; 
        for ($i = 0; $i < 15; $i++) {
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($this->level, $eid, $blocks[array_rand($blocks)], 3, $this->center->x, $this->center->y, $this->center->z);
            $this->eids[] = $eid;
        }
    }

    public function onRun($currentTick) {
        if (!$this->player->isOnline() || $this->ticks >= 45) {
            if ($this->ticks >= 45) $this->explode();
            else $this->cleanup();
            return;
        }
        $this->ticks++;

        foreach ($this->eids as $i => $eid) {
            $angle = ($this->ticks * 0.3) + ($i * M_PI / 7);
            $radius = 6.5;
            $height = ($i / 3); 
            BlockEffects::sendMove($this->level, $eid, $this->center->x + cos($angle) * $radius, $this->center->y + $height, $this->center->z + sin($angle) * $radius);
        }

        for ($i = 0; $i < 18; $i++) {
            $a = mt_rand(0, 628) / 100;
            $r = mt_rand(0, 65) / 10;
            $v = $this->center->add(cos($a) * $r, 0.2, sin($a) * $r);
            $this->level->addParticle(new BubbleParticle($v));
            $this->level->addParticle(new WaterParticle($v));
            if ($i % 4 === 0) {
                $this->level->addParticle(new SmokeParticle($v->add(0, 4, 0)));
                $this->level->addParticle(new DustParticle($v, 0, 150, 255));
            }
        }

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive() || $e->distance($this->center) > 8.0) continue;
            if ($e instanceof Player) { if (!$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue; }
            elseif (!($e instanceof NPCEntity) && !($e instanceof FactoryEntity)) continue;

            $dist = $e->distance($this->center);
            if ($dist > 1.5) {
                $e->setMotion($this->center->subtract($e)->normalize()->multiply(0.6));
            } else {
                $e->setMotion(new Vector3(0, 0, 0));
            }
        }
        
        if ($this->ticks % 8 === 0) $this->level->addSound(new FizzSound($this->center));
    }

    private function explode() {
        $this->level->addSound(new AnvilFallSound($this->center));
        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive() || $e->distance($this->center) > 8.5) continue;
            if ($e instanceof Player) { if (!$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue; }
            elseif (!($e instanceof NPCEntity) && !($e instanceof FactoryEntity)) continue;

            $ev = new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage);
            $e->attack($this->damage, $ev);
            $e->setMotion(new Vector3(0, 2.0, 0));
            for ($i = 0; $i < 10; $i++) {
                $v = $e->getPosition()->add(mt_rand(-5, 5)/10, mt_rand(0, 20)/10, mt_rand(-5, 5)/10);
                $this->level->addParticle(new RainSplashParticle($v));
                $this->level->addParticle(new CriticalParticle($v));
            }
        }
        $this->cleanup();
    }

    private function cleanup() {
        if (!empty($this->eids)) BlockEffects::voidAndRemove($this->plugin, $this->level, $this->eids);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}