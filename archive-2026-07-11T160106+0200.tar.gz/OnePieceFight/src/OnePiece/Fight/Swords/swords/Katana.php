<?php

namespace OnePiece\Fight\Swords\swords;

use OnePiece\Fight\Swords\BaseSword;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\scheduler\Task;

class Katana extends BaseSword {

    public function getId() { return "katana"; }
    public function getDisplayName() { return "Katana"; }
    public function getItemId() { return 268; }
    public function getMeleeDamage() { return 1; }
    public function getLevelRequirement() { return 1; }
    public function getRarity() { return "common"; }

    public function getAbilityNames() {
        return ["ability1" => "Silent Strike", "ability2" => "Blade Dash"];
    }

    public function getAbilityCooldowns() {
        return ["ability1" => 5, "ability2" => 10];
    }

    public function useAbility(Player $player, $ability) {
        if ($ability === "ability1") return $this->silentStrike($player);
        if ($ability === "ability2") return $this->bladeDash($player);
        return 0;
    }

    private function silentStrike(Player $player) {
        $target = $this->findFrontTarget($player, 6.0);
        if ($target === null) return 0;

        $this->dealDamage($player, $target, $this->getSwordDamage($player, 5.0));
        $pos = $target->getPosition();
        for ($i = 0; $i < 8; $i++) {
            $player->getLevel()->addParticle(new CriticalParticle($pos->add(mt_rand(-10, 10) / 10, 1, mt_rand(-10, 10) / 10)));
        }
        $player->getLevel()->addSound(new AnvilUseSound($pos));
        return 5;
    }

    private function bladeDash(Player $player) {
        $dir = $player->getDirectionVector();
        $player->setMotion($dir->multiply(1.8)->add(new Vector3(0, 0.2, 0)));
        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new KatanaDashTask($this, $player), 5);
        return 10;
    }
}

class KatanaDashTask extends Task {
    private $sword;
    private $playerName;
    private $level;

    public function __construct(Katana $sword, Player $player) {
        $this->sword = $sword;
        $this->playerName = $player->getName();
        $this->level = $player->getLevel();
    }

    public function onRun($currentTick) {
        $player = $this->level->getServer()->getPlayerExact($this->playerName);
        if ($player === null || !$player->isOnline()) return;

        $targets = $this->sword->getNearbyTargets($player, 4.0);
        foreach ($targets as $t) {
            $this->sword->dealDamage($player, $t, $this->sword->getSwordDamage($player, 7.0));
            $player->getLevel()->addParticle(new SmokeParticle($t->getPosition()->add(0, 1, 0)));
        }
    }
}