<?php

namespace OnePiece\Fight\Swords\swords;

use OnePiece\Fight\Swords\BaseSword;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\particle\InkParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\InstantEnchantParticle;
use pocketmine\level\sound\AnvilFallSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\EndermanTeleportSound;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\Task;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;

class Shusui extends BaseSword {

    public function getId() { return "shusui"; }
    public function getDisplayName() { return "Shusui"; }
    public function getItemId() { return 272; }
    public function getMeleeDamage() { return 2.0; }
    public function getLevelRequirement() { return 80; }
    public function getRarity() { return "rare"; }

    public function getAbilityNames() {
        return ["ability1" => "Ouryu Wave", "ability2" => "Purgatory Oni Giri"];
    }

    public function getAbilityCooldowns() {
        return ["ability1" => 8, "ability2" => 22];
    }

    public function useAbility(Player $player, $ability) {
        if ($ability === "ability1") return $this->ouryuWave($player);
        if ($ability === "ability2") return $this->purgatoryOniGiri($player);
        return 0;
    }

    private function ouryuWave(Player $player) {
        $damage = $this->getSwordDamage($player, 9.0);
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(new OuryuWaveTask($this->plugin, $this, $player, $damage), 1);
        $player->getLevel()->addSound(new AnvilUseSound($player->getPosition()));
        return 8;
    }

    private function purgatoryOniGiri(Player $player) {
        $damage = $this->getSwordDamage($player, 14.0);
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(new PurgatoryOniGiriTask($this->plugin, $this, $player, $damage), 1);
        $player->getLevel()->addSound(new EndermanTeleportSound($player->getPosition()));
        return 22;
    }
}

class OuryuWaveTask extends Task {
    private $plugin, $sword, $player, $level, $damage, $dir, $pos, $ticks = 0;

    public function __construct($plugin, $sword, Player $player, $damage) {
        $this->plugin = $plugin; $this->sword = $sword; $this->player = $player;
        $this->level = $player->getLevel(); $this->damage = $damage;
        $this->dir = $player->getDirectionVector();
        $this->pos = $player->getPosition()->add(0, 1.2, 0);
    }

    public function onRun($currentTick) {
        if ($this->ticks >= 14) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }
        $this->ticks++;
        $this->pos = $this->pos->add($this->dir->multiply(1.3));
        
        $side = new Vector3(-$this->dir->z, 0, $this->dir->x);
        for ($i = -10; $i <= 10; $i++) {
            $offset = $i / 5;
            $v = $this->pos->add($side->x * (1 - abs($offset) * 0.5), $offset * 1.5, $side->z * (1 - abs($offset) * 0.5));
            $this->level->addParticle(new InkParticle($v));
            if ($i % 4 === 0) $this->level->addParticle(new PortalParticle($v));
        }

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive() || $e->distance($this->pos) > 3.0) continue;
            if ($e instanceof Player) { if (!$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue; }
            elseif (!($e instanceof NPCEntity) && !($e instanceof FactoryEntity)) continue;

            $e->attack($this->damage, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage));
            $e->setMotion($this->dir->multiply(1.4)->add(0, 0.2, 0));
            $this->level->addParticle(new CriticalParticle($e->getPosition()->add(0, 1, 0)));
        }
    }
}

class PurgatoryOniGiriTask extends Task {
    private $plugin, $sword, $player, $level, $damage, $dir, $ticks = 0, $hit = [];

    public function __construct($plugin, $sword, Player $player, $damage) {
        $this->plugin = $plugin; $this->sword = $sword; $this->player = $player;
        $this->level = $player->getLevel(); $this->damage = $damage;
        $this->dir = $player->getDirectionVector();
    }

    public function onRun($currentTick) {
        if (!$this->player->isOnline() || $this->ticks >= 10) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }
        $this->ticks++;

        if ($this->ticks <= 4) {
            $this->player->setMotion($this->dir->multiply(2.2));
            for ($i = 0; $i < 3; $i++) {
                $v = $this->player->getPosition()->add(0, mt_rand(5, 15)/10, 0);
                $this->level->addParticle(new InkParticle($v));
                $this->level->addParticle(new PortalParticle($v));
            }
        }

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive() || $e->distance($this->player) > 3.5 || isset($this->hit[$e->getId()])) continue;
            if ($e instanceof Player) { if (!$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue; }
            elseif (!($e instanceof NPCEntity) && !($e instanceof FactoryEntity)) continue;

            $this->hit[$e->getId()] = $e;
            $e->attack($this->damage, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage));
            $e->setMotion(new Vector3(0, 0, 0));
            
            for ($i = 0; $i < 8; $i++) {
                $this->level->addParticle(new CriticalParticle($e->getPosition()->add(0, 1, 0)));
                $this->level->addParticle(new InkParticle($e->getPosition()->add(mt_rand(-5, 5)/10, mt_rand(5, 15)/10, mt_rand(-5, 5)/10)));
            }
        }

        if ($this->ticks === 4) $this->level->addSound(new AnvilFallSound($this->player->getPosition()));
    }
}