<?php

namespace OnePiece\Fight\Swords\swords;

use OnePiece\Fight\Swords\BaseSword;
use OnePiece\Devil\BlockEffects;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\particle\EntityFlameParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\InkParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\sound\AnvilFallSound;
use pocketmine\level\sound\BlazeShootSound;
use pocketmine\level\sound\GhastShootSound;
use pocketmine\level\sound\EndermanTeleportSound;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\Task;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;

class Enma extends BaseSword {

    public function getId() { return "enma"; }
    public function getDisplayName() { return "Enma"; }
    public function getItemId() { return 267; }
    public function getMeleeDamage() { return 4.5; }
    public function getLevelRequirement() { return 500; }
    public function getRarity() { return "legendary"; }

    public function getAbilityNames() {
        return ["ability1" => "Enma: Purgatory Slash", "ability2" => "Hell's Maw"];
    }

    public function getAbilityCooldowns() {
        return ["ability1" => 12, "ability2" => 30];
    }

    public function useAbility(Player $player, $ability) {
        if ($ability === "ability1") return $this->purgatorySlash($player);
        if ($ability === "ability2") return $this->hellsMaw($player);
        return 0;
    }

    private function purgatorySlash(Player $player) {
        $target = $this->findFrontTarget($player, 10.0);
        if ($target === null) return 0;

        if ($target instanceof Player) {
            if (!$this->plugin->canTargetPlayer($player->getName(), $target)) return 0;
        } elseif (!($target instanceof NPCEntity) && !($target instanceof FactoryEntity)) {
            return 0;
        }

        $damage = $this->getSwordDamage($player, 3.0);
        $lv = $player->getLevel();
        $pos = $target->getPosition();

        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(new EnmaSlashTask($this->plugin, $player, $target, $damage), 1);
        $lv->addSound(new GhastShootSound($player->getPosition()));
        return 12;
    }

    private function hellsMaw(Player $player) {
        $damage = $this->getSwordDamage($player, 0.5);
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(new EnmaHellsMawTask($this->plugin, $this, $player, $damage), 1);
        $player->getLevel()->addSound(new EndermanTeleportSound($player->getPosition()));
        return 30;
    }
}

class EnmaSlashTask extends Task {
    private $plugin, $player, $target, $damage, $ticks = 0;

    public function __construct($plugin, $player, $target, $damage) {
        $this->plugin = $plugin; $this->player = $player;
        $this->target = $target; $this->damage = $damage;
    }

    public function onRun($currentTick) {
        if (!$this->player->isOnline() || !$this->target->isAlive() || $this->ticks >= 5) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }
        $this->ticks++;
        
        $lv = $this->target->getLevel();
        $pos = $this->target->getPosition();

        if ($this->ticks === 3) {
            $this->target->attack($this->damage, new EntityDamageByEntityEvent($this->player, $this->target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage));
            $lv->addSound(new AnvilFallSound($pos));
            $lv->addParticle(new HugeExplodeParticle($pos));
        }

        for ($i = -15; $i <= 15; $i++) {
            $offset = $i / 5;
            $v = $pos->add(0, $offset + 1, 0);
            $lv->addParticle(new PortalParticle($v));
            $lv->addParticle(new EntityFlameParticle($v->add(mt_rand(-5, 5)/10, 0, mt_rand(-5, 5)/10)));
            if ($i % 5 === 0) $lv->addParticle(new InkParticle($v));
        }
    }
}

class EnmaHellsMawTask extends Task {
    private $plugin, $sword, $player, $level, $damage, $center, $ticks = 0, $eids = [];

    public function __construct($plugin, $sword, $player, $damage) {
        $this->plugin = $plugin; $this->sword = $sword; $this->player = $player;
        $this->level = $player->getLevel(); $this->damage = $damage;
        $this->center = $player->getPosition();
        
        for ($i = 0; $i < 6; $i++) {
            $eid = BlockEffects::newEid();
            BlockEffects::sendSpawn($this->level, $eid, 35, 10, $this->center->x, $this->center->y - 0.5, $this->center->z);
            $this->eids[] = $eid;
        }
    }

    public function onRun($currentTick) {
        if (!$this->player->isOnline() || $this->ticks >= 60) { $this->cleanup(); return; }
        $this->ticks++;

        foreach ($this->eids as $i => $eid) {
            $angle = ($this->ticks * 0.2) + ($i * M_PI / 3);
            $radius = 5.0 - ($this->ticks * 0.05);
            BlockEffects::sendMove($this->level, $eid, $this->center->x + cos($angle) * $radius, $this->center->y + 0.2, $this->center->z + sin($angle) * $radius);
        }

        for ($i = 0; $i < 10; $i++) {
            $a = mt_rand(0, 628) / 100;
            $r = mt_rand(0, 60) / 10;
            $v = $this->center->add(cos($a) * $r, 0.1, sin($a) * $r);
            $this->level->addParticle(new PortalParticle($v));
            if ($i % 3 === 0) $this->level->addParticle(new EntityFlameParticle($v));
        }

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive() || $e->distance($this->center) > 7.0) continue;
            if ($e instanceof Player) { if (!$this->plugin->canTargetPlayer($this->player->getName(), $e)) continue; }
            elseif (!($e instanceof NPCEntity) && !($e instanceof FactoryEntity)) continue;

            $dist = $e->distance($this->center);
            if ($dist > 0.8) {
                $e->setMotion($this->center->subtract($e)->normalize()->multiply(0.6));
            } else {
                $e->setMotion(new Vector3(0, 0, 0));
            }

            if ($this->ticks % 15 === 0) {
                $e->attack($this->damage, new EntityDamageByEntityEvent($this->player, $e, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage));
                $this->level->addParticle(new CriticalParticle($e->getPosition()->add(0, 1, 0)));
            }
        }

        if ($this->ticks % 10 === 0) $this->level->addSound(new BlazeShootSound($this->center));
    }

    private function cleanup() {
        if (!empty($this->eids)) BlockEffects::voidAndRemove($this->plugin, $this->level, $this->eids);
        $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
    }
}