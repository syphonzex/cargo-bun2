<?php

namespace OnePiece\Fight\Swords\swords;

use OnePiece\Fight\Swords\BaseSword;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat;
use pocketmine\level\particle\EnchantmentTableParticle;
use pocketmine\level\particle\WhiteSmokeParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\InstantEnchantParticle;
use pocketmine\level\sound\EndermanTeleportSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\AnvilFallSound;
use pocketmine\scheduler\Task;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;

class WadoIchimonji extends BaseSword {

    public function getId() { return "wado_ichimonji"; }
    public function getDisplayName() { return "Wado Ichimonji"; }
    public function getItemId() { return 283; }
    public function getMeleeDamage() { return 3.0; }
    public function getLevelRequirement() { return 300; }
    public function getRarity() { return "rare"; }

    public function getAbilityNames() {
        return ["ability1" => "Ittoryu: Iai", "ability2" => "Spirit Blade Dance"];
    }

    public function getAbilityCooldowns() {
        return ["ability1" => 7, "ability2" => 18];
    }

    public function useAbility(Player $player, $ability) {
        if ($ability === "ability1") return $this->iaiStrike($player);
        if ($ability === "ability2") return $this->spiritDance($player);
        return 0;
    }

    private function iaiStrike(Player $player) {
        $target = $this->findFrontTarget($player, 8.0);
        if ($target === null) return 0;
        
        if ($target instanceof Player) {
            if (!$this->plugin->canTargetPlayer($player->getName(), $target)) return 0;
        } elseif (!($target instanceof NPCEntity) && !($target instanceof FactoryEntity)) {
            return 0;
        }

        $damage = $this->getSwordDamage($player, 10.0);
        $startPos = $player->getPosition();
        $endPos = $target->getPosition()->add($player->getDirectionVector()->multiply(1.5));
        
        $player->teleport($endPos);
        $player->getLevel()->addSound(new EndermanTeleportSound($player));

        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new IaiFinishTask($this->plugin, $player, $target, $damage), 3);

        for ($i = 0; $i <= 12; $i++) {
            $p = $i / 12;
            $v = $startPos->add(($endPos->x - $startPos->x) * $p, 1.2, ($endPos->z - $startPos->z) * $p);
            $player->getLevel()->addParticle(new WhiteSmokeParticle($v));
            $player->getLevel()->addParticle(new InstantEnchantParticle($v));
        }

        return 7;
    }

    private function spiritDance(Player $player) {
        $target = $this->findFrontTarget($player, 7.0);
        if ($target === null) return 0;

        if ($target instanceof Player) {
            if (!$this->plugin->canTargetPlayer($player->getName(), $target)) return 0;
        } elseif (!($target instanceof NPCEntity) && !($target instanceof FactoryEntity)) {
            return 0;
        }

        $damage = $this->getSwordDamage($player, 4.5);
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(new SpiritDanceTask($this->plugin, $this, $player, $target, $damage), 2);
        
        return 18;
    }
}

class IaiFinishTask extends Task {
    private $plugin, $player, $target, $damage;

    public function __construct($plugin, $player, $target, $damage) {
        $this->plugin = $plugin; $this->player = $player;
        $this->target = $target; $this->damage = $damage;
    }

    public function onRun($currentTick) {
        if ($this->target->isAlive()) {
            $this->target->attack($this->damage, new EntityDamageByEntityEvent($this->player, $this->target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage));
            $this->target->getLevel()->addParticle(new CriticalParticle($this->target->getPosition()->add(0, 1, 0)));
            $this->target->getLevel()->addSound(new AnvilUseSound($this->target->getPosition()));
            $this->target->setMotion(new Vector3(0, 0, 0));
        }
    }
}

class SpiritDanceTask extends Task {
    private $plugin, $sword, $player, $target, $damage, $ticks = 0;

    public function __construct($plugin, $sword, $player, $target, $damage) {
        $this->plugin = $plugin; $this->sword = $sword;
        $this->player = $player; $this->target = $target;
        $this->damage = $damage;
    }

    public function onRun($currentTick) {
        if (!$this->player->isOnline() || !$this->target->isAlive() || $this->ticks >= 10) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }
        $this->ticks++;

        $this->target->setMotion(new Vector3(0, 0, 0));
        if ($this->ticks % 2 === 0) {
            $this->target->attack($this->damage, new EntityDamageByEntityEvent($this->player, $this->target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage));
        }
        
        $lv = $this->target->getLevel();
        $pos = $this->target->getPosition();

        for ($i = 0; $i < 16; $i++) {
            $angle = ($i / 8) * M_PI + ($this->ticks * 0.5);
            $v = $pos->add(cos($angle) * 2, mt_rand(0, 25) / 10, sin($angle) * 2);
            $lv->addParticle(new EnchantmentTableParticle($v));
            if ($i % 4 === 0) {
                $lv->addParticle(new WhiteSmokeParticle($v));
                $lv->addParticle(new InstantEnchantParticle($v));
            }
        }

        for ($j = 0; $j < 5; $j++) {
            $lv->addParticle(new CriticalParticle($pos->add(mt_rand(-10, 10)/10, 1, mt_rand(-10, 10)/10)));
        }

        if ($this->ticks % 2 === 0) {
            $lv->addSound(new AnvilUseSound($pos));
        }
    }
}