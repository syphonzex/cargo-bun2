<?php

namespace OnePiece\Fight\Swords\swords;

use OnePiece\Fight\Swords\BaseSword;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat;
use pocketmine\level\particle\HappyVillagerParticle;
use pocketmine\level\particle\InkParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\InstantEnchantParticle;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\sound\AnvilFallSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\GhastShootSound;
use pocketmine\level\sound\EndermanTeleportSound;
use pocketmine\level\sound\ExplodeSound;
use pocketmine\scheduler\Task;
use OnePiece\Devil\BlockEffects;
use OnePiece\NPC\NPCEntity;
use OnePieceTrades\Factory\FactoryEntity;

class Yoru extends BaseSword {

    public function getId() { return "yoru"; }
    public function getDisplayName() { return "Yoru"; }
    public function getItemId() { return 276; }
    public function getMeleeDamage() { return 5.0; }
    public function getLevelRequirement() { return 250; }
    public function getRarity() { return "legendary"; }

    public function getAbilityNames() {
        return ["ability1" => "World's Strongest Slash", "ability2" => "Grand Cross"];
    }

    public function getAbilityCooldowns() {
        return ["ability1" => 10, "ability2" => 35];
    }

    public function useAbility(Player $player, $ability) {
        if ($ability === "ability1") return $this->worldStrongestSlash($player);
        if ($ability === "ability2") return $this->grandCross($player);
        return 0;
    }

    private function worldStrongestSlash(Player $player) {
        $damage = $this->getSwordDamage($player, 18.0);
        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(new YoruSlashTask($this->plugin, $this, $player, $damage), 1);
        $player->getLevel()->addSound(new GhastShootSound($player->getPosition()));
        return 10;
    }

    private function grandCross(Player $player) {
        $target = $this->findFrontTarget($player, 10.0);
        if ($target === null) return 0;

        if (!($target instanceof Player) && !($target instanceof NPCEntity) && !($target instanceof FactoryEntity)) {
            return 0;
        }

        $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(new YoruGrandCrossTask($this->plugin, $this, $player, $target), 1);
        $player->getLevel()->addSound(new AnvilFallSound($player->getPosition()));
        return 35;
    }
}

class YoruSlashTask extends Task {
    private $plugin, $sword, $player, $level, $damage, $dir, $pos, $ticks = 0;

    public function __construct($plugin, $sword, Player $player, $damage) {
        $this->plugin = $plugin; $this->sword = $sword; $this->player = $player;
        $this->level = $player->getLevel(); $this->damage = $damage;
        $this->dir = $player->getDirectionVector();
        $this->pos = $player->getPosition()->add(0, 1.2, 0);
    }

    public function onRun($currentTick) {
        if ($this->ticks >= 18) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }
        $this->ticks++;
        $this->pos = $this->pos->add($this->dir->multiply(1.5));
        
        $side = new Vector3(-$this->dir->z, 0, $this->dir->x);
        for ($i = -15; $i <= 15; $i++) {
            $offset = $i / 4;
            $v = $this->pos->add($side->x * $offset, 0, $side->z * $offset);
            $this->level->addParticle(new HappyVillagerParticle($v));
            if ($i % 5 === 0) {
                $this->level->addParticle(new InkParticle($v));
                $this->level->addParticle(new InstantEnchantParticle($v->add(0, 0.5, 0)));
            }
        }

        foreach ($this->level->getEntities() as $e) {
            if ($e === $this->player || !$e->isAlive() || $e->distance($this->pos) > 4.0) continue;
            if (!($e instanceof Player) && !($e instanceof NPCEntity) && !($e instanceof FactoryEntity)) continue;

            $this->sword->dealDamage($this->player, $e, $this->damage);
            $e->setMotion($this->dir->multiply(1.5)->add(0, 0.2, 0));
        }
    }
}

class YoruGrandCrossTask extends Task {
    private $plugin, $sword, $player, $target, $level, $tick = 0, $phase = 1, $pLock, $tLock;

    public function __construct($plugin, $sword, Player $player, $target) {
        $this->plugin = $plugin;
        $this->sword  = $sword;
        $this->player = $player;
        $this->target = $target;
        $this->level  = $player->getLevel();
    }

    public function onRun($currentTick) {
        if (!$this->player->isOnline() || $this->player->closed || !$this->target->isAlive() || $this->target->closed) {
            $this->cleanup();
            return;
        }
        $this->tick++;

        if ($this->phase === 1) {
            $this->player->setMotion(new Vector3(0, 0, 0));
            $this->target->setMotion(new Vector3(0, 0, 0));
            for ($i = 0; $i < 6; $i++) {
                $v = $this->player->getPosition()->add(mt_rand(-10, 10) / 10, mt_rand(0, 25) / 10, mt_rand(-10, 10) / 10);
                $this->level->addParticle(new HappyVillagerParticle($v));
                $this->level->addParticle(new InkParticle($v));
            }

            if ($this->tick >= 35) {
                if (!$this->player->isOnline() || !$this->target->isAlive()) {
                    $this->cleanup();
                    return;
                }
                $tPos = $this->target->getPosition();
                $this->pLock = $tPos->subtract($this->player->getDirectionVector()->multiply(2.5));
                $this->tLock = $tPos;
                $this->player->teleport($this->pLock);
                $this->level->addSound(new EndermanTeleportSound($this->pLock));
                $this->phase = 2;
                $this->tick = 0;
            }
        } else if ($this->phase === 2) {
            if (!$this->player->isOnline() || !$this->target->isAlive()) {
                $this->cleanup();
                return;
            }
            $this->player->teleport($this->pLock);
            $this->target->teleport($this->tLock);

            if ($this->tick % 5 === 0) {
                $this->level->addParticle(new InstantEnchantParticle($this->target->getPosition()->add(0, 1, 0)));
                $this->level->addSound(new AnvilUseSound($this->target->getPosition()));
            }

            if ($this->tick >= 45) {
                $this->phase = 3;
            }
        } else if ($this->phase === 3) {
            if (!$this->player->isOnline() || !$this->target->isAlive()) {
                $this->cleanup();
                return;
            }

            $center = $this->target->getPosition()->add(0, 1, 0);
            for ($i = -25; $i <= 25; $i++) {
                $off = $i / 5;
                $h = $center->add($off, 0, 0);
                $v = $center->add(0, $off, 0);
                $this->level->addParticle(new HappyVillagerParticle($h));
                $this->level->addParticle(new HappyVillagerParticle($v));
                if ($i % 5 === 0) {
                    $this->level->addParticle(new InkParticle($h));
                    $this->level->addParticle(new InkParticle($v));
                    $this->level->addParticle(new SmokeParticle($h));
                    $this->level->addParticle(new SmokeParticle($v));
                }
            }
            
            $damage = $this->sword->getSwordDamage($this->player, 28.0);
            $this->sword->dealDamage($this->player, $this->target, $damage);

            $this->target->setMotion(new Vector3(0, 2.2, 0));
            $this->level->addSound(new ExplodeSound($center));
            $this->level->addParticle(new HugeExplodeParticle($center));
            $this->cleanup();
        }
    }

    private function cleanup() {
        try {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
        } catch (\Exception $e) {
        }
    }
}