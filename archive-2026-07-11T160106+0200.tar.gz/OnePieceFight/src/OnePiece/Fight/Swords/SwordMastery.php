<?php

namespace OnePiece\Fight\Swords;

use OnePiece\Fight\Main;
use pocketmine\utils\Config;

class SwordMastery {

    private $plugin;
    private $config;
    private $data = [];
    private $cooldowns = [];
    private $abilityDamage = [];

    const MAX_LEVEL = 100;
    const EXP_PER_USE = 2;
    const EXP_PER_HIT = 5;

    const ABILITY_UNLOCK = [
        "ability1" => 1,
        "ability2" => 50,
    ];

    const DAMAGE_SCALE = [
        "min"  => 1.0,
        "max"  => 2.0,
        "at"   => 100,
    ];

    const COOLDOWN_SCALE = [
        "min"  => 0.6,
        "max"  => 1.0,
        "at"   => 100,
    ];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->config = new Config($plugin->getDataFolder() . "swords.yml", Config::YAML);
    }

    public function load($name) {
        $all = $this->config->getAll();
        if (isset($all[$name]) && is_array($all[$name])) {
            $this->data[$name] = $all[$name];
            if (!isset($this->data[$name]["swords"]) || !is_array($this->data[$name]["swords"])) {
                $this->data[$name]["swords"] = [];
            }
            if (!isset($this->data[$name]["equipped"])) {
                $this->data[$name]["equipped"] = null;
            }
        } else {
            $this->data[$name] = ["swords" => [], "equipped" => null];
        }
    }

    public function save($name) {
        if (!isset($this->data[$name])) return;
        $this->config->set($name, $this->data[$name]);
        $this->config->save();
    }

    public function saveAll() {
        foreach ($this->data as $name => $d) {
            $this->config->set($name, $d);
        }
        $this->config->save();
    }

    public function hasSword($name, $swordId) {
        $swordId = strtolower($swordId);
        return isset($this->data[$name]["swords"][$swordId]);
    }

    public function addSword($name, $swordId) {
        $swordId = strtolower($swordId);
        if (!isset($this->data[$name])) {
            $this->data[$name] = ["swords" => [], "equipped" => null];
        }
        if (!isset($this->data[$name]["swords"][$swordId])) {
            $this->data[$name]["swords"][$swordId] = ["level" => 1, "exp" => 0];
        }
    }

    public function removeSword($name, $swordId) {
        $swordId = strtolower($swordId);
        if (isset($this->data[$name]["swords"][$swordId])) {
            unset($this->data[$name]["swords"][$swordId]);
        }
        if (isset($this->data[$name]["equipped"]) && $this->data[$name]["equipped"] === $swordId) {
            $this->data[$name]["equipped"] = null;
        }
    }

    public function getOwnedSwords($name) {
        return isset($this->data[$name]["swords"]) ? $this->data[$name]["swords"] : [];
    }

    public function getEquipped($name) {
        return isset($this->data[$name]["equipped"]) ? $this->data[$name]["equipped"] : null;
    }

    public function setEquipped($name, $swordId) {
        if ($swordId !== null) $swordId = strtolower($swordId);
        if (!isset($this->data[$name])) {
            $this->data[$name] = ["swords" => [], "equipped" => null];
        }
        $this->data[$name]["equipped"] = $swordId;
    }

    public function getLevel($name, $swordId = null) {
        if ($swordId === null) $swordId = $this->getEquipped($name);
        if ($swordId === null) return 1;
        $swordId = strtolower($swordId);
        return isset($this->data[$name]["swords"][$swordId]["level"]) ? (int)$this->data[$name]["swords"][$swordId]["level"] : 1;
    }

    public function getExp($name, $swordId = null) {
        if ($swordId === null) $swordId = $this->getEquipped($name);
        if ($swordId === null) return 0;
        $swordId = strtolower($swordId);
        return isset($this->data[$name]["swords"][$swordId]["exp"]) ? (int)$this->data[$name]["swords"][$swordId]["exp"] : 0;
    }

    public function getExpToNext($name, $swordId = null) {
        $l = $this->getLevel($name, $swordId);
        return 20 + ($l * 15) + (int)($l * $l * 1.5);
    }

    public function addExp($name, $amount, $swordId = null) {
        if ($swordId === null) $swordId = $this->getEquipped($name);
        if ($swordId === null) return;
        $swordId = strtolower($swordId);
        if (!isset($this->data[$name]["swords"][$swordId])) return;

        $this->data[$name]["swords"][$swordId]["exp"] += $amount;
        $leveled = false;

        while ($this->data[$name]["swords"][$swordId]["exp"] >= $this->getExpToNext($name, $swordId)
               && $this->data[$name]["swords"][$swordId]["level"] < self::MAX_LEVEL) {
            $this->data[$name]["swords"][$swordId]["exp"] -= $this->getExpToNext($name, $swordId);
            $this->data[$name]["swords"][$swordId]["level"]++;
            $leveled = true;
        }

        if ($this->data[$name]["swords"][$swordId]["level"] >= self::MAX_LEVEL) {
            $this->data[$name]["swords"][$swordId]["exp"] = 0;
        }

        if ($leveled) {
            $player = $this->plugin->getServer()->getPlayerExact($name);
            if ($player !== null) {
                $lv = $this->data[$name]["swords"][$swordId]["level"];
                $sw = $this->plugin->getSwordManager()->getSword($swordId);
                $sn = $sw !== null ? $sw->getDisplayName() : $swordId;
                $player->sendMessage("§6> " . $sn . " Mastery leveled up to §e" . $lv . "§6!");
                if ($lv === self::ABILITY_UNLOCK["ability2"]) {
                    $player->sendMessage("§a[UNLOCKED] §f" . $sn . "'s second ability is now available!");
                }
            }
            $this->save($name);
        }
    }

    public function onUse($name) {
        $this->addExp($name, self::EXP_PER_USE);
    }

    public function onMeleeHit($name) {
        $this->addExp($name, self::EXP_PER_HIT);
    }

    public function canUseAbility($name, $ability) {
        $req = isset(self::ABILITY_UNLOCK[$ability]) ? self::ABILITY_UNLOCK[$ability] : 999;
        return $this->getLevel($name) >= $req;
    }

    public function getDamageMultiplier($name) {
        $level = $this->getLevel($name);
        $progress = min(1.0, $level / self::DAMAGE_SCALE["at"]);
        return self::DAMAGE_SCALE["min"] + ($progress * (self::DAMAGE_SCALE["max"] - self::DAMAGE_SCALE["min"]));
    }

    public function getScaledCooldown($name, $baseCd) {
        $level = $this->getLevel($name);
        $progress = min(1.0, $level / self::COOLDOWN_SCALE["at"]);
        $mult = self::COOLDOWN_SCALE["max"] - ($progress * (self::COOLDOWN_SCALE["max"] - self::COOLDOWN_SCALE["min"]));
        return max(0.5, $baseCd * $mult);
    }

    public function setCooldown($name, $key, $seconds) {
        if (!isset($this->cooldowns[$name])) $this->cooldowns[$name] = [];
        $this->cooldowns[$name][$key] = microtime(true) + $seconds;
    }

    public function isCooldown($name, $key) {
        if (!isset($this->cooldowns[$name][$key])) return false;
        if (microtime(true) >= $this->cooldowns[$name][$key]) {
            unset($this->cooldowns[$name][$key]);
            return false;
        }
        return true;
    }

    public function getCooldownRemaining($name, $key) {
        if (!isset($this->cooldowns[$name][$key])) return 0;
        return max(0, $this->cooldowns[$name][$key] - microtime(true));
    }

    public function tickCooldowns() {
        $now = microtime(true);
        foreach ($this->cooldowns as $name => $keys) {
            foreach ($keys as $key => $expire) {
                if ($now >= $expire) {
                    unset($this->cooldowns[$name][$key]);
                }
            }
            if (empty($this->cooldowns[$name])) {
                unset($this->cooldowns[$name]);
            }
        }
    }

    public function setAbilityDamage($name, $damage) {
        $this->abilityDamage[$name] = $damage;
    }

    public function getProgressBar($name, $swordId = null) {
        $exp = $this->getExp($name, $swordId);
        $toNext = $this->getExpToNext($name, $swordId);
        $filled = $toNext > 0 ? (int)(($exp / $toNext) * 10) : 10;
        $bar = str_repeat("§a|", $filled) . str_repeat("§7|", 10 - $filled);
        return "[" . $bar . "§f]";
    }
}