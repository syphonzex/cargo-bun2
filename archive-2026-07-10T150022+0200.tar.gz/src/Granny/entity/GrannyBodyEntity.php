<?php

namespace Granny\entity;

use pocketmine\entity\Human;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\protocol\AddPlayerPacket;
use pocketmine\Player;
use pocketmine\item\Item;

class GrannyBodyEntity extends Human {

    public $bedX = 0;
    public $bedY = 0;
    public $bedZ = 0;

    public function getName() {
        return "GrannyBody";
    }

    public function initEntity() {
        parent::initEntity();
        $this->setMaxHealth(100);
        $this->setHealth(100);
        $bx = $this->bedX !== 0 ? $this->bedX : (int)round($this->x);
        $by = $this->bedY !== 0 ? $this->bedY : (int)floor($this->y);
        $bz = $this->bedZ !== 0 ? $this->bedZ : (int)round($this->z);
        $this->setDataProperty(self::DATA_PLAYER_BED_POSITION, self::DATA_TYPE_POS, [$bx, $by, $bz]);
        $this->setDataFlag(self::DATA_PLAYER_FLAGS, self::DATA_PLAYER_FLAG_SLEEP, true);
    }

    public function onUpdate($currentTick) {
        return false; // Static corpse entity never moves or ticks!
    }

    public function attack($damage, EntityDamageEvent $source) {
        $source->setCancelled(true); // Unconscious body cannot be hurt or moved!
    }

    public function spawnTo(Player $player) {
        if (!isset($this->hasSpawned[$player->getLoaderId()])) {
            $this->hasSpawned[$player->getLoaderId()] = $player;

            $pk = new AddPlayerPacket();
            $pk->uuid = $this->getUniqueId();
            $pk->username = uniqid('');
            $pk->eid = $this->getId();
            $pk->x = $this->x;
            $pk->y = $this->y;
            $pk->z = $this->z;
            $pk->speedX = 0;
            $pk->speedY = 0;
            $pk->speedZ = 0;
            $pk->yaw = 0;
            $pk->pitch = 0;
            $pk->item = Item::get(Item::AIR);
            
            $bx = $this->bedX !== 0 ? $this->bedX : (int)round($this->x);
            $by = $this->bedY !== 0 ? $this->bedY : (int)floor($this->y);
            $bz = $this->bedZ !== 0 ? $this->bedZ : (int)round($this->z);

            $pk->metadata = [
                2 => [4, ""], // NAMETAG (empty)
                3 => [0, 0], // SHOW_NAMETAG (hidden)
                15 => [0, 1], // DATA_PLAYER_FLAGS => SLEEP (1)
                17 => [6, [$bx, $by, $bz]], // DATA_PLAYER_BED_POSITION
                23 => [7, -1],
                24 => [0, 0]
            ];

            $player->dataPacket($pk);
        }
    }
}
