<?php

namespace Granny\entity;

use pocketmine\entity\Entity;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\network\protocol\LevelEventPacket;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\scheduler\PluginTask;
use Granny\Main;
use Granny\utils\SoundTrigger;

class BearTrapEntity extends Entity {

    const NETWORK_ID = 39;

    public $width = 0.4;
    public $height = 0.3;
    public $gravity = 0;

    private $checkTick = 0;

    public function getName() {
        return "BearTrap";
    }

    public function initEntity() {
        parent::initEntity();
        $this->setMaxHealth(1);
        $this->setHealth(1);
    }

public function onUpdate($currentTick) {
    if ($this->closed) {
        return false;
    }
    parent::onUpdate($currentTick);

    $this->checkTick++;
    if ($this->checkTick < 5) {
        return true;
    }
    $this->checkTick = 0;

    $plugin = $this->getPlugin();
    if ($plugin === null) {
        return true;
    }

    $myWorld = $this->getLevel()->getFolderName();
    $am = $plugin->getArenaManager();
    $session = null;
    if ($am !== null) {
        foreach ($am->getSessions() as $s) {
            if ($s->getWorldName() === $myWorld) {
                $session = $s;
                break;
            }
        }
    }

    foreach ($this->getLevel()->getNearbyEntities($this->getBoundingBox()->grow(0.5, 0.5, 0.5), $this) as $entity) {
        if (!($entity instanceof Player)) continue;
        if (!$entity->isAlive() || $entity->getGamemode() === 3) continue;
        if ($plugin->isGhost($entity->getName())) continue;
        if ($plugin->getTrapManager()->isTrapped($entity->getName())) continue;

        if ($session !== null && !$session->isPlayerInSession($entity->getName())) {
            continue;
        }

        if ($session !== null) {
            $ps = $session->getPlayerState();
            if (!$ps->isAlive($entity->getName())) continue;
        }

        $this->trigger($entity, $plugin);
        return false;
    }
    return true;
}

private function trigger(Player $player, Main $plugin) {
    $pk = new LevelEventPacket();
    $pk->evid = LevelEventPacket::EVENT_SOUND_ANVIL_FALL;
    $pk->x = $this->x;
    $pk->y = $this->y;
    $pk->z = $this->z;
    $pk->data = 0;
    $this->getLevel()->addChunkPacket(((int)$this->x) >> 4, ((int)$this->z) >> 4, $pk);

    $plugin->getTrapManager()->trapPlayer($player);
    $worldName = $this->getLevel()->getFolderName();
    SoundTrigger::triggerSound($plugin, new Vector3($this->x, $this->y, $this->z), $worldName);
    $this->close();
}

    private function getPlugin() {
        $plugin = $this->server->getPluginManager()->getPlugin("GrannyPlugin");
        if ($plugin instanceof Main) {
            return $plugin;
        }
        return null;
    }

    public function spawnTo(Player $player) {
        $pk = new AddEntityPacket();
        $pk->eid = $this->getId();
        $pk->type = self::NETWORK_ID;
        $pk->x = $this->x;
        $pk->y = $this->y;
        $pk->z = $this->z;
        $pk->speedX = 0;
        $pk->speedY = 0;
        $pk->speedZ = 0;
        $pk->yaw = 0;
        $pk->pitch = 0;
        $pk->metadata = $this->dataProperties;
        $player->dataPacket($pk);
        parent::spawnTo($player);
    }

    public static function createTrap(Main $plugin, Vector3 $pos, $level = null) {
        if ($level === null) {
            $level = $plugin->getServer()->getDefaultLevel();
        }

        $nbt = new CompoundTag("", [
            "Pos" => new ListTag("Pos", [
                new DoubleTag("", $pos->x),
                new DoubleTag("", $pos->y),
                new DoubleTag("", $pos->z)
            ]),
            "Motion" => new ListTag("Motion", [
                new DoubleTag("", 0),
                new DoubleTag("", 0),
                new DoubleTag("", 0)
            ]),
            "Rotation" => new ListTag("Rotation", [
                new FloatTag("", 0),
                new FloatTag("", 0)
            ])
        ]);

        $chunk = $level->getChunk(((int)$pos->x) >> 4, ((int)$pos->z) >> 4, true);
        $trap = Entity::createEntity("BearTrapEntity", $chunk, $nbt);
        if ($trap !== null) {
            $trap->spawnToAll();
        }
        return $trap;
    }
}
