<?php

namespace Granny\entity;

use pocketmine\scheduler\PluginTask;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\network\protocol\AnimatePacket;
use pocketmine\network\protocol\LevelEventPacket;
use Granny\Main;

class BuiltInCaughtAnimationTask extends PluginTask {

    private $granny;
    private $player;
    private $tick = 0;
    private $startX;
    private $startY;
    private $startZ;
    private $startPitch;

    public function __construct(Main $plugin, GrannyEntity $granny, Player $player) {
        parent::__construct($plugin);
        $this->granny = $granny;
        $this->player = $player;
        $this->startX = $player->x;
        $this->startY = $player->y;
        $this->startZ = $player->z;
        $this->startPitch = $player->pitch;
    }

    public function onRun($currentTick) {
        if (!$this->player->isOnline() || $this->granny->closed) {
            $this->finish();
            return;
        }

        $this->tick++;

        $dx = $this->granny->x - $this->player->x;
        $dy = ($this->granny->y + $this->granny->eyeHeight) - ($this->player->y + $this->player->getEyeHeight());
        $dz = $this->granny->z - $this->player->z;
        $dist = sqrt($dx * $dx + $dz * $dz);

        $grannyYaw = -atan2(-$dx, -$dz) * 180 / M_PI;
        $grannyPitch = ($dist > 0) ? -atan2(-$dy, $dist) * 180 / M_PI : 0;
        $this->granny->updateRotationPublic($grannyYaw, $grannyPitch);

        // Phase 1 (Ticks 1 to 20 / 1 second): make player look toward granny constantly immobilized
        if ($this->tick <= 20) {
            $yaw = -atan2($dx, $dz) * 180 / M_PI;
            $pitch = ($dist > 0) ? -atan2($dy, $dist) * 180 / M_PI : 0;
            $this->player->teleport(new Vector3($this->startX, $this->startY, $this->startZ), $yaw, $pitch);
        }
        // Phase 2 (At tick 20 / 1 second): granny swings her bat
        elseif ($this->tick === 21) {
            $pk = new AnimatePacket();
            $pk->eid = $this->granny->getId();
            $pk->action = 1; // SWING_ARM
            foreach ($this->granny->getLevel()->getPlayers() as $p) {
                $p->dataPacket($pk);
            }

            $spk = new LevelEventPacket();
            $spk->evid = LevelEventPacket::EVENT_SOUND_ANVIL_FALL;
            $spk->x = $this->player->x;
            $spk->y = $this->player->y;
            $spk->z = $this->player->z;
            $spk->data = 0;
            $this->player->getLevel()->addChunkPacket(((int)$this->player->x) >> 4, ((int)$this->player->z) >> 4, $spk);
        }
        // Phase 3 (Ticks 22 to 40 / 1 second): player looks up and goes down to floor
        elseif ($this->tick <= 40) {
            $progress = ($this->tick - 20) / 20.0;

            $yaw = -atan2($dx, $dz) * 180 / M_PI;
            $pitch = $this->startPitch + (-85 - $this->startPitch) * $progress;
            $currentY = $this->startY - (1.2 * $progress);

            $this->player->teleport(new Vector3($this->startX, $currentY, $this->startZ), $yaw, $pitch);
        }
        // End of animation (Tick 41)
        else {
            $this->finish();
        }
    }

    private function finish() {
        $this->getOwner()->getServer()->getScheduler()->cancelTask($this->getTaskId());
        if (!$this->granny->closed) {
            $this->granny->setFrozen(false);
        }

        if ($this->player->isOnline()) {
            $plugin = $this->getOwner();
            if ($plugin instanceof Main) {
                $plugin->getCutsceneManager()->stopBuiltInScene($this->player, false);
                $am = $plugin->getArenaManager();
                $session = null;
                if ($am !== null) {
                    foreach ($am->getSessions() as $s) {
                        if ($s->getWorldName() === $this->player->getLevel()->getFolderName()) {
                            $session = $s;
                            break;
                        }
                    }
                }
                if ($session !== null) {
                    $session->playerCaptured($this->player);
                } else {
                    $plugin->getDayManager()->playerCaught($this->player);
                }
            }
        }
    }
}
