<?php

namespace Granny\entity;

use pocketmine\entity\Human;
use pocketmine\entity\Entity;
use pocketmine\entity\Effect;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\math\Vector2;
use pocketmine\item\Item;
use pocketmine\network\protocol\AddPlayerPacket;
use pocketmine\network\protocol\AnimatePacket;
use pocketmine\network\protocol\MobEquipmentPacket;
use pocketmine\network\protocol\PlayerListPacket;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Timings;
use Granny\Main;
use Granny\entity\BearTrapEntity;

class GrannyEntity extends Human {

    const STATE_PATROL = 0;
    const STATE_HUNT = 1;
    const STATE_INVESTIGATE = 2;
    const STATE_CHASE = 3;
    const STATE_STUNNED = 4;
    const STATE_SEARCH = 5;

    const SPEED_PATROL = 0.6;
    const SPEED_HUNT = 0.9;
    const SPEED_CHASE = 1.2;
    const SPEED_INVESTIGATE = 0.5;
    const SPEED_STUNNED = 0.0;
    const SPEED_SEARCH = 0.5;

    const MELEE_RANGE = 1.6;
    const ATTACK_COOLDOWN = 30;

    public $width = 0.6;
    public $height = 1.8;
    public $eyeHeight = 1.62;
    protected $gravity = 0.08;
    protected $drag = 0.02;
    protected $stepHeight = 1.2;

    private $state = self::STATE_PATROL;
    private $speed = self::SPEED_PATROL;
    public $pathQueue = [];
    private $baseTarget = null;
    private $noiseTarget = null;
    private $patrolIndex = 0;
    private $attackDelay = 0;
    private $stunnedTimer = 0;
    private $dartFreezeTimer = 0;
    private $hasFellAsleep = false;
    private $corpseEntity = null;
    private $investigateTimer = 0;
    private $microPatrolCount = 0;
    private $stuckTimer = 0;
    private $lastStuckX = 0.0;
    private $lastStuckZ = 0.0;
    private $stuckCount = 0;
    private $investigateDropped = false;
    private $voiceLinePlayed = false;
    private $searchTimer = 0;
    private $lastTargetPos = null;
    private $slowTickTimer = 0;
    private $targetCheckTimer = 0;
    private $speedMultiplier = 1.0;
    private $detectionMultiplier = 1.0;
    private $meleeRangeSq = 2.56;
    private $isCutscenePuppet = false;
    private $isFrozen = false;

    private $lookAroundPhase = 0;
    private $lookAroundTimer = 0;
    private $lookAroundBaseYaw = 0.0;
    private $isLookingAround = false;
    private $pauseTimer = 0;
    private $headSwayTimer = 0;
    private $headSwayDir = 1;
    private $trapsPlaced = 0;

    private static $voiceLines = [
        "§7Granny§f: I know you're here...",
        "§7Granny§f: Do you want to play hide and seek?",
        "§7Granny§f: I see you...",
        "§7Granny§f: Come out, come out...",
        "§7Granny§f: You can't hide forever..."
    ];

    public function initEntity() {
        parent::initEntity();
        $this->setMaxHealth(200);
        $this->setHealth(200);
        $this->setNameTag("");
        $this->setNameTagVisible(false);
        $this->lastStuckX = $this->x;
        $this->lastStuckZ = $this->z;
        $this->meleeRangeSq = self::MELEE_RANGE * self::MELEE_RANGE;
        $this->dataProperties[self::DATA_NO_AI] = [self::DATA_TYPE_BYTE, 1];
        $this->getInventory()->setItemInHand(Item::get(280, 0, 1));
    }

    public function spawnTo(Player $player) {
        if ($player !== $this && !isset($this->hasSpawned[$player->getLoaderId()])) {
            $this->hasSpawned[$player->getLoaderId()] = $player;

            $add = new PlayerListPacket();
            $add->type = PlayerListPacket::TYPE_ADD;
            $add->entries[] = [$this->getUniqueId(), $this->getId(), "", $this->skinId, $this->skin];
            $player->dataPacket($add);

            $pk = new AddPlayerPacket();
            $pk->uuid = $this->getUniqueId();
            $pk->username = "";
            $pk->eid = $this->getId();
            $pk->x = $this->x;
            $pk->y = $this->y;
            $pk->z = $this->z;
            $pk->yaw = $this->yaw;
            $pk->pitch = $this->pitch;
            $pk->item = $this->getInventory()->getItemInHand();
            $pk->metadata = $this->dataProperties;
            $player->dataPacket($pk);

            $this->inventory->sendArmorContents($player);

            $remove = new PlayerListPacket();
            $remove->type = PlayerListPacket::TYPE_REMOVE;
            $remove->entries[] = [$this->getUniqueId()];
            $player->dataPacket($remove);

            $epk = new MobEquipmentPacket();
            $epk->eid = $this->getId();
            $epk->item = $this->getInventory()->getItemInHand();
            $epk->slot = 0;
            $epk->selectedSlot = 0;
            $player->dataPacket($epk);
        }
    }

    public function getName() {
        return "Granny";
    }

    public function setCutscenePuppet($val) {
        $this->isCutscenePuppet = (bool)$val;
    }

    public function isCutscenePuppet() {
        return $this->isCutscenePuppet;
    }

    public function setFrozen($val) {
        $this->isFrozen = (bool)$val;
        if ($this->isFrozen) {
            $this->motionX = 0;
            $this->motionZ = 0;
            $this->pathQueue = [];
        }
    }

    public function isFrozen() {
        return $this->isFrozen;
    }

    public function getState() {
        return $this->state;
    }

    public function setSpeedMultiplier($mult) {
        $this->speedMultiplier = $mult;
    }

    public function setDetectionMultiplier($mult) {
        $this->detectionMultiplier = $mult;
    }

    public function getDetectionMultiplier() {
        return $this->detectionMultiplier;
    }

    private function getPlugin() {
        $plugin = $this->server->getPluginManager()->getPlugin("GrannyPlugin");
        if ($plugin instanceof Main) {
            return $plugin;
        }
        return null;
    }

public function hearNoise(Vector3 $pos, $worldName = null) {
    if ($this->state === self::STATE_STUNNED) {
        return;
    }

    if ($worldName !== null && $this->getLevel()->getFolderName() !== $worldName) {
        return;
    }

    $this->noiseTarget = $pos;
    $this->pathQueue = [];
    $this->isLookingAround = false;
    $this->pauseTimer = 0;
    $this->setState(self::STATE_HUNT);
    $this->recalculatePath($pos);
}

    public function resetToSpawn() {
        $plugin = $this->getPlugin();
        if ($plugin === null) return;
        $x = (float)$plugin->getConfigValue("granny_spawn.x", $this->x);
        $y = (float)$plugin->getConfigValue("granny_spawn.y", $this->y);
        $z = (float)$plugin->getConfigValue("granny_spawn.z", $this->z);
        $this->setPosition(new Vector3($x, $y, $z));
        $this->pathQueue = [];
        $this->baseTarget = null;
        $this->noiseTarget = null;
        $this->isLookingAround = false;
        $this->pauseTimer = 0;
        $this->setState(self::STATE_PATROL);
    }

    private function setState($state) {
        $this->state = $state;
        $this->isLookingAround = false;
        $this->pauseTimer = 0;
        switch ($state) {
            case self::STATE_PATROL:
                $this->speed = self::SPEED_PATROL * $this->speedMultiplier;
                $this->baseTarget = null;
                $this->noiseTarget = null;
                $this->investigateTimer = 0;
                $this->microPatrolCount = 0;
                $this->investigateDropped = false;
                $this->voiceLinePlayed = false;
                $this->lastTargetPos = null;
                $this->stuckCount = 0;
                $this->syncPatrolIndexForward();
                break;
            case self::STATE_HUNT:
                $this->speed = self::SPEED_CHASE * $this->speedMultiplier;
                $this->baseTarget = null;
                break;
            case self::STATE_INVESTIGATE:
                $this->speed = self::SPEED_INVESTIGATE * $this->speedMultiplier;
                $this->investigateTimer = 200;
                $this->microPatrolCount = 0;
                $this->investigateDropped = false;
                $this->voiceLinePlayed = false;
                break;
            case self::STATE_CHASE:
                $this->speed = self::SPEED_CHASE * $this->speedMultiplier;
                $this->noiseTarget = null;
                break;
            case self::STATE_STUNNED:
                $this->speed = self::SPEED_STUNNED;
                $this->stunnedTimer = 200;
                $this->pathQueue = [];
                $this->baseTarget = null;
                $this->noiseTarget = null;
                $this->motionX = 0;
                $this->motionZ = 0;
                break;
            case self::STATE_SEARCH:
                $this->speed = self::SPEED_SEARCH * $this->speedMultiplier;
                $this->searchTimer = 100;
                $this->baseTarget = null;
                break;
        }
    }

    private function recalculatePath(Vector3 $target) {
        $plugin = $this->getPlugin();
        if ($plugin === null) {
            return;
        }
        $patrolOnly = ($this->state === self::STATE_PATROL);
        $this->pathQueue = $plugin->getNodeManager()->findPath($this, $target, $patrolOnly);
    }

    private function getMovementTarget() {
        if ($this->isLookingAround || $this->pauseTimer > 0) {
            return null;
        }
        if (!empty($this->pathQueue)) {
            return $this->pathQueue[0];
        }
        return null;
    }

    private function startLookAround() {
        $this->isLookingAround = true;
        $this->lookAroundPhase = 0;
        $this->lookAroundTimer = 0;
        $this->lookAroundBaseYaw = $this->yaw;
        $this->motionX = 0;
        $this->motionZ = 0;
    }

    private function tickLookAround($tickDiff) {
        $this->lookAroundTimer += $tickDiff;

        switch ($this->lookAroundPhase) {
            case 0:
                if ($this->lookAroundTimer >= 5) {
                    $this->lookAroundPhase = 1;
                    $this->lookAroundTimer = 0;
                }
                break;
            case 1:
                $progress = min(1.0, $this->lookAroundTimer / 8.0);
                $this->yaw = $this->lookAroundBaseYaw - 55 * $progress;
                if ($this->lookAroundTimer >= 8) {
                    $this->lookAroundPhase = 2;
                    $this->lookAroundTimer = 0;
                }
                break;
            case 2:
                if ($this->lookAroundTimer >= 6) {
                    $this->lookAroundPhase = 3;
                    $this->lookAroundTimer = 0;
                }
                break;
            case 3:
                $progress = min(1.0, $this->lookAroundTimer / 12.0);
                $this->yaw = $this->lookAroundBaseYaw - 55 + 110 * $progress;
                if ($this->lookAroundTimer >= 12) {
                    $this->lookAroundPhase = 4;
                    $this->lookAroundTimer = 0;
                }
                break;
            case 4:
                if ($this->lookAroundTimer >= 6) {
                    $this->lookAroundPhase = 5;
                    $this->lookAroundTimer = 0;
                }
                break;
            case 5:
                $progress = min(1.0, $this->lookAroundTimer / 6.0);
                $this->yaw = $this->lookAroundBaseYaw + 55 - 55 * $progress;
                if ($this->lookAroundTimer >= 6) {
                    $this->isLookingAround = false;
                    $this->yaw = $this->lookAroundBaseYaw;
                }
                break;
        }
        $this->updateMovement();
    }

    private function tickHeadSway($tickDiff) {
        if ($this->state === self::STATE_STUNNED) return;
        if ($this->isLookingAround) return;

        $this->headSwayTimer += $tickDiff;
        if ($this->headSwayTimer >= 4) {
            $this->headSwayTimer = 0;
            if ($this->state === self::STATE_PATROL || $this->state === self::STATE_INVESTIGATE) {
                $this->yaw += $this->headSwayDir * (mt_rand(5, 15) / 10.0);
                if (mt_rand(0, 100) < 15) {
                    $this->headSwayDir *= -1;
                }
            }
        }
    }

    protected function checkJump($dx, $dz) {
        if (!$this->onGround) return false;
        if ($this->isCollidedHorizontally) {
            $this->motionY = 0.42;
            return true;
        }
        return false;
    }

    public function updateMove($tickDiff) {
        if ($this->isLookingAround) {
            $this->tickLookAround($tickDiff);
            if (!$this->onGround) {
                $this->motionY -= $this->gravity;
                $this->move(0, $this->motionY * $tickDiff, 0);
            }
            return;
        }

        if ($this->pauseTimer > 0) {
            $this->pauseTimer -= $tickDiff;
            $this->motionX = 0;
            $this->motionZ = 0;
            if (!$this->onGround) {
                $this->motionY -= $this->gravity;
                $this->move(0, $this->motionY * $tickDiff, 0);
            }
            $this->updateMovement();
            return;
        }

        $target = $this->getMovementTarget();
        if ($target === null) {
            $this->motionX = 0;
            $this->motionZ = 0;
            if (!$this->onGround) {
                $this->motionY -= $this->gravity;
                $this->move(0, $this->motionY * $tickDiff, 0);
                $this->updateMovement();
            }
            return;
        }

        if ($this->state === self::STATE_STUNNED) {
            $this->motionX = 0;
            $this->motionZ = 0;
            if (!$this->onGround) {
                $this->motionY -= $this->gravity;
                $this->move(0, $this->motionY * $tickDiff, 0);
            }
            $this->updateMovement();
            return;
        }

        $targetPos = $target;

        $arrivedAtNode = false;
        if (!empty($this->pathQueue)) {
            $nx = $this->pathQueue[0]->x - $this->x;
            $nz = $this->pathQueue[0]->z - $this->z;
            $distToNode2D = $nx * $nx + $nz * $nz;
            if ($distToNode2D < 0.64) {
                array_shift($this->pathQueue);
                $arrivedAtNode = true;
                if (!empty($this->pathQueue)) {
                    $targetPos = $this->pathQueue[0];
                } else {
                    $this->motionX = 0;
                    $this->motionZ = 0;
                    $this->updateMovement();
                    return;
                }
            }
        }

        if ($arrivedAtNode && $this->state === self::STATE_PATROL) {
            if (mt_rand(0, 100) < 40) {
                $this->startLookAround();
                return;
            }
            if (mt_rand(0, 100) < 25) {
                $this->pauseTimer = mt_rand(10, 25);
                $this->startLookAround();
                return;
            }
        }

        $x = $targetPos->x - $this->x;
        $y = $targetPos->y - $this->y;
        $z = $targetPos->z - $this->z;
        $dist2D = sqrt($x * $x + $z * $z);

        if ($dist2D < 0.05) {
            $this->motionX = 0;
            $this->motionZ = 0;
        } else {
            $wobble = 0.0;
            if ($this->state === self::STATE_PATROL) {
                $wobble = (mt_rand(-10, 10) / 1000.0);
            }

            $this->motionX = ($this->speed + $wobble) * 0.15 * ($x / $dist2D);
            $this->motionZ = ($this->speed + $wobble) * 0.15 * ($z / $dist2D);

            $targetYaw = -atan2($x / $dist2D, $z / $dist2D) * 180 / M_PI;
            $yawDiff = fmod($targetYaw - $this->yaw + 540, 360) - 180;
            $turnRate = ($this->state === self::STATE_CHASE) ? 0.6 : 0.3;
            $this->yaw += $yawDiff * $turnRate;
        }

        if (abs($y) < 1.5) {
            $this->pitch = 0;
        } else {
            $this->pitch = rad2deg(-atan2($y, $dist2D));
        }

        $dx = $this->motionX * $tickDiff;
        $dz = $this->motionZ * $tickDiff;

        $isJump = $this->checkJump($dx, $dz);

        $this->move($dx, $this->motionY * $tickDiff, $dz);

        if (!$isJump) {
            if ($this->onGround) {
                $this->motionY = 0;
            } elseif ($this->motionY > -$this->gravity * 4) {
                $this->motionY = -$this->gravity * 4;
            } else {
                $this->motionY -= $this->gravity;
            }
        }

        $this->updateMovement();
    }

    public function onUpdate($currentTick) {
        if ($this->closed) return false;

        $tickDiff = $currentTick - $this->lastUpdate;
        if ($tickDiff <= 0) return false;
        $this->lastUpdate = $currentTick;

        if ($this->attackDelay > 0) {
            $this->attackDelay -= $tickDiff;
        }

        $this->slowTickTimer += $tickDiff;
        $this->targetCheckTimer += $tickDiff;

        $this->entityBaseTick($tickDiff);

        if ($this->closed || !$this->isAlive()) {
            return false;
        }

        if ($this->isCutscenePuppet) {
            $this->updateMove($tickDiff);
            return !$this->closed;
        }

        if ($this->isFrozen) {
            $this->motionX = 0;
            $this->motionZ = 0;
            return !$this->closed;
        }

        if (empty($this->pathQueue) || $this->targetCheckTimer >= 5) {
            $this->targetCheckTimer = 0;
            $this->tickAIState($tickDiff);
        }

        $this->updateMove($tickDiff);
        $this->tickHeadSway($tickDiff);

        if ($this->state === self::STATE_CHASE && $this->baseTarget instanceof Player) {
            $dist = $this->distanceSquared($this->baseTarget);
            if ($dist <= $this->meleeRangeSq && $this->baseTarget->isAlive()) {
                $this->attackPlayer($this->baseTarget);
            }
        }

        if ($this->slowTickTimer >= 10) {
            $this->slowTickTimer = 0;
            $this->tickDetection();
        }

        if ($this->stuckTimer >= 30) {
            $this->stuckTimer = 0;
            $this->tickStuckDetection();
        }
        $this->stuckTimer += $tickDiff;

        if ($this->stunnedTimer > 0) $this->stunnedTimer -= $tickDiff;
        if ($this->investigateTimer > 0) $this->investigateTimer -= $tickDiff;
        if ($this->searchTimer > 0) $this->searchTimer -= $tickDiff;

        return !$this->closed;
    }

    private function tickAIState($tickDiff) {
        switch ($this->state) {
            case self::STATE_PATROL:
                $this->tickPatrol();
                break;
            case self::STATE_HUNT:
                $this->tickHunt();
                break;
            case self::STATE_INVESTIGATE:
                $this->tickInvestigate();
                break;
            case self::STATE_CHASE:
                $this->tickChase();
                break;
            case self::STATE_STUNNED:
                $this->tickStunned();
                break;
            case self::STATE_SEARCH:
                $this->tickSearch();
                break;
        }
    }

    private function syncPatrolIndexForward() {
        $plugin = $this->getPlugin();
        if ($plugin === null) return;
        
        $patrolNodes = $plugin->getNodeManager()->getPatrolNodes();
        if (empty($patrolNodes)) return;

        $closestIdx = 0;
        $closestDist = PHP_INT_MAX;

        foreach ($patrolNodes as $idx => $node) {
            $dist = $this->distanceSquared($node->getPosition());
            if ($dist < $closestDist) {
                $closestDist = $dist;
                $closestIdx = $idx;
            }
        }

        $this->patrolIndex = ($closestIdx + 1) % count($patrolNodes);
        $this->pathQueue = [];
    }

    private function tickPatrol() {
        $plugin = $this->getPlugin();
        if ($plugin === null) return;

        $patrolNodes = $plugin->getNodeManager()->getPatrolNodes();
        if (empty($patrolNodes)) return;

        if ($this->patrolIndex >= count($patrolNodes)) {
            $this->patrolIndex = 0;
        }

        $target = $patrolNodes[$this->patrolIndex]->getPosition();
        if ($this->distanceSquared($target) < 0.25) {
            $this->patrolIndex++;
            if ($this->patrolIndex >= count($patrolNodes)) {
                $this->patrolIndex = 0;
            }
            $this->pathQueue = [];
            return;
        }

        if (empty($this->pathQueue)) {
            $this->recalculatePath($target);
        }
    }

    private function tickHunt() {
        if ($this->noiseTarget === null) {
            $this->setState(self::STATE_PATROL);
            return;
        }

        if (!empty($this->pathQueue)) {
            return;
        }

        $plugin = $this->getPlugin();
        if ($plugin !== null) {
            $closest = $plugin->getNodeManager()->getClosestNode($this->noiseTarget);
            if ($closest !== null && $this->distanceSquared($closest->getPosition()) < 2.0) {
                $this->setState(self::STATE_INVESTIGATE);
                return;
            }
        }

        $this->recalculatePath($this->noiseTarget);
        if (empty($this->pathQueue)) {
            $this->setState(self::STATE_INVESTIGATE);
        }
    }

private function tickInvestigate() {
    if (!$this->voiceLinePlayed) {
        $this->voiceLinePlayed = true;
        $line = self::$voiceLines[array_rand(self::$voiceLines)];
        foreach ($this->getLevel()->getNearbyEntities($this->getBoundingBox()->grow(20, 20, 20), $this) as $entity) {
            if ($entity instanceof Player) {
                $plugin = $this->getPlugin();
                if ($plugin !== null) {
                    $session = null;
                    $am = $plugin->getArenaManager();
                    if ($am !== null) {
                        foreach ($am->getSessions() as $s) {
                            if ($s->getWorldName() === $this->getLevel()->getFolderName()) {
                                $session = $s;
                                break;
                            }
                        }
                    }
                    if ($session === null || $session->isPlayerInSession($entity->getName())) {
                        $entity->sendTip($line);
                    }
                } else {
                    $entity->sendTip($line);
                }
            }
        }
    }

    if (!$this->investigateDropped && $this->trapsPlaced < 2) {
        $this->investigateDropped = true;
        $plugin = $this->getPlugin();
        if ($plugin !== null) {
            BearTrapEntity::createTrap($plugin, new Vector3($this->x, $this->y, $this->z), $this->getLevel());
            $this->trapsPlaced++;
        }
    }

    if (!$this->isLookingAround && $this->investigateTimer > 0 && $this->investigateTimer % 35 === 0) {
        $this->startLookAround();
        $this->microPatrolCount++;
    }

    if ($this->investigateTimer <= 0) {
        $this->setState(self::STATE_PATROL);
    }
}

public function getTrapCount() {
    return $this->trapsPlaced;
}

public function resetTrapCount() {
    $this->trapsPlaced = 0;
}

    private function tickChase() {
        if ($this->baseTarget === null || !($this->baseTarget instanceof Player)) {
            $this->setState(self::STATE_PATROL);
            return;
        }

        $player = $this->baseTarget;

        if (!$player->isOnline() || !$player->isAlive() || $player->getGamemode() === 3) {
            if ($this->lastTargetPos !== null) {
                $this->noiseTarget = $this->lastTargetPos;
                $this->pathQueue = [];
                $this->recalculatePath($this->lastTargetPos);
                $this->setState(self::STATE_SEARCH);
            } else {
                $this->setState(self::STATE_PATROL);
            }
            return;
        }

        $canSee = $this->canSeePlayer($player);

        if ($canSee) {
            $this->lastTargetPos = new Vector3($player->x, $player->y, $player->z);
        }

        if ($canSee) {
            if (empty($this->pathQueue)) {
                $this->recalculatePath($player);
            } else {
                $dest = end($this->pathQueue);
                if ($dest instanceof Vector3 && $dest->distanceSquared($player) > 9.0) {
                    $this->recalculatePath($player);
                }
            }
        } else {
            if (empty($this->pathQueue)) {
                if ($this->lastTargetPos !== null) {
                    $this->noiseTarget = $this->lastTargetPos;
                    $this->setState(self::STATE_SEARCH);
                    $this->recalculatePath($this->lastTargetPos);
                } else {
                    $this->setState(self::STATE_PATROL);
                }
            }
        }
    }

    private function canSeePlayer(Player $player) {
        $plugin = $this->getPlugin();
        if ($plugin !== null && $plugin->isGhost($player->getName())) {
            return false;
        }
        $distSq = $this->distanceSquared($player);
        $maxDistSq = ($this->state === self::STATE_CHASE || $this->state === self::STATE_HUNT || $this->state === self::STATE_SEARCH) ? 1225 : 484;
        if ($distSq > $maxDistSq) {
            return false;
        }

        $dx = $player->x - $this->x;
        $dz = $player->z - $this->z;
        $targetYaw = -atan2($dx, $dz) * 180 / M_PI;
        $diff = abs(fmod($targetYaw - $this->yaw + 540, 360) - 180);

        $maxAngle = ($this->state === self::STATE_CHASE || $this->state === self::STATE_HUNT || $this->state === self::STATE_SEARCH) ? 160 : 85;

        $inAngle = false;
        if ($diff <= $maxAngle) {
            $inAngle = true;
        } elseif ($diff <= 180 && $distSq <= 16) {
            $inAngle = true;
        }

        if (!$inAngle) {
            return false;
        }

        $level = $this->getLevel();
        if ($level === null) return false;

        $grannyEye = new \pocketmine\math\Vector3($this->x, $this->y + $this->eyeHeight, $this->z);
        $playerEye = new \pocketmine\math\Vector3($player->x, $player->y + $player->getEyeHeight(), $player->z);
        $playerChest = new \pocketmine\math\Vector3($player->x, $player->y + 1.3, $player->z);

        if (\Granny\utils\LineOfSight::hasLineOfSight($level, $grannyEye, $playerEye)) {
            return true;
        }
        if (\Granny\utils\LineOfSight::hasLineOfSight($level, $grannyEye, $playerChest)) {
            return true;
        }

        return false;
    }

    private function tickSearch() {
        if (!$this->isLookingAround && $this->searchTimer > 0 && $this->searchTimer % 25 === 0) {
            $this->startLookAround();
        }

        if (!empty($this->pathQueue)) {
            return;
        }

        if ($this->noiseTarget !== null) {
            $plugin = $this->getPlugin();
            if ($plugin !== null) {
                $closest = $plugin->getNodeManager()->getClosestNode($this->noiseTarget);
                if ($closest !== null && $this->distanceSquared($closest->getPosition()) < 2.0) {
                    $this->noiseTarget = null;
                } else {
                    $this->recalculatePath($this->noiseTarget);
                    if (empty($this->pathQueue)) {
                        $this->noiseTarget = null;
                    }
                }
            }
        }

        if ($this->searchTimer <= 0) {
            $this->setState(self::STATE_PATROL);
        }
    }

    private function tickStunned() {
        $this->motionX = 0;
        $this->motionY = 0;
        $this->motionZ = 0;

        if ($this->hasFellAsleep) {
            $this->pitch = 85;
            $this->updateRotationPublic($this->yaw, 85);
        } else {
            $this->pitch = 0;
            $this->updateRotationPublic($this->yaw, 0);
        }

        if ($this->dartFreezeTimer > 0) {
            $this->dartFreezeTimer--;
            if ($this->dartFreezeTimer <= 0 && !$this->hasFellAsleep) {
                $this->collapseUnconscious($this->stunnedTimer);
            }
            return;
        }

        if ($this->stunnedTimer <= 0) {
            $this->pitch = 0;
            $this->updateRotationPublic($this->yaw, 0);
            $this->resetToSpawn();
            $this->setState(self::STATE_PATROL);
        }
    }

private function tickDetection() {
    if ($this->state === self::STATE_STUNNED || $this->state === self::STATE_CHASE) {
        return;
    }

    if ($this->isCutscenePuppet || $this->isFrozen) {
        return;
    }

    $plugin = $this->getPlugin();
    if ($plugin === null) return;

    $session = null;
    $am = $plugin->getArenaManager();
    if ($am !== null) {
        $myWorld = $this->getLevel()->getFolderName();
        foreach ($am->getSessions() as $s) {
            if ($s->getWorldName() === $myWorld) {
                $session = $s;
                break;
            }
        }
    }

    if ($session === null) return;

    $sessionPlayers = $session->getPlayers();

    foreach ($sessionPlayers as $playerName) {
        $player = $plugin->getServer()->getPlayerExact($playerName);
        if ($player === null) continue;
        if (!$player->isAlive() || $player->getGamemode() === 3) continue;

        $ps = $session->getPlayerState();
        if (!$ps->isAlive($player->getName())) continue;

        if ($player->getLevel()->getFolderName() !== $this->getLevel()->getFolderName()) continue;

        if (!$this->canSeePlayer($player)) continue;

        $this->baseTarget = $player;
        $this->isLookingAround = false;
        $this->pauseTimer = 0;
        $this->pathQueue = [];
        $this->setState(self::STATE_CHASE);
        $this->recalculatePath($player);
        return;
    }
}

private function tickStuckDetection() {
    if ($this->state === self::STATE_STUNNED || $this->state === self::STATE_INVESTIGATE) {
        $this->lastStuckX = $this->x;
        $this->lastStuckZ = $this->z;
        $this->stuckCount = 0;
        return;
    }

    if ($this->isLookingAround || $this->pauseTimer > 0) {
        $this->lastStuckX = $this->x;
        $this->lastStuckZ = $this->z;
        return;
    }

    $dx = $this->x - $this->lastStuckX;
    $dz = $this->z - $this->lastStuckZ;
    $movedSq = $dx * $dx + $dz * $dz;

    if ($movedSq < 0.01) {
        $this->stuckCount++;

        $plugin = $this->getPlugin();
        if ($plugin === null) {
            $this->stuckCount = 0;
            $this->lastStuckX = $this->x;
            $this->lastStuckZ = $this->z;
            return;
        }

        if ($this->stuckCount >= 2) {
            $closest = $plugin->getNodeManager()->getClosestNode($this);
            if ($closest !== null) {
                $pos = $closest->getPosition();
                $this->setPosition(new Vector3($pos->x, $pos->y, $pos->z));
                $this->pathQueue = [];
                $this->stuckCount = 0;

                if ($this->state === self::STATE_HUNT && $this->noiseTarget !== null) {
                    $this->recalculatePath($this->noiseTarget);
                } elseif ($this->state === self::STATE_CHASE && $this->baseTarget !== null) {
                    $this->recalculatePath($this->baseTarget);
                } elseif ($this->state === self::STATE_SEARCH && $this->noiseTarget !== null) {
                    $this->recalculatePath($this->noiseTarget);
                }
            }
        }
    } else {
        $this->stuckCount = 0;
    }

    $this->lastStuckX = $this->x;
    $this->lastStuckZ = $this->z;
}

    public function entityBaseTick($tickDiff = 1, $EnchantL = 0) {
        Timings::$timerEntityBaseTick->startTiming();

        if ($this->closed) {
            Timings::$timerEntityBaseTick->stopTiming();
            return false;
        }

        if (!$this->isAlive()) {
            $this->despawnFromAll();
            $this->close();
            Timings::$timerEntityBaseTick->stopTiming();
            return false;
        }

        if (count($this->effects) > 0) {
            foreach ($this->effects as $effect) {
                if ($effect->canTick()) {
                    $effect->applyEffect($this);
                }
                $effect->setDuration($effect->getDuration() - $tickDiff);
                if ($effect->getDuration() <= 0) {
                    $this->removeEffect($effect->getId());
                }
            }
        }

        $hasUpdate = false;

        if ($this->y <= -16 && $this->isAlive()) {
            $ev = new EntityDamageEvent($this, EntityDamageEvent::CAUSE_VOID, 10);
            $this->attack($ev->getFinalDamage(), $ev);
            $hasUpdate = true;
        }

        if ($this->noDamageTicks > 0) {
            $this->noDamageTicks -= $tickDiff;
            if ($this->noDamageTicks < 0) {
                $this->noDamageTicks = 0;
            }
        }

        $this->age += $tickDiff;
        $this->ticksLived += $tickDiff;

        if ($this->attackTime > 0) {
            $this->attackTime -= $tickDiff;
        }

        Timings::$timerEntityBaseTick->stopTiming();
        return $hasUpdate;
    }

    public function updateRotationPublic($yaw, $pitch) {
        $this->yaw = $yaw;
        $this->pitch = $pitch;
        $level = $this->getLevel();
        if ($level !== null) {
            $chunk = $level->getChunk(((int)$this->x) >> 4, ((int)$this->z) >> 4);
            if ($chunk !== null) {
                $level->addEntityMovement($chunk->getX(), $chunk->getZ(), $this->getId(), $this->x, $this->y + $this->getEyeHeight(), $this->z, $this->yaw, $this->pitch, $this->yaw);
            }
        }
    }

    public function makePlayerFaceMe(Player $player) {
        $dx = $this->x - $player->x;
        $dy = ($this->y + $this->eyeHeight) - ($player->y + $player->getEyeHeight());
        $dz = $this->z - $player->z;
        $dist = sqrt($dx * $dx + $dz * $dz);

        $yaw = -atan2($dx, $dz) * 180 / M_PI;
        $pitch = ($dist > 0) ? -atan2($dy, $dist) * 180 / M_PI : 0;

        $player->teleport(new Vector3($player->x, $player->y, $player->z), $yaw, $pitch);

        $plugin = $this->getPlugin();
        if ($plugin !== null) {
            $name = $player->getName();
            $targetPos = new Vector3($player->x, $player->y, $player->z);
            $plugin->scheduleTask(function() use ($plugin, $name, $targetPos, $yaw, $pitch) {
                $p = $plugin->getServer()->getPlayerExact($name);
                if ($p !== null && $p->isOnline()) {
                    $p->teleport($targetPos, $yaw, $pitch);
                }
            }, 1);
        }

        $grannyYaw = -atan2(-$dx, -$dz) * 180 / M_PI;
        $grannyPitch = ($dist > 0) ? -atan2(-$dy, $dist) * 180 / M_PI : 0;
        $this->yaw = $grannyYaw;
        $this->pitch = $grannyPitch;
    }

    private function attackPlayer(Player $player) {
        $plugin = $this->getPlugin();
        if ($plugin !== null && $plugin->isGhost($player->getName())) {
            return;
        }
        if ($this->attackDelay > 0) {
            return;
        }
        $this->attackDelay = self::ATTACK_COOLDOWN;

        if ($plugin !== null) {
            $plugin->getTrapManager()->setTrapped($player->getName(), false);
            $player->setXpLevel(0);
            $player->setXpProgress(0.0);
            $plugin->getCutsceneManager()->startBuiltInScene($player, "caught");
        }

        $this->setFrozen(true);
        $this->isLookingAround = false;
        $this->pathQueue = [];
        $this->motionX = 0;
        $this->motionZ = 0;

        $ev = new EntityDamageByEntityEvent($this, $player, EntityDamageEvent::CAUSE_ENTITY_ATTACK, 0);
        $player->attack(0, $ev);

        if ($plugin !== null) {
            $task = new BuiltInCaughtAnimationTask($plugin, $this, $player);
            $plugin->getServer()->getScheduler()->scheduleRepeatingTask($task, 1);
        }
    }

    public function stunWithDart($duration = 1200) {
        $this->setState(self::STATE_STUNNED);
        $this->stunnedTimer = $duration + 40;
        $this->dartFreezeTimer = 40;
        $this->hasFellAsleep = false;
    }

    public function stun($duration = 1200) {
        $this->setState(self::STATE_STUNNED);
        $this->stunnedTimer = $duration;
        $this->dartFreezeTimer = 0;
        $this->hasFellAsleep = false;
        $this->pitch = 85;
        $this->updateRotationPublic($this->yaw, 85);
        $this->collapseUnconscious($duration);
    }

    private function collapseUnconscious($duration) {
        $this->hasFellAsleep = true;
        $level = $this->getLevel();
        if ($level === null) return;

        $this->motionX = 0;
        $this->motionY = 0;
        $this->motionZ = 0;
        $this->pitch = 85;
        $this->updateRotationPublic($this->yaw, 85);

        $dartItem = Item::get(Item::ARROW, 0, 1);
        $level->dropItem(new Vector3($this->x, $this->y + 0.5, $this->z), $dartItem);

        foreach ($level->getPlayers() as $p) {
            $p->sendTip("§a§lGranny is gone for about " . round($duration / 20) . " seconds!§r");
        }
    }

    public function attack($damage, EntityDamageEvent $source) {
        if ($this->state === self::STATE_STUNNED) {
            $isArrow = false;
            if ($source instanceof \pocketmine\event\entity\EntityDamageByChildEntityEvent) {
                $child = $source->getChild();
                if ($child instanceof \pocketmine\entity\Arrow || $child instanceof \pocketmine\entity\Projectile) {
                    $isArrow = true;
                    if (!$child->closed) $child->close();
                }
            } elseif ($source instanceof \pocketmine\event\entity\EntityDamageByEntityEvent) {
                $damager = $source->getDamager();
                if ($damager instanceof \pocketmine\entity\Arrow || $damager instanceof \pocketmine\entity\Projectile) {
                    $isArrow = true;
                    if (!$damager->closed) $damager->close();
                }
            }

            if ($isArrow) {
                $level = $this->getLevel();
                if ($level !== null) {
                    $level->dropItem(new Vector3($this->x, $this->y + 0.5, $this->z), Item::get(Item::ARROW, 0, 1));
                }
            }

            $source->setCancelled(true);
            return;
        }
        if ($source instanceof \pocketmine\event\entity\EntityDamageByChildEntityEvent) {
            $child = $source->getChild();
            if ($child instanceof \pocketmine\entity\Arrow || $child instanceof \pocketmine\entity\Projectile) {
                if (!$child->closed) {
                    $child->close();
                }

                $duration = 1200;
                $plugin = $this->getPlugin();
                if ($plugin !== null) {
                    $am = $plugin->getArenaManager();
                    if ($am !== null) {
                        foreach ($am->getSessions() as $s) {
                            if ($s->getWorldName() === $this->getLevel()->getFolderName()) {
                                $diff = strtolower($s->getDifficulty());
                                if ($diff === "easy") $duration = 2400;
                                elseif ($diff === "hard") $duration = 600;
                                elseif ($diff === "normal") $duration = 1200;
                                break;
                            }
                        }
                    }
                }
                $this->stunWithDart($duration);
                $source->setCancelled(true);
                return;
            }
        } elseif ($source instanceof EntityDamageByEntityEvent) {
            $attacker = $source->getDamager();

            if ($attacker instanceof \pocketmine\entity\Arrow || $attacker instanceof \pocketmine\entity\Projectile) {
                if (!$attacker->closed) {
                    $attacker->close();
                }

                $duration = 1200;
                $plugin = $this->getPlugin();
                if ($plugin !== null) {
                    $am = $plugin->getArenaManager();
                    if ($am !== null) {
                        foreach ($am->getSessions() as $s) {
                            if ($s->getWorldName() === $this->getLevel()->getFolderName()) {
                                $diff = strtolower($s->getDifficulty());
                                if ($diff === "easy") $duration = 2400;
                                elseif ($diff === "hard") $duration = 600;
                                elseif ($diff === "normal") $duration = 1200;
                                break;
                            }
                        }
                    }
                }
                $this->stunWithDart($duration);
                $source->setCancelled(true);
                return;
            }
        }
        $source->setCancelled(true);
    }

    public function knockBack(Entity $attacker, $damage, $x, $z, $base = 0.4) {
    }

    public function close() {
        if ($this->corpseEntity !== null && !$this->corpseEntity->closed) {
            $this->corpseEntity->close();
            $this->corpseEntity = null;
        }
        parent::close();
    }

    public function getDrops() {
        return [];
    }
}
