<?php

namespace Granny\game;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\entity\Entity;
use pocketmine\entity\Effect;
use pocketmine\item\Item;
use pocketmine\scheduler\PluginTask;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ShortTag;
use Granny\Main;
use Granny\entity\GrannyEntity;

class GameSession {

    const PHASE_WAITING = 0;
    const PHASE_INGAME = 1;
    const PHASE_ENDING = 2;
    const PHASE_CUTSCENE_END = 3;

    private $plugin;
    private $id;
    private $worldName;
    private $phase = self::PHASE_WAITING;
    private $players = [];
    private $playerDays = [];
    private $playerState;
    private $granny = null;
    private $unlockProgress = [];
    private $pendingEnd = null;
    private $cutscenePlayers = 0;
    private $unlockedLocks = [];
    private $screwdriverDropped = false;
    private $savedInventories = [];

    public function __construct(Main $plugin, $id, $worldName) {
        $this->plugin = $plugin;
        $this->id = $id;
        $this->worldName = $worldName;
        $this->playerState = new PlayerState();
    }

    public function getId() { return $this->id; }
    public function getWorldName() { return $this->worldName; }
    public function getDifficulty() {
        if (!empty($this->players)) {
            return $this->plugin->getMainLobby()->getDifficulty($this->players[0]);
        }
        return "normal";
    }
    public function getPhase() { return $this->phase; }
    public function getPlayerState() { return $this->playerState; }
    public function getGranny() { return $this->granny; }
    public function getPlayers() { return $this->players; }
    public function isScrewdriverDropped() { return $this->screwdriverDropped; }
    public function setScrewdriverDropped($dropped) { $this->screwdriverDropped = (bool)$dropped; }

    public function savePlayerInventory(Player $player) {
        $inv = $player->getInventory();
        $items = [];
        for ($slot = 0; $slot < $inv->getSize(); $slot++) {
            $item = $inv->getItem($slot);
            if ($item->getId() !== 0) {
                $items[$slot] = clone $item;
            }
        }
        $this->savedInventories[$player->getName()] = $items;
    }

    public function restorePlayerInventory(Player $player) {
        $name = $player->getName();
        if (isset($this->savedInventories[$name])) {
            $inv = $player->getInventory();
            $inv->clearAll();
            foreach ($this->savedInventories[$name] as $slot => $item) {
                $inv->setItem($slot, $item);
            }
            unset($this->savedInventories[$name]);
        }
    }

    public function getLevel() {
        return $this->plugin->getServer()->getLevelByName($this->worldName);
    }

    public function getDay($playerName) {
        return isset($this->playerDays[$playerName]) ? $this->playerDays[$playerName] : 1;
    }

    public function setDay($playerName, $day) {
        $this->playerDays[$playerName] = $day;
    }

    public function getUnlockProgress() {
        return $this->unlockProgress;
    }

    public function setUnlockProgress($key, $val) {
        $this->unlockProgress[$key] = $val;
    }

    public function isPartUnlocked($escName, $partName) {
        return isset($this->unlockProgress[$escName . ":" . $partName]);
    }

    public function setPartUnlocked($escName, $partName) {
        $this->unlockProgress[$escName . ":" . $partName] = true;
    }

public function isLockUnlocked($lockName) {
    return isset($this->unlockedLocks[$lockName]);
}

public function setLockUnlocked($lockName) {
    $this->unlockedLocks[$lockName] = true;
}

    public function getUnlockedCount($escName) {
        $count = 0;
        foreach ($this->unlockProgress as $key => $v) {
            if (strpos($key, $escName . ":") === 0) $count++;
        }
        return $count;
    }

    public function startGame(array $playerNames) {
        $this->phase = self::PHASE_INGAME;
        $this->unlockProgress = [];

        $playerCount = count($playerNames);
        $scaling = $this->getScaling($playerCount);

        $ml = $this->plugin->getMainLobby();
        $maxSpeed = 0;
        $maxDetect = 0;
        foreach ($playerNames as $pn) {
            $ds = $ml->getDifficultyScaling($pn);
            if ($ds["speed"] > $maxSpeed) $maxSpeed = $ds["speed"];
            if ($ds["detection"] > $maxDetect) $maxDetect = $ds["detection"];
        }
        if ($maxSpeed > 0) $scaling["speed_multiplier"] = $maxSpeed;
        if ($maxDetect > 0) $scaling["detection_multiplier"] = $maxDetect;
        $level = $this->getLevel();

        foreach ($playerNames as $name) {
            $player = $this->plugin->getServer()->getPlayerExact($name);
            if ($player === null) continue;
            $this->players[] = $name;
            $this->playerState->setState($name, PlayerState::STATE_ALIVE);
            $this->playerDays[$name] = 1;
            $this->teleportToStart($player);
            $player->getInventory()->clearAll();
            $player->getInventory()->addItem(Item::get(50, 0, 1));
            $player->setGamemode(0);
            $player->setHealth($player->getMaxHealth());
            $player->removeAllEffects();
            $player->sendTip("§f§lDAY 1§r\n\n\n\n\n");
            $this->plugin->getServer()->getCommandMap()->dispatch($player, "music stop");
        }

        $wn = $this->worldName;
        $this->plugin->getLockManager()->restoreAllLocks($wn);
        $this->plugin->getEscapeManager()->restoreAll($wn);

        $presetPicked = $this->plugin->getChestManager()->fillChestsWithRandomPreset($wn);
        if ($presetPicked !== null) {
            //$this->broadcastSession("§7Chest items loaded. §8[Preset: " . $presetPicked . "]");
        }

        $delay = (int)$this->plugin->getConfigValue("game.granny_spawn_delay", 5) * 20;
        $session = $this;
        $plugin = $this->plugin;
        $plugin->scheduleTask(function() use ($plugin, $session, $scaling) {
            $session->spawnGranny($scaling);
        }, $delay);

        //$this->broadcastSession("§4§lGAME STARTED! §r§7Escape before time runs out!");

        $cm = $this->plugin->getCutsceneManager();
        $points = $cm->getPoints("wake");
        if (count($points) >= 2) {
            foreach ($this->players as $name) {
                $p = $this->plugin->getServer()->getPlayerExact($name);
                if ($p !== null) {
                    $cm->playScene("wake", $p);
                }
            }
        }
    }

    public function playerEscaped(Player $player) {
        $name = $player->getName();
        $this->playerState->setState($name, PlayerState::STATE_ESCAPED);
        //$this->broadcastSession("§a" . $name . " §fhas escaped!");

        $this->plugin->getTrapManager()->setTrapped($name, false);
        $player->removeAllEffects();

        $alive = $this->playerState->getAlivePlayerNames();
        $shouldEnd = count($alive) <= 0;

        $cm = $this->plugin->getCutsceneManager();
        $points = $cm->getPoints("ending");

        if (count($points) >= 2) {
            if ($shouldEnd) {
                $this->phase = self::PHASE_CUTSCENE_END;
                $this->pendingEnd = true;
            }
            $cm->playScene("ending", $player);
            $this->cutscenePlayers++;
        } elseif ($shouldEnd) {
            $this->endGame(true);
        }
    }

public function playerCaptured(Player $player) {
    $name = $player->getName();
    $this->plugin->getTrapManager()->setTrapped($name, false);
    $player->setXpLevel(0);
    $player->setXpProgress(0.0);
    if ($this->granny !== null && !$this->granny->closed) {
        $this->granny->makePlayerFaceMe($player);
    }
    $day = $this->getDay($name);

    if ($day >= 5) {
        $this->playerState->setState($name, PlayerState::STATE_CAPTURED);
        $this->plugin->getTrapManager()->setTrapped($name, false);
        $player->removeAllEffects();
        $player->sendPopup("§4§lGAME OVER§r\n§cGranny got you on Day 5...");
        $this->playerDays[$name] = 1;

        $alive = $this->playerState->getAlivePlayerNames();
        $shouldEnd = count($alive) <= 0;

        $cm = $this->plugin->getCutsceneManager();
        $points = $cm->getPoints("gameover");

        if (count($points) >= 2) {
            if ($shouldEnd) {
                $this->phase = self::PHASE_CUTSCENE_END;
                $this->pendingEnd = false;
            }
            $cm->playScene("gameover", $player);
            $this->cutscenePlayers++;
        } else {
            $this->teleportToStart($player);
            $player->setGamemode(3);
            if ($shouldEnd) {
                $this->endGame(false);
            }
        }
        return;
    }

    $this->setDay($name, $day + 1);
    $newDay = $day + 1;

    $player->sendTip("§c§lDay " . $newDay . "§r\n\n\n\n\n");

    $grannyX = $this->granny !== null ? $this->granny->x : $player->x;
    $grannyY = $this->granny !== null ? $this->granny->y : $player->y;
    $grannyZ = $this->granny !== null ? $this->granny->z : $player->z;

    if ($this->granny !== null && !$this->granny->closed) {
        $this->granny->setFrozen(true);
    }

    $cm = $this->plugin->getCutsceneManager();
    $caughtPoints = $cm->getPoints("caught");

    if (count($caughtPoints) >= 2) {
        $cm->playCaughtScene($player, $grannyX, $grannyY, $grannyZ);

        $totalTime = 0;
        foreach ($caughtPoints as $i => $pt) {
            if ($i > 0) {
                $sec = isset($pt["seconds"]) ? $pt["seconds"] : 3.0;
                $totalTime += $sec;
            }
        }

        $afterCaughtDelay = (int)round(($totalTime + 1) * 20);
        $session = $this;
        $granny = $this->granny;
        $playerName = $player->getName();

        $this->plugin->scheduleTask(function() use ($session, $granny, $playerName) {
            $plugin = $session->getPlugin();
            $p = $plugin->getServer()->getPlayerExact($playerName);
            if ($p === null) return;

            $session->teleportToStartPublic($p);
            $p->setGamemode(0);
            $session->restorePlayerInventory($p);
            $p->setHealth($p->getMaxHealth());
            $p->removeAllEffects();

            if ($granny !== null && !$granny->closed) {
                $granny->resetToSpawn();
            }

            $cm = $plugin->getCutsceneManager();
            $wakePoints = $cm->getPoints("wake");
            if (count($wakePoints) >= 2) {
                $cm->playScene("wake", $p);

                $wakeTime = 0;
                foreach ($wakePoints as $i => $pt) {
                    if ($i > 0) $wakeTime += $pt["seconds"];
                    if (isset($pt["cut"])) $wakeTime += $pt["cut"];
                }
                $unfreezeDelay = (int)round(($wakeTime + 1) * 20);
                $plugin->scheduleTask(function() use ($granny) {
                    if ($granny !== null && !$granny->closed) {
                        $granny->setFrozen(false);
                    }
                }, $unfreezeDelay);
            } else {
                if ($granny !== null && !$granny->closed) {
                    $granny->setFrozen(false);
                }
            }
        }, $afterCaughtDelay);

    } else {
        $this->teleportToStart($player);
        $player->setGamemode(0);
        $this->restorePlayerInventory($player);
        $player->setHealth($player->getMaxHealth());
        $player->removeAllEffects();

        if ($this->granny !== null && !$this->granny->closed) {
            $this->granny->resetToSpawn();
            $this->granny->setFrozen(true);
        }

        $wakePoints = $cm->getPoints("wake");
        if (count($wakePoints) >= 2) {
            $cm->playScene("wake", $player);

            $totalTime = 0;
            foreach ($wakePoints as $i => $pt) {
                if ($i > 0) $totalTime += $pt["seconds"];
                if (isset($pt["cut"])) $totalTime += $pt["cut"];
            }
            $unfreezeDelay = (int)round(($totalTime + 1) * 20);
            $granny = $this->granny;
            $this->plugin->scheduleTask(function() use ($granny) {
                if ($granny !== null && !$granny->closed) {
                    $granny->setFrozen(false);
                }
            }, $unfreezeDelay);
        }
    }
}

public function teleportToStartPublic(Player $player) {
    $this->teleportToStart($player);
}

public function getPlugin() {
    return $this->plugin;
}

    public function onCutsceneFinished($playerName) {
        $this->cutscenePlayers--;
        if ($this->cutscenePlayers <= 0 && $this->phase === self::PHASE_CUTSCENE_END) {
            $won = $this->pendingEnd === true;
            $this->pendingEnd = null;
            $this->endGame($won);
        }
    }

    public function endGame($playersWon) {
        if ($this->phase === self::PHASE_ENDING) return;
        $this->phase = self::PHASE_ENDING;

        if ($playersWon) {
           // $this->broadcastSession("§a§lPLAYERS WIN! §r§7Escaped from Granny!");
        } else {
           // $this->broadcastSession("§c§lGRANNY WINS! §r§7No one escaped...");
        }

        $this->cleanup();
        $this->plugin->getArenaManager()->removeSession($this->getId());
    }

public function cleanup() {
    if ($this->granny !== null && !$this->granny->closed) {
        $this->granny->close();
    }
    $this->granny = null;

    $level = $this->getLevel();
    if ($level !== null) {
        foreach ($level->getEntities() as $entity) {
            if ($entity instanceof GrannyEntity || $entity instanceof \Granny\entity\BearTrapEntity) {
                if (!$entity->closed) $entity->close();
            }
        }
    }

    foreach ($this->players as $name) {
        $this->plugin->getTrapManager()->setTrapped($name, false);
        $player = $this->plugin->getServer()->getPlayerExact($name);
        if ($player !== null) {
            $player->removeAllEffects();
            $player->setGamemode(0);
            $this->plugin->getLobbyManager()->restorePlayer($player);
            $this->plugin->getMainLobby()->enterLobby($player);
        }
    }

    $this->playerState->resetAll();
    $this->players = [];
    $this->playerDays = [];
    $this->unlockProgress = [];
    $this->unlockedLocks = [];
    $this->screwdriverDropped = false;
}

    public function handlePlayerQuit(Player $player) {
        $name = $player->getName();
        if (!in_array($name, $this->players)) return;

        $this->playerState->setState($name, PlayerState::STATE_CAPTURED);
        $this->broadcastSession("§c" . $name . " §7disconnected.");
        $alive = $this->playerState->getAlivePlayerNames();
        if (count($alive) <= 0 && $this->phase === self::PHASE_INGAME) {
            $this->endGame(false);
        }
    }

public function removePlayer(Player $player) {
    $name = $player->getName();
    if (!in_array($name, $this->players)) return;

    $this->playerState->setState($name, PlayerState::STATE_CAPTURED);
    $this->plugin->getTrapManager()->setTrapped($name, false);

    $cm = $this->plugin->getCutsceneManager();
    if ($cm->isPlaying($name)) {
        $cm->stopScene($player, false);
    }

    $player->removeAllEffects();
    $player->setGamemode(0);
    $player->setHealth($player->getMaxHealth());
    $this->plugin->getLobbyManager()->restorePlayer($player);
    $this->plugin->getMainLobby()->enterLobby($player);

    $this->players = array_values(array_filter($this->players, function($p) use ($name) {
        return $p !== $name;
    }));
    unset($this->playerDays[$name]);
    $this->plugin->getArenaManager()->unassignPlayer($name);

    $this->broadcastSession("§c" . $name . " §7left the game.");

    $alive = $this->playerState->getAlivePlayerNames();
    $aliveInGame = [];
    foreach ($alive as $aName) {
        if (in_array($aName, $this->players)) {
            $aliveInGame[] = $aName;
        }
    }

    if (count($aliveInGame) <= 0 && $this->phase === self::PHASE_INGAME) {
        $this->endGame(false);
    }
}

    public function spawnGranny($scaling) {
        $x = (float)$this->plugin->getConfigValue("granny_spawn.x", 0);
        $y = (float)$this->plugin->getConfigValue("granny_spawn.y", 64);
        $z = (float)$this->plugin->getConfigValue("granny_spawn.z", 0);
        $level = $this->getLevel();
        if ($level === null) return;

        $skinData = $this->plugin->getGrannySkin();
        $skinId = $this->plugin->getGrannySkinId();
        if ($skinData === null) {
            foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                $skinData = $p->getSkinData();
                $skinId = $p->getSkinId();
                break;
            }
        }
        if ($skinData === null) return;

        $nbt = new CompoundTag("", [
            "Pos" => new ListTag("Pos", [
                new DoubleTag("", $x),
                new DoubleTag("", $y),
                new DoubleTag("", $z)
            ]),
            "Motion" => new ListTag("Motion", [
                new DoubleTag("", 0),
                new DoubleTag("", 0),
                new DoubleTag("", 0)
            ]),
            "Rotation" => new ListTag("Rotation", [
                new FloatTag("", 0),
                new FloatTag("", 0)
            ]),
            "Skin" => new CompoundTag("Skin", [
                "Data" => new StringTag("Data", $skinData),
                "Name" => new StringTag("Name", $skinId)
            ]),
            "Health" => new ShortTag("Health", 200)
        ]);

        $chunk = $level->getChunk(((int)$x) >> 4, ((int)$z) >> 4, true);
        $granny = Entity::createEntity("GrannyEntity", $chunk, $nbt);
        if ($granny !== null && $granny instanceof GrannyEntity) {
            $granny->setSpeedMultiplier(isset($scaling["speed_multiplier"]) ? (float)$scaling["speed_multiplier"] : 1.0);
            $granny->setDetectionMultiplier(isset($scaling["detection_multiplier"]) ? (float)$scaling["detection_multiplier"] : 1.0);
            $granny->spawnToAll();
            $this->granny = $granny;
        }
    }

    private function teleportToStart(Player $player) {
        $x = (float)$this->plugin->getConfigValue("start_room.x", 0);
        $y = (float)$this->plugin->getConfigValue("start_room.y", 64);
        $z = (float)$this->plugin->getConfigValue("start_room.z", 0);
        $level = $this->getLevel();
        if ($level !== null) {
            $player->teleport(new Position($x, $y, $z, $level));
        }
    }

    private function teleportToLobby(Player $player) {
        $x = (float)$this->plugin->getConfigValue("lobby.x", 0);
        $y = (float)$this->plugin->getConfigValue("lobby.y", 64);
        $z = (float)$this->plugin->getConfigValue("lobby.z", 0);
        $worldName = $this->plugin->getConfigValue("lobby.world", "world");
        $level = $this->plugin->getServer()->getLevelByName($worldName);
        if ($level === null) {
            $this->plugin->getServer()->loadLevel($worldName);
            $level = $this->plugin->getServer()->getLevelByName($worldName);
        }
        if ($level !== null) {
            $player->teleport(new Position($x, $y, $z, $level));
        }
    }

    private function getScaling($playerCount) {
        $key = (string)min($playerCount, 4);
        $scaling = $this->plugin->getConfigValue("scaling." . $key, null);
        if (!is_array($scaling)) {
            return ["speed_multiplier" => 1.0, "detection_multiplier" => 1.0];
        }
        return $scaling;
    }

    public function broadcastSession($msg) {
        foreach ($this->players as $name) {
            $p = $this->plugin->getServer()->getPlayerExact($name);
            if ($p !== null) {
                $p->sendMessage($msg);
            }
        }
    }

    public function isPlayerInSession($name) {
        return in_array($name, $this->players);
    }
}