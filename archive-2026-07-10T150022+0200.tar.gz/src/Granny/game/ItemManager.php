<?php

namespace Granny\game;

use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\entity\Entity;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ShortTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ByteTag;
use Granny\Main;

class ItemManager {

    const KEY_DOOR = 0;
    const KEY_WEAPON = 1;
    const SCREWDRIVER = 2;
    const BATTERY = 3;
    const DISTRACTION = 4;

    private $plugin;
    private $spawnedEntities = [];

    private static $itemDefs = [
        ["id" => 131, "meta" => 0, "name" => "§6Door Key"],
        ["id" => 101, "meta" => 0, "name" => "§bWeapon Key"],
        ["id" => 277, "meta" => 0, "name" => "§r§bScrewdriver"],
        ["id" => 348, "meta" => 0, "name" => "§aBattery"],
        ["id" => 344, "meta" => 0, "name" => "§dDistraction"]
    ];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function spawnItems() {
        $this->clearItems();
        $spawns = $this->plugin->getConfigValue("item_spawns", []);
        if(!is_array($spawns) || empty($spawns)) {
            return;
        }

        $available = self::$itemDefs;
        shuffle($available);
        shuffle($spawns);

        $count = min(count($available), count($spawns));
        for($i = 0; $i < $count; $i++) {
            $spawn = $spawns[$i];
            $def = $available[$i];
            $this->dropItemAt(
                new Vector3((float)$spawn["x"], (float)$spawn["y"], (float)$spawn["z"]),
                $def
            );
        }
    }

    private function dropItemAt(Vector3 $pos, $def) {
        $worldName = $this->plugin->getConfigValue("start_room.world", "world");
        $level = $this->plugin->getServer()->getLevelByName($worldName);
        if($level === null) {
            return;
        }

        $item = Item::get($def["id"], $def["meta"], 1);
        $item->setCustomName($def["name"]);

        $nbt = new CompoundTag("", [
            "Pos" => new ListTag("Pos", [
                new DoubleTag("", $pos->x),
                new DoubleTag("", $pos->y + 0.5),
                new DoubleTag("", $pos->z)
            ]),
            "Motion" => new ListTag("Motion", [
                new DoubleTag("", 0),
                new DoubleTag("", 0),
                new DoubleTag("", 0)
            ]),
            "Rotation" => new ListTag("Rotation", [
                new FloatTag("", 0),
                new FloatTag("", 0)
            ]),
            "Health" => new ShortTag("Health", 5),
            "Item" => new CompoundTag("Item", [
                "id" => new ShortTag("id", $item->getId()),
                "Damage" => new ShortTag("Damage", $item->getDamage()),
                "Count" => new ByteTag("Count", 1)
            ]),
            "PickupDelay" => new ShortTag("PickupDelay", 0),
            "Age" => new ShortTag("Age", 0)
        ]);

        $chunk = $level->getChunk(((int)$pos->x) >> 4, ((int)$pos->z) >> 4, true);
        $entity = Entity::createEntity("Item", $chunk, $nbt);
        if($entity !== null) {
            $entity->spawnToAll();
            $this->spawnedEntities[] = $entity;
        }
    }

    public function clearItems() {
        foreach($this->spawnedEntities as $entity) {
            if(!$entity->closed) {
                $entity->close();
            }
        }
        $this->spawnedEntities = [];
    }

    public function isKeyItem(Item $item) {
        foreach(self::$itemDefs as $def) {
            if($item->getId() === $def["id"] && $item->getDamage() === $def["meta"]) {
                return true;
            }
        }
        return false;
    }

    public function isDoorKey(Item $item) {
        $def = self::$itemDefs[self::KEY_DOOR];
        return $item->getId() === $def["id"] && $item->getDamage() === $def["meta"];
    }

    public function isDistraction(Item $item) {
        $def = self::$itemDefs[self::DISTRACTION];
        return $item->getId() === $def["id"] && $item->getDamage() === $def["meta"];
    }
    public function getItem($type) {
        if (!isset(self::$itemDefs[$type])) {
            return null;
        }
        $def = self::$itemDefs[$type];
        $item = Item::get($def["id"], $def["meta"], 1);
        $item->setCustomName($def["name"]);
        return $item;
    }
}
