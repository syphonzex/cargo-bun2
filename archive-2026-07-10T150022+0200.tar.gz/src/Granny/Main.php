<?php

namespace Granny;

use pocketmine\plugin\PluginBase;
use pocketmine\entity\Entity;
use Granny\entity\GrannyEntity;
use Granny\entity\BearTrapEntity;
use Granny\manager\NodeManager;
use Granny\manager\DayManager;
use Granny\manager\TrapManager;
use Granny\manager\LockManager;
use Granny\manager\ChestManager;
use Granny\manager\EscapeManager;
use Granny\manager\CutsceneManager;
use Granny\manager\WorldManager;
use Granny\game\GameManager;
use Granny\game\LobbyManager;
use Granny\game\PlayerState;
use Granny\game\ItemManager;
use Granny\game\MapReset;
use Granny\game\ArenaManager;
use Granny\game\MainLobby;
use Granny\listener\GrannyListener;
use Granny\command\GrannyCommand;

class Main extends PluginBase {

    private $nodeManager;
    private $dayManager;
    private $trapManager;
    private $lockManager;
    private $chestManager;
    private $escapeManager;
    private $cutsceneManager;
    private $worldManager;
    private $arenaManager;
    private $mainLobby;
    private $gameManager;
    private $lobbyManager;
    private $itemManager;
    private $mapReset;
    private $debugPlayers = [];
    private $ghostPlayers = [];
    private $grannySkin = null;
    private $grannySkinId = "granny";

    public function onEnable() {
        @mkdir($this->getDataFolder());
        $this->saveDefaultConfig();
        $this->saveResource("config.yml", false);
        Entity::registerEntity(GrannyEntity::class, true);
        Entity::registerEntity(BearTrapEntity::class, true);
        Entity::registerEntity(\Granny\entity\GrannyBodyEntity::class, true);
        $this->loadGrannySkin();
        $this->nodeManager = new NodeManager($this);
        $this->dayManager = new DayManager($this);
        $this->trapManager = new TrapManager($this);
        $this->lockManager = new LockManager($this);
        $this->chestManager = new ChestManager($this);
        $this->escapeManager = new EscapeManager($this);
        $this->cutsceneManager = new CutsceneManager($this);
        $this->worldManager = new WorldManager($this);
        $this->arenaManager = new ArenaManager($this);
        $this->mainLobby = new MainLobby($this);
        $this->itemManager = new ItemManager($this);
        $this->mapReset = new MapReset($this);
        $this->lobbyManager = new LobbyManager($this);
        $this->gameManager = new GameManager($this);
        $this->getServer()->getPluginManager()->registerEvents(new GrannyListener($this), $this);
        $this->getServer()->getCommandMap()->register("granny", new GrannyCommand($this));
    }

    public function onDisable() {
        $this->getServer()->getScheduler()->cancelTasks($this);
        $this->cleanupEntities();
        if ($this->arenaManager !== null) {
            $this->arenaManager->cleanupAll();
        }
        if ($this->worldManager !== null) {
            $this->worldManager->destroyWorldCopy(null);
        }
    }

    public function cleanupEntities() {
        foreach ($this->getServer()->getLevels() as $level) {
            foreach ($level->getEntities() as $entity) {
                if ($entity instanceof GrannyEntity || $entity instanceof BearTrapEntity) {
                    if (!$entity->closed) {
                        $entity->close();
                    }
                }
            }
        }
    }

    public function getNodeManager() { return $this->nodeManager; }
    public function getDayManager() { return $this->dayManager; }
    public function getTrapManager() { return $this->trapManager; }
    public function getLockManager() { return $this->lockManager; }
    public function getChestManager() { return $this->chestManager; }
    public function getEscapeManager() { return $this->escapeManager; }
    public function getCutsceneManager() { return $this->cutsceneManager; }
    public function getWorldManager() { return $this->worldManager; }
    public function getArenaManager() { return $this->arenaManager; }
    public function getMainLobby() { return $this->mainLobby; }
    public function getGameManager() { return $this->gameManager; }
    public function getLobbyManager() { return $this->lobbyManager; }
    public function getItemManager() { return $this->itemManager; }
    public function getMapReset() { return $this->mapReset; }

    private function loadGrannySkin() {
        $path = $this->getDataFolder() . "granny.png";
        if (!file_exists($path)) {
            $this->getLogger()->info("No granny.png found, using player skin.");
            return;
        }

        $img = @imagecreatefrompng($path);
        if ($img === false) {
            $this->getLogger()->warning("Failed to load granny.png - invalid image.");
            return;
        }

        $w = imagesx($img);
        $h = imagesy($img);

        if (($w === 64 && $h === 64) || ($w === 64 && $h === 32)) {
            $skinData = "";
            for ($y = 0; $y < $h; $y++) {
                for ($x = 0; $x < $w; $x++) {
                    $rgba = imagecolorat($img, $x, $y);
                    $a = ((~((int)($rgba >> 24))) << 1) & 0xff;
                    $r = ($rgba >> 16) & 0xff;
                    $g = ($rgba >> 8) & 0xff;
                    $b = $rgba & 0xff;
                    $skinData .= chr($r) . chr($g) . chr($b) . chr($a);
                }
            }
            imagedestroy($img);
            $this->grannySkin = $skinData;
            $this->getLogger()->info("Loaded granny.png skin (" . $w . "x" . $h . ")");
        } else {
            imagedestroy($img);
            $this->getLogger()->warning("granny.png must be 64x64 or 64x32, got " . $w . "x" . $h);
        }
    }

    public function getGrannySkin() {
        return $this->grannySkin;
    }

    public function getGrannySkinId() {
        return $this->grannySkinId;
    }

    public function isDebug($playerName) {
        return isset($this->debugPlayers[$playerName]);
    }

    public function isGhost($playerName) {
        return isset($this->ghostPlayers[strtolower($playerName)]) && $this->ghostPlayers[strtolower($playerName)];
    }

    public function toggleGhost(\pocketmine\Player $player) {
        $name = strtolower($player->getName());
        if ($this->isGhost($name)) {
            unset($this->ghostPlayers[$name]);
            $player->sendMessage("§c§l[Ghost Mode] §r§cDisabled! Granny can now see and attack you.");
            return false;
        }
        $this->ghostPlayers[$name] = true;
        $player->sendMessage("§a§l[Ghost Mode] §r§aEnabled! Granny can no longer see or attack you.");
        return true;
    }

    public function toggleDebug($playerName) {
        if (isset($this->debugPlayers[$playerName])) {
            unset($this->debugPlayers[$playerName]);
            return false;
        }
        $this->debugPlayers[$playerName] = true;
        return true;
    }

    public function getGrannyEntities() {
        $result = [];
        foreach ($this->getServer()->getLevels() as $level) {
            foreach ($level->getEntities() as $entity) {
                if ($entity instanceof GrannyEntity && !$entity->closed && !$entity->isCutscenePuppet()) {
                    $result[] = $entity;
                }
            }
        }
        return $result;
    }

    public function scheduleTask(callable $callable, $delay) {
        $this->getServer()->getScheduler()->scheduleDelayedTask(
            new \Granny\manager\CutsceneCallbackTask($this, $callable),
            $delay
        );
    }

    public function getConfigValue($path, $default = null) {
        $keys = explode(".", $path);
        $val = $this->getConfig()->getAll();
        foreach ($keys as $key) {
            if (is_array($val) && isset($val[$key])) {
                $val = $val[$key];
            } else {
                return $default;
            }
        }
        return $val;
    }
}