<?php

namespace Granny\utils;

use pocketmine\math\Vector3;
use Granny\Main;

class SoundTrigger {

public static function triggerSound(Main $plugin, Vector3 $pos, $worldName = null, $customRange = null) {
    if (is_numeric($worldName)) {
        $worldName = null;
    }

    foreach ($plugin->getGrannyEntities() as $granny) {
        if ($granny->getLevel() === null) {
            continue;
        }
        if ($worldName !== null && $granny->getLevel()->getFolderName() !== (string)$worldName) {
            continue;
        }
        $granny->hearNoise($pos, $granny->getLevel()->getFolderName());
    }
}
}
