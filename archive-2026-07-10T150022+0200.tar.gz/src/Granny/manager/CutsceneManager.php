<?php

namespace Granny\manager;

use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;
use pocketmine\entity\Effect;
use pocketmine\item\Item;
use pocketmine\network\protocol\AnimatePacket;
use pocketmine\network\protocol\LevelEventPacket;
use pocketmine\network\protocol\MovePlayerPacket;
use pocketmine\scheduler\PluginTask;
use pocketmine\utils\Config;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ShortTag;
use Granny\Main;
use Granny\entity\GrannyEntity;

class CutsceneManager {

    private $plugin;
    private $data;
    private $sessions = [];
    private $taskIds = [];
    private $puppetGranny = null;

    const SCENES = ["wake", "gameover", "ending", "caught"];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->data = new Config(
            $plugin->getDataFolder() . "cutscenes.yml",
            Config::YAML,
            [
                "cutspawn" => null,
                "scenes" => [
                    "wake" => ["points" => [], "actions" => []],
                    "gameover" => ["points" => [], "actions" => []],
                    "ending" => ["points" => [], "actions" => []],
                    "caught" => ["points" => [], "actions" => []]
                ]
            ]
        );
    }

    public function isValidScene($name) {
        return in_array($name, self::SCENES);
    }

    public function setCutSpawn(Vector3 $pos, $yaw, $pitch, $world) {
        $all = $this->data->getAll();
        $all["cutspawn"] = [
            "x" => round($pos->x, 4),
            "y" => round($pos->y, 4),
            "z" => round($pos->z, 4),
            "yaw" => round($yaw, 4),
            "pitch" => round($pitch, 4),
            "world" => $world
        ];
        $this->data->setAll($all);
        $this->data->save();
    }

    public function getCutSpawn() {
        $all = $this->data->getAll();
        return isset($all["cutspawn"]) ? $all["cutspawn"] : null;
    }

    private function getScene($scene) {
        $all = $this->data->getAll();
        if (!isset($all["scenes"][$scene])) return ["points" => [], "actions" => []];
        $s = $all["scenes"][$scene];
        if (!isset($s["points"])) $s["points"] = [];
        if (!isset($s["actions"])) $s["actions"] = [];
        return $s;
    }

    private function saveScene($scene, $data) {
        $all = $this->data->getAll();
        $all["scenes"][$scene] = $data;
        $this->data->setAll($all);
        $this->data->save();
    }

    public function addPoint($scene, $x, $y, $z, $yaw, $pitch, $seconds, $cutAfter = 0) {
        $s = $this->getScene($scene);
        $point = [
            "x" => round($x, 4),
            "y" => round($y, 4),
            "z" => round($z, 4),
            "yaw" => round($yaw, 4),
            "pitch" => round($pitch, 4),
            "seconds" => (float)$seconds
        ];
        if ($cutAfter > 0) {
            $point["cut"] = (float)$cutAfter;
        }
        $s["points"][] = $point;
        $this->saveScene($scene, $s);
        return count($s["points"]) - 1;
    }
    
    public function addCaughtPoint($scene, $yawOffset, $pitchOffset, $seconds) {
        $s = $this->getScene($scene);
        $point = [
        "yaw_offset" => round($yawOffset, 4),
        "pitch_offset" => round($pitchOffset, 4),
        "seconds" => (float)$seconds,
        "dynamic" => true
        ];
        $s["points"][] = $point;
        $this->saveScene($scene, $s);
    return count($s["points"]) - 1;
    }


    public function removePoint($scene, $index) {
        $s = $this->getScene($scene);
        if (!isset($s["points"][$index])) return false;
        array_splice($s["points"], $index, 1);
        $this->saveScene($scene, $s);
        return true;
    }

    public function getPoints($scene) {
        $s = $this->getScene($scene);
        return $s["points"];
    }

    public function addAction($scene, $action) {
        $s = $this->getScene($scene);
        $s["actions"][] = $action;
        $this->saveScene($scene, $s);
        return count($s["actions"]) - 1;
    }

    public function removeAction($scene, $index) {
        $s = $this->getScene($scene);
        if (!isset($s["actions"][$index])) return false;
        array_splice($s["actions"], $index, 1);
        $this->saveScene($scene, $s);
        return true;
    }

    public function getActions($scene) {
        $s = $this->getScene($scene);
        return $s["actions"];
    }

    public function clearScene($scene) {
        $this->saveScene($scene, ["points" => [], "actions" => []]);
    }

    public function isPlaying($playerName) {
        return isset($this->sessions[strtolower($playerName)]);
    }

    public function hasSession($playerName) {
        return isset($this->sessions[strtolower($playerName)]);
    }

    private function spawnPuppetGranny(Vector3 $pos, $level) {
        $this->despawnPuppetGranny();

        $skinData = $this->plugin->getGrannySkin();
        $skinId = $this->plugin->getGrannySkinId();
        if ($skinData === null) {
            foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                $skinData = $p->getSkinData();
                $skinId = $p->getSkinId();
                break;
            }
        }
        if ($skinData === null) return;

        $nbt = new CompoundTag("", [
            "Pos" => new ListTag("Pos", [
                new DoubleTag("", $pos->x),
                new DoubleTag("", $pos->y),
                new DoubleTag("", $pos->z)
            ]),
            "Motion" => new ListTag("Motion", [
                new DoubleTag("", 0),
                new DoubleTag("", 0),
                new DoubleTag("", 0)
            ]),
            "Rotation" => new ListTag("Rotation", [
                new FloatTag("", 0),
                new FloatTag("", 0)
            ]),
            "Skin" => new CompoundTag("Skin", [
                "Data" => new StringTag("Data", $skinData),
                "Name" => new StringTag("Name", $skinId)
            ]),
            "Health" => new ShortTag("Health", 200)
        ]);

        $chunk = $level->getChunk(((int)$pos->x) >> 4, ((int)$pos->z) >> 4, true);
        $entity = Entity::createEntity("GrannyEntity", $chunk, $nbt);
        if ($entity !== null && $entity instanceof GrannyEntity) {
            $entity->spawnToAll();
            $entity->setCutscenePuppet(true);
            $this->puppetGranny = $entity;
        }
    }

    private function despawnPuppetGranny() {
        if ($this->puppetGranny !== null && !$this->puppetGranny->closed) {
            $this->puppetGranny->close();
        }
        $this->puppetGranny = null;
    }

    public function getPuppetGranny() {
        return $this->puppetGranny;
    }

    public function playScene($scene, Player $player) {
        $s = $this->getScene($scene);
        $points = $s["points"];
        $actions = $s["actions"];

        if (count($points) < 2) return false;

        $name = strtolower($player->getName());

        $this->sessions[$name] = [
            "scene" => $scene,
            "ox" => $player->x,
            "oy" => $player->y,
            "oz" => $player->z,
            "oyaw" => $player->yaw,
            "opitch" => $player->pitch,
            "gamemode" => $player->getGamemode(),
            "inventory" => []
        ];

        $inv = $player->getInventory();
        $items = [];
        for ($slot = 0; $slot < $inv->getSize(); $slot++) {
            $item = $inv->getItem($slot);
            if ($item->getId() !== 0) {
                $items[$slot] = clone $item;
            }
        }
        $this->sessions[$name]["inventory"] = $items;

        $player->setGamemode(3);

        $waypoints = $this->buildPath($points);
        if (count($waypoints) < 2) {
            unset($this->sessions[$name]);
            $this->despawnPuppetGranny();
            return false;
        }

        $this->scheduleActions($player, $actions, $points);

        $player->teleport(
            new Vector3($waypoints[0]["x"], $waypoints[0]["y"], $waypoints[0]["z"]),
            $waypoints[0]["yaw"],
            $waypoints[0]["pitch"]
        );

        $task = new CutscenePlayTask($this->plugin, $this, $player, $waypoints, $scene);
        $handler = $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($task, 1);
        $this->taskIds[$name] = $handler->getTaskId();

        return true;
    }
    
    public function playCaughtScene(Player $player, $grannyX, $grannyY, $grannyZ) {
    $s = $this->getScene("caught");
    $points = $s["points"];
    $actions = $s["actions"];

    if (count($points) < 2) return false;

    $name = strtolower($player->getName());

    $this->sessions[$name] = [
        "scene" => "caught",
        "ox" => $player->x,
        "oy" => $player->y,
        "oz" => $player->z,
        "oyaw" => $player->yaw,
        "opitch" => $player->pitch,
        "gamemode" => $player->getGamemode(),
        "inventory" => []
    ];

    $inv = $player->getInventory();
    $items = [];
    for ($slot = 0; $slot < $inv->getSize(); $slot++) {
        $item = $inv->getItem($slot);
        if ($item->getId() !== 0) {
            $items[$slot] = clone $item;
        }
    }
    $this->sessions[$name]["inventory"] = $items;

    $player->setGamemode(3);

    $dx = $grannyX - $player->x;
    $dz = $grannyZ - $player->z;
    $dy = ($grannyY + 1.62) - ($player->y + $player->eyeHeight);
    $dist = sqrt($dx * $dx + $dz * $dz);

    $baseYaw = -atan2($dx, $dz) * 180 / M_PI;
    $basePitch = ($dist > 0) ? -atan2($dy, $dist) * 180 / M_PI : 0;

    $resolvedPoints = [];
    foreach ($points as $pt) {
        $yOff = isset($pt["yaw_offset"]) ? $pt["yaw_offset"] : 0;
        $pOff = isset($pt["pitch_offset"]) ? $pt["pitch_offset"] : 0;
        $sec = isset($pt["seconds"]) ? $pt["seconds"] : 3.0;

        $resolvedPoints[] = [
            "x" => $player->x,
            "y" => $player->y,
            "z" => $player->z,
            "yaw" => $baseYaw + $yOff,
            "pitch" => max(-90, min(90, $basePitch + $pOff)),
            "seconds" => $sec
        ];
    }

    $waypoints = $this->buildPath($resolvedPoints);
    if (count($waypoints) < 2) {
        unset($this->sessions[$name]);
        return false;
    }

    $this->scheduleActions($player, $actions, $resolvedPoints);

    $player->teleport(
        new Vector3($waypoints[0]["x"], $waypoints[0]["y"], $waypoints[0]["z"]),
        $waypoints[0]["yaw"],
        $waypoints[0]["pitch"]
    );

    $task = new CutscenePlayTask($this->plugin, $this, $player, $waypoints, "caught");
    $handler = $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($task, 1);
    $this->taskIds[$name] = $handler->getTaskId();

    return true;
}

    public function playSceneForAll($scene, $playerNames = []) {
        $count = 0;
        foreach ($playerNames as $name) {
            $player = $this->plugin->getServer()->getPlayerExact($name);
            if ($player !== null && $player->isOnline()) {
                $this->playScene($scene, $player);
                $count++;
            }
        }
        return $count;
    }

    private function scheduleActions(Player $player, $actions, $points) {
        foreach ($actions as $action) {
            $triggerTime = isset($action["at"]) ? (float)$action["at"] : 0;
            $delayTicks = max(1, (int)round($triggerTime * 20));
            $plugin = $this->plugin;
            $playerName = $player->getName();
            $act = $action;
            $mgr = $this;

            $plugin->scheduleTask(function() use ($plugin, $mgr, $playerName, $act) {
                $p = $plugin->getServer()->getPlayerExact($playerName);
                if ($p === null || !$p->isOnline()) return;
                if (!$mgr->hasSession($playerName)) return;
                $mgr->executeAction($p, $act);
            }, $delayTicks);
        }
    }

    public function executeAction(Player $player, $action) {
        $type = $action["type"];
        $puppet = $this->puppetGranny;

        switch ($type) {
            case "tip":
                $player->sendTip($action["text"]);
                break;

            case "popup":
                $player->sendPopup($action["text"]);
                break;

            case "blind":
                $blind = Effect::getEffect(Effect::BLINDNESS);
                $duration = isset($action["duration"]) ? (int)($action["duration"] * 20) : 60;
                $blind->setDuration($duration)->setAmplifier(10)->setVisible(false);
                $player->addEffect($blind);
                break;

            case "clearblind":
                $player->removeEffect(Effect::BLINDNESS);
                break;

            case "grannytp":
                if ($puppet === null || $puppet->closed) {
                    $this->spawnPuppetGranny(new Vector3($action["x"], $action["y"], $action["z"]), $player->getLevel());
                    $puppet = $this->puppetGranny;
                }
                if ($puppet !== null && !$puppet->closed) {
                    $puppet->setPosition(new Vector3($action["x"], $action["y"], $action["z"]));
                    $puppet->yaw = isset($action["yaw"]) ? $action["yaw"] : $puppet->yaw;
                    $puppet->pitch = isset($action["pitch"]) ? $action["pitch"] : $puppet->pitch;
                    $puppet->pathQueue = [];

                    $mpk = new MovePlayerPacket();
                    $mpk->eid = $puppet->getId();
                    $mpk->x = $puppet->x;
                    $mpk->y = $puppet->y + $puppet->eyeHeight;
                    $mpk->z = $puppet->z;
                    $mpk->yaw = $puppet->yaw;
                    $mpk->bodyYaw = $puppet->yaw;
                    $mpk->pitch = $puppet->pitch;
                    foreach ($puppet->getLevel()->getPlayers() as $p) {
                        $p->dataPacket($mpk);
                    }
                }
                break;

            case "grannywalk":
                if ($puppet === null || $puppet->closed) {
                    $this->spawnPuppetGranny(new Vector3($action["x"], $action["y"], $action["z"]), $player->getLevel());
                    $puppet = $this->puppetGranny;
                }
                if ($puppet !== null && !$puppet->closed) {
                    $puppet->pathQueue = [new Vector3($action["x"], $action["y"], $action["z"])];
                }
                break;

            case "grannyswing":
                if ($puppet !== null && !$puppet->closed) {
                    $pk = new AnimatePacket();
                    $pk->eid = $puppet->getId();
                    $pk->action = 1;
                    foreach ($puppet->getLevel()->getPlayers() as $p) {
                        $p->dataPacket($pk);
                    }
                }
                break;

            case "sound":
                $soundId = isset($action["sound_id"]) ? (int)$action["sound_id"] : 1003;
                $pk = new LevelEventPacket();
                $pk->evid = $soundId;
                $pk->x = $player->x;
                $pk->y = $player->y;
                $pk->z = $player->z;
                $pk->data = 0;
                $player->dataPacket($pk);
                break;
        }
    }

    public function stopScene(Player $player, $teleportBack = true) {
        $name = strtolower($player->getName());

        if (isset($this->taskIds[$name])) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->taskIds[$name]);
            unset($this->taskIds[$name]);
        }

        if (isset($this->sessions[$name]) && $player->isOnline()) {
            $s = $this->sessions[$name];
            if ($s["scene"] === "wake") {
                $player->setGamemode(0);
            } else {
                $player->setGamemode($s["gamemode"]);
            }
            if (!empty($s["inventory"])) {
                $inv = $player->getInventory();
                $inv->clearAll();
                foreach ($s["inventory"] as $slot => $item) {
                    $inv->setItem($slot, $item);
                }
            }
            $player->removeEffect(Effect::BLINDNESS);
            if ($teleportBack) {
                $player->teleport(new Vector3($s["ox"], $s["oy"], $s["oz"]), $s["oyaw"], $s["opitch"]);
            }
        }

        $this->despawnPuppetGranny();
        unset($this->sessions[$name]);
    }

    public function startBuiltInScene(Player $player, $sceneName = "caught_builtin") {
        $name = strtolower($player->getName());

        $this->sessions[$name] = [
            "scene" => $sceneName,
            "ox" => $player->x,
            "oy" => $player->y,
            "oz" => $player->z,
            "oyaw" => $player->yaw,
            "opitch" => $player->pitch,
            "gamemode" => $player->getGamemode(),
            "inventory" => []
        ];

        $inv = $player->getInventory();
        $items = [];
        for ($slot = 0; $slot < $inv->getSize(); $slot++) {
            $item = $inv->getItem($slot);
            if ($item->getId() !== 0) {
                $items[$slot] = clone $item;
            }
        }
        $this->sessions[$name]["inventory"] = $items;

        $player->setGamemode(3);
    }

    public function stopBuiltInScene(Player $player, $teleportBack = false) {
        $name = strtolower($player->getName());
        if (isset($this->sessions[$name]) && $player->isOnline()) {
            $s = $this->sessions[$name];
            $player->setGamemode($s["gamemode"]);
            if (!empty($s["inventory"])) {
                $inv = $player->getInventory();
                $inv->clearAll();
                foreach ($s["inventory"] as $slot => $item) {
                    $inv->setItem($slot, $item);
                }
            }
            if ($teleportBack) {
                $player->teleport(new Vector3($s["ox"], $s["oy"], $s["oz"]), $s["oyaw"], $s["opitch"]);
            }
            unset($this->sessions[$name]);
        }
    }

public function onCinematicDone(Player $player, $scene = "") {
    $name = strtolower($player->getName());
    $sessionScene = isset($this->sessions[$name]) ? $this->sessions[$name]["scene"] : $scene;
    $savedSession = isset($this->sessions[$name]) ? $this->sessions[$name] : null;

    $this->stopScene($player, false);

    if ($sessionScene === "gameover" || $sessionScene === "ending" || $sessionScene === "caught") {
        $gameSession = $this->plugin->getArenaManager()->getPlayerSession($player->getName());
        if ($gameSession !== null) {
            $gameSession->onCutsceneFinished($player->getName());
        } else {
            $this->plugin->getMainLobby()->enterLobby($player);
        }
    } else {
        if ($savedSession !== null) {
            $player->teleport(new Vector3($savedSession["ox"], $savedSession["oy"], $savedSession["oz"]), $savedSession["oyaw"], $savedSession["opitch"]);
        }
    }
}

    public function stopAll() {
        foreach ($this->sessions as $name => $v) {
            $player = $this->plugin->getServer()->getPlayerExact($name);
            if ($player !== null) {
                $this->stopScene($player, true);
            }
        }
        $this->sessions = [];
        $this->despawnPuppetGranny();
    }

    private function buildPath(array $points) {
        $count = count($points);
        if ($count < 2) return [];

        $waypoints = [];
        $pts = [];

        foreach ($points as $i => $p) {
            $pts[$i] = [
                "x" => (float)$p["x"],
                "y" => (float)$p["y"],
                "z" => (float)$p["z"],
                "yaw" => (float)$p["yaw"],
                "pitch" => (float)$p["pitch"],
                "seconds" => isset($p["seconds"]) ? (float)$p["seconds"] : 3.0
            ];
        }

        for ($i = 1; $i < $count; $i++) {
            $diff = $pts[$i]["yaw"] - $pts[$i - 1]["yaw"];
            while ($diff > 180) $diff -= 360;
            while ($diff < -180) $diff += 360;
            $pts[$i]["yaw"] = $pts[$i - 1]["yaw"] + $diff;
        }

        $cutSpawn = $this->getCutSpawn();

        for ($i = 0; $i < $count - 1; $i++) {
            $p0 = $pts[max(0, $i - 1)];
            $p1 = $pts[$i];
            $p2 = $pts[$i + 1];
            $p3 = $pts[min($count - 1, $i + 2)];

            $segTicks = max(2, (int)round($pts[$i + 1]["seconds"] * 20));

            for ($tick = 0; $tick < $segTicks; $tick++) {
                $t = (float)$tick / (float)$segTicks;

                $x = $this->cmr($p0["x"], $p1["x"], $p2["x"], $p3["x"], $t);
                $y = $this->cmr($p0["y"], $p1["y"], $p2["y"], $p3["y"], $t);
                $z = $this->cmr($p0["z"], $p1["z"], $p2["z"], $p3["z"], $t);
                $yaw = $this->cmr($p0["yaw"], $p1["yaw"], $p2["yaw"], $p3["yaw"], $t);
                $pitch = $this->cmr($p0["pitch"], $p1["pitch"], $p2["pitch"], $p3["pitch"], $t);

                $yaw = fmod($yaw, 360.0);
                if ($yaw < 0) $yaw += 360.0;
                if ($pitch > 90) $pitch = 90.0;
                if ($pitch < -90) $pitch = -90.0;

                $waypoints[] = ["x" => $x, "y" => $y, "z" => $z, "yaw" => $yaw, "pitch" => $pitch];
            }

            if (isset($points[$i + 1]["cut"]) && $points[$i + 1]["cut"] > 0 && $cutSpawn !== null) {
                $cutTicks = max(1, (int)round($points[$i + 1]["cut"] * 20));
                $waypoints[] = ["x" => $p2["x"], "y" => $p2["y"], "z" => $p2["z"], "yaw" => fmod($p2["yaw"], 360.0), "pitch" => $p2["pitch"], "blind_on" => true];
                for ($ct = 0; $ct < $cutTicks; $ct++) {
                    $waypoints[] = ["x" => $cutSpawn["x"], "y" => $cutSpawn["y"], "z" => $cutSpawn["z"], "yaw" => $cutSpawn["yaw"], "pitch" => $cutSpawn["pitch"], "is_cut" => true];
                }
                $waypoints[] = ["x" => $p2["x"], "y" => $p2["y"], "z" => $p2["z"], "yaw" => fmod($p2["yaw"], 360.0), "pitch" => $p2["pitch"], "blind_off" => true];
            }
        }

        $last = $pts[$count - 1];
        $fy = fmod($last["yaw"], 360.0);
        if ($fy < 0) $fy += 360.0;
        $waypoints[] = ["x" => $last["x"], "y" => $last["y"], "z" => $last["z"], "yaw" => $fy, "pitch" => $last["pitch"]];

        return $waypoints;
    }

    private function cmr($a, $b, $c, $d, $t) {
        $t2 = $t * $t;
        $t3 = $t2 * $t;
        return 0.5 * (
            (2.0 * $b) +
            (-$a + $c) * $t +
            (2.0 * $a - 5.0 * $b + 4.0 * $c - $d) * $t2 +
            (-$a + 3.0 * $b - 3.0 * $c + $d) * $t3
        );
    }
}

class CutscenePlayTask extends PluginTask {

    private $manager;
    private $player;
    private $waypoints;
    private $scene;
    private $index = 0;
    private $total;
    private $started = false;
    private $startDelay = 10;

    public function __construct(Main $plugin, CutsceneManager $manager, Player $player, array $waypoints, $scene = "") {
        parent::__construct($plugin);
        $this->manager = $manager;
        $this->player = $player;
        $this->waypoints = $waypoints;
        $this->total = count($waypoints);
        $this->scene = $scene;
    }

    public function onRun($tick) {
        if (!$this->player->isOnline()) {
            $this->manager->stopScene($this->player, false);
            return;
        }

        if (!$this->manager->hasSession($this->player->getName())) {
            return;
        }

        if (!$this->started) {
            $this->startDelay--;
            if ($this->startDelay > 0) {
                $wp = $this->waypoints[0];
                $this->player->teleport(new Vector3($wp["x"], $wp["y"], $wp["z"]), $wp["yaw"], $wp["pitch"]);
                return;
            }
            $this->started = true;
            $wp = $this->waypoints[0];
            $this->player->teleport(new Vector3($wp["x"], $wp["y"], $wp["z"]), $wp["yaw"], $wp["pitch"]);
        }

        if ($this->index >= $this->total) {
            $this->manager->onCinematicDone($this->player, $this->scene);
            return;
        }

        $wp = $this->waypoints[$this->index];

        if (isset($wp["blind_on"]) && $wp["blind_on"]) {
            $blind = Effect::getEffect(Effect::BLINDNESS);
            $blind->setDuration(600)->setAmplifier(10)->setVisible(false);
            $this->player->addEffect($blind);
            $this->player->teleport(new Vector3($wp["x"], $wp["y"], $wp["z"]), $wp["yaw"], $wp["pitch"]);
            $this->index++;
            return;
        }

        if (isset($wp["is_cut"]) && $wp["is_cut"]) {
            $this->player->teleport(new Vector3($wp["x"], $wp["y"], $wp["z"]), $wp["yaw"], $wp["pitch"]);
            $this->index++;
            return;
        }

        if (isset($wp["blind_off"]) && $wp["blind_off"]) {
            $this->player->removeEffect(Effect::BLINDNESS);
            $this->player->teleport(new Vector3($wp["x"], $wp["y"], $wp["z"]), $wp["yaw"], $wp["pitch"]);
            $this->index++;
            return;
        }

        $this->movePlayer($wp["x"], $wp["y"], $wp["z"], $wp["yaw"], $wp["pitch"]);

        $this->index++;
    }

    private function movePlayer($x, $y, $z, $yaw, $pitch) {
        $this->player->x = $x;
        $this->player->y = $y;
        $this->player->z = $z;
        $this->player->yaw = $yaw;
        $this->player->pitch = $pitch;

        $pk = new MovePlayerPacket();
        $pk->eid = 0;
        $pk->x = $x;
        $pk->y = $y + $this->player->eyeHeight;
        $pk->z = $z;
        $pk->yaw = $yaw;
        $pk->bodyYaw = $yaw;
        $pk->pitch = $pitch;
        $this->player->dataPacket($pk);
    }
}

class CutsceneCallbackTask extends PluginTask {

    private $callable;

    public function __construct(Main $plugin, callable $callable) {
        parent::__construct($plugin);
        $this->callable = $callable;
    }

    public function onRun($currentTick) {
        $fn = $this->callable;
        $fn();
    }
}