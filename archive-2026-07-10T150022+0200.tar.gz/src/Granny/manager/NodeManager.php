<?php

namespace Granny\manager;

use pocketmine\math\Vector3;
use pocketmine\level\Level;
use pocketmine\network\protocol\LevelEventPacket;
use pocketmine\Player;
use pocketmine\item\Item;
use pocketmine\scheduler\PluginTask;
use Granny\Main;
use Granny\pathfinding\Node;
use Granny\pathfinding\NodeGraph;
use Granny\pathfinding\Pathfinder;

class NodeManager {

    private $plugin;
    private $graph;
    private $pathfinder;
    private $debugTaskId = null;
    private $editorPlayers = [];
    private $selectedLinkNode = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->graph = new NodeGraph();
        $this->pathfinder = new Pathfinder($this->graph);
        $this->loadNodes();
    }

    public function getGraph() {
        return $this->graph;
    }

    public function getPathfinder() {
        return $this->pathfinder;
    }

    public function addNode($name, Vector3 $pos, $patrol = false) {
        if ($this->graph->getNode($name) !== null) {
            return false;
        }
        $this->graph->addNode(new Node($name, $pos, $patrol));
        $this->saveNodes();
        return true;
    }

    public function removeNode($name) {
        $result = $this->graph->removeNode($name);
        if ($result) {
            $this->saveNodes();
        }
        return $result;
    }

    public function linkNodes($name1, $name2) {
        $result = $this->graph->linkNodes($name1, $name2);
        if ($result) {
            $this->saveNodes();
        }
        return $result;
    }

    public function unlinkNodes($name1, $name2) {
        $result = $this->graph->unlinkNodes($name1, $name2);
        if ($result) {
            $this->saveNodes();
        }
        return $result;
    }

    public function findPath(Vector3 $from, Vector3 $to, $patrolOnly = false) {
        return $this->pathfinder->findPath($from, $to, $patrolOnly);
    }

    public function getClosestNode(Vector3 $pos, $patrolOnly = false) {
        return $this->graph->getClosestNode($pos, $patrolOnly);
    }

    public function getClosestNodeWithin(Vector3 $pos, $maxDist = 3.5) {
        $closest = null;
        $closestDist = $maxDist;
        foreach ($this->graph->getNodes() as $node) {
            $dist = $node->getPosition()->distance($pos);
            if ($dist <= $closestDist) {
                $closestDist = $dist;
                $closest = $node;
            }
        }
        return $closest;
    }

    public function getNextNodeName() {
        $i = 1;
        while ($this->graph->getNode("node" . $i) !== null) {
            $i++;
        }
        return "node" . $i;
    }

    public function getPatrolNodes() {
        return $this->graph->getPatrolNodes();
    }

    public function isNodeEditor(Player $player) {
        return isset($this->editorPlayers[$player->getName()]);
    }

    public function toggleNodeEditor(Player $player) {
        if ($this->isNodeEditor($player)) {
            $this->exitNodeEditor($player);
        } else {
            $this->enterNodeEditor($player);
        }
    }

    public function enterNodeEditor(Player $player) {
        $name = $player->getName();
        $this->editorPlayers[$name] = true;
        
        if (!$this->plugin->isDebug($name)) {
            $this->plugin->addDebugPlayer($player);
        }

        $inv = $player->getInventory();
        $inv->clearAll();

        $item0 = Item::get(Item::STICK, 0, 1);
        $item0->setCustomName("§a§lAdd Normal Node §r§7(Tap)");
        $inv->setItem(0, $item0);

        $item1 = Item::get(Item::BLAZE_ROD, 0, 1);
        $item1->setCustomName("§b§lAdd Patrol Node §r§7(Tap)");
        $inv->setItem(1, $item1);

        $item2 = Item::get(Item::STRING, 0, 1);
        $item2->setCustomName("§e§lLink Nodes §r§7(Tap Node A then Node B)");
        $inv->setItem(2, $item2);

        $item3 = Item::get(Item::REDSTONE, 0, 1);
        $item3->setCustomName("§c§lUnlink Nodes §r§7(Tap Node A then Node B)");
        $inv->setItem(3, $item3);

        $item4 = Item::get(Item::BONE, 0, 1);
        $item4->setCustomName("§4§lRemove Node §r§7(Tap near Node)");
        $inv->setItem(4, $item4);

        $item8 = Item::get(Item::EMERALD, 0, 1);
        $item8->setCustomName("§2§lSave & Exit Node Mode §r§7(Tap)");
        $inv->setItem(8, $item8);

        $inv->setHeldItemIndex(0);
        $inv->sendContents($player);

        $player->sendMessage("§6═════════════════════════════");
        $player->sendMessage("§a§lEntered Node Editor Mode!");
        $player->sendMessage("§7Use the items in your hotbar to manage nodes effortlessly.");
        $player->sendMessage("§6═════════════════════════════");
    }

    public function exitNodeEditor(Player $player) {
        $name = $player->getName();
        unset($this->editorPlayers[$name]);
        unset($this->selectedLinkNode[$name]);

        $player->getInventory()->clearAll();
        $player->sendMessage("§2§l[Node Editor] §r§aAll node changes saved! Exited Node Editor Mode.");
    }

    public function handleEditorItemUse(Player $player, Item $item) {
        $name = $player->getName();
        $customName = $item->getCustomName();
        $pos = new Vector3(round($player->x, 2), round($player->y, 2), round($player->z, 2));

        if (strpos($customName, "Add Normal Node") !== false) {
            $nodeName = $this->getNextNodeName();
            if ($this->addNode($nodeName, $pos, false)) {
                $player->sendMessage("§a[Node Editor] Added Normal Node: §e" . $nodeName . " §aat (" . $pos->x . ", " . $pos->y . ", " . $pos->z . ")");
            }
        } elseif (strpos($customName, "Add Patrol Node") !== false) {
            $nodeName = $this->getNextNodeName();
            if ($this->addNode($nodeName, $pos, true)) {
                $player->sendMessage("§b[Node Editor] Added Patrol Node: §e" . $nodeName . " §bat (" . $pos->x . ", " . $pos->y . ", " . $pos->z . ")");
            }
        } elseif (strpos($customName, "Link Nodes") !== false) {
            $closest = $this->getClosestNodeWithin($player->getPosition(), 3.5);
            if ($closest === null) {
                $player->sendMessage("§c[Node Editor] Stand within 3.5 blocks of a node to select it!");
                return;
            }
            if (!isset($this->selectedLinkNode[$name])) {
                $this->selectedLinkNode[$name] = $closest->getName();
                $player->sendMessage("§e[Node Editor] Selected Node A: §f" . $closest->getName() . "§e. Now tap near Node B to link!");
            } else {
                $nodeA = $this->selectedLinkNode[$name];
                if ($nodeA === $closest->getName()) {
                    unset($this->selectedLinkNode[$name]);
                    $player->sendMessage("§c[Node Editor] Tapped same node. Selection cleared!");
                } else {
                    $this->linkNodes($nodeA, $closest->getName());
                    $player->sendMessage("§a[Node Editor] Linked §e" . $nodeA . " §a<-> §e" . $closest->getName() . "!");
                    unset($this->selectedLinkNode[$name]);
                }
            }
        } elseif (strpos($customName, "Unlink Nodes") !== false) {
            $closest = $this->getClosestNodeWithin($player->getPosition(), 3.5);
            if ($closest === null) {
                $player->sendMessage("§c[Node Editor] Stand within 3.5 blocks of a node to select it!");
                return;
            }
            if (!isset($this->selectedLinkNode[$name])) {
                $this->selectedLinkNode[$name] = $closest->getName();
                $player->sendMessage("§e[Node Editor] Selected Node A to Unlink: §f" . $closest->getName() . "§e. Now tap Node B!");
            } else {
                $nodeA = $this->selectedLinkNode[$name];
                if ($nodeA === $closest->getName()) {
                    unset($this->selectedLinkNode[$name]);
                    $player->sendMessage("§c[Node Editor] Selection cleared!");
                } else {
                    $this->unlinkNodes($nodeA, $closest->getName());
                    $player->sendMessage("§c[Node Editor] Unlinked §e" . $nodeA . " §c<-> §e" . $closest->getName() . "!");
                    unset($this->selectedLinkNode[$name]);
                }
            }
        } elseif (strpos($customName, "Remove Node") !== false) {
            $closest = $this->getClosestNodeWithin($player->getPosition(), 3.5);
            if ($closest !== null) {
                $nodeName = $closest->getName();
                $this->removeNode($nodeName);
                $player->sendMessage("§4[Node Editor] Removed Node: §e" . $nodeName);
            } else {
                $player->sendMessage("§c[Node Editor] No node found within 3.5 blocks to remove!");
            }
        } elseif (strpos($customName, "Save & Exit") !== false) {
            $this->exitNodeEditor($player);
        }
    }

    public function startDebugTask() {
        if ($this->debugTaskId !== null) {
            return;
        }
        $task = new DebugParticleTask($this->plugin, $this);
        $handler = $this->plugin->getServer()->getScheduler()->scheduleRepeatingTask($task, 10);
        $this->debugTaskId = $handler->getTaskId();
    }

    public function stopDebugTask() {
        if ($this->debugTaskId !== null) {
            $this->plugin->getServer()->getScheduler()->cancelTask($this->debugTaskId);
            $this->debugTaskId = null;
        }
    }

    public function hasDebugPlayers() {
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if ($this->plugin->isDebug($player->getName())) {
                return true;
            }
        }
        return false;
    }

    public function sendDebugParticles() {
        $debugPlayers = [];
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if ($this->plugin->isDebug($player->getName())) {
                $debugPlayers[] = $player;
            }
        }

        if (empty($debugPlayers)) {
            $this->stopDebugTask();
            return;
        }

        foreach ($this->graph->getNodes() as $node) {
            $pos = $node->getPosition();

            $pk = new LevelEventPacket();
            $pk->evid = LevelEventPacket::EVENT_ADD_PARTICLE_MASK | 4;
            $pk->x = $pos->x;
            $pk->y = $pos->y + 1;
            $pk->z = $pos->z;
            $pk->data = 0;

            foreach ($debugPlayers as $player) {
                $player->dataPacket($pk);
            }

            foreach ($node->getLinks() as $linkName) {
                $linked = $this->graph->getNode($linkName);
                if ($linked === null) continue;

                $lpos = $linked->getPosition();
                $diffX = $lpos->x - $pos->x;
                $diffY = $lpos->y - $pos->y;
                $diffZ = $lpos->z - $pos->z;
                $steps = (int)max(1, $pos->distance($lpos) * 2);

                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $fpk = new LevelEventPacket();
                    $fpk->evid = LevelEventPacket::EVENT_ADD_PARTICLE_MASK | 9;
                    $fpk->x = $pos->x + $diffX * $t;
                    $fpk->y = $pos->y + 1 + $diffY * $t;
                    $fpk->z = $pos->z + $diffZ * $t;
                    $fpk->data = 0;

                    foreach ($debugPlayers as $player) {
                        $player->dataPacket($fpk);
                    }
                }
            }
        }

        foreach ($debugPlayers as $player) {
            $ppos = $player->getPosition();
            $foundNode = null;
            $closestDist = 1.5;

            foreach ($this->graph->getNodes() as $node) {
                $dist = $node->getPosition()->distance($ppos);
                if ($dist <= $closestDist) {
                    $closestDist = $dist;
                    $foundNode = $node;
                }
            }

            if ($foundNode !== null) {
                $player->sendTip("§a§lYou are in: §e" . $foundNode->getName() . " §r" . ($foundNode->isPatrol() ? "§b[Patrol]" : "§7[Normal]"));
                continue;
            }

            $foundPath = null;
            $minDiff = 0.6;
            $checkedPairs = [];

            foreach ($this->graph->getNodes() as $nodeA) {
                $posA = $nodeA->getPosition();
                $distA = $posA->distance($ppos);

                foreach ($nodeA->getLinks() as $linkName) {
                    $pairKey = ($nodeA->getName() < $linkName) ? $nodeA->getName() . "-" . $linkName : $linkName . "-" . $nodeA->getName();
                    if (isset($checkedPairs[$pairKey])) continue;
                    $checkedPairs[$pairKey] = true;

                    $nodeB = $this->graph->getNode($linkName);
                    if ($nodeB === null) continue;

                    $posB = $nodeB->getPosition();
                    $distB = $posB->distance($ppos);
                    $totalDist = $posA->distance($posB);

                    if ($totalDist < 0.1) continue;

                    $diff = ($distA + $distB) - $totalDist;
                    if ($diff < $minDiff) {
                        $minDiff = $diff;
                        $foundPath = "§e" . $nodeA->getName() . " §a<-> §e" . $nodeB->getName();
                    }
                }
            }

            if ($foundPath !== null) {
                $player->sendTip("§lPath: " . $foundPath);
            }
        }

        foreach ($this->plugin->getGrannyEntities() as $granny) {
            $gLevel = $granny->getLevel();
            if ($gLevel === null || $granny->closed || $granny->isCutscenePuppet()) continue;

            $gLevelName = $gLevel->getFolderName();
            $targetPlayers = [];
            foreach ($debugPlayers as $dp) {
                if ($dp->getLevel()->getFolderName() === $gLevelName) {
                    $targetPlayers[] = $dp;
                }
            }
            if (empty($targetPlayers)) continue;

            $eye = new Vector3($granny->x, $granny->y + $granny->getEyeHeight(), $granny->z);
            $angles = [-75, -50, -25, 0, 25, 50, 75];

            foreach ($angles as $angleOffset) {
                $rayYaw = deg2rad($granny->yaw + $angleOffset);
                $rayPitch = deg2rad($granny->pitch);
                $dirX = -sin($rayYaw) * cos($rayPitch);
                $dirY = -sin($rayPitch);
                $dirZ = cos($rayYaw) * cos($rayPitch);

                for ($d = 1.5; $d <= 14.0; $d += 1.5) {
                    $rayPos = new Vector3($eye->x + $dirX * $d, $eye->y + $dirY * $d, $eye->z + $dirZ * $d);
                    $block = $gLevel->getBlock(new Vector3((int)floor($rayPos->x), (int)floor($rayPos->y), (int)floor($rayPos->z)));
                    if ($block->isSolid()) {
                        break;
                    }
                    $gLevel->addParticle(new \pocketmine\level\particle\FlameParticle($rayPos), $targetPlayers);
                }
            }
        }
    }

    public function showDebugParticles(Player $player) {
        $this->sendDebugParticles();
    }

    private function loadNodes() {
        $config = $this->plugin->getConfig();
        $nodes = $config->get("nodes", []);
        if (is_array($nodes) && !empty($nodes)) {
            $this->graph->loadFromArray($nodes);
        }
    }

    private function saveNodes() {
        $this->plugin->getConfig()->set("nodes", $this->graph->toArray());
        $this->plugin->getConfig()->save();
    }
}

class DebugParticleTask extends PluginTask {

    private $nodeManager;

    public function __construct(Main $plugin, NodeManager $nodeManager) {
        parent::__construct($plugin);
        $this->nodeManager = $nodeManager;
    }

    public function onRun($currentTick) {
        $this->nodeManager->sendDebugParticles();
    }
}
