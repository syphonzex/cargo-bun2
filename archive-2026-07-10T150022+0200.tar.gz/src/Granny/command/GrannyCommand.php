<?php

namespace Granny\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginIdentifiableCommand;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ShortTag;
use Granny\Main;
use Granny\entity\GrannyEntity;

class GrannyCommand extends Command implements PluginIdentifiableCommand {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("granny", "Granny plugin management", "/granny help");
        $this->setPermission("granny.command");
        $this->plugin = $plugin;
    }

    public function getPlugin() {
        return $this->plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§cRun this command in-game.");
            return true;
        }

        if (!$this->testPermission($sender)) {
            return true;
        }

        if (empty($args)) {
            $this->sendUsage($sender);
            return true;
        }

        $sub = strtolower(array_shift($args));

        switch ($sub) {
            case "node":
                $this->handleNode($sender, $args);
                break;
            case "nodemode":
            case "nodeedit":
                $this->plugin->getNodeManager()->toggleNodeEditor($sender);
                break;
            case "lock":
                $this->handleLock($sender, $args);
                break;
            case "chest":
                $this->handleChest($sender, $args);
                break;
            case "escape":
                $this->handleEscape($sender, $args);
                break;
            case "cutscene":
            case "cs":
                $this->handleCutscene($sender, $args);
                break;
            case "confirm":
                $this->handleConfirm($sender);
                break;
            case "cancel":
                $this->handleCancel($sender);
                break;
            case "setstart":
                $this->handleSetPos($sender, "start_room", "Start room");
                break;
            case "setlobby":
                $this->handleSetPos($sender, "lobby", "Lobby");
                break;
            case "setgranny":
                $this->handleSetPos($sender, "granny_spawn", "Granny spawn");
                break;
            case "setescape":
                $this->handleSetPos($sender, "escape_door", "Escape door");
                break;
            case "setscrew":
            case "setscrewdriver":
                $lm = $this->plugin->getLockManager();
                $lm->setScrewdriverTarget($sender->x, $sender->y, $sender->z);
                $sender->sendMessage("§aScrewdriver target set at §e" . round($sender->x, 1) . " " . round($sender->y, 1) . " " . round($sender->z, 1) . "§a");
                $sender->sendMessage("§7This position will work in §eall§7 arenas created from the template.");
                $sender->sendMessage("§7Arrows landing near this exact spot will drop the screwdriver.");
                break;
            case "settemplate":
                $this->handleSetTemplate($sender);
                break;
            case "additemspawn":
                $this->handleAddItemSpawn($sender);
                break;
            case "spawn":
                $this->handleSpawn($sender);
                break;
            case "debug":
                $this->handleDebug($sender);
                break;
            case "enter":
                $this->plugin->getMainLobby()->enterLobby($sender);
                break;
            case "join":
                $this->plugin->getLobbyManager()->addPlayer($sender);
                break;
case "leave":
    $session = $this->plugin->getArenaManager()->getPlayerSession($sender->getName());
    if ($session !== null) {
        $session->removePlayer($sender);
    } else {
        $this->plugin->getLobbyManager()->removePlayer($sender);
    }
    break;
            case "forcestart":
                $this->handleForceStart($sender);
                break;
            case "forceend":
                $this->handleForceEnd($sender);
                break;
            case "ghost":
            case "ghostmode":
                if (!$sender->isOp()) {
                    $sender->sendMessage("§cThis command is OP only!");
                    return true;
                }
                $this->plugin->toggleGhost($sender);
                break;
            case "help":
            default:
                $this->sendUsage($sender);
                break;
        }
        return true;
    }

    private function sendUsage(Player $player) {
        $player->sendMessage("§6--- Granny Commands ---");
        $player->sendMessage("§e/granny node mode §7- Enter interactive item-based Node Editor");
        $player->sendMessage("§e/granny node §7- Node management");
        $player->sendMessage("§e/granny cutscene §7- Cutscene editor (or /granny cs)");
        $player->sendMessage("§e/granny lock §7- Simple lock system");
        $player->sendMessage("§e/granny escape §7- Multi-part escape routes");
        $player->sendMessage("§e/granny chest §7- Chest preset system");
        $player->sendMessage("§e/granny confirm §7| §ecancel §7- Build mode controls");
        $player->sendMessage("§e/granny settemplate §7- Set current world as template");
        $player->sendMessage("§e/granny setstart §7| §esetlobby §7| §esetgranny §7| §esetescape §7| §esetscrew");
        $player->sendMessage("§e/granny additemspawn §7| §espawn §7| §edebug §7| §eghost");
        $player->sendMessage("§e/granny enter §7- Enter Granny main lobby");
        $player->sendMessage("§e/granny join §7| §eleave §7| §eforcestart §7| §eforceend");
    }

    private function handleNode(Player $player, array $args) {
        if (empty($args)) {
            $player->sendMessage("§e/granny node mode §7- Enter interactive item-based Node Editor");
            $player->sendMessage("§e/granny node add <name> [patrol]");
            $player->sendMessage("§e/granny node remove <name>");
            $player->sendMessage("§e/granny node list");
            $player->sendMessage("§e/granny node link <n1> <n2>");
            $player->sendMessage("§e/granny node unlink <n1> <n2>");
            return;
        }

        $action = strtolower(array_shift($args));

        switch ($action) {
            case "mode":
            case "edit":
            case "gui":
                $this->plugin->getNodeManager()->toggleNodeEditor($player);
                break;
            case "add":
                if (empty($args)) { $player->sendMessage("§cUsage: /granny node add <name> [patrol]"); return; }
                $name = array_shift($args);
                $patrol = (!empty($args) && strtolower($args[0]) === "patrol");
                $pos = new Vector3(round($player->x, 2), round($player->y, 2), round($player->z, 2));
                if ($this->plugin->getNodeManager()->addNode($name, $pos, $patrol)) {
                    $type = $patrol ? " (Patrol)" : "";
                    $player->sendMessage("§aNode §e" . $name . $type . "§a added.");
                } else {
                    $player->sendMessage("§cNode §e" . $name . "§c already exists.");
                }
                break;
            case "remove":
                if (empty($args)) { $player->sendMessage("§cUsage: /granny node remove <name>"); return; }
                if ($this->plugin->getNodeManager()->removeNode($args[0])) {
                    $player->sendMessage("§aNode §e" . $args[0] . "§a removed.");
                } else {
                    $player->sendMessage("§cNode not found.");
                }
                break;
            case "list":
                $nodes = $this->plugin->getNodeManager()->getGraph()->getNodes();
                if (empty($nodes)) { $player->sendMessage("§7No nodes defined."); return; }
                $player->sendMessage("§6--- Nodes ---");
                foreach ($nodes as $n => $node) {
                    $p = $node->getPosition();
                    $t = $node->isPatrol() ? " §d[P]" : "";
                    $l = $node->getLinks();
                    $ls = empty($l) ? "§7none" : "§b" . implode(", ", $l);
                    $player->sendMessage("§e" . $n . $t . " §f(" . round($p->x, 1) . ", " . round($p->y, 1) . ", " . round($p->z, 1) . ") §7-> " . $ls);
                }
                break;
            case "link":
                if (count($args) < 2) { $player->sendMessage("§cUsage: /granny node link <n1> <n2>"); return; }
                if ($this->plugin->getNodeManager()->linkNodes($args[0], $args[1])) {
                    $player->sendMessage("§aLinked §e" . $args[0] . " §a<-> §e" . $args[1]);
                } else {
                    $player->sendMessage("§cOne or both nodes not found.");
                }
                break;
            case "unlink":
                if (count($args) < 2) { $player->sendMessage("§cUsage: /granny node unlink <n1> <n2>"); return; }
                if ($this->plugin->getNodeManager()->unlinkNodes($args[0], $args[1])) {
                    $player->sendMessage("§aUnlinked §e" . $args[0] . " §a<-> §e" . $args[1]);
                } else {
                    $player->sendMessage("§cOne or both nodes not found.");
                }
                break;
        }
    }

    private function handleLock(Player $player, array $args) {
        if (empty($args)) {
            $player->sendMessage("§6--- Lock Commands ---");
            $player->sendMessage("§e/granny lock create <name> §7- Hold key item");
            $player->sendMessage("§e/granny lock list §7- Show all locks");
            $player->sendMessage("§e/granny lock remove <name>");
            $player->sendMessage("§e/granny lock restore §7- Rebuild all");
            $player->sendMessage("§e/granny lock alert <name> <on|off> §7- Alert Granny");
            $player->sendMessage("§e/granny lock action remove <name> §7- Remove blocks on unlock");
            $player->sendMessage("§e/granny lock action place <name> §7- Place blocks on unlock");
            $player->sendMessage("§e/granny lock action give <name> §7- Give held item");
            $player->sendMessage("§e/granny lock action cmd <name> <cmd> §7- Run command");
            $player->sendMessage("§e/granny lock action msg <name> <msg> §7- Send message");
            return;
        }

        $action = strtolower(array_shift($args));
        $lm = $this->plugin->getLockManager();

        switch ($action) {
            case "create":
                if (empty($args)) { $player->sendMessage("§cUsage: /granny lock create <name>"); return; }
                if ($lm->isInBuildMode($player->getName())) {
                    $player->sendMessage("§cAlready in build mode! Use /granny confirm or cancel");
                    return;
                }
                $name = $args[0];
                $result = $lm->createLock($name, $player);
                if ($result === null) {
                    $player->sendMessage("§cHold the key item in your hand first!");
                } elseif ($result === false) {
                    $player->sendMessage("§cLock §e" . $name . "§c already exists.");
                } else {
                    $item = $player->getInventory()->getItemInHand();
                    $player->sendMessage("§aLock §e" . $name . "§a created!");
                    $player->sendMessage("§7Key: §f" . $item->getName() . " §7(" . $item->getId() . ":" . $item->getDamage() . ")");
                    $player->sendMessage("§6§lBUILD MODE §r§7- Place blocks that disappear on unlock.");
                    $player->sendMessage("§7Done: §e/granny confirm §7| Cancel: §e/granny cancel");
                }
                break;

            case "list":
                $locks = $lm->getLocks();
                if (empty($locks)) { $player->sendMessage("§7No locks defined."); return; }
                $player->sendMessage("§6--- Locks ---");
                foreach ($locks as $name => $lock) {
                    $blockCount = count($lock["blocks"]);
                    $keyName = $lock["key_name"] !== "" ? $lock["key_name"] : "ID " . $lock["key_id"] . ":" . $lock["key_meta"];
                    $alert = (isset($lock["alert_granny"]) && $lock["alert_granny"]) ? "§cON" : "§aOFF";
                    $actionCount = isset($lock["actions"]) ? count($lock["actions"]) : 0;
                    $player->sendMessage("§e" . $name . " §7Key: §f" . $keyName . " §7Blocks: §f" . $blockCount . " §7Alert: " . $alert . " §7Actions: §f" . $actionCount);
                }
                break;

            case "remove":
                if (empty($args)) { $player->sendMessage("§cUsage: /granny lock remove <name>"); return; }
                if ($lm->removeLock($args[0])) {
                    $player->sendMessage("§aLock §e" . $args[0] . "§a removed.");
                } else {
                    $player->sendMessage("§cLock not found.");
                }
                break;

            case "restore":
                $lm->restoreAllLocks();
                $player->sendMessage("§aAll lock blocks restored.");
                break;

            case "alert":
                if (count($args) < 2) { $player->sendMessage("§cUsage: /granny lock alert <name> <on|off>"); return; }
                $val = strtolower($args[1]) === "on";
                if ($lm->setAlertGranny($args[0], $val)) {
                    $player->sendMessage("§aLock §e" . $args[0] . "§a alert Granny: " . ($val ? "§cON" : "§aOFF"));
                } else {
                    $player->sendMessage("§cLock not found.");
                }
                break;

            case "action":
                $this->handleLockAction($player, $args);
                break;
        }
    }

    private function handleLockAction(Player $player, array $args) {
        if (count($args) < 2) {
            $player->sendMessage("§cUsage: /granny lock action <type> <lockName> [data]");
            $player->sendMessage("§7Types: remove, place, give, cmd, msg");
            return;
        }

        $type = strtolower(array_shift($args));
        $lockName = array_shift($args);
        $lm = $this->plugin->getLockManager();

        if ($lm->getLock($lockName) === null) {
            $player->sendMessage("§cLock §e" . $lockName . " §cnot found.");
            return;
        }

        switch ($type) {
            case "remove":
                $lm->startBuildMode($player->getName(), $lockName, "remove_blocks");
                $player->sendMessage("§6§lBUILD MODE §r§7- Place blocks that will be §cREMOVED §7on unlock.");
                $player->sendMessage("§7Done: §e/granny confirm §7| Cancel: §e/granny cancel");
                break;

            case "place":
                $lm->startBuildMode($player->getName(), $lockName, "place_blocks");
                $player->sendMessage("§6§lBUILD MODE §r§7- Place blocks that will §aAPPEAR §7on unlock.");
                $player->sendMessage("§7These blocks will appear when the lock is unlocked.");
                $player->sendMessage("§7Done: §e/granny confirm §7| Cancel: §e/granny cancel");
                break;

            case "give":
                $item = $player->getInventory()->getItemInHand();
                if ($item->getId() === 0) { $player->sendMessage("§cHold the item to give!"); return; }
                $lm->addAction($lockName, "give_item", [
                    "item_id" => $item->getId(),
                    "item_meta" => $item->getDamage(),
                    "item_count" => $item->getCount(),
                    "item_name" => $item->hasCustomName() ? $item->getCustomName() : ""
                ]);
                $player->sendMessage("§aGive-item action added: §f" . $item->getName() . " x" . $item->getCount());
                break;

            case "cmd":
                if (empty($args)) { $player->sendMessage("§cUsage: /granny lock action cmd <name> <command>"); return; }
                $cmd = implode(" ", $args);
                $lm->addAction($lockName, "run_command", ["command" => $cmd]);
                $player->sendMessage("§aCommand action added: §f" . $cmd);
                $player->sendMessage("§7Use {player} for the player's name.");
                break;

            case "msg":
                if (empty($args)) { $player->sendMessage("§cUsage: /granny lock action msg <name> <message>"); return; }
                $msg = implode(" ", $args);
                $lm->addAction($lockName, "send_message", ["message" => $msg]);
                $player->sendMessage("§aMessage action added: §f" . $msg);
                break;
        }
    }

    private function handleChest(Player $player, array $args) {
        if (empty($args)) {
            $player->sendMessage("§6--- Chest Commands ---");
            $player->sendMessage("§e/granny chest preset create <name>");
            $player->sendMessage("§e/granny chest preset additem <preset> <chestIndex> §7- Hold item");
            $player->sendMessage("§e/granny chest preset removeitem <preset> <chestIndex> <itemIndex>");
            $player->sendMessage("§e/granny chest preset list");
            $player->sendMessage("§e/granny chest preset remove <name>");
            $player->sendMessage("§e/granny chest register <preset> §7- Then tap a chest");
            $player->sendMessage("§e/granny chest fill §7- Fill chests with random preset");
            $player->sendMessage("§e/granny chest clear §7- Clear all chests");
            return;
        }

        $action = strtolower(array_shift($args));
        $cm = $this->plugin->getChestManager();

        switch ($action) {
            case "preset":
                $this->handleChestPreset($player, $args);
                break;

            case "register":
                if (empty($args)) { $player->sendMessage("§cUsage: /granny chest register <preset>"); return; }
                $presetName = $args[0];
                $preset = $cm->getPreset($presetName);
                if ($preset === null) {
                    $player->sendMessage("§cPreset §e" . $presetName . "§c not found. Create it first.");
                    return;
                }
                $cm->setRegisterMode($player->getName(), $presetName);
                $player->sendMessage("§aTap a chest to register it to preset §e" . $presetName);
                break;

            case "fill":
                $preset = $cm->fillChestsWithRandomPreset();
                if ($preset === null) {
                    $player->sendMessage("§cNo presets defined.");
                } else {
                    $player->sendMessage("§aChests filled with preset: §e" . $preset);
                }
                break;

            case "clear":
                $cm->clearAllChests();
                $player->sendMessage("§aAll chests cleared.");
                break;

            default:
                $player->sendMessage("§cUnknown chest action. Use /granny chest");
                break;
        }
    }

    private function handleChestPreset(Player $player, array $args) {
        if (empty($args)) {
            $player->sendMessage("§cUsage: /granny chest preset <create|additem|removeitem|list|remove>");
            return;
        }

        $action = strtolower(array_shift($args));
        $cm = $this->plugin->getChestManager();

        switch ($action) {
            case "create":
                if (empty($args)) { $player->sendMessage("§cUsage: /granny chest preset create <name>"); return; }
                if ($cm->createPreset($args[0])) {
                    $player->sendMessage("§aPreset §e" . $args[0] . "§a created.");
                } else {
                    $player->sendMessage("§cPreset §e" . $args[0] . "§c already exists.");
                }
                break;

            case "additem":
                if (count($args) < 2 || !is_numeric($args[1])) {
                    $player->sendMessage("§cUsage: /granny chest preset additem <preset> <chestIndex>");
                    $player->sendMessage("§7Use /granny chest preset list to see chest indexes.");
                    return;
                }
                $item = $player->getInventory()->getItemInHand();
                if ($item->getId() === 0) {
                    $player->sendMessage("§cHold an item in your hand!");
                    return;
                }
                if ($cm->addItemToChest($args[0], (int)$args[1], $item)) {
                    $player->sendMessage("§aAdded §f" . $item->getName() . " x" . $item->getCount() . "§a to chest §e#" . $args[1] . " §ain preset §e" . $args[0]);
                } else {
                    $player->sendMessage("§cPreset or chest index not found.");
                }
                break;

            case "removeitem":
                if (count($args) < 3 || !is_numeric($args[1]) || !is_numeric($args[2])) {
                    $player->sendMessage("§cUsage: /granny chest preset removeitem <preset> <chestIndex> <itemIndex>");
                    return;
                }
                if ($cm->removeItemFromChest($args[0], (int)$args[1], (int)$args[2])) {
                    $player->sendMessage("§aRemoved item §e#" . $args[2] . "§a from chest §e#" . $args[1] . " §ain preset §e" . $args[0]);
                } else {
                    $player->sendMessage("§cPreset, chest, or item index not found.");
                }
                break;

            case "list":
                $presets = $cm->getPresets();
                if (empty($presets)) {
                    $player->sendMessage("§7No presets defined.");
                    return;
                }
                $player->sendMessage("§6--- Chest Presets ---");
                foreach ($presets as $name => $presetData) {
                    $chests = isset($presetData["chests"]) ? $presetData["chests"] : [];
                    $player->sendMessage("§e" . $name . " §7(" . count($chests) . " chests):");
                    foreach ($chests as $ci => $chest) {
                        $items = isset($chest["items"]) ? $chest["items"] : [];
                        $player->sendMessage("  §bChest #" . $ci . " §7at §f" . $chest["x"] . " " . $chest["y"] . " " . $chest["z"] . " §7(" . count($items) . " items)");
                        foreach ($items as $ii => $itemData) {
                            $label = $itemData["name"] !== "" ? $itemData["name"] : "ID " . $itemData["id"] . ":" . $itemData["meta"];
                            $player->sendMessage("    §f[" . $ii . "] " . $label . " x" . $itemData["count"]);
                        }
                    }
                }
                break;

            case "remove":
                if (empty($args)) { $player->sendMessage("§cUsage: /granny chest preset remove <name>"); return; }
                if ($cm->removePreset($args[0])) {
                    $player->sendMessage("§aPreset §e" . $args[0] . "§a removed.");
                } else {
                    $player->sendMessage("§cPreset not found.");
                }
                break;
        }
    }

    private function handleEscape(Player $player, array $args) {
        if (empty($args)) {
            $player->sendMessage("§6--- Escape Route Commands ---");
            $player->sendMessage("§e/granny escape create <name>");
            $player->sendMessage("§e/granny escape remove <name>");
            $player->sendMessage("§e/granny escape addpart <escape> <part> §7- Hold key item");
            $player->sendMessage("§e/granny escape removepart <escape> <part>");
            $player->sendMessage("§e/granny escape setblocks <escape> <part> §7- Set lock blocks (build)");
            $player->sendMessage("§e/granny escape action remove <esc> <part> §7- Remove blocks on unlock (build)");
            $player->sendMessage("§e/granny escape action place <esc> <part> §7- Place blocks on unlock (build)");
            $player->sendMessage("§e/granny escape action give <esc> <part> §7- Give held item on unlock");
            $player->sendMessage("§e/granny escape action cmd <esc> <part> <cmd> §7- Run command on unlock");
            $player->sendMessage("§e/granny escape action msg <esc> <part> <msg> §7- Send message on unlock");
            $player->sendMessage("§e/granny escape setkey <name> §7- Hold main escape key");
            $player->sendMessage("§e/granny escape alert <name> <part> <on|off> §7- Alert Granny");
            $player->sendMessage("§e/granny escape list");
            $player->sendMessage("§e/granny escape restore §7- Rebuild all");
            return;
        }

        $action = strtolower(array_shift($args));
        $esm = $this->plugin->getEscapeManager();

        switch ($action) {
            case "create":
                if (empty($args)) { $player->sendMessage("§cUsage: /granny escape create <name>"); return; }
                if ($esm->createEscape($args[0])) {
                    $player->sendMessage("§aEscape route §e" . $args[0] . "§a created.");
                } else {
                    $player->sendMessage("§cAlready exists.");
                }
                break;

            case "remove":
                if (empty($args)) { $player->sendMessage("§cUsage: /granny escape remove <name>"); return; }
                if ($esm->removeEscape($args[0])) {
                    $player->sendMessage("§aEscape route §e" . $args[0] . "§a removed.");
                } else {
                    $player->sendMessage("§cNot found.");
                }
                break;

            case "addpart":
                if (count($args) < 2) { $player->sendMessage("§cUsage: /granny escape addpart <escape> <part>"); return; }
                $item = $player->getInventory()->getItemInHand();
                if ($item->getId() === 0) { $player->sendMessage("§cHold the key item first!"); return; }
                $result = $esm->addPart($args[0], $args[1], $item);
                if ($result === true) {
                    $player->sendMessage("§aPart §e" . $args[1] . "§a added to §e" . $args[0]);
                    $player->sendMessage("§7Key: §f" . $item->getName() . " §7(" . $item->getId() . ":" . $item->getDamage() . ")");
                    $player->sendMessage("§7Now set lock blocks: §e/granny escape setblocks " . $args[0] . " " . $args[1]);
                } elseif ($result === "exists") {
                    $player->sendMessage("§cPart §e" . $args[1] . "§c already exists.");
                } else {
                    $player->sendMessage("§cEscape route not found.");
                }
                break;

            case "removepart":
                if (count($args) < 2) { $player->sendMessage("§cUsage: /granny escape removepart <escape> <part>"); return; }
                if ($esm->removePart($args[0], $args[1])) {
                    $player->sendMessage("§aPart §e" . $args[1] . "§a removed.");
                } else {
                    $player->sendMessage("§cNot found.");
                }
                break;

            case "setblocks":
                if (count($args) < 2) { $player->sendMessage("§cUsage: /granny escape setblocks <escape> <part>"); return; }
                $esm->startBuildMode($player->getName(), $args[0], $args[1], "lock");
                $player->sendMessage("§6§lBUILD MODE §r§7- Place the lock blocks for §e" . $args[1]);
                $player->sendMessage("§7Done: §e/granny confirm §7| Cancel: §e/granny cancel");
                break;

            case "setkey":
                if (empty($args)) { $player->sendMessage("§cUsage: /granny escape setkey <name>"); return; }
                $item = $player->getInventory()->getItemInHand();
                if ($item->getId() === 0) { $player->sendMessage("§cHold the main escape key item!"); return; }
                if ($esm->setMainKey($args[0], $item)) {
                    $player->sendMessage("§aMain key for §e" . $args[0] . "§a set to §f" . $item->getName() . " §7(" . $item->getId() . ":" . $item->getDamage() . ")");
                    $player->sendMessage("§7After all parts are unlocked, players use this key to escape and win.");
                } else {
                    $player->sendMessage("§cEscape route not found.");
                }
                break;

            case "alert":
                if (count($args) < 3) { $player->sendMessage("§cUsage: /granny escape alert <escape> <part> <on|off>"); return; }
                $val = strtolower($args[2]) === "on";
                if ($esm->setPartAlertGranny($args[0], $args[1], $val)) {
                    $player->sendMessage("§aPart §e" . $args[1] . "§a alert Granny: " . ($val ? "§cON" : "§aOFF"));
                } else {
                    $player->sendMessage("§cEscape or part not found.");
                }
                break;

            case "action":
                $this->handleEscapeAction($player, $args);
                break;

            case "list":
                $escapes = $esm->getEscapes();
                if (empty($escapes)) { $player->sendMessage("§7No escape routes defined."); return; }
                $player->sendMessage("§6--- Escape Routes ---");
                foreach ($escapes as $name => $esc) {
                    $parts = isset($esc["parts"]) ? $esc["parts"] : [];
                    $open = $esm->isEscapeOpen($name) ? "§a[OPEN]" : "§c[LOCKED]";
                    $mainKey = isset($esc["main_key"]) && $esc["main_key"] !== null ? ($esc["main_key"]["name"] !== "" ? $esc["main_key"]["name"] : "ID " . $esc["main_key"]["id"] . ":" . $esc["main_key"]["meta"]) : "§7none";
                    $player->sendMessage("§e" . $name . " " . $open . " §7(" . count($parts) . " parts) §7Key: §f" . $mainKey);
                    foreach ($parts as $pName => $part) {
                        $unlocked = $esm->isPartUnlocked($name, $pName) ? "§a#" : "§cX";
                        $keyLabel = $part["key_name"] !== "" ? $part["key_name"] : "ID " . $part["key_id"] . ":" . $part["key_meta"];
                        $actionCount = count($part["actions"]);
                        $blockCount = count($part["lock_blocks"]);
                        $alert = (isset($part["alert_granny"]) && $part["alert_granny"]) ? "§cON" : "§aOFF";
                        $player->sendMessage("  " . $unlocked . " §f" . $pName . " §7Key: §f" . $keyLabel . " §7B: §f" . $blockCount . " §7A: §f" . $actionCount . " §7Alert: " . $alert);
                    }
                }
                break;

            case "restore":
                $esm->restoreAll();
                $player->sendMessage("§aAll escape routes restored.");
                break;
        }
    }

    private function handleEscapeAction(Player $player, array $args) {
        if (count($args) < 3) {
            $player->sendMessage("§cUsage: /granny escape action <type> <escape> <part> [data]");
            $player->sendMessage("§7Types: remove, place, give, cmd, msg");
            return;
        }

        $type = strtolower(array_shift($args));
        $escName = array_shift($args);
        $partName = array_shift($args);
        $esm = $this->plugin->getEscapeManager();

        switch ($type) {
            case "remove":
                $esm->startBuildMode($player->getName(), $escName, $partName, "remove_blocks");
                $player->sendMessage("§6§lBUILD MODE §r§7- Place blocks that will be §cREMOVED §7on unlock.");
                $player->sendMessage("§7Done: §e/granny confirm §7| Cancel: §e/granny cancel");
                break;

            case "place":
                $esm->startBuildMode($player->getName(), $escName, $partName, "place_blocks");
                $player->sendMessage("§6§lBUILD MODE §r§7- Place blocks that will §aAPPEAR §7on unlock.");
                $player->sendMessage("§7These blocks will appear when the lock is unlocked.");
                $player->sendMessage("§7Done: §e/granny confirm §7| Cancel: §e/granny cancel");
                break;

            case "give":
                $item = $player->getInventory()->getItemInHand();
                if ($item->getId() === 0) { $player->sendMessage("§cHold the item to give!"); return; }
                $esm->addAction($escName, $partName, "give_item", [
                    "item_id" => $item->getId(),
                    "item_meta" => $item->getDamage(),
                    "item_count" => $item->getCount(),
                    "item_name" => $item->hasCustomName() ? $item->getCustomName() : ""
                ]);
                $player->sendMessage("§aGive-item action added: §f" . $item->getName() . " x" . $item->getCount());
                break;

            case "cmd":
                if (empty($args)) { $player->sendMessage("§cUsage: /granny escape action cmd <esc> <part> <command>"); return; }
                $cmd = implode(" ", $args);
                $esm->addAction($escName, $partName, "run_command", ["command" => $cmd]);
                $player->sendMessage("§aCommand action added: §f" . $cmd);
                $player->sendMessage("§7Use {player} for the player's name.");
                break;

            case "msg":
                if (empty($args)) { $player->sendMessage("§cUsage: /granny escape action msg <esc> <part> <message>"); return; }
                $msg = implode(" ", $args);
                $esm->addAction($escName, $partName, "send_message", ["message" => $msg]);
                $player->sendMessage("§aMessage action added: §f" . $msg);
                break;
        }
    }

    private function handleConfirm(Player $player) {
        $name = $player->getName();
        $lm = $this->plugin->getLockManager();
        $esm = $this->plugin->getEscapeManager();

        if ($lm->isInBuildMode($name)) {
            $lockName = $lm->getBuildLockName($name);
            if ($lm->confirmBuild($name)) {
                $player->sendMessage("§aLock §e" . $lockName . "§a saved!");
            } else {
                $player->sendMessage("§cNo blocks placed.");
            }
            return;
        }

        if ($esm->isInBuildMode($name)) {
            $ctx = $esm->getBuildContext($name);
            if ($esm->confirmBuild($name)) {
                $player->sendMessage("§aSaved §e" . $ctx["type"] . "§a for §e" . $ctx["part"] . " §ain §e" . $ctx["escape"]);
            } else {
                $player->sendMessage("§cNo blocks placed.");
            }
            return;
        }

        $player->sendMessage("§cYou are not in build mode.");
    }

    private function handleCancel(Player $player) {
        $name = $player->getName();
        $lm = $this->plugin->getLockManager();
        $esm = $this->plugin->getEscapeManager();

        if ($lm->isInBuildMode($name)) {
            $lm->cancelBuild($name);
            $player->sendMessage("§cBuild cancelled.");
            return;
        }

        if ($esm->isInBuildMode($name)) {
            $esm->cancelBuild($name);
            $player->sendMessage("§cBuild cancelled.");
            return;
        }

        $player->sendMessage("§cYou are not in build mode.");
    }

private function handleCutscene(Player $player, array $args) {
    if (empty($args)) {
        $player->sendMessage("§6--- Cutscene Commands ---");
        $player->sendMessage("§e/granny cs setspawn §7- Set blackout box position");
        $player->sendMessage("§e/granny cs addpos <scene> [sec] §7- Add camera point");
        $player->sendMessage("§e/granny cs addcut <scene> [cut_sec] §7- Add point with cut");
        $player->sendMessage("§e/granny cs removepos <scene> <#> §7- Remove camera point");
        $player->sendMessage("§e/granny cs action <scene> <type> <at_sec> [data]");
        $player->sendMessage("§7 Actions: §ftip, popup, blind, clearblind,");
        $player->sendMessage("§7 §fgrannytp, grannywalk, grannyswing, sound");
        $player->sendMessage("§e/granny cs removeaction <scene> <#>");
        $player->sendMessage("§e/granny cs list <scene> §7- Show points + actions");
        $player->sendMessage("§e/granny cs clear <scene>");
        $player->sendMessage("§e/granny cs play <scene> §7- Test play");
        $player->sendMessage("§e/granny cs stop §7- Stop all cutscenes");
        $player->sendMessage("§7Scenes: §fwake, gameover, ending, caught");
        $player->sendMessage("§7For §fcaught§7: addpos stores yaw/pitch offset only (no xyz)");
        return;
    }

    $action = strtolower(array_shift($args));
    $cm = $this->plugin->getCutsceneManager();

    switch ($action) {
        case "setspawn":
            $cm->setCutSpawn($player, $player->yaw, $player->pitch, $player->getLevel()->getName());
            $player->sendMessage("§aCutscene spawn set at your position.");
            break;

        case "addpos":
            if (empty($args) || !$cm->isValidScene($args[0])) {
                $player->sendMessage("§cUsage: /granny cs addpos <scene> [seconds]");
                $player->sendMessage("§7[seconds] = travel time from previous point (default: 3)");
                $player->sendMessage("§7For 'caught': your look direction = offset from granny direction");
                return;
            }
            $scene = $args[0];
            $seconds = isset($args[1]) ? (float)$args[1] : 3.0;
            if ($seconds < 0.5) $seconds = 0.5;

            if ($scene === "caught") {
                $idx = $cm->addCaughtPoint($scene, $player->yaw, $player->pitch, $seconds);
                $player->sendMessage("§aPoint §e#" . $idx . "§a added to §ecaught §7[" . $seconds . "s]");
                $player->sendMessage("§7 YawOffset: §f" . round($player->yaw, 1) . " §7PitchOffset: §f" . round($player->pitch, 1));
                $player->sendMessage("§7 Yaw 0 = looking at granny. Your current angle = offset.");
            } else {
                $idx = $cm->addPoint($scene, $player->x, $player->y, $player->z, $player->yaw, $player->pitch, $seconds);
                $player->sendMessage("§aPoint §e#" . $idx . "§a added to §e" . $scene . " §7[" . $seconds . "s]");
                $player->sendMessage("§7 Pos: §f" . round($player->x, 1) . " " . round($player->y, 1) . " " . round($player->z, 1) . " §7Yaw: §f" . round($player->yaw, 1) . " §7Pitch: §f" . round($player->pitch, 1));
            }
            break;

        case "addcut":
            if (empty($args) || !$cm->isValidScene($args[0])) {
                $player->sendMessage("§cUsage: /granny cs addcut <scene> [cut_sec]");
                $player->sendMessage("§7Camera travels here in <sec>, then blacks out for [cut_sec] (default 2)");
                return;
            }
            if ($args[0] === "caught") {
                $player->sendMessage("§cCuts are not supported for caught cutscene.");
                return;
            }
            $scene = $args[0];
            $travelSec = isset($args[1]) ? (float)$args[1] : 3.0;
            $cutSec = isset($args[2]) ? (float)$args[2] : 2.0;
            if ($travelSec < 0.5) $travelSec = 0.5;
            if ($cutSec < 0.5) $cutSec = 0.5;
            $idx = $cm->addPoint($scene, $player->x, $player->y, $player->z, $player->yaw, $player->pitch, $travelSec, $cutSec);
            $player->sendMessage("§aPoint §e#" . $idx . "§a added to §e" . $scene . " §7[" . $travelSec . "s travel] §c[" . $cutSec . "s cut]");
            $player->sendMessage("§7 Screen goes black for " . $cutSec . "s after arriving here.");
            break;

        case "removepos":
            if (count($args) < 2 || !$cm->isValidScene($args[0]) || !is_numeric($args[1])) {
                $player->sendMessage("§cUsage: /granny cs removepos <scene> <index>");
                return;
            }
            if ($cm->removePoint($args[0], (int)$args[1])) {
                $player->sendMessage("§aPoint §e#" . $args[1] . "§a removed from §e" . $args[0]);
            } else {
                $player->sendMessage("§cPoint not found.");
            }
            break;

        case "action":
            $this->cutsceneActionAdd($player, $args, $cm);
            break;

        case "removeaction":
            if (count($args) < 2 || !$cm->isValidScene($args[0]) || !is_numeric($args[1])) {
                $player->sendMessage("§cUsage: /granny cs removeaction <scene> <index>");
                return;
            }
            if ($cm->removeAction($args[0], (int)$args[1])) {
                $player->sendMessage("§aAction §e#" . $args[1] . "§a removed from §e" . $args[0]);
            } else {
                $player->sendMessage("§cAction not found.");
            }
            break;

        case "list":
            $this->cutsceneList($player, $args, $cm);
            break;

        case "clear":
            if (empty($args) || !$cm->isValidScene($args[0])) {
                $player->sendMessage("§cUsage: /granny cs clear <scene>");
                return;
            }
            $cm->clearScene($args[0]);
            $player->sendMessage("§aScene §e" . $args[0] . "§a cleared.");
            break;

        case "play":
            if (empty($args) || !$cm->isValidScene($args[0])) {
                $player->sendMessage("§cUsage: /granny cs play <scene>");
                return;
            }
            if ($args[0] === "caught") {
                $result = $cm->playCaughtScene($player, $player->x + 2, $player->y, $player->z);
                if ($result) {
                    $player->sendMessage("§aPlaying §ecaught§a... (test: fake granny 2 blocks ahead)");
                } else {
                    $player->sendMessage("§cScene §ecaught§c needs at least 2 camera points.");
                }
            } else {
                if ($cm->playScene($args[0], $player)) {
                    $player->sendMessage("§aPlaying §e" . $args[0] . "§a...");
                } else {
                    $player->sendMessage("§cScene §e" . $args[0] . "§c needs at least 2 camera points.");
                }
            }
            break;

        case "stop":
            $cm->stopAll();
            $player->sendMessage("§aAll cutscenes stopped.");
            break;

        default:
            $player->sendMessage("§cUnknown cutscene action. Use /granny cs");
            break;
    }
}

    private function cutsceneActionAdd(Player $player, array $args, $cm) {
        if (count($args) < 3) {
            $player->sendMessage("§cUsage: /granny cs action <scene> <type> <at_seconds> [data]");
            $player->sendMessage("§7Types: tip, popup, blind, clearblind, grannytp, grannywalk, grannyswing, sound");
            $player->sendMessage("§7<at_seconds> = when to trigger during the cutscene");
            return;
        }

        $scene = strtolower(array_shift($args));
        $type = strtolower(array_shift($args));
        $atSec = (float)array_shift($args);

        if (!$cm->isValidScene($scene)) {
            $player->sendMessage("§cInvalid scene. Use: wake, gameover, ending");
            return;
        }

        $act = ["type" => $type, "at" => $atSec];

        switch ($type) {
            case "tip":
            case "popup":
                if (empty($args)) {
                    $player->sendMessage("§cUsage: /granny cs action " . $scene . " " . $type . " <at_sec> <text>");
                    return;
                }
                $act["text"] = implode(" ", $args);
                break;

            case "blind":
                $act["duration"] = !empty($args) ? (float)$args[0] : 3.0;
                break;

            case "clearblind":
                break;

            case "grannytp":
                $act["x"] = round($player->x, 4);
                $act["y"] = round($player->y, 4);
                $act["z"] = round($player->z, 4);
                $act["yaw"] = round($player->yaw, 4);
                $act["pitch"] = round($player->pitch, 4);
                break;

            case "grannywalk":
                $act["x"] = round($player->x, 4);
                $act["y"] = round($player->y, 4);
                $act["z"] = round($player->z, 4);
                break;

            case "grannyswing":
                break;

            case "sound":
                if (empty($args) || !is_numeric($args[0])) {
                    $player->sendMessage("§cUsage: /granny cs action " . $scene . " sound <at_sec> <soundId>");
                    $player->sendMessage("§7Sounds: 1000=click 1003=door 1020=anvil_break 1022=anvil_fall");
                    return;
                }
                $act["sound_id"] = (int)$args[0];
                break;

            default:
                $player->sendMessage("§cUnknown action type: " . $type);
                return;
        }

        $idx = $cm->addAction($scene, $act);
        $player->sendMessage("§aAction §e#" . $idx . " §a(" . $type . ") added to §e" . $scene . " §7at " . $atSec . "s");
        if ($type === "grannytp" || $type === "grannywalk") {
            $player->sendMessage("§7  Pos: §f" . round($player->x, 1) . " " . round($player->y, 1) . " " . round($player->z, 1));
        }
    }

    private function cutsceneList(Player $player, array $args, $cm) {
        if (empty($args) || !$cm->isValidScene($args[0])) {
            $player->sendMessage("§cUsage: /granny cs list <wake|gameover|ending>");
            return;
        }

        $scene = $args[0];
        $points = $cm->getPoints($scene);
        $actions = $cm->getActions($scene);

        $player->sendMessage("§6--- " . ucfirst($scene) . " Cutscene ---");

        if (empty($points)) {
            $player->sendMessage("§7No camera points.");
        } else {
            $player->sendMessage("§eCamera Points (" . count($points) . "):");
            $totalTime = 0;
            foreach ($points as $i => $pt) {
                if ($i > 0) $totalTime += $pt["seconds"];
                $cutInfo = isset($pt["cut"]) ? " §c[CUT " . $pt["cut"] . "s]" : "";
                $player->sendMessage("  §f#" . $i . " §7(" . round($pt["x"], 1) . " " . round($pt["y"], 1) . " " . round($pt["z"], 1) . ") §7yaw:" . round($pt["yaw"], 1) . " §7[" . $pt["seconds"] . "s]" . $cutInfo . " §8@" . round($totalTime, 1) . "s");
            }
            $player->sendMessage("§7Total camera time: §f" . round($totalTime, 1) . "s");
        }

        if (empty($actions)) {
            $player->sendMessage("§7No actions.");
        } else {
            $player->sendMessage("§eActions (" . count($actions) . "):");
            foreach ($actions as $i => $act) {
                $info = "  §f#" . $i . " §e" . $act["type"] . " §7at " . $act["at"] . "s";
                switch ($act["type"]) {
                    case "tip":
                    case "popup":
                        $info .= " §r" . $act["text"];
                        break;
                    case "blind":
                        $info .= " §7dur:" . (isset($act["duration"]) ? $act["duration"] : 3) . "s";
                        break;
                    case "grannytp":
                    case "grannywalk":
                        $info .= " §7pos:" . round($act["x"], 1) . "," . round($act["y"], 1) . "," . round($act["z"], 1);
                        break;
                    case "sound":
                        $info .= " §7id:" . $act["sound_id"];
                        break;
                }
                $player->sendMessage($info);
            }
        }
    }

    private function handleSetTemplate(Player $player) {
        $worldName = $player->getLevel()->getFolderName();
        $this->plugin->getWorldManager()->setTemplate($worldName);
        $player->sendMessage("§aTemplate world set to §e" . $worldName);
        $player->sendMessage("§7This world will be copied for each game round.");
    }

    private function handleSetPos(Player $player, $configKey, $label) {
        $config = $this->plugin->getConfig();
        $all = $config->getAll();
        $all[$configKey] = [
            "x" => round($player->x, 2),
            "y" => round($player->y, 2),
            "z" => round($player->z, 2),
            "world" => $player->getLevel()->getName()
        ];
        $config->setAll($all);
        $config->save();
        $player->sendMessage("§a" . $label . " set at your position.");
    }

    private function handleAddItemSpawn(Player $player) {
        $config = $this->plugin->getConfig();
        $all = $config->getAll();
        if (!isset($all["item_spawns"]) || !is_array($all["item_spawns"])) {
            $all["item_spawns"] = [];
        }
        $all["item_spawns"][] = [
            "x" => round($player->x, 2),
            "y" => round($player->y, 2),
            "z" => round($player->z, 2)
        ];
        $config->setAll($all);
        $config->save();
        $player->sendMessage("§aItem spawn point added. Total: §e" . count($all["item_spawns"]));
    }

    private function handleSpawn(Player $player) {
        $skinData = $this->plugin->getGrannySkin();
        $skinId = $this->plugin->getGrannySkinId();
        if ($skinData === null) {
            $skinData = $player->getSkinData();
            $skinId = $player->getSkinId();
        }

        $nbt = new CompoundTag("", [
            "Pos" => new ListTag("Pos", [
                new DoubleTag("", $player->x),
                new DoubleTag("", $player->y),
                new DoubleTag("", $player->z)
            ]),
            "Motion" => new ListTag("Motion", [
                new DoubleTag("", 0),
                new DoubleTag("", 0),
                new DoubleTag("", 0)
            ]),
            "Rotation" => new ListTag("Rotation", [
                new FloatTag("", $player->yaw),
                new FloatTag("", $player->pitch)
            ]),
            "Skin" => new CompoundTag("Skin", [
                "Data" => new StringTag("Data", $skinData),
                "Name" => new StringTag("Name", $skinId)
            ]),
            "Health" => new ShortTag("Health", 200)
        ]);

        $chunk = $player->getLevel()->getChunk(((int)$player->x) >> 4, ((int)$player->z) >> 4, true);
        $granny = Entity::createEntity("GrannyEntity", $chunk, $nbt);

        if ($granny !== null) {
            $granny->spawnToAll();
            $player->sendMessage("§aGranny spawned at your position.");
        } else {
            $player->sendMessage("§cFailed to spawn Granny.");
        }
    }

    private function handleDebug(Player $player) {
        $state = $this->plugin->toggleDebug($player->getName());
        $nm = $this->plugin->getNodeManager();
        if ($state) {
            $player->sendMessage("§aDebug mode §eENABLED§a. Particles will show continuously.");
            $nm->startDebugTask();
        } else {
            $player->sendMessage("§cDebug mode §eDISABLED§c.");
            if (!$nm->hasDebugPlayers()) {
                $nm->stopDebugTask();
            }
        }
    }

    private function handleForceStart(Player $player) {
        $queue = $this->plugin->getLobbyManager()->getQueue();
        if (empty($queue)) {
            $player->sendMessage("§cNo players in queue.");
            return;
        }
        $this->plugin->getLobbyManager()->cancelCountdown();
        $this->plugin->getGameManager()->startGame($queue);
        $player->sendMessage("§aGame force-started.");
    }

    private function handleForceEnd(Player $player) {
        $gm = $this->plugin->getGameManager();
        if ($gm->getPhase() !== \Granny\game\GameManager::PHASE_INGAME) {
            $player->sendMessage("§cNo game in progress.");
            return;
        }
        $gm->endGame(false);
        $player->sendMessage("§aGame force-ended.");
    }
}