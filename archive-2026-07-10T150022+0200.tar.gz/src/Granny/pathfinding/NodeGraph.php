<?php

namespace Granny\pathfinding;

use pocketmine\math\Vector3;

class NodeGraph {

    private $nodes = [];

    public function addNode(Node $node) {
        $this->nodes[$node->getName()] = $node;
    }

    public function removeNode($name) {
        if(isset($this->nodes[$name])) {
            foreach($this->nodes as $node) {
                $node->removeLink($name);
            }
            unset($this->nodes[$name]);
            return true;
        }
        return false;
    }

    public function getNode($name) {
        return isset($this->nodes[$name]) ? $this->nodes[$name] : null;
    }

    public function getNodes() {
        return $this->nodes;
    }

    public function linkNodes($name1, $name2) {
        if(!isset($this->nodes[$name1]) || !isset($this->nodes[$name2])) {
            return false;
        }
        $this->nodes[$name1]->addLink($name2);
        $this->nodes[$name2]->addLink($name1);
        return true;
    }

    public function unlinkNodes($name1, $name2) {
        if(!isset($this->nodes[$name1]) || !isset($this->nodes[$name2])) {
            return false;
        }
        $this->nodes[$name1]->removeLink($name2);
        $this->nodes[$name2]->removeLink($name1);
        return true;
    }

    public function getClosestNode(Vector3 $pos, $patrolOnly = false) {
        $closest = null;
        $closestDist = PHP_INT_MAX;
        foreach($this->nodes as $node) {
            if ($patrolOnly && !$node->isPatrol()) {
                continue;
            }
            $dist = $node->distanceTo($pos);
            if($dist < $closestDist) {
                $closestDist = $dist;
                $closest = $node;
            }
        }
        return $closest;
    }

    public function getPatrolNodes() {
        $patrol = [];
        foreach($this->nodes as $node) {
            if($node->isPatrol()) {
                $patrol[] = $node;
            }
        }
        return $patrol;
    }

    public function toArray() {
        $data = [];
        foreach($this->nodes as $name => $node) {
            $data[$name] = $node->toArray();
        }
        return $data;
    }

    public function loadFromArray(array $data) {
        $this->nodes = [];
        foreach($data as $name => $nodeData) {
            $this->nodes[$name] = Node::fromArray($name, $nodeData);
        }
    }
}
