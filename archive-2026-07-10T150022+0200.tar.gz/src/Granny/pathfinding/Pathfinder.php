<?php

namespace Granny\pathfinding;

use pocketmine\math\Vector3;

class Pathfinder {

    private $graph;

    public function __construct(NodeGraph $graph) {
        $this->graph = $graph;
    }

    public function findPath(Vector3 $from, Vector3 $to, $patrolOnly = false) {
        $startNode = $this->graph->getClosestNode($from, $patrolOnly);
        $endNode = $this->graph->getClosestNode($to, $patrolOnly);

        if($startNode === null || $endNode === null) {
            return [];
        }

        if($startNode->getName() === $endNode->getName()) {
            if ($from->distanceSquared($endNode->getPosition()) < 2.25) {
                return [];
            }
            return [$endNode->getPosition()];
        }

        $dist = [];
        $prev = [];
        $queue = [];
        $nodes = $this->graph->getNodes();

        foreach($nodes as $name => $node) {
            $dist[$name] = PHP_INT_MAX;
            $prev[$name] = null;
            $queue[$name] = true;
        }

        $dist[$startNode->getName()] = 0;

        while(!empty($queue)) {
            $u = null;
            $minDist = PHP_INT_MAX;
            foreach($queue as $name => $v) {
                if($dist[$name] < $minDist) {
                    $minDist = $dist[$name];
                    $u = $name;
                }
            }

            if($u === null) {
                break;
            }

            unset($queue[$u]);

            if($u === $endNode->getName()) {
                break;
            }

            $currentNode = $this->graph->getNode($u);
            if($currentNode === null) {
                continue;
            }

            foreach($currentNode->getLinks() as $linkName) {
                if(!isset($queue[$linkName])) {
                    continue;
                }
                $linkedNode = $this->graph->getNode($linkName);
                if($linkedNode === null) {
                    continue;
                }
                if ($patrolOnly && !$linkedNode->isPatrol()) {
                    continue;
                }
                $alt = $dist[$u] + $currentNode->distanceTo($linkedNode->getPosition());
                if($alt < $dist[$linkName]) {
                    $dist[$linkName] = $alt;
                    $prev[$linkName] = $u;
                }
            }
        }

        $path = [];
        $current = $endNode->getName();
        while($current !== null) {
            $node = $this->graph->getNode($current);
            if($node !== null) {
                array_unshift($path, $node->getPosition());
            }
            $current = $prev[$current];
        }

        if(empty($path) || !$path[0]->equals($startNode->getPosition())) {
            return [];
        }

        if(count($path) > 1) {
            array_shift($path);
        }

        return $path;
    }
}
