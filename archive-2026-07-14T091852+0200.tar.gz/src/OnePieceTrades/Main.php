<?php

namespace OnePieceTrades;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\entity\Entity;
use pocketmine\scheduler\Task;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\network\protocol\RemoveEntityPacket;
use pocketmine\network\protocol\SetEntityLinkPacket;
use pocketmine\network\protocol\Info as ProtocolInfo;
use OnePieceTrades\Factory\FactoryManager;
use OnePieceTrades\Factory\FactoryEntity;
use OnePieceTrades\Factory\FactoryListener;
use OnePieceTrades\Factory\FactoryCommand;

class Main extends PluginBase implements Listener {

    private $tradeManager;
    private $factoryManager;
    private $pendingSet = [];
    private $seated = [];
    private $seatEntities = [];
    private $tradeSessions = [];
    private $tradeConfirm = [];
    private $tradeItems = [];
    public $suppressReopen = [];
    private $occupiedStations = [];
    private $entityCount = 100000;
    private $prefix = "§e[Trade] §r";

    public function onEnable() {
        @mkdir($this->getDataFolder());
        $this->tradeManager   = new TradeManager($this);
        $this->factoryManager = new FactoryManager($this);
        Entity::registerEntity(FactoryEntity::class, true);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        new FactoryListener($this);
        $this->getServer()->getCommandMap()->register("onepiece", new FactoryCommand($this));
        $this->factoryManager->startSchedulers();
        $this->getLogger()->info("OnePieceTrades enabled [Smart Mode]");
    }

    public function onDisable() {
        foreach ($this->seated as $name => $data) {
            $player = $this->getServer()->getPlayerExact($name);
            if ($player !== null && $player->isOnline()) {
                $this->unseatPlayer($player);
            }
        }
        $this->tradeManager->saveAll();
    }

    public function getTradeManager() { return $this->tradeManager; }
    public function getFactoryManager() { return $this->factoryManager; }
    public function getPrefix() { return $this->prefix; }
    public function tradeDebug($msg) { $this->getLogger()->info("[TRADE-DEBUG] " . $msg); }
    public function getSeated() { return $this->seated; }
    public function getTradeSessions() { return $this->tradeSessions; }
    public function getTradeConfirm() { return $this->tradeConfirm; }
    public function getTradeItems() { return $this->tradeItems; }

    public function isSuppressReopen(Player $player) {
        return isset($this->suppressReopen[strtolower($player->getName())]);
    }

    private function setSuppressReopen(Player $player) {
        $name = strtolower($player->getName());
        $this->suppressReopen[$name] = true;
        $plugin = $this;
        $this->scheduleTask(function() use ($plugin, $name) {
            unset($plugin->suppressReopen[$name]);
        }, 10);
    }

    public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
        $cmd = strtolower($command->getName());
        if ($cmd !== "lptrade" && $cmd !== "optrade") return false;

        if (!($sender instanceof Player)) {
            $sender->sendMessage($this->prefix . "Use this in-game.");
            return true;
        }

        $name = strtolower($sender->getName());

        // --- PLAYER TRADING COMMANDS (/lptrade) ---
        if ($cmd === "lptrade") {
            if (count($args) === 0) {
                if (isset($this->tradeSessions[$name])) {
                    $sender->sendMessage("§6--- Trade Commands ---");
                    $sender->sendMessage("§f/lptrade storage §7- View your fruit storage slots");
                    $sender->sendMessage("§f/lptrade add <storage_slot> §7- Add fruit to trade");
                    $sender->sendMessage("§f/lptrade remove <trade_slot> §7- Remove fruit from trade");
                    $sender->sendMessage("§f/lptrade status §7- View trade items");
                    $sender->sendMessage("§f/lptrade confirm §7- Confirm trade");
                    $sender->sendMessage("§f/lptrade cancel §7- Cancel trade");
                } else {
                    $sender->sendMessage($this->prefix . "§cYou are not in a trade. Sit on a trade station to start.");
                }
                return true;
            }

            $sub = strtolower($args[0]);
            switch ($sub) {
                case "storage":
                    $this->showStorageChat($sender);
                    break;
                case "add":
                    if (!isset($this->tradeSessions[$name])) {
                        $sender->sendMessage($this->prefix . "§cYou are not in a trade.");
                        return true;
                    }
                    if (!isset($args[1])) {
                        $sender->sendMessage($this->prefix . "§cUsage: /lptrade add <storage_slot>");
                        return true;
                    }
                    $this->handleTradeAdd($sender, (int)$args[1] - 1);
                    break;
                case "remove":
                    if (!isset($this->tradeSessions[$name])) {
                        $sender->sendMessage($this->prefix . "§cYou are not in a trade.");
                        return true;
                    }
                    if (!isset($args[1])) {
                        $sender->sendMessage($this->prefix . "§cUsage: /lptrade remove <trade_slot>");
                        return true;
                    }
                    $this->handleTradeRemove($sender, (int)$args[1]);
                    break;
                case "status":
                    if (!isset($this->tradeSessions[$name])) {
                        $sender->sendMessage($this->prefix . "§cYou are not in a trade.");
                        return true;
                    }
                    $this->showTradeStatus($sender);
                    break;
                case "confirm":
                    if (!isset($this->tradeSessions[$name])) {
                        $sender->sendMessage($this->prefix . "§cYou are not in a trade.");
                        return true;
                    }
                    $this->handleTradeConfirm($sender);
                    break;
                case "cancel":
                    if (!isset($this->tradeSessions[$name])) {
                        $sender->sendMessage($this->prefix . "§cYou are not in a trade.");
                        return true;
                    }
                    $this->cancelTradeByPlayer($sender);
                    break;
                default:
                    $sender->sendMessage($this->prefix . "§cUnknown subcommand for /lptrade.");
                    break;
            }
            return true;
        }

        // --- ADMIN COMMANDS (/optrade) ---
        if ($cmd === "optrade") {
            if (!$sender->isOp()) {
                $sender->sendMessage($this->prefix . "§cYou do not have permission to use admin commands.");
                return true;
            }

            if (count($args) === 0) {
                $sender->sendMessage($this->prefix . "§6--- Admin Trade Management ---");
                $sender->sendMessage("§f/optrade create <name> §7- Create a new station");
                $sender->sendMessage("§f/optrade set <1|2> §7- Set seat for last created station");
                $sender->sendMessage("§f/optrade delete <name> §7- Delete a station");
                $sender->sendMessage("§f/optrade list §7- List all stations");
                return true;
            }

            $sub = strtolower($args[0]);
            switch ($sub) {
                case "create":
                    if (!isset($args[1])) {
                        $sender->sendMessage($this->prefix . "§cUsage: /optrade create <name>");
                        return true;
                    }
                    $stName = implode(" ", array_slice($args, 1));
                    $this->tradeManager->createStation($stName);
                    $sender->sendMessage($this->prefix . "§aStation §e" . $stName . " §acreated.");
                    break;
                case "set":
                    if (!isset($args[1])) {
                        $sender->sendMessage($this->prefix . "§cUsage: /optrade set <1|2>");
                        return true;
                    }
                    $seatNum = (int)$args[1];
                    $st = $this->tradeManager->getLastCreatedBy($sender->getName());
                    if ($st === null) {
                        $sender->sendMessage($this->prefix . "§cNo stations found.");
                        return true;
                    }
                    $this->pendingSet[$name] = ["station" => $st, "seat" => $seatNum];
                    $sender->sendMessage($this->prefix . "§aTap stairs to set seat " . $seatNum . " for §e" . $st);
                    break;
                case "list":
                    $stations = $this->tradeManager->getAllStations();
                    $sender->sendMessage("§6--- Registered Trade Stations ---");
                    foreach($stations as $s) $sender->sendMessage("§e- " . $s["name"]);
                    break;
                case "delete":
                    if (!isset($args[1])) {
                        $sender->sendMessage($this->prefix . "§cUsage: /optrade delete <name>");
                        return true;
                    }
                    $this->tradeManager->deleteStation($args[1]);
                    $sender->sendMessage($this->prefix . "§aStation deleted.");
                    break;
                default:
                    $sender->sendMessage($this->prefix . "§cUnknown subcommand for /optrade.");
                    break;
            }
            return true;
        }

        return true;
    }

    public function onInteract(PlayerInteractEvent $event) {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $name = strtolower($player->getName());

        if (isset($this->pendingSet[$name])) {
            $event->setCancelled(true);
            if ($this->isStairsBlock($block->getId())) {
                $pending = $this->pendingSet[$name];
                $pos = ["x" => $block->getFloorX(), "y" => $block->getFloorY(), "z" => $block->getFloorZ(), "level" => $block->getLevel()->getFolderName()];
                $this->tradeManager->setSeat($pending["station"], $pending["seat"], $pos);
                $player->sendMessage($this->prefix . "§aSeat set.");
                unset($this->pendingSet[$name]);
            }
            return;
        }

        if ($this->isStairsBlock($block->getId())) {
            $station = $this->tradeManager->getStationBySeat($block->getFloorX(), $block->getFloorY(), $block->getFloorZ(), $block->getLevel()->getFolderName());
            if ($station !== null) {
                $event->setCancelled(true);
                if (!isset($this->seated[$name])) {
                    if (isset($this->occupiedStations[$station["name"]])) {
                        $player->sendMessage($this->prefix . "§cStation in use.");
                        return;
                    }
                    $this->seatPlayer($player, $station["name"], $station["seat"], $block);
                }
            }
        }
    }

    public function isStairsBlock($id) {
        return in_array($id, [53, 67, 108, 109, 114, 128, 134, 135, 136, 156, 163, 164, 180]);
    }

    public function seatPlayer(Player $player, $stationName, $seatNum, Block $block) {
        $name = strtolower($player->getName());
        $this->entityCount++;
        $eid = $this->entityCount;

        $seatX = $block->getFloorX() + 0.5;
        $seatY = $block->getFloorY() + 0.3;
        $seatZ = $block->getFloorZ() + 0.5;

        // Create the dummy seat entity
        $pk = new AddEntityPacket();
        $pk->eid = $eid;
        $pk->type = 84; // Falling Block or similar dummy
        $pk->x = $seatX;
        $pk->y = $seatY;
        $pk->z = $seatZ;
        // Flags: 3 = RIDING, 38 = INVISIBLE
        $pk->metadata = [
            0 => [Entity::DATA_TYPE_LONG, (1 << 3) | (1 << 38)], 
            2 => [Entity::DATA_TYPE_STRING, ""],
            15 => [Entity::DATA_TYPE_BYTE, 1]
        ];
        Server::getInstance()->broadcastPacket(Server::getInstance()->getOnlinePlayers(), $pk);
        
        // Packet for the SEATED PLAYER (must use ID 0 to sit themselves)
        $pkSelf = new SetEntityLinkPacket();
        $pkSelf->from = $eid;
        $pkSelf->to = 0; // 0 = "Myself" in Bedrock protocol
        $pkSelf->type = 2; // RIDER
        $player->dataPacket($pkSelf);

        // Packet for OTHERS (must use player's actual ID)
        $pkOthers = new SetEntityLinkPacket();
        $pkOthers->from = $eid;
        $pkOthers->to = $player->getId();
        $pkOthers->type = 2;
        
        // Broadcast to everyone EXCEPT the player themselves
        $others = [];
        foreach(Server::getInstance()->getOnlinePlayers() as $p) {
            if($p->getId() !== $player->getId()) $others[] = $p;
        }
        Server::getInstance()->broadcastPacket($others, $pkOthers);

        $this->seated[$name] = [
            "station" => $stationName, 
            "seat" => $seatNum, 
            "sit_time" => microtime(true), 
            "pos" => ["x" => $player->getX(), "y" => $player->getY(), "z" => $player->getZ()], 
            "level" => $player->getLevel()->getFolderName()
        ];
        $this->seatEntities[$name] = $eid;

        $player->sendMessage($this->prefix . "§aSat down.");
        $player->sendMessage($this->prefix . "§7Use §e/lptrade cancel §7to stand up and cancel trade.");
        
        $other = $this->getSeatOccupant($stationName, $seatNum === 1 ? 2 : 1);
        if ($other !== null) {
            $otherP = $this->getServer()->getPlayerExact($other);
            if ($otherP !== null) $this->startTrade($player, $otherP, $stationName);
        }
    }

    public function unseatPlayer(Player $player) {
        $name = strtolower($player->getName());
        if (!isset($this->seated[$name])) return;
        $this->setSuppressReopen($player);
        if (isset($this->seatEntities[$name])) {
            $eid = $this->seatEntities[$name];
            $pkc = new SetEntityLinkPacket();
            $pkc->from = $eid; $pkc->to = $player->getId(); $pkc->type = 0;
            Server::getInstance()->broadcastPacket(Server::getInstance()->getOnlinePlayers(), $pkc);
            $rpk = new RemoveEntityPacket(); $rpk->eid = $eid;
            Server::getInstance()->broadcastPacket(Server::getInstance()->getOnlinePlayers(), $rpk);
            unset($this->seatEntities[$name]);
        }
        $data = $this->seated[$name];
        $player->teleport(new Vector3($data["pos"]["x"], $data["pos"]["y"] + 1, $data["pos"]["z"]));
        unset($this->seated[$name]);
        $this->cancelTradeByPlayer($player);
    }

    public function onPlayerMove(PlayerMoveEvent $event) {
        $name = strtolower($event->getPlayer()->getName());
        if (isset($this->seated[$name])) {
            if (microtime(true) - $this->seated[$name]["sit_time"] > 1.5) {
                $f = $event->getFrom(); $t = $event->getTo();
                if (($t->x-$f->x)**2 + ($t->z-$f->z)**2 > 0.0025) $this->unseatPlayer($event->getPlayer());
            }
        }
    }

    public function getSeatOccupant($station, $num) {
        foreach($this->seated as $n => $d) if($d["station"] === $station && $d["seat"] === $num) return $n;
        return null;
    }

    public function startTrade(Player $p1, Player $p2, $station) {
        $n1 = strtolower($p1->getName()); $n2 = strtolower($p2->getName());
        $this->tradeSessions[$n1] = ["partner" => $n2, "station" => $station];
        $this->tradeSessions[$n2] = ["partner" => $n1, "station" => $station];
        $this->tradeConfirm[$n1] = false; $this->tradeConfirm[$n2] = false;
        $this->tradeItems[$n1] = []; $this->tradeItems[$n2] = [];
        $this->occupiedStations[$station] = true;
        foreach([$p1, $p2] as $p) {
            $p->sendMessage($this->prefix . "§aTrade started!");
            $p->sendMessage($this->prefix . "§fUse §e/lptrade storage §fand §e/lptrade add <slot>");
        }
    }

    public function getFruitDisplayName($id) {
        $dp = $this->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($dp !== null) {
            $f = $dp->getFruitManager()->getFruit($id);
            if ($f) return $f->getRarityColor() . $f->getDisplayName() . " §r";
        }
        return $id;
    }

    public function handleTradeAdd(Player $player, int $slot) {
        $name = strtolower($player->getName());
        $bp = $this->getServer()->getPluginManager()->getPlugin("OnePieceBerry");
        $storage = $bp->getFruitStorage()->getStorage($name);
        if (!isset($storage[$slot])) { $player->sendMessage("§cInvalid slot."); return; }
        foreach($this->tradeItems[$name] as $item) if($item["slot"] === $slot) { $player->sendMessage("§cAlready added."); return; }
        if (count($this->tradeItems[$name]) >= 4) { $player->sendMessage("§cMax 4 fruits."); return; }
        $fruitId = $storage[$slot];
        $this->tradeItems[$name][] = ["slot" => $slot, "fruit_id" => $fruitId];
        $this->tradeConfirm[$name] = false; $this->tradeConfirm[$this->tradeSessions[$name]["partner"]] = false;
        
        $dispName = $this->getFruitDisplayName($fruitId);
        $player->sendMessage("§aAdded: " . $dispName);
        $partnerName = $this->tradeSessions[$name]["partner"];
        $partner = $this->getServer()->getPlayerExact($partnerName);
        if ($partner !== null) {
            $partner->sendMessage("§e" . $player->getName() . " added: " . $dispName);
            $partner->sendMessage("§7(Use §e/lptrade status §7- to check the Trade status.)");
        }
    }

    public function handleTradeRemove(Player $player, int $tSlot) {
        $name = strtolower($player->getName());
        if (!isset($this->tradeItems[$name][$tSlot-1])) { $player->sendMessage("§cInvalid."); return; }
        array_splice($this->tradeItems[$name], $tSlot-1, 1);
        $this->tradeConfirm[$name] = false; $this->tradeConfirm[$this->tradeSessions[$name]["partner"]] = false;
        $player->sendMessage("§eRemoved.");
        $partnerName = $this->tradeSessions[$name]["partner"];
        $partner = $this->getServer()->getPlayerExact($partnerName);
        if ($partner !== null) {
            $partner->sendMessage("§e" . $player->getName() . " removed a fruit from the trade.");
            $partner->sendMessage("§7(Use §e/lptrade status §7- to check the Trade status.)");
        }
    }

    public function showTradeStatus(Player $player) {
        $name = strtolower($player->getName()); $pn = $this->tradeSessions[$name]["partner"];
        $player->sendMessage("§6--- Trade Status ---");
        $player->sendMessage("§eYou:");
        foreach($this->tradeItems[$name] as $i => $d) $player->sendMessage(" " . ($i+1) . ". " . $this->getFruitDisplayName($d["fruit_id"]));
        $player->sendMessage("§ePartner:");
        foreach($this->tradeItems[$pn] as $i => $d) $player->sendMessage(" " . ($i+1) . ". " . $this->getFruitDisplayName($d["fruit_id"]));
    }

    public function showStorageChat(Player $player) {
        $bp = $this->getServer()->getPluginManager()->getPlugin("OnePieceBerry");
        $st = $bp->getFruitStorage()->getStorage(strtolower($player->getName()));
        $player->sendMessage("§6--- Storage ---");
        foreach($st as $i => $id) {
            $player->sendMessage(" §f[" . ($i+1) . "] §e" . $this->getFruitDisplayName($id));
        }
    }

    public function handleTradeConfirm(Player $player) {
        $name = strtolower($player->getName());
        $this->tradeConfirm[$name] = true;
        $pn = $this->tradeSessions[$name]["partner"];
        $player->sendMessage("§aConfirmed.");
        $partner = $this->getServer()->getPlayerExact($pn);
        if ($partner) {
            $partner->sendMessage("§e" . $player->getName() . " confirmed the trade.");
        }
        if ($this->tradeConfirm[$pn] ?? false) $this->executeTrade($player, $partner);
    }

    public function executeTrade(Player $p1, Player $p2) {
        $n1 = strtolower($p1->getName()); $n2 = strtolower($p2->getName());
        $bp = $this->getServer()->getPluginManager()->getPlugin("OnePieceBerry");
        $fs = $bp->getFruitStorage();
        $s1 = $fs->getStorage($n1); $s2 = $fs->getStorage($n2);
        
        foreach($this->tradeItems[$n1] as $ti) if(!isset($s1[$ti["slot"]]) || $s1[$ti["slot"]] !== $ti["fruit_id"]) { $this->cancelTradeByPlayer($p1); return; }
        foreach($this->tradeItems[$n2] as $ti) if(!isset($s2[$ti["slot"]]) || $s2[$ti["slot"]] !== $ti["fruit_id"]) { $this->cancelTradeByPlayer($p1); return; }

        $f1 = []; foreach($this->tradeItems[$n1] as $ti) $f1[] = $ti["fruit_id"];
        $f2 = []; foreach($this->tradeItems[$n2] as $ti) $f2[] = $ti["fruit_id"];

        $v1 = []; foreach($this->tradeItems[$n1] as $ti) $v1[] = $ti["slot"]; rsort($v1);
        $v2 = []; foreach($this->tradeItems[$n2] as $ti) $v2[] = $ti["slot"]; rsort($v2);

        // Partner Space Checks with actual names
        if (!$fs->hasSpace($n2) && count($f1) > 0) {
             $p2->sendMessage($this->prefix . "§cYour storage is full! Trade failed.");
             $p1->sendMessage($this->prefix . "§c" . $p2->getName() . "'s storage is full! Trade failed.");
             $this->cleanupTrade($p1, $p2);
             return;
        }
        if (!$fs->hasSpace($n1) && count($f2) > 0) {
             $p1->sendMessage($this->prefix . "§cYour storage is full! Trade failed.");
             $p2->sendMessage($this->prefix . "§c" . $p1->getName() . "'s storage is full! Trade failed.");
             $this->cleanupTrade($p1, $p2);
             return;
        }

        foreach($v1 as $slot) $fs->removeFruit($n1, $slot);
        foreach($v2 as $slot) $fs->removeFruit($n2, $slot);
        
        $this->deliver($p2, $f1); $this->deliver($p1, $f2);
        $p1->sendMessage("§aTrade success!"); $p2->sendMessage("§aTrade success!");
        $this->cleanupTrade($p1, $p2);
    }

    private function deliver(Player $r, array $ids) {
        $bp = $this->getServer()->getPluginManager()->getPlugin("OnePieceBerry");
        foreach($ids as $id) {
            if($bp->getFruitStorage()->hasSpace($r->getName())) {
                $bp->getFruitStorage()->addFruit($r->getName(), $id);
                $r->sendMessage("§aReceived " . $this->getFruitDisplayName($id) . " §ain storage.");
            } else {
                $item = Item::get(Item::GOLDEN_APPLE, 0, 1);
                $item->setCustomName($this->getFruitDisplayName($id));
                $r->getInventory()->addItem($item);
                $r->sendMessage("§aReceived " . $this->getFruitDisplayName($id) . " §ain inventory.");
            }
        }
    }

    public function cleanupTrade(Player $p1, Player $p2) {
        $n1 = strtolower($p1->getName()); $n2 = strtolower($p2->getName());
        if(isset($this->tradeSessions[$n1])) unset($this->occupiedStations[$this->tradeSessions[$n1]["station"]]);
        unset($this->tradeSessions[$n1], $this->tradeSessions[$n2], $this->tradeConfirm[$n1], $this->tradeConfirm[$n2], $this->tradeItems[$n1], $this->tradeItems[$n2]);
    }

    public function cancelTradeByPlayer(Player $player) {
        $name = strtolower($player->getName());
        if(!isset($this->tradeSessions[$name])) return;
        $pn = $this->tradeSessions[$name]["partner"];
        $partner = $this->getServer()->getPlayerExact($pn);
        if($partner) $partner->sendMessage("§c" . $player->getName() . " cancelled the trade.");
        $player->sendMessage("§cTrade cancelled.");
        $this->cleanupTrade($player, $partner ?? $player);
    }

    public function onPlayerQuit(PlayerQuitEvent $e) { $this->cancelTradeByPlayer($e->getPlayer()); }
    public function onDamage(EntityDamageEvent $e) { if($e->getEntity() instanceof Player && (isset($this->seated[strtolower($e->getEntity()->getName())]) || isset($this->tradeSessions[strtolower($e->getEntity()->getName())]))) $e->setCancelled(); }
    public function scheduleTask(callable $c, int $d) { Server::getInstance()->getScheduler()->scheduleDelayedTask(new class($c) extends Task { private $c; public function __construct($c){$this->c=$c;} public function onRun($t){($this->c)();} }, $d); }
}