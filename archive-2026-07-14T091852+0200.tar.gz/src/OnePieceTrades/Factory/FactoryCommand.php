<?php

namespace OnePieceTrades\Factory;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use OnePieceTrades\Main;

class FactoryCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct(
            "factory",
            "Manage Devil Fruit Factories",
            "/factory <create|setpos|time|duration|start|stop|remove|list|info>",
            []
        );
        $this->plugin = $plugin;
        $this->setPermission("op");
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if (!$sender->isOp()) {
            $sender->sendMessage("§cNo permission.");
            return true;
        }

        $fm = $this->plugin->getFactoryManager();

        if (empty($args)) {
            $this->sendHelp($sender);
            return true;
        }

        $sub = strtolower(array_shift($args));

        switch ($sub) {

            case "create":
                if (empty($args)) { $sender->sendMessage("§cUsage: /factory create <name>"); return true; }
                $name = implode(" ", $args);
                if ($fm->createFactory($name)) {
                    $sender->sendMessage("§aFactory §f" . $name . " §acreated. Now use §f/factory setpos " . $name . " §ato place it.");
                } else {
                    $sender->sendMessage("§cFactory §f" . $name . " §calready exists.");
                }
                break;

            case "setpos":
                if (!($sender instanceof Player)) { $sender->sendMessage("§cIn-game only."); return true; }
                if (empty($args)) { $sender->sendMessage("§cUsage: /factory setpos <name>"); return true; }
                $name = implode(" ", $args);
                if (!$fm->factoryExists($name)) { $sender->sendMessage("§cFactory not found."); return true; }
                $pos   = $sender->getPosition();
                $level = $pos->getLevel()->getFolderName();
                $fm->setPos($name, (int)$pos->x, (int)$pos->y, (int)$pos->z, $level);
                $sender->sendMessage("§aPosition set for §f" . $name . " §aat §f" . (int)$pos->x . "/" . (int)$pos->y . "/" . (int)$pos->z . " §ain world §f" . $level . "§a.");
                break;

            case "time":
                if (count($args) < 2) { $sender->sendMessage("§cUsage: /factory time <name> <seconds>"); return true; }
                $seconds = (int)array_pop($args);
                $name    = implode(" ", $args);
                if (!$fm->factoryExists($name)) { $sender->sendMessage("§cFactory not found."); return true; }
                if ($seconds < 10) { $sender->sendMessage("§cMinimum is 10 seconds."); return true; }
                $fm->setStartTime($name, $seconds);
                $sender->sendMessage("§aFactory §f" . $name . " §awill spawn every §f" . $fm->formatTime($seconds) . "§a.");
                break;

            case "duration":
                if (count($args) < 2) { $sender->sendMessage("§cUsage: /factory duration <name> <seconds>"); return true; }
                $seconds = (int)array_pop($args);
                $name    = implode(" ", $args);
                if (!$fm->factoryExists($name)) { $sender->sendMessage("§cFactory not found."); return true; }
                if ($seconds < 30) { $sender->sendMessage("§cMinimum is 30 seconds."); return true; }
                $fm->setDuration($name, $seconds);
                $sender->sendMessage("§aFactory §f" . $name . " §awill expire after §f" . $fm->formatTime($seconds) . " §aif not destroyed.");
                break;

            case "start":
                if (empty($args)) { $sender->sendMessage("§cUsage: /factory start <name>"); return true; }
                $name = implode(" ", $args);
                $key  = strtolower($name);
                if (!$fm->factoryExists($name)) { $sender->sendMessage("§cFactory not found."); return true; }
                if ($fm->isActive($key)) { $sender->sendMessage("§cFactory §f" . $name . " §cis already active!"); return true; }
                if ($fm->startFactory($key)) {
                    $sender->sendMessage("§aFactory §f" . $name . " §astarted manually!");
                } else {
                    $sender->sendMessage("§cFailed — make sure position is set.");
                }
                break;

            case "stop":
                if (empty($args)) { $sender->sendMessage("§cUsage: /factory stop <name>"); return true; }
                $name = implode(" ", $args);
                $key  = strtolower($name);
                if (!$fm->isActive($key)) { $sender->sendMessage("§cFactory §f" . $name . " §cis not active."); return true; }
                $fm->despawnEntity($key);
                $ref = new \ReflectionProperty($fm, 'active');
                $ref->setAccessible(true);
                $all = $ref->getValue($fm);
                unset($all[$key]);
                $ref->setValue($fm, $all);
                $sender->sendMessage("§aFactory §f" . $name . " §astopped.");
                break;

            case "remove":
            case "delete":
                if (empty($args)) { $sender->sendMessage("§cUsage: /factory remove <name>"); return true; }
                $name = implode(" ", $args);
                if ($fm->deleteFactory($name)) {
                    $sender->sendMessage("§aFactory §f" . $name . " §adeleted.");
                } else {
                    $sender->sendMessage("§cFactory not found.");
                }
                break;

            case "list":
                $factories = $fm->getAllFactories();
                if (empty($factories)) { $sender->sendMessage("§cNo factories configured."); return true; }
                $sender->sendMessage("§6§l[FACTORIES]");
                foreach ($factories as $key => $data) {
                    $posStr  = $data["pos"] !== null ? $data["pos"]["x"] . "/" . $data["pos"]["y"] . "/" . $data["pos"]["z"] . " (" . $data["level"] . ")" : "§cNot set";
                    $status  = $fm->isActive($key) ? "§aACTIVE" : "§7Idle";
                    $sender->sendMessage("§e" . $data["name"] . " §8| " . $status . " §8| " . $fm->formatTime($data["start_time"]) . " interval §8| " . $fm->formatTime($data["duration"]) . " duration §8| §7" . $posStr);
                }
                break;

            case "info":
                if (empty($args)) { $sender->sendMessage("§cUsage: /factory info <name>"); return true; }
                $name = implode(" ", $args);
                $key  = strtolower($name);
                $data = $fm->getFactory($name);
                if ($data === null) { $sender->sendMessage("§cFactory not found."); return true; }
                $posStr = $data["pos"] !== null ? $data["pos"]["x"] . "/" . $data["pos"]["y"] . "/" . $data["pos"]["z"] . " (" . $data["level"] . ")" : "§cNot set";
                $sender->sendMessage("§6§l[" . $data["name"] . "]");
                $sender->sendMessage("§7Position: §f" . $posStr);
                $sender->sendMessage("§7Spawn interval: §f" . $fm->formatTime($data["start_time"]));
                $sender->sendMessage("§7Duration: §f" . $fm->formatTime($data["duration"]));
                if ($fm->isActive($key)) {
                    $active       = $fm->getActiveData($key);
                    $fruitDisplay = $fm->getFruitDisplay($active["fruit_id"]);
                    $fruitColor   = $fm->getFruitColor($active["fruit_id"]);
                    $rarity       = $fm->getFruitRarity($active["fruit_id"]);
                    $bar          = $fm->getHpBar($active["hp"], $active["max_hp"]);
                    $sender->sendMessage("§aStatus: ACTIVE");
                    $sender->sendMessage("§7HP: " . $bar . " §f" . number_format((int)$active["hp"]) . "§7/§f" . number_format($active["max_hp"]));
                    $sender->sendMessage("§7Prize: " . $fruitColor . $fruitDisplay . " §8[" . strtoupper($rarity) . "]");
                    $log = $active["damage_log"];
                    if (!empty($log)) {
                        arsort($log);
                        $sender->sendMessage("§7Damage leaderboard:");
                        $rank = 1;
                        foreach ($log as $pName => $dmg) {
                            $sender->sendMessage("§7  #" . $rank . " §f" . $pName . " §7— " . number_format((int)$dmg));
                            if (++$rank > 5) break;
                        }
                    } else {
                        $sender->sendMessage("§7No damage dealt yet.");
                    }
                } else {
                    $sender->sendMessage("§7Status: Idle");
                }
                break;

            default:
                $this->sendHelp($sender);
        }

        return true;
    }

    private function sendHelp(CommandSender $sender) {
        $sender->sendMessage("§6§l[FACTORY COMMANDS]");
        $sender->sendMessage("§f/factory create <name>          §7Create a new factory");
        $sender->sendMessage("§f/factory setpos <name>          §7Set spawn position to your feet");
        $sender->sendMessage("§f/factory time <name> <sec>      §7Seconds between each spawn");
        $sender->sendMessage("§f/factory duration <name> <sec>  §7How long before it expires");
        $sender->sendMessage("§f/factory start <name>           §7Manually spawn the factory now");
        $sender->sendMessage("§f/factory stop <name>            §7Force-stop an active factory");
        $sender->sendMessage("§f/factory remove <name>          §7Delete a factory permanently");
        $sender->sendMessage("§f/factory list                   §7Show all factories");
        $sender->sendMessage("§f/factory info <name>            §7Live HP and damage log");
    }
}
