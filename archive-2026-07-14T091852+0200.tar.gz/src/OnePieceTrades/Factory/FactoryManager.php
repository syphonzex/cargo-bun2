<?php

namespace OnePieceTrades\Factory;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\utils\Config;
use pocketmine\entity\Entity;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ShortTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\network\protocol\RemoveEntityPacket;
use OnePieceTrades\Main;
use OnePieceTrades\Factory\FactoryStartTask;
use OnePieceTrades\Factory\FactoryExpireTask;

class FactoryManager {

    private $plugin;
    private $config;
    private $factories = [];
    private $active    = [];
    private $resolving = [];

    const RARITY_WEIGHTS = [
        "common"    => 5500,
        "rare"      => 2000,
        "legendary" => 100,
        "mythical"  => 10,
        "god"  => 1,
    ];

    const FACTORY_MAX_HP = 1000;

    public function __construct(Main $plugin) {
        $this->plugin    = $plugin;
        $this->config    = new Config($plugin->getDataFolder() . "factories.yml", Config::YAML);
        $this->factories = $this->config->getAll();
    }

    public function saveAll() {
        $this->config->setAll($this->factories);
        $this->config->save();
    }

    public function createFactory($name) {
        $key = strtolower($name);
        if (isset($this->factories[$key])) return false;
        $this->factories[$key] = [
            "name"       => $name,
            "pos"        => null,
            "level"      => null,
            "start_time" => 3600,
            "duration"   => 300,
        ];
        $this->saveAll();
        return true;
    }

    public function factoryExists($name) {
        return isset($this->factories[strtolower($name)]);
    }

    public function setPos($name, $x, $y, $z, $level) {
        $key = strtolower($name);
        if (!isset($this->factories[$key])) return false;
        $this->factories[$key]["pos"]   = ["x" => (int)$x, "y" => (int)$y, "z" => (int)$z];
        $this->factories[$key]["level"] = $level;
        $this->saveAll();
        return true;
    }

    public function setStartTime($name, $seconds) {
        $key = strtolower($name);
        if (!isset($this->factories[$key])) return false;
        $this->factories[$key]["start_time"] = (int)$seconds;
        $this->saveAll();
        return true;
    }

    public function setDuration($name, $seconds) {
        $key = strtolower($name);
        if (!isset($this->factories[$key])) return false;
        $this->factories[$key]["duration"] = (int)$seconds;
        $this->saveAll();
        return true;
    }

    public function deleteFactory($name) {
        $key = strtolower($name);
        if (!isset($this->factories[$key])) return false;
        if (isset($this->active[$key])) {
            $this->despawnEntity($key);
            unset($this->active[$key]);
        }
        unset($this->factories[$key]);
        $this->saveAll();
        return true;
    }

    public function getAllFactories()   { return $this->factories; }
    public function getFactory($name)  { return $this->factories[strtolower($name)] ?? null; }
    public function isActive($name)    { return isset($this->active[strtolower($name)]); }
    public function getActiveData($name) { return $this->active[strtolower($name)] ?? null; }

    public function getAllActiveKeys() {
        return array_keys($this->active);
    }

    public function startFactory($key) {
        $key  = strtolower($key);
        $data = $this->factories[$key] ?? null;
        if ($data === null || $data["pos"] === null) return false;
        if (isset($this->active[$key])) return false;

        $fruitId = $this->rollFruit();
        if ($fruitId === null) return false;

        $maxHp = self::FACTORY_MAX_HP;

        $this->active[$key] = [
            "name"       => $data["name"],
            "fruit_id"   => $fruitId,
            "hp"         => $maxHp,
            "max_hp"     => $maxHp,
            "damage_log" => [],
            "entity"     => null,
            "pos"        => $data["pos"],
            "level"      => $data["level"],
            "duration"   => $data["duration"],
        ];

        unset($this->resolving[$key]);

        $fruitDisplay = $this->getFruitDisplay($fruitId);
        $fruitColor   = $this->getFruitColor($fruitId);
        $rarity       = $this->getFruitRarity($fruitId);

        $this->broadcast("§6§l[FACTORY BREACH] §r§eFactory Breaching has started at §f" . $data["name"] . "§e!");
        $this->broadcast("§7Top damage dealer wins the prize!");

        $this->spawnEntity($key);

        $plugin = $this->plugin;
        $plugin->getServer()->getScheduler()->scheduleDelayedTask(
            new FactoryExpireTask($plugin, $key),
            $data["duration"] * 20
        );

        return true;
    }

    public function recordDamage($key, $playerName, $damage) {
        if (!isset($this->active[$key])) return;
        if (isset($this->resolving[$key])) return;

        $this->active[$key]["hp"] = max(0, $this->active[$key]["hp"] - $damage);

        if (!isset($this->active[$key]["damage_log"][$playerName])) {
            $this->active[$key]["damage_log"][$playerName] = 0.0;
        }
        $this->active[$key]["damage_log"][$playerName] += $damage;

        // FIX: Instantly resolve the factory and give rewards the millisecond HP reaches 0
        if ($this->active[$key]["hp"] <= 0) {
            $this->resolveFactory($key);
        }
    }

    public function resolveFactory($key) {
        if (!isset($this->active[$key])) return;
        if (isset($this->resolving[$key])) return;

        $this->resolving[$key] = true;

        $active  = $this->active[$key];
        $log     = $active["damage_log"];
        $fruitId = $active["fruit_id"];

        $fruitDisplay = $this->getFruitDisplay($fruitId);
        $fruitColor   = $this->getFruitColor($fruitId);
        $rarity       = $this->getFruitRarity($fruitId);

        $this->despawnEntity($key);
        unset($this->active[$key]);
        unset($this->resolving[$key]);

        if (empty($log)) {
            $this->broadcast("§c§l[FACTORY] §r§cThe factory expired with no damage dealt. No reward given.");
            return;
        }

        arsort($log);
        $total   = array_sum($log);
        reset($log);
        $topName = key($log);
        $topDmg  = $log[$topName];

        $this->broadcast("§6§l[FACTORY BREACH] §r§eFactory destroyed!");
        $this->broadcast("§aWinner: §f" . $topName . " §a- " . number_format((int)$topDmg) . " damage");

        $rank = 1;
        foreach ($log as $pName => $dmg) {
            $pct   = $total > 0 ? round(($dmg / $total) * 100, 1) : 0;
            $color = $rank === 1 ? "§e" : ($rank === 2 ? "§7" : ($rank === 3 ? "§6" : "§8"));
            $this->broadcast($color . "#" . $rank . " §f" . $pName . " §7- " . number_format((int)$dmg) . " dmg §8(" . $pct . "%)");
            $participant = Server::getInstance()->getPlayerExact($pName);
            if ($participant !== null && $participant->isOnline()) {
                $participant->sendMessage("§6§l[FACTORY] §r§7Your contribution: §f" . number_format((int)$dmg) . " dmg §8(" . $pct . "%) §7- Rank §f#" . $rank);
            }
            if (++$rank > 5) break;
        }

        $winner = Server::getInstance()->getPlayerExact($topName);
        if ($winner !== null && $winner->isOnline()) {
            $this->deliverFruit($winner, $fruitId, $fruitDisplay, $fruitColor);
            \pocketmine\Server::getInstance()->getLogger()->info("[Factory Debug] Player " . $topName . " obtained fruit: " . $fruitId . " from factory: " . $active["name"]);
        } else {
            $this->broadcast("§c" . $topName . " was offline - the prize fruit was lost.");
        }
    }

    private function deliverFruit(Player $winner, $fruitId, $fruitDisplay, $fruitColor) {
        $berryPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceBerry");
        $devilPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");

        $item = \pocketmine\item\Item::get(\pocketmine\item\Item::GOLDEN_APPLE, 0, 1);
        $item->setCustomName($fruitColor . $fruitDisplay);
        $winner->getInventory()->addItem($item);
        $winner->sendMessage("§6§l[FACTORY] §r§aYou received a random devil fruit!");
    }

    private function spawnEntity($key) {
        $active    = $this->active[$key];
        $levelName = $active["level"];
        $pos       = $active["pos"];

        $server = Server::getInstance();
        if (!$server->isLevelLoaded($levelName)) $server->loadLevel($levelName);
        $level = $server->getLevelByName($levelName);
        if ($level === null) return;

        $nbt = new CompoundTag("", [
            new ListTag("Pos", [
                new DoubleTag("", (float)$pos["x"] + 0.5),
                new DoubleTag("", (float)$pos["y"]),
                new DoubleTag("", (float)$pos["z"] + 0.5),
            ]),
            new ListTag("Motion", [
                new DoubleTag("", 0.0),
                new DoubleTag("", 0.0),
                new DoubleTag("", 0.0),
            ]),
            new ListTag("Rotation", [
                new FloatTag("", 0.0),
                new FloatTag("", 0.0),
            ]),
            new ShortTag("Health", $active["max_hp"]),
            new ShortTag("MaxHealth", $active["max_hp"]),
            new StringTag("FactoryKey", $key),
        ]);

        $chunk  = $level->getChunk($pos["x"] >> 4, $pos["z"] >> 4, true);
        $entity = new FactoryEntity($chunk, $nbt);
        $entity->factoryKey = $key;
        $entity->spawnToAll();

        $this->active[$key]["entity"] = $entity;
    }

    public function despawnEntity($key) {
        if (!isset($this->active[$key])) return;
        $entity = $this->active[$key]["entity"] ?? null;
        if ($entity instanceof FactoryEntity && !$entity->closed) {
            $eid = $entity->getId();
            $level = $entity->getLevel();

            $pk      = new RemoveEntityPacket();
            $pk->eid = $eid;

            if ($level !== null) {
                foreach ($level->getPlayers() as $p) {
                    try { $p->dataPacket($pk); } catch (\Exception $e) {}
                }
            }
            foreach (Server::getInstance()->getOnlinePlayers() as $p) {
                try { $p->dataPacket($pk); } catch (\Exception $e) {}
            }

            $entity->despawnFromAll();
            $entity->close();
        }
        if (isset($this->active[$key])) {
            $this->active[$key]["entity"] = null;
        }
    }

    public function rollFruit() {
        $devilPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($devilPlugin === null || !$devilPlugin->isEnabled()) return null;

        $berryPlugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceBerry");
        $paused = [];
        if ($berryPlugin !== null && $berryPlugin->isEnabled()) {
            $paused = $berryPlugin->getPausedFruits();
        }

        $fm     = $devilPlugin->getFruitManager();
        $fruits = $fm->getAllFruits();

        $pool = [];
        foreach ($fruits as $id => $fruit) {
            if (in_array($id, $paused)) continue;
            $weight = self::RARITY_WEIGHTS[$fruit->getRarity()] ?? 1000;
            for ($i = 0; $i < $weight; $i++) {
                $pool[] = $id;
            }
        }

        return empty($pool) ? null : $pool[array_rand($pool)];
    }

    public function getFruitDisplay($fruitId) {
        $dp = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($dp === null) return $fruitId;
        $fruit = $dp->getFruitManager()->getFruit($fruitId);
        return $fruit !== null ? $fruit->getDisplayName() : $fruitId;
    }

    public function getFruitColor($fruitId) {
        $dp = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($dp === null) return "§f";
        $fruit = $dp->getFruitManager()->getFruit($fruitId);
        return $fruit !== null ? $fruit->getRarityColor() : "§f";
    }

    public function getFruitRarity($fruitId) {
        $dp = Server::getInstance()->getPluginManager()->getPlugin("OnePieceDevil");
        if ($dp === null) return "unknown";
        $fruit = $dp->getFruitManager()->getFruit($fruitId);
        return $fruit !== null ? $fruit->getRarity() : "unknown";
    }

    public function getHpBar($hp, $maxHp, $width = 20) {
        $ratio  = $maxHp > 0 ? max(0.0, min(1.0, $hp / $maxHp)) : 0.0;
        $filled = (int)round($ratio * $width);
        $empty  = $width - $filled;
        $color  = $ratio > 0.5 ? "§a" : ($ratio > 0.25 ? "§e" : "§c");
        return $color . str_repeat("█", $filled) . "§8" . str_repeat("█", $empty);
    }

    public function formatTime($seconds) {
        $h = floor($seconds / 3600);
        $m = floor(($seconds % 3600) / 60);
        $s = $seconds % 60;
        if ($h > 0) return "{$h}h {$m}m {$s}s";
        if ($m > 0) return "{$m}m {$s}s";
        return "{$s}s";
    }

    public function startSchedulers() {
        foreach ($this->factories as $key => $data) {
            if ($data["pos"] === null) continue;
            $this->scheduleFactory($key);
        }
    }

    public function scheduleFactory($key) {
        $data = $this->factories[$key] ?? null;
        if ($data === null || $data["pos"] === null) return;
        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask(
            new FactoryStartTask($this->plugin, $key),
            $data["start_time"] * 20
        );
    }

    private function broadcast($msg) {
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            $p->sendMessage($msg);
        }
    }
}