<?php

namespace OnePieceTrades\Factory;

use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\Player;
use OnePieceTrades\Main;

class FactoryListener implements Listener {

    private $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $plugin->getServer()->getPluginManager()->registerEvents($this, $plugin);
    }

    /**
     * @priority HIGH
     * @ignoreCancelled false
     */
    public function onEntityDamage(EntityDamageEvent $event) {
        $entity = $event->getEntity();
        if (!($entity instanceof FactoryEntity)) return;

        if ($event instanceof EntityDamageByEntityEvent) {
            $attacker = $event->getDamager();
            if (!($attacker instanceof Player)) {
                $event->setCancelled(true);
                return;
            }
            $entity->setLastAttacker($attacker->getName());
            $event->setCancelled(false);
            return;
        }

        $cause = $event->getCause();
        if ($cause === EntityDamageEvent::CAUSE_MAGIC ||
            $cause === EntityDamageEvent::CAUSE_FIRE ||
            $cause === EntityDamageEvent::CAUSE_ENTITY_EXPLOSION) {
            $event->setCancelled(false);
            return;
        }

        $event->setCancelled(true);
    }
}
