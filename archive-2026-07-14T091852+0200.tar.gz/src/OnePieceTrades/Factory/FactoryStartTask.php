<?php

namespace OnePieceTrades\Factory;

use pocketmine\scheduler\Task;
use OnePieceTrades\Main;

class FactoryStartTask extends Task {

    private $plugin;
    private $factoryKey;

    public function __construct(Main $plugin, $factoryKey) {
        $this->plugin     = $plugin;
        $this->factoryKey = $factoryKey;
    }

    public function onRun($currentTick) {
        $fm = $this->plugin->getFactoryManager();
        if ($fm->isActive($this->factoryKey)) return;
        $fm->startFactory($this->factoryKey);
        $fm->scheduleFactory($this->factoryKey);
    }
}
