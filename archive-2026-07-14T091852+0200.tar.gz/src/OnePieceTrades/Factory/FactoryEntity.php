<?php

namespace OnePieceTrades\Factory;

use pocketmine\entity\Entity;
use pocketmine\entity\Living;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\network\protocol\MoveEntityPacket;
use pocketmine\Player;
use pocketmine\Server;

class FactoryEntity extends Living {

    const NETWORK_ID      = 66;
    const DATA_BLOCK_INFO = 20;
    const BLOCK_ID        = 247;
    const BLOCK_DAMAGE    = 0;

    const IDX_NAMETAG      = 2;
    const IDX_SHOW_NAMETAG = 3;

    public $width  = 1.0;
    public $height = 1.0;

    public  $factoryKey;
    private $spawnX;
    private $spawnY;
    private $spawnZ;
    private $tickCount  = 0;
    private $lastAttackerName = null;

    public function __construct($chunk, $nbt) {
        parent::__construct($chunk, $nbt);
    }

    private function getFactoryManager() {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("OnePieceTrades");
        if ($plugin === null) return null;
        return $plugin->getFactoryManager();
    }

    public function getName() {
        return "Factory";
    }

    public function initEntity() {
        parent::initEntity();
        $maxHp = isset($this->namedtag->MaxHealth) ? (int)$this->namedtag->MaxHealth->getValue() : 1000;
        $this->setMaxHealth($maxHp);
        $this->setHealth($maxHp);

        if (isset($this->namedtag->FactoryKey)) {
            $this->factoryKey = $this->namedtag->FactoryKey->getValue();
        }

        $this->spawnX = $this->x;
        $this->spawnY = $this->y;
        $this->spawnZ = $this->z;
    }

    public function setLastAttacker($playerName) {
        $this->lastAttackerName = $playerName;
    }

    public function attack($damage, EntityDamageEvent $source) {
        if ($this->closed || !$this->isAlive()) return;

        $attackerName = null;

        if ($source instanceof EntityDamageByEntityEvent) {
            $raw = $source->getDamager();
            if ($raw instanceof Player) {
                $attackerName = $raw->getName();
                $this->lastAttackerName = $attackerName;
            }
        } elseif ($source->getCause() === EntityDamageEvent::CAUSE_MAGIC ||
                  $source->getCause() === EntityDamageEvent::CAUSE_FIRE ||
                  $source->getCause() === EntityDamageEvent::CAUSE_ENTITY_EXPLOSION) {
            $attackerName = $this->lastAttackerName;
        }

        if ($attackerName === null) return;

        $dm = $this->getFactoryManager();
        if ($dm === null || $this->factoryKey === null || !$dm->isActive($this->factoryKey)) return;

        $finalDamage = max(1, $source->getFinalDamage());
        $dm->recordDamage($this->factoryKey, $attackerName, $finalDamage);

        $newActive = $dm->getActiveData($this->factoryKey);
        if ($newActive === null) return;

        $bar = $dm->getHpBar($newActive["hp"], $newActive["max_hp"]);
        $attacker = Server::getInstance()->getPlayerExact($attackerName);
        if ($attacker !== null) {
            $attacker->sendTip("§6Factory §r" . $bar . " §f" . number_format((int)$newActive["hp"]) . "§7/§f" . number_format($newActive["max_hp"]));
        }

        foreach ($this->level->getPlayers() as $p) {
            $pct = $newActive["max_hp"] > 0 ? round(($newActive["hp"] / $newActive["max_hp"]) * 100, 1) : 0;
            $p->sendPopup("§6[FACTORY] §f" . number_format((int)$newActive["hp"]) . "§7/§f" . number_format($newActive["max_hp"]) . " §7(" . $pct . "%)");
        }

        $this->setHealth(max(0.5, $newActive["hp"]));
    }

    public function knockBack(Entity $attacker, $damage, $x, $z, $base = 0.4) {}

    private function broadcastPosition() {
        $pk        = new MoveEntityPacket();
        $pk->eid   = $this->getId();
        $pk->x     = $this->spawnX;
        $pk->y     = $this->spawnY;
        $pk->z     = $this->spawnZ;
        $pk->yaw   = 0.0;
        $pk->pitch = 0.0;
        $pk->headYaw = 0.0;
        foreach ($this->level->getPlayers() as $p) {
            try { $p->dataPacket($pk); } catch (\Exception $e) {}
        }
        $this->x = $this->spawnX;
        $this->y = $this->spawnY;
        $this->z = $this->spawnZ;
        $this->motionX = 0.0;
        $this->motionY = 0.0;
        $this->motionZ = 0.0;
    }

    private function buildNameTag() {
        if ($this->factoryKey === null) return "Factory Breach";
        $dm = $this->getFactoryManager();
        if ($dm === null || !$dm->isActive($this->factoryKey)) return "Factory Breach";
        $active = $dm->getActiveData($this->factoryKey);
        if ($active === null) return "Factory Breach";
        $bar = $dm->getHpBar($active["hp"], $active["max_hp"]);
        return "Factory Breach\n" . $bar . "\n§f" . number_format((int)$active["hp"]) . "§7/§f" . number_format($active["max_hp"]);
    }

    public function entityBaseTick($tickDiff = 1, $EnchantL = 0) {
        $hasUpdate = parent::entityBaseTick($tickDiff, $EnchantL);
        $this->tickCount += $tickDiff;
        if ($this->closed) return $hasUpdate;

        $this->broadcastPosition();

        if ($this->tickCount % 20 === 0) {
            if ($this->factoryKey === null) {
                $this->despawnFromAll(); $this->close();
                return $hasUpdate;
            }
            $dm = $this->getFactoryManager();
            if ($dm === null || !$dm->isActive($this->factoryKey)) {
                $this->despawnFromAll(); $this->close();
                return $hasUpdate;
            }
            $active = $dm->getActiveData($this->factoryKey);
            if ($active === null) {
                $this->despawnFromAll(); $this->close();
                return $hasUpdate;
            }

            $tag = $this->buildNameTag();
            $this->dataProperties[self::IDX_NAMETAG]      = [Entity::DATA_TYPE_STRING, $tag];
            $this->dataProperties[self::IDX_SHOW_NAMETAG] = [Entity::DATA_TYPE_BYTE, 1];
            $this->sendData($this->level->getPlayers());
        }

        return $hasUpdate;
    }

    public function getDrops() { return []; }
    public function getXpDropAmount() { return 0; }

    public function spawnTo(Player $player) {
        $tag = $this->buildNameTag();

        $pk           = new AddEntityPacket();
        $pk->eid      = $this->getId();
        $pk->type     = self::NETWORK_ID;
        $pk->x        = $this->spawnX ?? $this->x;
        $pk->y        = $this->spawnY ?? $this->y;
        $pk->z        = $this->spawnZ ?? $this->z;
        $pk->speedX   = 0.0;
        $pk->speedY   = 0.0;
        $pk->speedZ   = 0.0;
        $pk->yaw      = 0.0;
        $pk->pitch    = 0.0;
        $pk->metadata = [
            Entity::DATA_FLAGS     => [Entity::DATA_TYPE_BYTE,   0],
            self::DATA_BLOCK_INFO  => [Entity::DATA_TYPE_INT,    self::BLOCK_ID | (self::BLOCK_DAMAGE << 8)],
            Entity::DATA_NO_AI     => [Entity::DATA_TYPE_BYTE,   1],
            self::IDX_NAMETAG      => [Entity::DATA_TYPE_STRING, $tag],
            self::IDX_SHOW_NAMETAG => [Entity::DATA_TYPE_BYTE,   1],
        ];
        $player->dataPacket($pk);

        parent::spawnTo($player);
    }
}
