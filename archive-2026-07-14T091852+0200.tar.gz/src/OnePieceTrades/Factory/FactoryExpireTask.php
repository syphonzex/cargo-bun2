<?php

namespace OnePieceTrades\Factory;

use pocketmine\scheduler\Task;
use OnePieceTrades\Main;

class FactoryExpireTask extends Task {

    private $plugin;
    private $factoryKey;

    public function __construct(Main $plugin, $factoryKey) {
        $this->plugin     = $plugin;
        $this->factoryKey = $factoryKey;
    }

    public function onRun($currentTick) {
        $fm = $this->plugin->getFactoryManager();
        if (!$fm->isActive($this->factoryKey)) return;
        $fm->resolveFactory($this->factoryKey);
    }
}
