<?php

namespace OnePieceTrades;

use pocketmine\Player;
use pocketmine\level\Position;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\network\protocol\UpdateBlockPacket;
use pocketmine\network\protocol\BlockEntityDataPacket;
use pocketmine\network\protocol\ContainerOpenPacket;
use pocketmine\network\protocol\BlockEventPacket;
use pocketmine\inventory\BaseInventory;
use pocketmine\inventory\FakeBlockMenu;
use pocketmine\inventory\InventoryType;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class TradeInventory extends BaseInventory {

    public $customName;
    public $pos;
    public $owner;


    public function __construct(Player $player, $name = "Trade") {
        $this->customName = $name;
        $this->owner      = $player;
        $this->pos        = Position::fromObject($player->add(0, 2), $player->level);
        $this->holder     = new FakeBlockMenu($this, $this->pos);
        parent::__construct($this->holder, InventoryType::get(InventoryType::CHEST));
    }


    public function sendChestState(Player $player, $open = true) {
        $pk        = new BlockEventPacket();
        $pk->x     = (int)$this->pos->x;
        $pk->y     = (int)$this->pos->y;
        $pk->z     = (int)$this->pos->z;
        $pk->case1 = 1;
        $pk->case2 = $open ? 1 : 0;
        $player->dataPacket($pk);
    }

    public function onOpen(Player $who) {
        if (!$who->isOnline()) return;

        $pk            = new UpdateBlockPacket();
        $pk->x         = $this->pos->x;
        $pk->y         = $this->pos->y;
        $pk->z         = $this->pos->z;
        $pk->blockId   = 54;
        $pk->blockData = 0;
        $pk->flags     = UpdateBlockPacket::FLAG_ALL;
        $who->dataPacket($pk);

        $compound             = new CompoundTag();
        $compound->id         = new StringTag("id", "Chest");
        $compound->CustomName = new StringTag("CustomName", $this->customName);
        $compound->x          = new IntTag("x", (int)$this->pos->x);
        $compound->y          = new IntTag("y", (int)$this->pos->y);
        $compound->z          = new IntTag("z", (int)$this->pos->z);

        $nbt = new NBT(NBT::LITTLE_ENDIAN);
        $nbt->setData($compound);

        $pk           = new BlockEntityDataPacket();
        $pk->x        = $this->pos->x;
        $pk->y        = $this->pos->y;
        $pk->z        = $this->pos->z;
        $pk->namedtag = $nbt->write();
        $who->dataPacket($pk);

        parent::onOpen($who);

        $inventory = $this;
        Server::getInstance()->getScheduler()->scheduleDelayedTask(new class($who, $inventory) extends Task {
            private $player;
            private $inventory;
            public function __construct(Player $p, $inv) { $this->player = $p; $this->inventory = $inv; }
            public function onRun($currentTick) {
                if (!$this->player->isOnline()) return;
                $this->inventory->sendChestState($this->player, true);

                $pk           = new ContainerOpenPacket();
                $pk->windowid = $this->player->getWindowId($this->inventory);
                $pk->type     = $this->inventory->getType()->getNetworkType();
                $pk->slots    = $this->inventory->getSize();
                $pk->x        = (int)$this->inventory->pos->x;
                $pk->y        = (int)$this->inventory->pos->y;
                $pk->z        = (int)$this->inventory->pos->z;
                $this->player->dataPacket($pk);
                $this->inventory->sendContents($this->player);
            }
        }, 4);
    }

    public function onClose(Player $who) {
        if (!$who->isOnline()) return;

        $this->sendChestState($who, false);

        $pk            = new UpdateBlockPacket();
        $pk->x         = $this->pos->x;
        $pk->y         = $this->pos->y;
        $pk->z         = $this->pos->z;
        $pk->blockId   = $who->getLevel()->getBlockIdAt($this->pos->x, $this->pos->y, $this->pos->z);
        $pk->blockData = $who->getLevel()->getBlockDataAt($this->pos->x, $this->pos->y, $this->pos->z);
        $pk->flags     = UpdateBlockPacket::FLAG_ALL;
        $who->dataPacket($pk);

        parent::onClose($who);
    }

    public function sendContents($target) {
        if ($this->owner !== null && $target instanceof Player && $target->getName() === $this->owner->getName()) {
            parent::sendContents($target);
        }
    }
}
