<?php

namespace OnePieceTrades;

use pocketmine\utils\Config;

class TradeManager {

    private $plugin;
    private $config;
    private $stations = [];
    private $lastCreated = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->config = new Config($plugin->getDataFolder() . "stations.yml", Config::YAML);
        $this->stations = $this->config->getAll();
    }

    public function saveAll() {
        $this->config->setAll($this->stations);
        $this->config->save();
    }

    public function createStation($name) {
        $key = strtolower($name);
        $this->stations[$key] = [
            "name" => $name,
            "seat1" => null,
            "seat2" => null
        ];
        $this->saveAll();
    }

    public function stationExists($name) {
        return isset($this->stations[strtolower($name)]);
    }

    public function deleteStation($name) {
        $key = strtolower($name);
        unset($this->stations[$key]);
        $this->saveAll();
    }

    public function renameStation($oldName, $newName) {
        $oldKey = strtolower($oldName);
        $newKey = strtolower($newName);
        if (!isset($this->stations[$oldKey])) return;

        $data = $this->stations[$oldKey];
        $data["name"] = $newName;
        unset($this->stations[$oldKey]);
        $this->stations[$newKey] = $data;
        $this->saveAll();
    }

    public function setSeat($stationName, $seatNum, $pos) {
        $key = strtolower($stationName);
        if (!isset($this->stations[$key])) return;
        $this->stations[$key]["seat" . $seatNum] = $pos;
        $this->saveAll();
    }

    public function getStation($name) {
        $key = strtolower($name);
        return $this->stations[$key] ?? null;
    }

    public function getAllStations() {
        return $this->stations;
    }

    public function getStationBySeat($x, $y, $z, $level) {
        foreach ($this->stations as $key => $data) {
            for ($s = 1; $s <= 2; $s++) {
                $seat = $data["seat" . $s];
                if ($seat === null) continue;
                if ((int)$seat["x"] === $x && (int)$seat["y"] === $y && (int)$seat["z"] === $z && $seat["level"] === $level) {
                    return [
                        "name" => $data["name"],
                        "key" => $key,
                        "seat" => $s
                    ];
                }
            }
        }
        return null;
    }

    public function getLastCreatedBy($playerName) {
        $last = null;
        foreach ($this->stations as $key => $data) {
            $last = $data["name"];
        }
        return $last;
    }
}