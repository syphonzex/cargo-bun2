<?php

namespace OnePieceTrades;

use pocketmine\Player;
use pocketmine\item\Item;
use pocketmine\event\Listener;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\inventory\InventoryCloseEvent;
use pocketmine\event\player\PlayerQuitEvent;

class TradeGUIListener implements Listener {

    private $plugin;
    private static $windows = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public static function getWindow(Player $player) {
        return self::$windows[strtolower($player->getName())] ?? null;
    }

    public static function setWindow(Player $player, $data) {
        self::$windows[strtolower($player->getName())] = $data;
    }

    public static function removeWindow(Player $player) {
        unset(self::$windows[strtolower($player->getName())]);
    }

    public function onTransaction(InventoryTransactionEvent $event) {
        $transaction = $event->getTransaction();
        $player = $transaction->getPlayer();
        if (!($player instanceof Player)) return;

        $window = self::getWindow($player);
        if ($window === null) return;

        $inventory = $window["inventory"];
        if (!($inventory instanceof TradeInventory)) return;

        $clickedSlot = -1;

        foreach ($transaction->getTransactions() as $trans) {
            if ($trans->getInventory() instanceof TradeInventory) {
                $clickedSlot = $trans->getSlot();
                break;
            }
        }

        if ($clickedSlot < 0) return;

        $event->setCancelled(true);
        $player->getFloatingInventory()->clearAll();
        $player->getInventory()->sendContents($player);
        $inventory->sendContents($player);

        if ($window["type"] === "trade") {
            $this->handleTradeClick($player, $clickedSlot);
        } elseif ($window["type"] === "storage_picker") {
            $this->handleStoragePickerClick($player, $clickedSlot, $window["target_slot"]);
        }
    }

    private function handleTradeClick(Player $player, $slot) {
        $name = strtolower($player->getName());
        $sessions = $this->plugin->getTradeSessions();
        if (!isset($sessions[$name])) return;

        if ($slot === 26) {
            $this->plugin->cancelTradeByPlayer($player);
            return;
        }

        if ($slot === 12) {
            $confirm = $this->plugin->getTradeConfirm();
            if (!($confirm[$name] ?? false)) {
                $this->plugin->handleTradeConfirm($player);
            }
            return;
        }

        $myOfferSlots = [1, 2];

        if ($slot === 3 || in_array($slot, $myOfferSlots)) {
            $targetSlot = 0;
            if (in_array($slot, $myOfferSlots)) {
                $slotIndex = array_search($slot, $myOfferSlots);
                $tradeItems = $this->plugin->getTradeItems();
                $myItems = $tradeItems[$name] ?? [];

                if (isset($myItems[$slotIndex]) && $myItems[$slotIndex]->getId() !== Item::AIR) {
                    $this->handleFruitSlotRemove($player, $slotIndex);
                    return;
                }
                $targetSlot = $slotIndex;
            }

            $window = self::getWindow($player);
            $player->removeWindow($window["inventory"]);
            $plugin = $this->plugin;
            $this->plugin->scheduleTask(function() use ($plugin, $player, $targetSlot) {
                if ($player->isOnline()) {
                    $plugin->openStoragePickerMenu($player, $targetSlot);
                }
            }, 5);
        }
    }

    private function handleFruitSlotRemove(Player $player, $slotIndex) {
        $name = strtolower($player->getName());
        $tradeItems = $this->plugin->getTradeItems();
        $currentItems = isset($tradeItems[$name]) ? $tradeItems[$name] : [];

        if (!isset($currentItems[$slotIndex]) || $currentItems[$slotIndex]->getId() === Item::AIR) return;

        $returning = clone $currentItems[$slotIndex];
        $sourceTag = $returning->getNamedTagEntry("trade_source");
        $fruitTag  = $returning->getNamedTagEntry("trade_fruit_id");

        if ($sourceTag !== null && $fruitTag !== null) {
            $source  = $sourceTag->getValue();
            $fruitId = $fruitTag->getValue();

            if (strpos($source, "storage:") === 0) {
                $berryPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceBerry");
                if ($berryPlugin !== null) {
                    $berryPlugin->getFruitStorage()->addFruit($player->getName(), $fruitId);
                    $this->plugin->tradeDebug($player->getName() . " RETURNED fruit '" . $fruitId . "' to storage");
                }
            }
        }

        unset($currentItems[$slotIndex]);
        $this->updateTradeItems($name, $currentItems);
        $this->resetConfirms($player);
        $this->plugin->refreshOwnMenu($player);
        $this->plugin->refreshPartnerMenu($player);
        $fIdDbg = ($fruitTag !== null) ? $fruitTag->getValue() : "unknown";
        $srcDbg = ($sourceTag !== null) ? $sourceTag->getValue() : "unknown";
        $this->plugin->tradeDebug($player->getName() . " REMOVED fruit '" . $fIdDbg . "' from slot " . ($slotIndex + 1) . " (returned to: " . $srcDbg . ")");
        $player->sendMessage($this->plugin->getPrefix() . "§eFruit removed from trade slot.");
    }

    private function handleStoragePickerClick(Player $player, $slot, $targetSlotIndex) {
        $name = strtolower($player->getName());

        if ($slot === 26) {
            $window = self::getWindow($player);
            $player->removeWindow($window["inventory"]);
            $plugin = $this->plugin;
            $this->plugin->scheduleTask(function() use ($plugin, $player) {
                if ($player->isOnline()) $plugin->openTradeMenu($player);
            }, 5);
            return;
        }

        if ($slot < 9 || $slot > 25) return;

        $window    = self::getWindow($player);
        $inventory = $window["inventory"];
        $clickedItem = $inventory->getItem($slot);

        if ($clickedItem->getId() === Item::AIR) return;
        if ($clickedItem->getId() === 102 || $clickedItem->getId() === Item::IRON_BARS) return;

        $customName = $clickedItem->getCustomName();
        $storageSlotMatch = [];
        preg_match('/\[Storage Slot (\d+)\]/', $customName, $storageSlotMatch);
        if (empty($storageSlotMatch)) return;

        $storageSlotNum = (int)$storageSlotMatch[1] - 1;

        $devilPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceDevil");
        $berryPlugin = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceBerry");

        $fruitId = null;
        $source  = null;

        if ($berryPlugin !== null && $berryPlugin->isEnabled()) {
            $fs = $berryPlugin->getFruitStorage();
            $storedFruits = $fs->getStorage($player->getName());
            if (isset($storedFruits[$storageSlotNum])) {
                $fruitId = $storedFruits[$storageSlotNum];
                $source  = "storage:" . $fruitId;
                $fs->removeFruit($player->getName(), $storageSlotNum);
                $this->plugin->tradeDebug($player->getName() . " WITHDREW fruit '" . $fruitId . "' from storage slot " . $storageSlotNum);
            }
        }

        if ($fruitId === null) {
            $player->sendMessage($this->plugin->getPrefix() . "§cCould not retrieve fruit from storage.");
            return;
        }

        $sessions    = $this->plugin->getTradeSessions();
        $partnerName = isset($sessions[$name]) ? $sessions[$name]["partner"] : null;

        if ($partnerName !== null) {
            $berryPluginCheck = $this->plugin->getServer()->getPluginManager()->getPlugin("OnePieceBerry");
            if ($berryPluginCheck !== null && $berryPluginCheck->isEnabled()) {
                $partnerFs = $berryPluginCheck->getFruitStorage();
                if (!$partnerFs->hasSpace($partnerName)) {
                    $berryPluginCheck->getFruitStorage()->addFruit($player->getName(), $fruitId);
                    $player->removeWindow($window["inventory"]);
                    $partner = $this->plugin->getServer()->getPlayerExact($partnerName);
                    $this->plugin->tradeDebug("CANCEL: " . $partnerName . " has full storage, fruit '" . $fruitId . "' returned to " . $player->getName());
                    $msg = $this->plugin->getPrefix() . "§cTrade cancelled: §e" . ($partner !== null ? $partner->getName() : $partnerName) . " §chas a full fruit storage. Ask them to withdraw a fruit first.";
                    $player->sendMessage($msg);
                    $plugin = $this->plugin;
                    $this->plugin->scheduleTask(function() use ($plugin, $player, $partner, $msg) {
                        $plugin->cancelTradeByPlayer($player);
                    }, 2);
                    return;
                }
            }
        }

        $display = $fruitId;
        $color   = "§f";
        if ($devilPlugin !== null) {
            $fruit = $devilPlugin->getFruitManager()->getFruit($fruitId);
            if ($fruit !== null) {
                $display = $fruit->getDisplayName();
                $color   = $fruit->getRarityColor();
            }
        }

        $tradeItem = Item::get(Item::GOLDEN_APPLE, 0, 1);
        $tradeItem->setCustomName($color . $display);

        $nbt = $tradeItem->getNamedTag();
        $nbt->trade_source   = new \pocketmine\nbt\tag\StringTag("trade_source", $source);
        $nbt->trade_fruit_id = new \pocketmine\nbt\tag\StringTag("trade_fruit_id", $fruitId);
        $tradeItem->setNamedTag($nbt);

        $tradeItems    = $this->plugin->getTradeItems();
        $currentItems  = isset($tradeItems[$name]) ? $tradeItems[$name] : [];
        $currentItems[$targetSlotIndex] = $tradeItem;
        $this->updateTradeItems($name, $currentItems);
        $this->resetConfirms($player);

        $this->plugin->tradeDebug($player->getName() . " PLACED fruit '" . $fruitId . "' in trade slot " . ($targetSlotIndex + 1) . " (source: " . $source . ")");
        $player->sendMessage($this->plugin->getPrefix() . "§a" . $display . " §aplaced in trade slot " . ($targetSlotIndex + 1) . ".");

        $player->removeWindow($window["inventory"]);
        $plugin = $this->plugin;
        $this->plugin->scheduleTask(function() use ($plugin, $player) {
            if ($player->isOnline()) {
                $plugin->openTradeMenu($player);
                $plugin->refreshPartnerMenu($player);
            }
        }, 5);
    }

    private function updateTradeItems($name, $items) {
        $ref = new \ReflectionProperty($this->plugin, 'tradeItems');
        $ref->setAccessible(true);
        $allItems = $ref->getValue($this->plugin);
        $allItems[$name] = $items;
        $ref->setValue($this->plugin, $allItems);
    }

    private function resetConfirms(Player $player) {
        $name     = strtolower($player->getName());
        $sessions = $this->plugin->getTradeSessions();
        if (!isset($sessions[$name])) return;

        $partnerName = $sessions[$name]["partner"];

        $ref = new \ReflectionProperty($this->plugin, 'tradeConfirm');
        $ref->setAccessible(true);
        $confirms = $ref->getValue($this->plugin);
        $confirms[$name]        = false;
        $confirms[$partnerName] = false;
        $ref->setValue($this->plugin, $confirms);
    }

    public function onClose(InventoryCloseEvent $event) {
        $player    = $event->getPlayer();
        $inventory = $event->getInventory();

        if (!($inventory instanceof TradeInventory)) return;

        $window = self::getWindow($player);
        if ($window === null || $window["inventory"] !== $inventory) return;

        $plugin = $this->plugin;
        $type   = $window["type"];

        $this->plugin->scheduleTask(function() use ($plugin, $player, $type) {
            if (!$player->isOnline()) return;
            if ($plugin->isSuppressReopen($player)) return;
            $sessions = $plugin->getTradeSessions();
            $name = strtolower($player->getName());
            if (isset($sessions[$name])) {
                $plugin->openTradeMenu($player);
            }
        }, 5);
    }

    public function onQuit(PlayerQuitEvent $event) {
        self::removeWindow($event->getPlayer());
    }
}